"""What one OCR call returns — the same shape in Python, on the CLI and in JavaScript.

:class:`OCRResult` wraps the Document IR (the truth) with the service's verdict
on it (``status``, ``review_required`` per page) and the projections a caller
usually wants: Markdown, reading-order text, layout text and a flat list of
lines with their confidence and box. Every projection is computed from the IR on
demand, deterministically; none of them is a source of truth (hard rule 4) — a
program that must know *how sure* the engine is about a value reads
:attr:`OCRResult.lines` or the IR, not the text.
"""

from collections.abc import Iterable
from dataclasses import dataclass, field
from functools import cached_property
from typing import Any

from titanocr.ir import BlockType, DocumentIR
from titanocr.render_md import RenderOptions, ir_to_markdown
from titanocr.render_md.text import ir_to_layout_text, ir_to_text

OUTPUTS = ("text", "layout_text", "markdown", "spatial_markdown", "lines", "ir")
"""Everything :meth:`OCRResult.to_dict` can include."""

_CLEAN_MARKDOWN = RenderOptions(block_geometry=False)
_NO_TEXT = frozenset({BlockType.connector, BlockType.rule})


@dataclass(frozen=True)
class OCRLine:
    """One recognised line: its text, how sure the engine is, and where it is."""

    page: int
    text: str
    confidence: float
    bbox: tuple[float, float, float, float]
    """Page-space pixels of the prepared page (origin top-left), as in the IR."""
    origin: str
    """``digital`` (PDF text layer, exact), ``ocr`` or ``vlm``."""
    block_id: str
    block_type: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "page": self.page,
            "text": self.text,
            "confidence": self.confidence,
            "bbox": list(self.bbox),
            "origin": self.origin,
            "block_id": self.block_id,
            "block_type": self.block_type,
        }


@dataclass(frozen=True)
class OCRResult:
    """One processed document."""

    ir: DocumentIR
    status: str
    """``done``, or ``partial`` when some pages failed (named in :attr:`pages`)."""
    pages: tuple[dict[str, Any], ...] = field(default=())
    """Per-page verdicts from the service: ``status``, ``route``, ``triage``,
    ``trigger``, ``review_required``, ``reason``."""
    degraded: bool = False

    @property
    def review_required(self) -> bool:
        """True when any page's content is below the confidence thresholds.

        Such content is still returned, but it is **flagged, not certain**
        (hard rule 12): check it before acting on it.
        """
        return any(bool(page.get("review_required")) for page in self.pages)

    @cached_property
    def markdown(self) -> str:
        """Markdown with headings, lists and tables; no geometry comments."""
        return ir_to_markdown(self.ir, _CLEAN_MARKDOWN)

    @cached_property
    def spatial_markdown(self) -> str:
        """The stored-artifact Markdown: every block annotated with its location,
        source lines and confidence in HTML comments (docs/10)."""
        return ir_to_markdown(self.ir)

    @cached_property
    def text(self) -> str:
        """The words in reading order; table rows as cells joined by `` | ``."""
        return ir_to_text(self.ir)

    @cached_property
    def layout_text(self) -> str:
        """Every line on its visual row and column (like ``pdftotext -layout``):
        a table-shaped page keeps each row — a test, its value, unit and range —
        on one line."""
        return ir_to_layout_text(self.ir)

    @cached_property
    def lines(self) -> tuple[OCRLine, ...]:
        """Every non-empty line in reading order, with confidence and bbox."""
        out: list[OCRLine] = []
        for page in self.ir.pages:
            for block in sorted(page.blocks, key=lambda b: b.reading_order):
                if block.type in _NO_TEXT:
                    continue
                ordered = sorted(
                    block.lines or (), key=lambda ln: ((ln.bbox[1] + ln.bbox[3]) / 2, ln.bbox[0])
                )
                out.extend(
                    OCRLine(
                        page=page.page_no,
                        text=line.text,
                        confidence=line.confidence,
                        bbox=line.bbox,
                        origin=line.origin.value,
                        block_id=block.block_id,
                        block_type=block.type.value,
                    )
                    for line in ordered
                    if line.text.strip()
                )
        return tuple(out)

    def to_dict(self, outputs: Iterable[str] = OUTPUTS) -> dict[str, Any]:
        """A JSON-ready dict (what the CLI's ``--format json`` and the JS package get)."""
        wanted = set(outputs)
        unknown = wanted - set(OUTPUTS)
        if unknown:
            raise ValueError(f"unknown output(s) {sorted(unknown)} — choose from {OUTPUTS}")
        out: dict[str, Any] = {
            "doc_id": str(self.ir.doc_id),
            "status": self.status,
            "review_required": self.review_required,
            "degraded": self.degraded,
            "page_count": self.ir.page_count,
            "pages": list(self.pages),
        }
        if "text" in wanted:
            out["text"] = self.text
        if "layout_text" in wanted:
            out["layout_text"] = self.layout_text
        if "markdown" in wanted:
            out["markdown"] = self.markdown
        if "spatial_markdown" in wanted:
            out["spatial_markdown"] = self.spatial_markdown
        if "lines" in wanted:
            out["lines"] = [line.to_dict() for line in self.lines]
        if "ir" in wanted:
            out["ir"] = self.ir.model_dump(mode="json")
        return out

    @classmethod
    def from_service(cls, status: dict[str, Any], ir: dict[str, Any]) -> "OCRResult":
        """Build from the service's status document and IR JSON."""
        pages = tuple(
            {
                key: page.get(key)
                for key in ("page_no", "status", "route", "triage", "trigger", "review_required")
            }
            | {"reason": page.get("reason")}
            for page in status.get("pages", [])
        )
        return cls(
            ir=DocumentIR.model_validate(ir),
            status=str(status["status"]),
            pages=pages,
            degraded=bool(status.get("degraded")),
        )


__all__ = ["OUTPUTS", "OCRLine", "OCRResult"]
