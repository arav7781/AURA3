"""Spawn-based worker pool: pre-fork, pin, warm up, gate readiness (docs/07).

The pool wraps a ``ProcessPoolExecutor(mp_context=spawn)`` whose initializer is
:func:`titanocr.api.worker.worker_init` — env pinning happens there, before
the heavy imports (belt) *and* the same vars are exported here in the parent
before the executor exists, so spawn children inherit them from their very
first instruction (braces). A ``multiprocessing.Queue`` carries worker events;
a daemon thread drains it and folds per-page stage updates into the job table
via ``run_coroutine_threadsafe`` — status polling picks them up (ADR 0003 #2).

Failure isolation (docs/07): a worker death breaks the whole executor
(``BrokenProcessPool`` is how ``ProcessPoolExecutor`` reports any abrupt worker
exit), so :meth:`WorkerPool.run_page` converts that into :class:`WorkerCrashed`
for the affected page and **recreates the executor once** — first caller in
wins, concurrent losers see the fresh executor and skip. The pod survives; the
page is the blast radius. ``/readyz`` re-gates (503) while replacement workers
warm — honest, a cold pool is not ready.
"""

import asyncio
import functools
import logging
import multiprocessing
import os
import queue as queue_mod
import threading
from concurrent.futures import Future, ProcessPoolExecutor
from concurrent.futures.process import BrokenProcessPool
from pathlib import Path
from typing import Any

from titanocr.api.jobs import JobManager, UnknownDocumentError
from titanocr.api.worker import (
    PAGE_EVENT,
    PIN_VARS,
    READY_EVENT,
    DigitalLayoutResult,
    DigitalRegionsResult,
    WorkerPageResult,
    run_digital_layout,
    run_digital_regions,
    run_page,
    worker_init,
    worker_probe,
    worker_touch,
)

logger = logging.getLogger("titanocr.pool")

_DRAIN_POLL_S = 0.2


class WorkerCrashed(Exception):
    """The worker executing this page died; the page is failed, the pool recovers."""


class WorkerPool:
    def __init__(
        self,
        *,
        workers: int,
        pipeline_dir: Path,
        models_dir: Path,
        artifacts_dir: Path,
        fixtures_dir: Path,
        jobs: JobManager,
    ) -> None:
        self.workers = workers
        self._initargs = (
            str(pipeline_dir),
            str(models_dir),
            str(artifacts_dir),
            str(fixtures_dir),
        )
        self._jobs = jobs
        self._ctx = multiprocessing.get_context("spawn")
        self._queue: Any = None
        self._executor: ProcessPoolExecutor | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._drain_thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._ready_pids: set[int] = set()
        self._warmup_failures: dict[int, str] = {}
        self._recreate_lock: asyncio.Lock = asyncio.Lock()
        self._crash_count = 0
        self._last_error: str | None = None

    # -- lifecycle ---------------------------------------------------------------

    def start(self) -> None:
        """Create the executor and force every worker to spawn and warm up now
        (pre-fork, docs/07 — never per request). Returns immediately; readiness
        arrives asynchronously via the progress queue."""
        self._loop = asyncio.get_running_loop()
        # Braces to worker_init's belt: exported before any child exists, so the
        # env is pinned from the child's first instruction (docs/07 arithmetic).
        for var in PIN_VARS:
            os.environ[var] = "1"
        self._queue = self._ctx.Queue()
        self._drain_thread = threading.Thread(
            target=self._drain, name="pool-progress-drain", daemon=True
        )
        self._drain_thread.start()
        self._executor = self._make_executor()
        logger.info("worker pool starting", extra={"workers": self.workers})

    def _make_executor(self) -> ProcessPoolExecutor:
        executor = ProcessPoolExecutor(
            max_workers=self.workers,
            mp_context=self._ctx,
            initializer=worker_init,
            initargs=(*self._initargs, self._queue),
        )
        # Force-spawn: each submit sees no idle worker (initializers are busy
        # warming) and spawns a new process, so all N exist before any traffic.
        for _ in range(self.workers):
            executor.submit(worker_touch).add_done_callback(self._note_spawn_result)
        return executor

    def _note_spawn_result(self, future: Future[int]) -> None:
        if future.cancelled():
            return
        exc = future.exception()
        if exc is not None:
            with self._lock:
                self._last_error = f"worker failed to start: {type(exc).__name__}: {exc}"
            logger.error("worker failed to start", extra={"error": str(exc)})
        else:
            # A successful spawn after a recreate clears the stale failure.
            with self._lock:
                self._last_error = None

    async def shutdown(self) -> None:
        """Graceful stop: callers have already drained their futures; remaining
        (crashed-doc) stragglers are cancelled, workers joined, thread stopped."""
        executor = self._executor
        self._executor = None
        if executor is not None:
            await asyncio.to_thread(executor.shutdown, True, cancel_futures=True)
        self._stop.set()
        if self._drain_thread is not None:
            self._drain_thread.join(timeout=5.0)
            self._drain_thread = None
        logger.info("worker pool stopped", extra={"crashes": self._crash_count})

    # -- readiness ---------------------------------------------------------------

    @property
    def ready_count(self) -> int:
        with self._lock:
            return len(self._ready_pids)

    @property
    def ready(self) -> bool:
        return self._executor is not None and self.ready_count >= self.workers

    @property
    def worker_pids(self) -> tuple[int, ...]:
        """PIDs of currently-warm workers (from their ready events)."""
        with self._lock:
            return tuple(sorted(self._ready_pids))

    @property
    def warmup_failures(self) -> dict[int, str]:
        """``pid → reason`` for workers whose warm-up inference failed (§4.3).

        A worker that cannot warm still answers (its sessions would load on the
        first page), but the pod is not ready: readiness reports the reason so
        an operator never has to read logs to learn what is missing."""
        with self._lock:
            return dict(self._warmup_failures)

    @property
    def crash_count(self) -> int:
        return self._crash_count

    @property
    def last_error(self) -> str | None:
        with self._lock:
            return self._last_error

    # -- work --------------------------------------------------------------------

    async def run_page(
        self,
        doc_id: str,
        page_no: int,
        source_path: Path,
        kind: str,
        pipeline_version: str,
        deadline_monotonic: float | None,
    ) -> WorkerPageResult:
        """Run one page in a worker. Raises :class:`WorkerCrashed` if the worker
        died mid-page (after arranging pool recovery)."""
        call = functools.partial(
            run_page,
            doc_id,
            page_no,
            str(source_path),
            kind,
            pipeline_version,
            deadline_monotonic,
        )
        executor = self._executor
        if executor is None:
            raise WorkerCrashed("worker pool is not running")
        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(executor, call)
        except BrokenProcessPool as exc:
            self._crash_count += 1
            logger.error(
                "worker crashed mid-page — recreating pool",
                extra={"doc_id": doc_id, "page_no": page_no, "crashes": self._crash_count},
            )
            await self._recreate(executor)
            raise WorkerCrashed(f"worker process died while processing page {page_no}") from exc

    async def run_digital_layout(
        self,
        doc_id: str,
        page_no: int,
        png_path: Path,
        lines: tuple[Any, ...],
        pipeline_version: str,
        deadline_monotonic: float | None,
    ) -> DigitalLayoutResult:
        """Type one born-digital page's regions in a worker (phase 19, ADR 0017).

        Unlike :meth:`run_page`, a crash here is **not** a page failure: region
        typing is an enhancement to a route that already has exact text, so the
        pool is recovered and the caller keeps its untyped grouping.
        """
        call = functools.partial(
            run_digital_layout,
            doc_id,
            page_no,
            str(png_path),
            lines,
            pipeline_version,
            deadline_monotonic,
        )
        executor = self._executor
        if executor is None:
            return DigitalLayoutResult(
                page_no=page_no, blocks=(), provenance=(), failure_reason="worker pool not running"
            )
        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(executor, call)
        except BrokenProcessPool as exc:
            self._crash_count += 1
            logger.error(
                "worker crashed during digital layout — recreating pool",
                extra={"doc_id": doc_id, "page_no": page_no, "crashes": self._crash_count},
            )
            await self._recreate(executor)
            return DigitalLayoutResult(
                page_no=page_no,
                blocks=(),
                provenance=(),
                failure_reason=f"worker died during layout: {exc}",
            )

    async def run_digital_regions(
        self,
        doc_id: str,
        page_no: int,
        png_path: Path,
        regions: tuple[tuple[float, float, float, float], ...],
        pipeline_version: str,
        deadline_monotonic: float | None,
    ) -> DigitalRegionsResult:
        """OCR one born-digital page's raster regions in a worker (phase 23, ADR 0020).

        Like :meth:`run_digital_layout`, a crash here is **not** a page failure:
        the page already has its exact text, so the pool is recovered and the
        caller keeps every region as a figure.
        """
        call = functools.partial(
            run_digital_regions,
            doc_id,
            page_no,
            str(png_path),
            regions,
            pipeline_version,
            deadline_monotonic,
        )
        empty: tuple[tuple[Any, ...], ...] = tuple(() for _ in regions)
        executor = self._executor
        if executor is None:
            return DigitalRegionsResult(
                page_no=page_no,
                lines=empty,
                provenance=(),
                failure_reason="worker pool not running",
            )
        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(executor, call)
        except BrokenProcessPool as exc:
            self._crash_count += 1
            logger.error(
                "worker crashed during region OCR — recreating pool",
                extra={"doc_id": doc_id, "page_no": page_no, "crashes": self._crash_count},
            )
            await self._recreate(executor)
            return DigitalRegionsResult(
                page_no=page_no,
                lines=empty,
                provenance=(),
                failure_reason=f"worker died during region OCR: {exc}",
            )

    async def probe(self) -> dict[str, Any]:
        """Pinning/RSS probe from one live worker (tests + phase-log evidence)."""
        executor = self._executor
        if executor is None:
            raise WorkerCrashed("worker pool is not running")
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(executor, worker_probe)

    async def _recreate(self, broken: ProcessPoolExecutor) -> None:
        """Replace a broken executor exactly once; concurrent losers no-op."""
        async with self._recreate_lock:
            if self._executor is not broken:
                return  # someone else already swapped it
            with self._lock:
                self._ready_pids.clear()  # /readyz drops to 503 while replacements warm
                self._warmup_failures.clear()
            broken.shutdown(wait=False, cancel_futures=True)
            self._executor = self._make_executor()
            logger.warning("worker pool recreated", extra={"crashes": self._crash_count})

    # -- progress drain (worker → job table) --------------------------------------

    def _drain(self) -> None:
        while not self._stop.is_set():
            try:
                event = self._queue.get(timeout=_DRAIN_POLL_S)
            except queue_mod.Empty:
                continue
            except (EOFError, OSError):
                return  # queue torn down during shutdown
            try:
                self._handle_event(event)
            except Exception:
                logger.exception("bad worker event", extra={"event": repr(event)})

    def _handle_event(self, event: tuple[Any, ...]) -> None:
        kind = event[0]
        if kind == READY_EVENT:
            _, pid, warmup_ms, pinned, warmup_error = event
            with self._lock:
                self._ready_pids.add(int(pid))
                ready = len(self._ready_pids)
                if warmup_error:
                    self._warmup_failures[int(pid)] = str(warmup_error)
                else:
                    self._warmup_failures.pop(int(pid), None)
            logger.info(
                "worker ready",
                extra={
                    "pid": pid,
                    "warmup_ms": round(float(warmup_ms), 1),
                    "pinned_before_import": bool(pinned),
                    "warmup_error": warmup_error,
                    "ready": f"{ready}/{self.workers}",
                },
            )
        elif kind == PAGE_EVENT:
            _, doc_id, page_no, stage = event
            loop = self._loop
            if loop is not None and loop.is_running():
                asyncio.run_coroutine_threadsafe(
                    self._note_page_stage(str(doc_id), int(page_no), str(stage)), loop
                )

    async def _note_page_stage(self, doc_id: str, page_no: int, stage: str) -> None:
        """Live-progress fold: only touches pages still in flight (a late event
        must never resurrect a stage chip on a settled page)."""
        try:
            await self._jobs.note_page_stage(doc_id, page_no, stage)
        except UnknownDocumentError:
            logger.debug(
                "stage event for unknown doc/page", extra={"doc_id": doc_id, "page_no": page_no}
            )


__all__ = ["WorkerCrashed", "WorkerPool"]
