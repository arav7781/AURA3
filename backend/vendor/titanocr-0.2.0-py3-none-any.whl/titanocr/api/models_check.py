"""Startup model-integrity gate (phase 09; docs/01 §packaging, hard rule 9).

Every engine in a served pipeline that loads a model exposes ``model_path`` (the
det/rec wrappers and the prep-side cls, see ``engines/rapidocr.py``). At startup
each referenced file is checksummed against ``models/MANIFEST.json``; a missing
manifest entry or a sha256 mismatch is a readiness failure with a pointed
message — never a production document. The service has no auto-download
fallback: every fetch goes through ``titanocr.modelstore`` (``make models``,
``titanocr models``, and the library's first start, which fetches *before* the
service exists — ADR 0024).

The check runs once at startup, not per ``/readyz`` poll — server-variant
models are ~85 MB and probes fire every few seconds.
"""

import hashlib
import json
import logging
from collections.abc import Mapping
from pathlib import Path

from titanocr.stages import ResolvedPipeline

logger = logging.getLogger("titanocr.models")

_CHUNK = 1 << 20


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while chunk := fh.read(_CHUNK):
            digest.update(chunk)
    return digest.hexdigest()


def _referenced_model_paths(pipelines: Mapping[str, ResolvedPipeline]) -> dict[Path, str]:
    """Model files referenced by resolved engines → ``pipeline:stage`` context."""
    paths: dict[Path, str] = {}
    for version, pipeline in pipelines.items():
        for stage_key, stage in pipeline.stages.items():
            for engine in (stage.engine, stage.fallback):
                if engine is None:
                    continue
                # The prep engine carries its cls component and the recogniser
                # an optional second model; unwrap both.
                candidates = [
                    engine,
                    getattr(engine, "_cls", None),
                    getattr(engine, "_second", None),
                ]
                for candidate in candidates:
                    path = getattr(candidate, "model_path", None)
                    if isinstance(path, Path):
                        paths.setdefault(path, f"{version}:{stage_key}")
    return paths


def verify_models(pipelines: Mapping[str, ResolvedPipeline], models_dir: Path) -> list[str]:
    """Checksum every referenced model against the manifest; returns error
    strings (empty = healthy). Errors fail readiness, by design loudly."""
    referenced = _referenced_model_paths(pipelines)
    if not referenced:
        return []

    manifest_path = models_dir / "MANIFEST.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return [f"model manifest unreadable ({manifest_path}): {exc}"]
    expected: dict[str, str] = {}
    for entry in manifest.get("models", []):
        for filename in entry.get("files", []):
            expected[str(filename)] = str(entry["sha256"])

    errors: list[str] = []
    for path, context in sorted(referenced.items(), key=lambda item: str(item[0])):
        if not path.is_file():
            errors.append(f"model file missing: {path} (used by {context}) — run `make models`")
            continue
        pinned = expected.get(path.name)
        if pinned is None:
            errors.append(
                f"model {path.name} (used by {context}) is not pinned in {manifest_path} — "
                "every served model must be in the manifest"
            )
            continue
        actual = _sha256(path)
        if actual != pinned:
            errors.append(
                f"model checksum mismatch: {path} (used by {context}) — expected "
                f"sha256 {pinned[:12]}…, found {actual[:12]}…; the file is corrupt or "
                "tampered, re-run `make models`"
            )
        else:
            logger.info(
                "model verified", extra={"model": path.name, "sha256": actual[:12], "by": context}
            )
    return errors


__all__ = ["verify_models"]
