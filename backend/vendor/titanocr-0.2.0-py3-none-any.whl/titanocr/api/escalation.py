"""Process-scoped escalation runtime (phase 13): provider client + circuit breaker.

The `Escalator` engine is pure over the IR — it takes its client, the page PNG
and the breaker from ``ctx.resources`` (docs/08 rule 5). *Something* has to own
those across documents, though: a breaker that reset per document could never
protect the pipeline from an unhealthy provider (docs/07 §failure isolation),
and a fresh HTTP client per call would throw away connection reuse. That owner
is this module, built once in the app lifespan from :class:`Settings`.

Secrets live only in env (plan §13): no key (or no endpoint/model) → the runtime
reports itself disabled, the orchestrator records every triage decision, skips
every call and serves the document ``degraded``. The demo therefore works with
no secrets at all, which is the point of P5.
"""

import logging
from dataclasses import dataclass
from typing import Any

import httpx

from titanocr.engines.vlm import CircuitBreaker, OpenAICompatClient, VLMClient
from titanocr.settings import Settings

logger = logging.getLogger("titanocr.escalation")


@dataclass(frozen=True)
class EscalationRuntime:
    """What the orchestrator needs to run stage 5, or the reason it cannot."""

    client: VLMClient | None
    breaker: CircuitBreaker
    max_regions_per_page: int
    max_regions_per_doc: int
    concurrency: int
    disabled_reason: str | None = None
    """``None`` when configured; otherwise why calls will be skipped — recorded
    on the page slot and in the signals log, never swallowed."""

    @property
    def enabled(self) -> bool:
        return self.client is not None

    def status(self) -> dict[str, Any]:
        """Informational ``/readyz`` detail (§4.5) — a provider outage degrades
        documents, it never makes the pod unready."""
        return {
            "configured": self.enabled,
            "reason": self.disabled_reason,
            "model": getattr(self.client, "model", None),
            "max_regions_per_page": self.max_regions_per_page,
            "max_regions_per_doc": self.max_regions_per_doc,
            "breaker": self.breaker.snapshot(),
        }

    async def aclose(self) -> None:
        """Release the provider connection pool on shutdown; a client without
        one (a fake, in tests) simply has nothing to close."""
        if isinstance(self.client, OpenAICompatClient):
            await self.client.aclose()


def build_escalation_runtime(
    settings: Settings, *, transport: httpx.AsyncBaseTransport | None = None
) -> EscalationRuntime:
    """Wire the runtime from env. ``transport`` is the test seam (a fake provider
    via ``httpx.MockTransport``); production passes nothing."""
    breaker = CircuitBreaker(
        threshold=settings.vlm_breaker_threshold,
        cooldown_s=settings.vlm_breaker_cooldown_s,
    )
    missing = [
        name
        for name, value in (
            ("OCR_VLM_BASE_URL", settings.vlm_base_url),
            ("OCR_VLM_MODEL", settings.vlm_model),
            ("OCR_VLM_API_KEY", settings.vlm_api_key),
        )
        if not value
    ]
    if missing:
        reason = f"escalation not configured — missing {', '.join(missing)}"
        logger.info("escalation disabled", extra={"reason": reason})
        return EscalationRuntime(
            client=None,
            breaker=breaker,
            max_regions_per_page=settings.vlm_max_regions_per_page,
            max_regions_per_doc=settings.vlm_max_regions_per_doc,
            concurrency=settings.vlm_concurrency,
            disabled_reason=reason,
        )

    assert settings.vlm_base_url is not None
    assert settings.vlm_model is not None
    assert settings.vlm_api_key is not None
    client = OpenAICompatClient(
        base_url=settings.vlm_base_url,
        model=settings.vlm_model,
        api_key=settings.vlm_api_key.get_secret_value(),
        timeout_s=settings.vlm_timeout_s,
        max_retries=settings.vlm_max_retries,
        transport=transport,
    )
    logger.info(
        "escalation configured",
        extra={"provider": client.provider, "model": client.model, "base_url": client.base_url},
    )
    return EscalationRuntime(
        client=client,
        breaker=breaker,
        max_regions_per_page=settings.vlm_max_regions_per_page,
        max_regions_per_doc=settings.vlm_max_regions_per_doc,
        concurrency=settings.vlm_concurrency,
    )


__all__ = ["EscalationRuntime", "build_escalation_runtime"]
