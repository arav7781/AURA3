"""In-flight dedupe re-check at processing time (docs/07 §idempotency).

Ingest-time dedupe (:mod:`titanocr.api.jobs`) answers the *resubmission* case:
the same bytes arrive twice, the second submit returns the first document. It
cannot answer the case docs/07 actually warns about — **two in-flight copies**,
which is what a queue retry produces and what two pods sharing an artifacts
volume produce. That race is settled here, at the moment a document starts
processing rather than at ingest, with a lock file in the artifact root:

    var/artifacts/.dedupe/{digest}.lock      the winner's claim (pid + host + doc_id)
    var/artifacts/.dedupe/{digest}.result    what the winner produced, for adopters

The first copy to create the lock file (``O_CREAT | O_EXCL`` — atomic on POSIX
and on the shared filesystems this runs over) processes the document. A second
copy waits and then **adopts** the winner's artifacts verbatim instead of
repeating the work: the same bytes under the same pipeline are the same
document, so the adopted ``ir.json``/``output.md`` are byte-identical to the
winner's (they carry the winner's ``doc_id`` — that is the document those
artifacts belong to; the adopter's ``meta.json`` records ``adopted_from``).

Nothing here may deadlock the pipeline (the phase-14 risk note):

* the lock carries the winner's pid and host, and its mtime is a heartbeat;
* a lock whose owner died on this host is stealable immediately, and any lock
  whose heartbeat stopped for ``stale_after_s`` is stealable by anyone;
* a waiter that exhausts ``wait_timeout_s`` gives up and processes the document
  itself — a slow winner costs duplicated work, never a stuck document.

Only *waiters* adopt. A stale ``.result`` with no live lock is ignored: this
module settles concurrent copies, it is not a persistent result cache.
"""

import asyncio
import contextlib
import hashlib
import json
import logging
import os
import socket
import time
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, cast

logger = logging.getLogger("titanocr.dedupe")

LOCK_DIRNAME = ".dedupe"

_STALE_AFTER_S = 30.0
"""No heartbeat for this long → the holder is presumed gone and the lock stealable."""

_POLL_S = 0.05
_HEARTBEAT_FACTOR = 3.0

_RESULT_TTL_S = 3600.0
"""How long a published result stays adoptable before it is pruned. Waiters are
bounded by the document deadline, so anything this old has no reader left."""


def dedupe_key(
    content_hash: str, pipeline_version: str, doc_type_hint: str, escalation_mode: str
) -> str:
    """The idempotency key — the job table's dedupe key, verbatim.

    docs/07 states it as ``(content_hash, pipeline_version)``; phases 12/13 made
    the doc-type hint and the escalation mode part of *what is delivered* (the
    hint changes triage, ``escalation=off`` deliberately yields the degraded
    OCR-only result), so they join the key here too. A superset never adopts
    across a difference that changes the answer.
    """
    return "\n".join((content_hash, pipeline_version, doc_type_hint, escalation_mode))


def _digest(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:32]


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return True
    return True


@dataclass(frozen=True)
class DedupeAdoption:
    """The winner's outcome, as recorded by the winner when it released the lock."""

    winner_doc_id: str
    state: str
    degraded: bool = False
    reject_reason: str | None = None
    totals_ms: float | None = None
    totals_cost_inr: float = 0.0
    escalated_pages: int = 0
    pages: tuple[tuple[int, str, str | None], ...] = ()
    """``(page_no, status, route)`` per page — enough to rebuild the status document."""

    waited_s: float = 0.0

    @classmethod
    def from_record(cls, record: dict[str, Any]) -> "DedupeAdoption | None":
        try:
            return cls(
                winner_doc_id=str(record["doc_id"]),
                state=str(record["state"]),
                degraded=bool(record.get("degraded", False)),
                reject_reason=record.get("reject_reason"),
                totals_ms=record.get("totals_ms"),
                totals_cost_inr=float(record.get("totals_cost_inr", 0.0)),
                escalated_pages=int(record.get("escalated_pages", 0)),
                pages=tuple(
                    (int(p["page_no"]), str(p["status"]), p.get("route"))
                    for p in record.get("pages", [])
                ),
            )
        except (KeyError, TypeError, ValueError):
            return None


class DedupeLease:
    """A held lock. Heartbeats while the document is processed; always released."""

    def __init__(self, owner: "DedupeGuard", key: str, path: Path, doc_id: str, stolen: bool):
        self._owner = owner
        self._key = key
        self._path = path
        self._doc_id = doc_id
        self.stolen = stolen
        self._heartbeat_task: asyncio.Task[None] | None = None

    @property
    def path(self) -> Path:
        return self._path

    def heartbeat(self) -> None:
        """Touch the lock — the liveness signal a waiter reads (mtime)."""
        with contextlib.suppress(OSError):
            os.utime(self._path, None)

    def start_heartbeat(self, interval_s: float) -> None:
        """Keep the lock's mtime fresh while the document is processed."""

        async def beat() -> None:
            while True:
                await asyncio.sleep(interval_s)
                self.heartbeat()

        self._heartbeat_task = asyncio.create_task(beat(), name=f"dedupe-heartbeat-{self._doc_id}")

    def release(self, result: dict[str, Any] | None = None) -> None:
        """Publish the outcome (if any) for waiters, then drop the lock.

        ``result=None`` — the document failed or was abandoned — publishes
        nothing: a waiter must re-run the work rather than adopt a non-result.
        """
        if self._heartbeat_task is not None:
            self._heartbeat_task.cancel()
            self._heartbeat_task = None
        if result is not None:
            self._owner.publish_result(self._key, {**result, "doc_id": self._doc_id})
        self._path.unlink(missing_ok=True)


class DedupeGuard:
    """Owns the lock directory under the artifact root."""

    def __init__(
        self,
        root: Path,
        *,
        stale_after_s: float = _STALE_AFTER_S,
        poll_s: float = _POLL_S,
    ) -> None:
        self._dir = root / LOCK_DIRNAME
        self._stale_after_s = stale_after_s
        self._poll_s = poll_s
        self._host = socket.gethostname()

    @property
    def dir(self) -> Path:
        return self._dir

    def _lock_path(self, key: str) -> Path:
        return self._dir / f"{_digest(key)}.lock"

    def _result_path(self, key: str) -> Path:
        return self._dir / f"{_digest(key)}.result"

    def publish_result(self, key: str, record: dict[str, Any]) -> None:
        """Record what the winner produced, for a waiter to adopt."""
        path = self._result_path(key)
        tmp = path.with_name(path.name + ".tmp")
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(json.dumps(record, sort_keys=True), encoding="utf-8")
            os.replace(tmp, path)
        except OSError as exc:  # a result we cannot publish only costs duplicated work
            logger.warning("dedupe result not published", extra={"error": str(exc)})

    def prune(self, ttl_s: float = _RESULT_TTL_S) -> None:
        """Drop result records older than the TTL — nobody can still be waiting
        on them, and a hidden directory must not grow without bound."""
        cutoff = time.time() - ttl_s
        try:
            entries = list(self._dir.glob("*.result"))
        except OSError:
            return
        for path in entries:
            try:
                if path.stat().st_mtime < cutoff:
                    path.unlink(missing_ok=True)
            except OSError:
                continue

    def _read_json(self, path: Path) -> dict[str, Any] | None:
        try:
            loaded: Any = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        return cast(dict[str, Any], loaded) if isinstance(loaded, dict) else None

    def _claim(self, key: str, doc_id: str, *, stolen: bool) -> DedupeLease | None:
        """Create the lock file exclusively (or steal it); ``None`` if someone holds it."""
        path = self._lock_path(key)
        record = json.dumps(
            {
                "key": key,
                "doc_id": doc_id,
                "pid": os.getpid(),
                "host": self._host,
                "claimed_at": time.time(),
            },
            sort_keys=True,
        )
        self._dir.mkdir(parents=True, exist_ok=True)
        if stolen:
            # Replace atomically: the previous holder is gone, and a torn write
            # here would strand the key for everyone.
            tmp = path.with_name(f"{path.name}.{os.getpid()}.steal")
            tmp.write_text(record, encoding="utf-8")
            os.replace(tmp, path)
            return DedupeLease(self, key, path, doc_id, stolen=True)
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
        except FileExistsError:
            return None
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(record)
        return DedupeLease(self, key, path, doc_id, stolen=False)

    def _stale(self, path: Path) -> bool:
        """A lock nobody is tending: dead owner on this host, or a stopped heartbeat."""
        try:
            age = time.time() - path.stat().st_mtime
        except OSError:
            return False
        holder = self._read_json(path) or {}
        pid = holder.get("pid")
        host = holder.get("host")
        if host == self._host and isinstance(pid, int) and not _pid_alive(pid):
            return True
        return age > self._stale_after_s

    async def acquire(
        self, *, key: str, doc_id: str, wait_timeout_s: float
    ) -> DedupeLease | DedupeAdoption:
        """Claim the key, or wait for the in-flight winner and adopt its result.

        Never raises for lock-file trouble: any filesystem problem degrades to
        "process it yourself" (an unguarded lease), because a document that
        cannot be locked must still be delivered.
        """
        started = time.monotonic()
        path = self._lock_path(key)
        try:
            self.prune()
            lease = self._claim(key, doc_id, stolen=False)
            # Whose result we are entitled to adopt: the holder observed on the
            # failed claim. A leftover .result from an earlier run belongs to a
            # different document and is ignored (only waiters adopt, and only
            # the winner they actually waited for).
            holder = self._read_json(path) or {}
            waiting_for = holder.get("doc_id") if lease is None else None
            while lease is None:
                lock_held = path.exists()
                if not lock_held:
                    result = self._read_json(self._result_path(key))
                    adoption = DedupeAdoption.from_record(result) if result else None
                    if adoption is not None and adoption.winner_doc_id == waiting_for:
                        # The winner finished and dropped the lock while we waited.
                        return replace(adoption, waited_s=time.monotonic() - started)
                    lease = self._claim(key, doc_id, stolen=False)
                    continue
                if self._stale(path):
                    holder = self._read_json(path) or {}
                    logger.warning(
                        "stealing stale dedupe lock",
                        extra={
                            "doc_id": doc_id,
                            "stale_holder": holder.get("doc_id"),
                            "stale_pid": holder.get("pid"),
                        },
                    )
                    lease = self._claim(key, doc_id, stolen=True)
                    continue
                if time.monotonic() - started > wait_timeout_s:
                    logger.warning(
                        "dedupe wait timed out — processing anyway",
                        extra={"doc_id": doc_id, "waited_s": round(time.monotonic() - started, 3)},
                    )
                    return DedupeLease(self, key, self._lock_path(key), doc_id, stolen=False)
                await asyncio.sleep(self._poll_s)
        except OSError as exc:
            logger.warning(
                "dedupe lock unavailable — processing unguarded",
                extra={"doc_id": doc_id, "error": str(exc)},
            )
            return DedupeLease(self, key, self._lock_path(key), doc_id, stolen=False)
        lease.start_heartbeat(max(self._stale_after_s / _HEARTBEAT_FACTOR, self._poll_s))
        return lease


__all__ = [
    "LOCK_DIRNAME",
    "DedupeAdoption",
    "DedupeGuard",
    "DedupeLease",
    "dedupe_key",
]
