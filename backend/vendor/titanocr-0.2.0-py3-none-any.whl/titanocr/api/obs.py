"""Observability: structured JSON logs + request middleware + provenance timing.

One JSON object per line (ts, level, logger, msg, then any extras such as
``doc_id``/``trace_id``), so every job-related line is machine-greppable by
``doc_id``. Stage timings belong in ``provenance[]`` — :func:`stage_timer` is the
one helper that measures and appends a :class:`~titanocr.ir.ProvenanceEntry`;
never build a second timing system next to it.
"""

import json
import logging
import sys
import time
import uuid
from collections.abc import Awaitable, Callable, Generator
from contextlib import contextmanager
from typing import Any

from fastapi import FastAPI, Request, Response

from titanocr.ir import ProvenanceEntry

_RESERVED = frozenset(
    {
        "args",
        "asctime",
        "created",
        "exc_info",
        "exc_text",
        "filename",
        "funcName",
        "levelname",
        "levelno",
        "lineno",
        "message",
        "module",
        "msecs",
        "msg",
        "name",
        "pathname",
        "process",
        "processName",
        "relativeCreated",
        "stack_info",
        "taskName",
        "thread",
        "threadName",
    }
)


class JsonFormatter(logging.Formatter):
    """``LogRecord`` → one compact JSON line; ``extra={...}`` keys pass through."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created))
            + f".{int(record.msecs):03d}Z",
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for key, value in record.__dict__.items():
            if key in _RESERVED or key in payload:
                continue
            payload[key] = (
                value if isinstance(value, str | int | float | bool | None) else str(value)
            )
        if record.exc_info and record.exc_info[0] is not None:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False, default=str)


def configure_logging(level: str) -> None:
    """Root logger → one stdout handler with :class:`JsonFormatter` (idempotent)."""
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level.upper())


def install_request_logging(app: FastAPI) -> None:
    """Log every request as one JSON line with method/path/status/ms + trace_id.

    A ``doc_id`` path segment (``/v1/documents/{doc_id}…``) is lifted onto the
    line so request logs join up with job logs.
    """
    logger = logging.getLogger("titanocr.api.request")

    async def _log_request(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        trace_id = uuid.uuid4().hex
        started = time.perf_counter()
        response = await call_next(request)
        extra: dict[str, Any] = {
            "trace_id": trace_id,
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "ms": round((time.perf_counter() - started) * 1000.0, 3),
        }
        doc_id = _doc_id_from_path(request.url.path)
        if doc_id is not None:
            extra["doc_id"] = doc_id
        logger.info("request", extra=extra)
        return response

    app.middleware("http")(_log_request)


def _doc_id_from_path(path: str) -> str | None:
    parts = path.strip("/").split("/")
    if len(parts) >= 3 and parts[0] == "v1" and parts[1] == "documents":
        return parts[2]
    return None


@contextmanager
def stage_timer(
    sink: list[ProvenanceEntry],
    *,
    stage: str,
    engine: str,
    version: str,
    cost_inr: float = 0.0,
) -> Generator[None]:
    """Measure a stage and append its :class:`~titanocr.ir.ProvenanceEntry` to ``sink``."""
    started = time.perf_counter()
    try:
        yield
    finally:
        ms = (time.perf_counter() - started) * 1000.0
        sink.append(
            ProvenanceEntry(stage=stage, engine=engine, version=version, ms=ms, cost_inr=cost_inr)
        )


__all__ = [
    "JsonFormatter",
    "configure_logging",
    "install_request_logging",
    "stage_timer",
]
