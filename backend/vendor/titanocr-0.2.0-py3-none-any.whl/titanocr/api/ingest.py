"""Stage 0 — ingest: magic-byte sniff, page enumeration, caps, encrypted-PDF reject.

Uploads are untrusted (plan §14): the format comes from content, never the
extension or client mime; encrypted PDFs and page-cap breaches are rejected with
a clear 422 **before** a job exists; the whole-file sha256 (computed by the route
alongside this) is the dedupe key (ADR 0003 #6). Runs synchronously in a worker
thread — pdfium/Pillow header reads are cheap but they are not event-loop work.
"""

from dataclasses import dataclass
from pathlib import Path

from titanocr.engines.images import ImageProbeError, probe_image
from titanocr.engines.raster import EncryptedPdfError, PdfOpenError, pdf_page_count

INGEST_ENGINE = "builtin"
INGEST_VERSION = "1"

_HEIC_BRANDS = frozenset(
    {b"heic", b"heix", b"heim", b"heis", b"hevc", b"hevm", b"hevs", b"heif", b"mif1", b"msf1"}
)

FORMATS: dict[str, tuple[str, str]] = {
    "pdf": ("pdf", "application/pdf"),
    "jpeg": ("jpg", "image/jpeg"),
    "png": ("png", "image/png"),
    "tiff": ("tif", "image/tiff"),
    "webp": ("webp", "image/webp"),
    "heic": ("heic", "image/heic"),
}


class IngestRejected(Exception):
    """Upload refused at stage 0 — the route answers 422 with this reason."""

    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True)
class IngestResult:
    fmt: str
    ext: str
    mime: str
    n_pages: int
    page_dims: tuple[tuple[int, int], ...] | None
    """Per-page pixel dimensions for raster uploads; ``None`` for PDFs (the
    orchestrator takes PDF page dimensions from the render)."""


def sniff_format(head: bytes) -> str | None:
    """Magic-byte detection of the accepted upload formats; ``None`` = unsupported."""
    if head.startswith(b"%PDF-"):
        return "pdf"
    if head.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head.startswith(b"II*\x00") or head.startswith(b"MM\x00*"):
        return "tiff"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if head[4:8] == b"ftyp" and head[8:12] in _HEIC_BRANDS:
        return "heic"
    return None


def inspect_upload(path: Path, fmt: str, *, page_cap: int) -> IngestResult:
    """Enumerate pages and enforce caps for an already-sniffed upload.

    Raises :class:`IngestRejected` for encrypted PDFs, unparseable files and
    page-cap breaches — loud rejects, never silent truncation (ADR 0001).
    """
    ext, mime = FORMATS[fmt]
    if fmt == "pdf":
        try:
            n_pages = pdf_page_count(path)
        except EncryptedPdfError:
            raise IngestRejected(
                "encrypted PDF — remove the password protection and resubmit"
            ) from None
        except PdfOpenError as exc:
            raise IngestRejected(f"unreadable PDF — {exc}") from None
        page_dims: tuple[tuple[int, int], ...] | None = None
    else:
        try:
            page_dims = tuple(probe_image(path))
        except ImageProbeError as exc:
            raise IngestRejected(f"unreadable {fmt} image — {exc}") from None
        n_pages = len(page_dims)
    if n_pages < 1:
        raise IngestRejected("document contains no pages")
    if n_pages > page_cap:
        raise IngestRejected(f"document has {n_pages} pages — exceeds the {page_cap}-page cap")
    return IngestResult(fmt=fmt, ext=ext, mime=mime, n_pages=n_pages, page_dims=page_dims)


__all__ = [
    "FORMATS",
    "INGEST_ENGINE",
    "INGEST_VERSION",
    "IngestRejected",
    "IngestResult",
    "inspect_upload",
    "sniff_format",
]
