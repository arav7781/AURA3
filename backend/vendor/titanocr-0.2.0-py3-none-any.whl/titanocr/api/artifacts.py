"""Per-document artifact store: ``var/artifacts/{doc_id}/`` (plan §4, §14).

Layout per document::

    original.<ext>        the upload, byte-identical
    ir.json               full Document IR (written at terminal state)
    pages/page-{n}.json   per-page IR, written as each page completes — the UI's
                          live-boxes source (ADR 0003 #2: polling + artifacts)
    pages/page-{n}.pre-escalation.json   the same page as OCR delivered it, kept
                          when a VLM escalation replaced blocks (phase 13)
    pages/page-{n}.png    page raster (prep space)
    output.md             Markdown projection (display artifact, never the source)
    meta.json             pipeline_version, renderer version, timings

Every write is atomic (tmp file + ``os.replace`` in the same directory) so a
poller can never observe a half-written artifact. ``doc_id`` is a server-generated
UUID and is the **only** value that ever touches a path — no user-controlled
filenames reach the filesystem (plan §14).
"""

import json
import os
from pathlib import Path
from typing import Any


class ArtifactStore:
    def __init__(self, root: Path) -> None:
        self.root = root

    def ensure_root(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)

    def doc_dir(self, doc_id: str) -> Path:
        return self.root / doc_id

    def original_path(self, doc_id: str, ext: str) -> Path:
        return self.doc_dir(doc_id) / f"original.{ext}"

    def find_original(self, doc_id: str) -> Path | None:
        matches = sorted(self.doc_dir(doc_id).glob("original.*"))
        return matches[0] if matches else None

    def ir_path(self, doc_id: str) -> Path:
        return self.doc_dir(doc_id) / "ir.json"

    def page_ir_path(self, doc_id: str, page_no: int) -> Path:
        return self.doc_dir(doc_id) / "pages" / f"page-{page_no}.json"

    def page_png_path(self, doc_id: str, page_no: int) -> Path:
        return self.doc_dir(doc_id) / "pages" / f"page-{page_no}.png"

    def page_original_png_path(self, doc_id: str, page_no: int) -> Path:
        """``variant=original`` for OCR-routed pages (phase 08): the un-prepped
        render/decode, kept alongside the post-prep ``page-{n}.png``."""
        return self.doc_dir(doc_id) / "pages" / f"page-{page_no}.orig.png"

    def page_pre_escalation_ir_path(self, doc_id: str, page_no: int) -> Path:
        """The page IR **as OCR delivered it**, written just before a VLM
        escalation replaces blocks (phase 13).

        docs/02 invariant 4 says escalation records what it replaced and the
        pre-escalation content is retained; ``escalations[].replaced_block_ids``
        carries the ids, this artifact carries the text. Together they are the
        OCR-vs-VLM diff docs/03's disagreement-rate metric (and the demo's
        side-by-side view) needs.
        """
        return self.doc_dir(doc_id) / "pages" / f"page-{page_no}.pre-escalation.json"

    def markdown_path(self, doc_id: str) -> Path:
        return self.doc_dir(doc_id) / "output.md"

    def meta_path(self, doc_id: str) -> Path:
        return self.doc_dir(doc_id) / "meta.json"

    def store_original(self, doc_id: str, ext: str, src: Path) -> Path:
        """Move the streamed upload into place (copy + atomic rename, cross-fs safe)."""
        dest = self.original_path(doc_id, ext)
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".tmp")
        tmp.write_bytes(src.read_bytes())
        os.replace(tmp, dest)
        src.unlink(missing_ok=True)
        return dest

    def write_ir(self, doc_id: str, ir_json: str) -> Path:
        return self._write_text(self.ir_path(doc_id), ir_json)

    def write_page_ir(self, doc_id: str, page_no: int, page_json: str) -> Path:
        return self._write_text(self.page_ir_path(doc_id, page_no), page_json)

    def write_page_pre_escalation_ir(self, doc_id: str, page_no: int, page_json: str) -> Path:
        return self._write_text(self.page_pre_escalation_ir_path(doc_id, page_no), page_json)

    def write_page_png(self, doc_id: str, page_no: int, data: bytes) -> Path:
        return self._write_bytes(self.page_png_path(doc_id, page_no), data)

    def write_page_original_png(self, doc_id: str, page_no: int, data: bytes) -> Path:
        return self._write_bytes(self.page_original_png_path(doc_id, page_no), data)

    def write_markdown(self, doc_id: str, markdown: str) -> Path:
        return self._write_text(self.markdown_path(doc_id), markdown)

    def write_meta(self, doc_id: str, meta: dict[str, Any]) -> Path:
        return self._write_text(
            self.meta_path(doc_id), json.dumps(meta, sort_keys=True, ensure_ascii=False)
        )

    def _write_text(self, path: Path, text: str) -> Path:
        return self._write_bytes(path, text.encode("utf-8"))

    def _write_bytes(self, path: Path, data: bytes) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_bytes(data)
        os.replace(tmp, path)
        return path


__all__ = ["ArtifactStore"]
