"""Orchestrator v2 — ingest + digital fast path + pool-run prep (phases 06/08).

Per document: classification (pdf-inspector, falling back to pdfium text per the
phase-03 convention — both attempts recorded in provenance), per-page display
rasters, positioned-item extraction, coverage-checked per-page routing, and
per-page IR artifacts as pages complete. Digital pages are exact by construction
(docs/01 stage 1): every line/span carries ``origin="digital"`` and confidence
1.0. OCR-routed pages (and every image upload) submit to the **worker pool**
(phase 08): rasterise/decode + prep run inside a spawn worker under the document
deadline, bounded in flight by pool size (docs/07 — no overcommit). Phase 09:
workers run the full OCR core (det → rec → interim blocks → signals), pages
reach ``done`` and every processed page's confidence block is appended to the
signals JSONL (docs/03 — thresholds re-fittable offline). A pipeline without
resolvable OCR engines still preps; its pages stay honestly ``pending_engine``.
A worker crash fails that page, recreates the pool and the remaining pages
continue (docs/07 §failure isolation). Phase 12: every assembled page is triaged
(:meth:`Orchestrator._settle_page` — docs/03 policy via the configured
``TriagePolicy``); escalate decisions are recorded and skipped (document
``degraded``) until phase 13 wires the escalator, reject verdicts (worker-side
pre-OCR gate or the post-OCR backstop) mark pages ``rejected`` and an
all-rejected document ``rejected`` with its reason.

Routing rule (phase 06 §4.5, the docs/03 accept rule): a page goes digital iff the
classifier marks it text-based **and** measured ``text_coverage`` — non-whitespace
characters delivered vs pdfium's independent count — is ≥ ``min_text_coverage``.
A parser that dropped half a page fails that check and the page routes to OCR:
never silent truncation (ADR 0001 §V3).

Blocks here are interim clusters (vertical-gap grouping + the light phase-07
typing pass in :func:`group_blocks`); real layout arrives in phase 10.
``output.md`` is the render_md projection of the final IR (phase 07) — a
display artifact, never the source (ADR 0001 §1).

Phase 13 replaces the skip with the real thing: an escalate decision schedules a
**VLM escalation** on the parent event loop (the only async stage, docs/07),
bounded per document by a semaphore and by the region caps, deadline-aware, and
merged additively into the page (docs/02 invariant 4) with the pre-escalation IR
kept as an artifact. Anything that prevents the call — no key, ``escalation=off``,
an open circuit breaker, an expired deadline, a provider failure — degrades that
page and flags it for review; the document is still served.
"""

import asyncio
import json
import logging
import shutil
import uuid
from collections.abc import Callable, Mapping, Sequence
from dataclasses import asdict, dataclass, field
from itertools import pairwise
from pathlib import Path
from time import monotonic, perf_counter
from typing import Any, Protocol, cast

from titanocr.api.artifacts import ArtifactStore
from titanocr.api.dedupe import DedupeAdoption, DedupeGuard, DedupeLease, dedupe_key
from titanocr.api.escalation import EscalationRuntime
from titanocr.api.ingest import INGEST_ENGINE, INGEST_VERSION
from titanocr.api.jobs import TERMINAL_STATES, JobManager, JobRecord, JobState
from titanocr.api.pool import DigitalLayoutResult, DigitalRegionsResult, WorkerCrashed, WorkerPool
from titanocr.api.signals_log import SignalsLog
from titanocr.api.worker import PENDING_REASON, WorkerPageResult
from titanocr.engines.diagram import connector_blocks, find_connectors
from titanocr.engines.layout import (
    RAPID_LAYOUT_VERSION,
    RasterRegion,
    decode_png_page,
    find_rules_in_png,
    find_rules_on_page,
    raster_regions,
    unclaimed_ink_fraction,
)
from titanocr.engines.pdftext import PageGeometry, PdfTextClassification, garbled_char_ratio
from titanocr.engines.tables import (
    GEOMETRIC_VERSION,
    lattice_regions,
    lattice_tables,
    retype_digital_tables,
    split_column_blocks,
    split_wide_gap_lines,
)
from titanocr.engines.vlm import (
    PROMPT_TEMPLATE_VERSION,
    RESOURCE_BREAKER,
    RESOURCE_CLIENT,
    RESOURCE_PAGE_PNG,
    EscalationOutcome,
    skipped_outcome,
)
from titanocr.ir import (
    BBox,
    Block,
    BlockType,
    ConfidenceBlock,
    DocumentIR,
    Line,
    Origin,
    Page,
    PageOrigin,
    Prep,
    ProvenanceEntry,
    Quality,
    Source,
    SourceKind,
    Totals,
    canonical_json,
)
from titanocr.render_md import RENDERER_VERSION, ir_to_markdown
from titanocr.stages import (
    LOW_CONF_FLOOR,
    CostAccumulator,
    Deadline,
    EngineDegraded,
    PageEvent,
    PageImage,
    ResolvedPipeline,
    ResolvedStage,
    ResourceRegistry,
    StageContext,
    TriageAction,
    TriageDecision,
    TriagePolicy,
    cluster_paragraph_blocks,
    compute_signals,
    is_section_heading,
)

logger = logging.getLogger("titanocr.orchestrator")

ROUTE_DIGITAL = "digital"
ROUTE_OCR = "ocr"

_POINTS_PER_INCH = 72.0

_DIGITAL_BLUR_SCORE = 1000.0

_REGIONS_VERSION = "raster-regions-1"
"""Provenance version of the digital route's raster-region pass (ADR 0020)."""

_CLAIMED_BLOCK_TYPES = frozenset(
    {BlockType.figure, BlockType.signature, BlockType.connector, BlockType.rule, BlockType.table}
)
"""Blocks whose ink the region finder treats as already accounted for: a
layout-typed picture, a drawn connector, a ruling, a table's grid. Their pixels
are structure the page already recorded — not a region to read again."""


def _region_is_readable(lines: Sequence[Line], conf_floor: float, min_chars: int) -> bool:
    """Did OCR find *text* in a raster region, or only strokes it could not read?

    Readable when any line clears the recognizer's confidence floor, or when
    the region carries at least ``min_chars`` recognised characters however low
    their confidence — the latter is the handwriting signature (detection
    succeeds, recognition collapses) that triage must still see and escalate.
    A lone sub-floor character on a logo is neither: it is the picture.
    """
    if any(line.confidence >= conf_floor for line in lines):
        return True
    return sum(_nonws(line.text) for line in lines) >= min_chars


def _inside_fraction(inner: BBox, outer: BBox) -> float:
    """Fraction of ``inner``'s area that lies inside ``outer``."""
    w = min(inner[2], outer[2]) - max(inner[0], outer[0])
    h = min(inner[3], outer[3]) - max(inner[1], outer[1])
    area = max(0.0, inner[2] - inner[0]) * max(0.0, inner[3] - inner[1])
    return (max(0.0, w) * max(0.0, h) / area) if area > 0 else 0.0


"""Synthetic sharpness for rendered digital pages — no measurement exists until the
prep stage (phase 08); a render is sharp by construction."""


class PdfTextEngine(Protocol):
    """The informal phase-06 pdftext interface both engines implement (no docs/08
    Protocol exists for this kind — it predates the pool-side stage seam)."""

    version: str

    def classify(self, pdf_path: Path) -> PdfTextClassification: ...

    def extract_lines(
        self, pdf_path: Path, geometries: Mapping[int, PageGeometry]
    ) -> dict[int, list[Line]]: ...


class RasterEngine(Protocol):
    version: str

    def rasterize(self, pdf_path: Path, page_no: int, dpi: float | None = None) -> PageImage: ...

    def encode_png(self, image: PageImage) -> bytes: ...

    def page_sizes_pts(self, pdf_path: Path) -> list[tuple[float, float]]: ...

    def image_boxes_pts(
        self, pdf_path: Path, page_no: int
    ) -> list[tuple[float, float, float, float]]: ...

    def text_char_counts(self, pdf_path: Path) -> list[int]: ...


class EscalatorEngine(Protocol):
    """The escalator as the orchestrator uses it (phase 13).

    docs/08's ``Escalator`` Protocol returns the merged blocks; settling a page
    also needs what was replaced, what it cost and what failed, so the engine
    exposes a richer :meth:`run` alongside it — the same "extra method beyond
    the Protocol" shape the worker already uses for the triage engine's
    pre-OCR quality gate. An escalator without it degrades to a recorded skip.
    """

    version: str

    async def run(
        self, page: Page, decision: TriageDecision, ctx: StageContext
    ) -> EscalationOutcome: ...


@dataclass
class _EscalationState:
    """Per-document escalation bookkeeping.

    One document is processed at a time (``_run`` awaits ``_process``), so a
    single field on the orchestrator is the whole state — no keying, no leaks.
    """

    semaphore: asyncio.Semaphore
    deadline_ts: float
    regions_left: int
    tasks: list[asyncio.Task[None]] = field(default_factory=list["asyncio.Task[None]"])
    pages: dict[int, Page] = field(default_factory=dict[int, Page])
    provenance: list[ProvenanceEntry] = field(default_factory=list[ProvenanceEntry])
    cost_inr: float = 0.0
    escalated_pages: int = 0
    escalated_regions: int = 0


def _retype_with_rules(
    blocks: Sequence[Block], png: bytes, width_px: float, height_px: float
) -> tuple[list[Block], int]:
    """The borderless reconstruction over a page's positioned items, with the
    page's own raster at hand so the header refinement can read the rules drawn
    under group labels (phase 24 §7). Off the event loop like the drawn-structure
    pass before it; a raster that fails to decode costs only the rules."""
    try:
        page: PageImage | None = decode_png_page(png)
    except Exception:
        page = None
    return retype_digital_tables(blocks, page_width=width_px, page_height=height_px, page=page)


def _with_drawn_structure(
    blocks: Sequence[Block],
    png: bytes,
    page_no: int,
    *,
    detect_connectors: bool = False,
    detect_rules: bool = False,
) -> tuple[list[Block], int]:
    """What the page *draws*, added to what its text layer says (ADR 0011, 0014).

    A born-digital page carries its structure as vector art: the grid of a ruled
    table, the boxes and connectors of an architecture figure are **drawn**, not
    written, so the text layer sees only the characters inside them. The
    rendered raster the orchestrator already produces for display is where that
    structure is visible, and this is the one place the fast path looks at it.

    Three findings come out of the same detection pass, in this order:

    1. **Ruled tables.** Rules that cross each other bound cells; the components
       that do so are table regions, rebuilt through the OCR route's ruled
       strategy (:func:`~titanocr.engines.tables.lattice_tables`). Doing this
       before anything else matters because a real grid outranks every heuristic
       that follows it — the borderless pass guesses columns from where text
       happens to sit, and on a fully ruled table it guessed wrong.
    2. **Connectors** (IR 1.6, ADR 0012). A diagram's arrows: bent, curved or
       diagonal strokes with the ends that carry a head, resolved to the blocks
       they run between. A rule that turns out to have an arrowhead is promoted
       here and dropped from the rules below, so each stroke is modelled once.
    3. **Page rules** — only when the pipeline asks for them (ADR 0014). The
       detection above runs regardless, because the lattice and the arrows are
       built out of it, but a plain line is not emitted as a block by default:
       the pass cannot tell a drawn division from textured artwork, and on a
       picture it invents dozens of divisions the page never had. Rules inside a
       region that became a table are dropped either way — that ink is the
       table's grid, and the table already models it.

    Detection failures are swallowed and logged: a page's text is delivered
    whatever the raster analysis does with it.
    """
    try:
        page = decode_png_page(png)
        lines = [line for b in blocks for line in (b.lines or ())]
        found = find_rules_on_page(
            page, lines, [b.bbox for b in blocks if b.type is BlockType.table]
        )
        blocks, table_regions = lattice_tables(
            page,
            blocks,
            lattice_regions([bbox for bbox, _ in found]),
            page_width=page.width,
            page_height=page.height,
            page_no=page_no,
        )
        found = [
            (bbox, coverage)
            for bbox, coverage in found
            if not any(_bbox_within(bbox, region) for region in table_regions)
        ]
        drawn = (
            find_connectors(
                page,
                [line for b in blocks for line in (b.lines or ())],
                avoid=table_regions,
                straight=[bbox for bbox, _ in found],
            )
            if detect_connectors
            else []
        )
        connectors = connector_blocks(
            drawn, blocks, page_no, page_span=float(max(page.width, page.height))
        )
    except Exception as exc:  # pragma: no cover - an enhancement, never the page
        logger.warning(
            "drawn-structure detection failed", extra={"error": str(exc), "page": page_no}
        )
        return list(blocks), 0
    n_tables = len(table_regions)
    promoted = {c.from_rule for c in drawn if c.from_rule is not None}
    # `found` did its work above — the grid and the arrow candidates came out of
    # it. What `detect_rules` gates is calling the leftover ink a finding.
    emitted = found if detect_rules else []
    rules = [
        Block(
            block_id=f"p{page_no}_r{i}",
            type=BlockType.rule,
            bbox=bbox,
            reading_order=0,  # assigned below, over the merged set
            # The route that produced the block, not a claim about text: this
            # page never ran OCR, and saying `ocr` would assert a recognition
            # step that provenance shows never happened. A rule carries no text
            # for the distinction to bite on either way.
            origin=Origin.digital,
            confidence=min(1.0, max(0.0, coverage)),
        )
        for i, (bbox, coverage) in enumerate(emitted)
        if i not in promoted
    ]
    if not rules and not connectors:
        return list(blocks), n_tables
    # Reading order over the merged set, top-to-bottom then left-to-right, so a
    # rule lands between the blocks it divides rather than after all of them.
    merged = sorted(
        [*blocks, *rules, *connectors], key=lambda b: (round(b.bbox[1]), round(b.bbox[0]))
    )
    return [b.model_copy(update={"reading_order": i}) for i, b in enumerate(merged)], n_tables


def _bbox_within(inner: BBox, outer: BBox, tol: float = 2.0) -> bool:
    return (
        inner[0] >= outer[0] - tol
        and inner[1] >= outer[1] - tol
        and inner[2] <= outer[2] + tol
        and inner[3] <= outer[3] + tol
    )


def _nonws(text: str) -> int:
    return sum(1 for ch in text if not ch.isspace())


def _copy_artifacts(src: Path, dest: Path) -> None:
    """Copy a winner's deliverables into the adopting document's directory.

    The upload itself (``original.*``) is not copied — the adopter stored its
    own bytes at submit, and they are the same bytes by definition of the key.
    """
    dest.mkdir(parents=True, exist_ok=True)
    for name in ("ir.json", "output.md"):
        source = src / name
        if source.is_file():
            shutil.copy2(source, dest / name)
    pages = src / "pages"
    if pages.is_dir():
        shutil.copytree(pages, dest / "pages", dirs_exist_ok=True)


_HEADER_HEIGHT_RATIO = 1.3
"""A line at least this many times taller than the page's median line height is
typed ``header`` — bbox height as font-size proxy (plan §9 rule 2, phase 07)."""

_HEADER_MAX_CHARS = 60
"""Tall but long lines are not headings: guards against cross-column merged
lines (the known phase-06 two-column clustering artifact) whose union bbox can
exceed the height ratio."""

_KV_MAX_KEY_CHARS = 60
_KV_MAX_VALUE_CHARS = 48
"""``Key: value`` shape: short key, short value. The value cap keeps merged
two-column lines (long tails after the first colon) out of kv typing."""

_CELL_GAP_RATIO = 2.0
"""Spans on one line separated horizontally by at least this many median line
heights are cells of a table row (or independent column flows), not one text
run — inline style changes produce gaps well under one line height."""

_CELL_INDENT_RATIO = 2.0
"""A narrow line joins an adjacent cell run only when indented at least this
many median line heights from the group's left margin — wrapped cell text and
sub-rows are indented, while footnotes under a grid sit on the margin."""

_CELL_RUN_MIN_LINES = 3
"""Minimum consecutive cell-row lines to split out as a table candidate —
matches ``retype_digital_tables(min_rows=3)``; shorter runs are more likely
the phase-06 merged-column artifact than a grid."""

"""ALL-CAPS section titles are short and narrow; a full-width caps line is
emphasised prose, not a heading."""


def group_blocks(
    page_no: int, lines: Sequence[Line], *, block_gap_ratio: float
) -> tuple[Block, ...]:
    """Interim layout for the digital fast path (phase 06 §4.4, typed in 07).

    Lines arrive top-to-bottom from the pdftext engines; a new block starts when
    the vertical gap to the previous line exceeds ``block_gap_ratio`` x the median
    line height — and at every prose ↔ cell-run boundary (a run of multi-cell
    rows, :func:`_split_cell_runs`), so a grid embedded in a text flow reaches
    :func:`~titanocr.engines.tables.retype_digital_tables` as its own block
    instead of glued to prose (first real-sample finding, 2026-08-14). A light
    typing pass then gives the markdown projection honest structure: a line
    ≥ 1.3x the page median height becomes its own ``header`` block — unless it
    is itself a multi-cell row, whose tall union bbox is a table row, never a
    heading — as does a short, narrow ALL-CAPS section title; a group whose
    every line reads ``Key: value`` becomes ``kv``; everything else stays
    ``paragraph``.
    """
    if not lines:
        return ()
    heights = sorted(line.bbox[3] - line.bbox[1] for line in lines)
    median_h = max(heights[len(heights) // 2], 1.0)
    page_text_width = max(
        max(line.bbox[2] for line in lines) - min(line.bbox[0] for line in lines), 1.0
    )
    groups: list[list[Line]] = [[lines[0]]]
    for line in lines[1:]:
        prev = groups[-1][-1]
        if line.bbox[1] - prev.bbox[3] > block_gap_ratio * median_h:
            groups.append([line])
        else:
            groups[-1].append(line)
    groups = [run for group in groups for run in _split_cell_runs(group, median_h)]

    header_min_h = _HEADER_HEIGHT_RATIO * median_h
    typed: list[tuple[BlockType, list[Line]]] = []
    for group in groups:
        run: list[Line] = []
        for line in group:
            tall = line.bbox[3] - line.bbox[1] >= header_min_h
            heading = (
                (tall and len(line.text) <= _HEADER_MAX_CHARS)
                or is_section_heading(line, page_text_width)
            ) and not _is_multicell_row(line, median_h)
            if heading:
                if run:
                    typed.append((_body_type(run), run))
                    run = []
                typed.append((BlockType.header, [line]))
            else:
                run.append(line)
        if run:
            typed.append((_body_type(run), run))

    blocks: list[Block] = []
    for idx, (block_type, group) in enumerate(typed):
        bbox = (
            min(line.bbox[0] for line in group),
            min(line.bbox[1] for line in group),
            max(line.bbox[2] for line in group),
            max(line.bbox[3] for line in group),
        )
        blocks.append(
            Block(
                block_id=f"p{page_no}_b{idx}",
                type=block_type,
                bbox=bbox,
                reading_order=idx,
                origin=Origin.digital,
                confidence=1.0,
                lines=tuple(group),
            )
        )
    return tuple(blocks)


def _body_type(group: Sequence[Line]) -> BlockType:
    if all(_is_kv_line(line.text) for line in group):
        return BlockType.kv
    return BlockType.paragraph


def _is_kv_line(text: str) -> bool:
    key, sep, value = text.partition(":")
    return (
        bool(sep)
        and 0 < len(key.strip()) <= _KV_MAX_KEY_CHARS
        and not key[:1].isspace()
        and 0 < len(value.strip()) <= _KV_MAX_VALUE_CHARS
    )


def _is_multicell_row(line: Line, median_h: float) -> bool:
    """A line whose spans sit in horizontally separated runs — the phase-06
    y-cluster of a table row (its cells side by side) or of two column flows."""
    spans = line.spans or ()
    gap_min = _CELL_GAP_RATIO * median_h
    return any(b.bbox[0] - a.bbox[2] >= gap_min for a, b in pairwise(spans))


def _split_cell_runs(group: list[Line], median_h: float) -> list[list[Line]]:
    """Split a vertical-gap group at prose ↔ cell-run boundaries.

    Multi-cell rows seed the runs; lines indented from the group's left margin
    that touch a run (wrapped cell text, a straddling super-header, a sub-row
    like ``(in INR)``) join it transitively. Margin-anchored lines (footnotes
    under a grid) stay prose. Cell runs shorter than ``_CELL_RUN_MIN_LINES``
    fold back into prose — a lone gappy line is more likely a merged-column
    artifact than a grid.
    """
    cellish = [_is_multicell_row(ln, median_h) for ln in group]
    if not any(cellish):
        return [group]
    x0 = min(ln.bbox[0] for ln in group)
    indent_min = _CELL_INDENT_RATIO * median_h
    joinable = [ln.bbox[0] - x0 >= indent_min for ln in group]
    changed = True
    while changed:
        changed = False
        for i, is_cell in enumerate(cellish):
            if is_cell or not joinable[i]:
                continue
            if (i > 0 and cellish[i - 1]) or (i + 1 < len(cellish) and cellish[i + 1]):
                cellish[i] = True
                changed = True
    runs: list[tuple[bool, list[Line]]] = []
    for flag, line in zip(cellish, group, strict=True):
        if runs and runs[-1][0] == flag:
            runs[-1][1].append(line)
        else:
            runs.append((flag, [line]))
    demoted = [(flag and len(seg) >= _CELL_RUN_MIN_LINES, seg) for flag, seg in runs]
    merged: list[tuple[bool, list[Line]]] = []
    for flag, seg in demoted:
        if merged and merged[-1][0] == flag:
            merged[-1][1].extend(seg)
        else:
            merged.append((flag, seg))
    return [seg for _flag, seg in merged]


def _pending_page(page_no: int, width: int, height: int, dpi_estimate: float | None) -> Page:
    """Placeholder for a page the pool could not process (crash/failure/no pool):
    zero delivered text, zeroed confidence signals (triage would escalate,
    honestly), no blocks."""
    return Page(
        page_no=page_no,
        width=width,
        height=height,
        dpi_estimate=dpi_estimate,
        origin=PageOrigin.ocr,
        prep=Prep(applied=(), skew_deg=0.0, crop_bbox_in_original=None, scale=1.0),
        quality=Quality(blur_score=0.0, resolution_ok=True, is_grayscale=False),
        confidence=ConfidenceBlock(
            mean_rec=0.0,
            p10_rec=0.0,
            text_coverage=0.0,
            low_conf_area_ratio=0.0,
            handwriting_ratio=0.0,
        ),
        blocks=(),
    )


@dataclass
class _DigitalPageWork:
    """One PDF page's concurrent work on the digital route (``_process_pdf``):
    its routing verdict, its page when digital, and what it adds to the
    document's provenance and counters — merged in page order afterwards."""

    page_no: int
    route: str = ROUTE_OCR
    coverage: float = 0.0
    page: Page | None = None
    provenance: list[ProvenanceEntry] = field(default_factory=list[ProvenanceEntry])
    layout_ms: float = 0.0
    layout_typed: bool = False
    rule_ms: float = 0.0
    rules: int = 0
    table_ms: float = 0.0
    tables: int = 0
    region_ms: float = 0.0
    regions: int = 0


class Orchestrator:
    def __init__(
        self,
        jobs: JobManager,
        store: ArtifactStore,
        *,
        resolved: Mapping[str, ResolvedPipeline],
        pool: WorkerPool | None = None,
        doc_deadline_s: float = 300.0,
        signals_log: SignalsLog | None = None,
        escalation: EscalationRuntime | None = None,
        dedupe: DedupeGuard | None = None,
    ) -> None:
        self._jobs = jobs
        self._store = store
        self._resolved = resolved
        self._pool = pool
        self._doc_deadline_s = doc_deadline_s
        self._dedupe = dedupe if dedupe is not None else DedupeGuard(store.root)
        self._signals = signals_log
        self._escalation = escalation
        self._esc: _EscalationState | None = None
        self._stopping = asyncio.Event()
        self._task: asyncio.Task[None] | None = None

    def start(self) -> None:
        self._task = asyncio.create_task(self._run(), name="orchestrator")

    async def drain(self) -> None:
        """Graceful shutdown: finish the in-flight job and the queued backlog, then stop."""
        self._stopping.set()
        if self._task is not None:
            await self._task
            self._task = None

    async def _run(self) -> None:
        while True:
            doc_id = await self._jobs.next_doc(timeout_s=0.1)
            if doc_id is None:
                if self._stopping.is_set() and self._jobs.queue_empty():
                    return
                continue
            record = self._jobs.get(doc_id)
            try:
                await self._process(record)
            except Exception:
                logger.exception("document processing failed", extra={"doc_id": record.doc_id})
                await self._jobs.finish(record.doc_id, "failed")

    async def _process(self, record: JobRecord) -> None:
        """Dedupe guard around the real work (docs/07 §idempotency, phase 14 §4.1).

        The re-check belongs here, not at ingest: the race the queue produces is
        two copies *in flight*, and only one of them may do the work. The loser
        adopts the winner's artifacts; a winner that dies holding the lock is
        stolen from after its heartbeat stops, so nothing can wedge.
        """
        doc_id = record.doc_id
        logger.info("processing started", extra={"doc_id": doc_id, "format": record.fmt})
        await self._jobs.mark_processing(doc_id)

        key = dedupe_key(
            record.content_hash,
            record.pipeline_version,
            record.doc_type_hint,
            record.escalation_mode,
        )
        claim = await self._dedupe.acquire(
            key=key, doc_id=doc_id, wait_timeout_s=self._doc_deadline_s
        )
        lease: DedupeLease | None = None
        if isinstance(claim, DedupeAdoption):
            if await self._adopt(record, claim):
                return
            logger.warning(
                "dedupe winner left no artifacts — processing this copy",
                extra={"doc_id": doc_id, "winner": claim.winner_doc_id},
            )
        else:
            lease = claim
        try:
            await self._process_document(record)
        finally:
            if lease is not None:
                lease.release(self._dedupe_result(doc_id))

    def _dedupe_result(self, doc_id: str) -> dict[str, Any] | None:
        """What a waiting copy may adopt — ``None`` unless the document settled."""
        record = self._jobs.get(doc_id)
        if record.state not in TERMINAL_STATES:
            return None
        return {
            "state": record.state,
            "degraded": record.degraded,
            "reject_reason": record.reject_reason,
            "totals_ms": record.totals_ms,
            "totals_cost_inr": record.totals_cost_inr,
            "escalated_pages": record.escalated_pages,
            "pages": [
                {"page_no": slot.page_no, "status": slot.status, "route": slot.route}
                for slot in record.pages
            ],
        }

    async def _adopt(self, record: JobRecord, adoption: DedupeAdoption) -> bool:
        """Serve the winner's artifacts as this document's result.

        The artifacts are copied **verbatim** — same bytes in, same bytes out
        (DoD 3) — so the adopted ``ir.json`` carries the winner's ``doc_id``:
        by content hash the two submissions *are* one document. ``meta.json``
        records ``adopted_from`` so the provenance of the copy is never lost.
        Returns False when the winner's artifacts are gone (then we process).
        """
        doc_id = record.doc_id
        src = self._store.doc_dir(adoption.winner_doc_id)
        if not (src / "ir.json").is_file():
            return False
        dest = self._store.doc_dir(doc_id)
        try:
            await asyncio.to_thread(_copy_artifacts, src, dest)
        except OSError as exc:
            logger.warning(
                "dedupe adoption copy failed", extra={"doc_id": doc_id, "error": str(exc)}
            )
            return False
        meta: dict[str, Any] = {}
        meta_path = src / "meta.json"
        if meta_path.is_file():
            loaded: Any = json.loads(meta_path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                meta = cast(dict[str, Any], loaded)
        meta["adopted_from"] = adoption.winner_doc_id
        self._store.write_meta(doc_id, meta)

        if adoption.pages:
            routes = [route or ROUTE_DIGITAL for _, _, route in adoption.pages]
            await self._jobs.init_pages(doc_id, routes)
            for page_no, status, _route in adoption.pages:
                await self._jobs.set_page(doc_id, page_no, status=cast(Any, status))
        await self._jobs.finish(
            doc_id,
            cast(JobState, adoption.state),
            totals_ms=adoption.totals_ms,
            totals_cost_inr=adoption.totals_cost_inr,
            escalated_pages=adoption.escalated_pages,
            reject_reason=adoption.reject_reason,
            degraded=adoption.degraded,
        )
        logger.info(
            "document adopted from an in-flight duplicate",
            extra={
                "doc_id": doc_id,
                "winner": adoption.winner_doc_id,
                "state": adoption.state,
                "waited_s": round(adoption.waited_s, 3),
            },
        )
        return True

    async def _process_document(self, record: JobRecord) -> None:
        doc_id = record.doc_id
        provenance: list[ProvenanceEntry] = [
            ProvenanceEntry(
                stage="ingest",
                engine=INGEST_ENGINE,
                version=INGEST_VERSION,
                ms=record.ingest_ms,
                cost_inr=0.0,
            )
        ]
        await self._jobs.set_stage_rollup(doc_id, "ingest", "done", ms=record.ingest_ms)

        original = self._store.find_original(doc_id)
        if original is None:
            raise RuntimeError(f"original upload missing for {doc_id}")

        # Deadline for the whole document, propagated into every worker's
        # StageContext (docs/07 §backpressure — deadlines propagate; queue time
        # counts because the timestamp, not a budget, crosses the boundary).
        deadline_ts = monotonic() + self._doc_deadline_s
        runtime = self._escalation
        self._esc = _EscalationState(
            # Bounded escalation concurrency for the document (§4.6) — the
            # provider is IO, but it is also spend: never fan out unbounded.
            semaphore=asyncio.Semaphore(runtime.concurrency if runtime else 1),
            deadline_ts=deadline_ts,
            regions_left=runtime.max_regions_per_doc if runtime else 0,
        )

        if record.fmt == "pdf":
            state, pages = await self._process_pdf(record, original, provenance, deadline_ts)
        else:
            state, pages = await self._process_image(record, original, provenance, deadline_ts)

        # Stage 5 runs concurrently with the tail of the document; nothing is
        # assembled until every escalation has settled.
        escalations = self._esc
        await self._drain_escalations(doc_id)
        provenance.extend(escalations.provenance)
        pages = [escalations.pages.get(page.page_no, page) for page in pages]

        # Phase 12: fold the per-page triage outcomes into the document verdict.
        # Every page rejected → the document is a reject/resubmit case (served
        # with its reason, docs/03); a mix keeps the good pages and ends partial;
        # any escalation that did not fully happen (skipped, failed, capped)
        # marks the result degraded — served, honestly less than it should be.
        slots = self._jobs.get(doc_id).pages
        rejected = [slot for slot in slots if slot.status == "rejected"]
        degraded = any(slot.escalation not in (None, "done") for slot in slots)
        reject_reason: str | None = None
        if rejected and len(rejected) == len(slots):
            state = "rejected"
            reject_reason = rejected[0].reason
        elif rejected and state == "done":
            state = "partial"

        total_ms = sum(entry.ms for entry in provenance)
        ir = DocumentIR(
            ir_version="1.8",
            doc_id=uuid.UUID(doc_id),
            content_hash=record.content_hash,
            source=Source(
                kind=SourceKind.upload,
                filename=record.filename,
                mime=record.mime,
                bytes=record.size_bytes,
            ),
            page_count=len(pages),
            pages=tuple(pages),
            provenance=tuple(provenance),
            totals=Totals(
                ms=total_ms,
                # Cost is provider-reported usage x the versioned price table —
                # never a hardcoded per-page number (hard rule 10).
                cost_inr=escalations.cost_inr,
                escalated_pages=escalations.escalated_pages,
                escalated_regions=escalations.escalated_regions,
            ),
        )
        self._store.write_ir(doc_id, canonical_json(ir))
        # The real projection (phase 07): display artifact only — IR stays the source.
        self._store.write_markdown(doc_id, ir_to_markdown(ir))
        self._store.write_meta(
            doc_id,
            {
                "pipeline_version": record.pipeline_version,
                "renderer_version": RENDERER_VERSION,
                "ir_version": ir.ir_version,
                "timings": {"total_ms": total_ms},
            },
        )
        await self._jobs.finish(
            doc_id,
            state,
            totals_ms=total_ms,
            totals_cost_inr=escalations.cost_inr,
            escalated_pages=escalations.escalated_pages,
            reject_reason=reject_reason,
            degraded=degraded,
        )
        self._esc = None
        logger.info(
            "document finished",
            extra={
                "doc_id": doc_id,
                "state": state,
                "ms": total_ms,
                "degraded": degraded,
                "escalated_pages": escalations.escalated_pages,
                "escalated_regions": escalations.escalated_regions,
                "cost_inr": escalations.cost_inr,
            },
        )

    # -- PDF path (stages 0-1: classify + digital fast path) ----------------------

    async def _process_pdf(
        self,
        record: JobRecord,
        path: Path,
        provenance: list[ProvenanceEntry],
        deadline_ts: float,
    ) -> tuple[JobState, list[Page]]:
        doc_id = record.doc_id
        pipeline = self._resolved.get(record.pipeline_version)
        if pipeline is None:
            raise RuntimeError(f"pipeline {record.pipeline_version!r} not resolved at startup")
        pdftext_stage = pipeline.stages["pdftext"]
        rasterizer = cast(RasterEngine, pipeline.stages["rasterize"].engine)
        primary = cast(PdfTextEngine, pdftext_stage.engine)
        dpi = float(getattr(primary, "digital_render_dpi", 150.0))
        min_cov = float(getattr(primary, "min_text_coverage", 0.95))
        block_gap_ratio = float(getattr(primary, "block_gap_ratio", 1.8))
        max_garbled_ratio = float(getattr(primary, "max_garbled_char_ratio", 0.10))
        max_unclaimed_ink_frac = float(getattr(primary, "max_unclaimed_ink_frac", 0.35))
        detect_connectors = bool(getattr(primary, "detect_connectors", False))
        detect_rules = bool(getattr(primary, "detect_rules", False))
        ocr_regions = bool(getattr(primary, "ocr_unclaimed_regions", True))
        region_min_side_px = int(getattr(primary, "region_min_side_px", 20))
        max_regions_per_page = int(getattr(primary, "max_regions_per_page", 16))

        # Classification — primary with fallback, both attempts in provenance.
        await self._jobs.set_stage_rollup(doc_id, "classify", "processing")
        classification, used_fallback = await asyncio.to_thread(
            self._classify_chain, pdftext_stage, path, provenance
        )
        await self._jobs.set_stage_rollup(doc_id, "classify", "done", ms=provenance[-1].ms)
        logger.info(
            "classified",
            extra={
                "doc_id": doc_id,
                "pdf_type": classification.pdf_type.value,
                "confidence": classification.confidence,
                "pages_needing_ocr": sorted(classification.pages_needing_ocr),
                "engine": provenance[-1].engine,
            },
        )

        n_pages = record.n_pages
        routes = [
            ROUTE_DIGITAL if page_no not in classification.pages_needing_ocr else ROUTE_OCR
            for page_no in range(1, n_pages + 1)
        ]
        await self._jobs.init_pages(doc_id, routes)

        # Display rasters at the digital render DPI — the page-space the IR bboxes
        # target (plan §7 coordinate rule); one PNG per page, digital or not.
        await self._jobs.set_stage_rollup(doc_id, "raster", "processing")
        sizes_pts = await asyncio.to_thread(rasterizer.page_sizes_pts, path)
        geometries: dict[int, PageGeometry] = {}
        raster_started = perf_counter()
        for page_no in range(1, n_pages + 1):
            await self._jobs.set_page(doc_id, page_no, status="processing", stage="raster")
            png, width_px, height_px = await asyncio.to_thread(
                self._render_page, rasterizer, path, page_no, dpi
            )
            self._store.write_page_png(doc_id, page_no, png)
            width_pts, height_pts = sizes_pts[page_no - 1]
            geometries[page_no] = PageGeometry(
                width_pts=width_pts,
                height_pts=height_pts,
                width_px=width_px,
                height_px=height_px,
                scale=dpi / _POINTS_PER_INCH,
            )
        raster_ms = (perf_counter() - raster_started) * 1000.0
        provenance.append(
            ProvenanceEntry(
                stage="raster",
                engine=pipeline.stages["rasterize"].engine_name,
                version=rasterizer.version,
                ms=raster_ms,
                cost_inr=0.0,
            )
        )
        await self._jobs.set_stage_rollup(doc_id, "raster", "done", ms=raster_ms)

        # Positioned-text extraction — same fallback chain; the pdfium reference
        # char counts are the coverage yardstick regardless of which engine ran.
        await self._jobs.set_stage_rollup(doc_id, "extract", "processing")
        for page_no in range(1, n_pages + 1):
            await self._jobs.set_page(doc_id, page_no, status="processing", stage="extract")
        ref_counts = await asyncio.to_thread(rasterizer.text_char_counts, path)
        lines_by_page = await asyncio.to_thread(
            self._extract_chain, pdftext_stage, path, geometries, used_fallback, provenance
        )
        await self._jobs.set_stage_rollup(doc_id, "extract", "done", ms=provenance[-1].ms)

        by_page: dict[int, Page] = {}
        ocr_pages: list[int] = []
        digital_table_ms = 0.0
        digital_tables = 0
        digital_rule_ms = 0.0
        digital_rules = 0
        digital_layout_ms = 0.0
        digital_layout_pages = 0
        digital_region_ms = 0.0
        digital_regions = 0
        digital_region_pages = 0
        # Each page's own work — region discovery, layout typing in a pool worker,
        # drawn structure, tables, raster-region OCR — runs concurrently, bounded
        # by the pool (docs/07 §backpressure): on a 40-page born-digital PDF these
        # were 40 sequential pool round-trips while every other worker idled.
        # What must stay ordered stays ordered: provenance is merged, pages are
        # settled (triage, escalation budget) and routed in page order below, so
        # the IR is byte-identical to the sequential loop's.
        page_limit = asyncio.Semaphore(self._pool.workers if self._pool is not None else 1)

        async def examine(page_no: int) -> _DigitalPageWork:
            async with page_limit:
                work = _DigitalPageWork(page_no=page_no)
                geom = geometries[page_no]
                lines = lines_by_page.get(page_no, [])
                reference = ref_counts[page_no - 1]
                delivered = sum(_nonws(line.text) for line in lines)
                coverage = min(1.0, delivered / reference) if reference > 0 else 0.0
                garbled_ratio = garbled_char_ratio(line.text for line in lines)
                is_digital = (
                    page_no not in classification.pages_needing_ocr
                    and reference > 0
                    and coverage >= min_cov
                    and bool(lines)
                    and garbled_ratio <= max_garbled_ratio
                )
                if bool(lines) and garbled_ratio > max_garbled_ratio:
                    # High character coverage against pdfium's own (equally broken)
                    # reference count doesn't catch this: the text layer's ToUnicode
                    # CMap doesn't match its glyph indices, so the page renders fine
                    # but every extracted character is garbage. Never trust it —
                    # fall back to OCR on the raster, same as any scanned page.
                    logger.warning(
                        "digital text layer looks garbled — routing to OCR instead",
                        extra={
                            "doc_id": doc_id,
                            "page_no": page_no,
                            "garbled_char_ratio": garbled_ratio,
                            "max_garbled_char_ratio": max_garbled_ratio,
                        },
                    )

                unclaimed_ratio = 0.0
                page_regions: list[RasterRegion] = []
                if is_digital:
                    # Two independent parsers can share one blind spot: a
                    # PowerPoint-exported PDF's shape captions sitting inside a
                    # nested Form XObject neither pdf-inspector nor pypdfium2 walks
                    # into, so both report the same *incomplete* text and the
                    # coverage check above — one parser cross-checked against the
                    # other — cannot see it. This looks at the rendered pixels
                    # instead: ink the text layer never claimed is content it
                    # missed, whatever the two parsers agree on.
                    #
                    # A table's own border grid and a plain printed rule are also
                    # real ink no *text* line covers, and on a page with a
                    # full-bordered results table that ink is not small — every row
                    # divider of a normal, fully-extracted table read as "missing
                    # content" the first time this ran, on the project's own golden
                    # fixture. Detecting rules first and letting their ink count as
                    # claimed too is what tells structural ink apart from content
                    # that silently never made it into the text layer.
                    png_bytes = self._store.page_png_path(doc_id, page_no).read_bytes()
                    pre_rules = await asyncio.to_thread(find_rules_in_png, png_bytes, lines, [])
                    claimed = [ln.bbox for ln in lines] + [bbox for bbox, _ in pre_rules]
                    if ocr_regions:
                        # Phase 23 (ADR 0020): the page's raster regions — image
                        # objects and unclaimed ink — are found *before* the valve
                        # below judges the page, and count as claimed for it. A
                        # pasted scan or a large logo is content this route will
                        # read region by region; only ink no region explains — a
                        # whole-page scan with a stub text layer — still sends the
                        # page to OCR wholesale.
                        page_regions = await self._discover_raster_regions(
                            path,
                            page_no,
                            geom,
                            png_bytes,
                            claimed,
                            rasterizer,
                            min_side_px=region_min_side_px,
                            max_regions=max_regions_per_page,
                            doc_id=doc_id,
                        )
                        claimed = claimed + [region.bbox for region in page_regions]
                    unclaimed_ratio = await asyncio.to_thread(
                        unclaimed_ink_fraction, png_bytes, claimed
                    )
                    if unclaimed_ratio > max_unclaimed_ink_frac:
                        is_digital = False
                        logger.warning(
                            "digital text layer leaves real ink unclaimed — routing to OCR instead",
                            extra={
                                "doc_id": doc_id,
                                "page_no": page_no,
                                "unclaimed_ink_fraction": unclaimed_ratio,
                                "max_unclaimed_ink_frac": max_unclaimed_ink_frac,
                            },
                        )
                route = ROUTE_DIGITAL if is_digital else ROUTE_OCR
                if is_digital:
                    # Region typing (phase 19, ADR 0017). A born-digital page has
                    # exact text and needs no OCR, but without typed regions a
                    # diagram's labels arrive as body paragraphs — and the largest
                    # of them as document headings — while ADR 0016's arrows have no
                    # `figure` to anchor to. So the same layout stage the OCR route
                    # uses runs here too, in a **pool worker**: it is a model
                    # session, and a model session never runs on the event loop
                    # (hard rule 7). `group_blocks` remains the fallback, so a box
                    # with no models still completes a digital document exactly as
                    # before — typing is an enhancement to this route, not a
                    # precondition for it.
                    blocks = []
                    layout_started = perf_counter()
                    typing = await self._type_digital_regions(
                        doc_id, page_no, tuple(lines), pipeline, deadline_ts
                    )
                    if typing is not None and typing.blocks:
                        blocks = list(typing.blocks)
                        work.provenance.extend(typing.provenance)
                        work.layout_ms += (perf_counter() - layout_started) * 1000.0
                        work.layout_typed = True
                    if not blocks:
                        blocks = group_blocks(page_no, lines, block_gap_ratio=block_gap_ratio)
                    # What the page draws comes first: a grid that is actually ruled
                    # on the page outranks every heuristic below, which can only
                    # infer structure from where the text happens to sit. Off the
                    # event loop, like the raster and extract calls around it — and
                    # on the page's own PNG, not the loop variable from the raster
                    # pass, which holds whichever page rasterised last.
                    rule_started = perf_counter()
                    before = len(blocks)
                    page_png = self._store.page_png_path(doc_id, page_no).read_bytes()
                    typed_blocks, n_ruled = await asyncio.to_thread(
                        _with_drawn_structure,
                        blocks,
                        page_png,
                        page_no,
                        detect_connectors=detect_connectors,
                        detect_rules=detect_rules,
                    )
                    work.rule_ms += (perf_counter() - rule_started) * 1000.0
                    work.rules += max(0, len(typed_blocks) - before - n_ruled)
                    # Digital-path table reconstruction (phase 11 §4.6): the same
                    # borderless code path as the OCR route, over item boxes — for
                    # the regions the drawn grid did not already claim.
                    table_started = perf_counter()
                    typed_blocks, n_tables = await asyncio.to_thread(
                        _retype_with_rules, typed_blocks, page_png, geom.width_px, geom.height_px
                    )
                    # Only now that a block is known not to be a table does a wide
                    # gap between runs mean they are separate content (ADR 0011 note
                    # in tables.py): two diagram boxes, a heading and its date.
                    typed_blocks = split_wide_gap_lines(typed_blocks)
                    # ...and once the lines are separated, a block still spanning
                    # several columns is not one positioned unit: stacking its lines
                    # at its top-left discards the x of every one of them.
                    typed_blocks = split_column_blocks(typed_blocks)
                    work.table_ms += (perf_counter() - table_started) * 1000.0
                    work.tables += n_tables + n_ruled
                    # Raster regions (phase 23, ADR 0020): what the page carries as
                    # pixels — a logo, a stamp, a pasted scan — found from the PDF's
                    # own image objects and from ink nothing above claimed, then
                    # OCR'd in a worker. Additive: the exact lines stay exact; the
                    # page turns `mixed` only when an OCR line was actually added.
                    page_origin = PageOrigin.digital
                    region_confidence: ConfidenceBlock | None = None
                    if ocr_regions and page_regions:
                        region_started = perf_counter()
                        (
                            typed_blocks,
                            page_origin,
                            region_confidence,
                            n_regions,
                        ) = await self._merge_raster_regions(
                            doc_id,
                            page_no,
                            page_regions,
                            list(typed_blocks),
                            geom,
                            pipeline,
                            deadline_ts,
                            work.provenance,
                        )
                        work.region_ms += (perf_counter() - region_started) * 1000.0
                        work.regions += n_regions
                    work.page = Page(
                        page_no=page_no,
                        width=geom.width_px,
                        height=geom.height_px,
                        dpi_estimate=dpi,
                        origin=page_origin,
                        prep=Prep(applied=(), skew_deg=0.0, crop_bbox_in_original=None, scale=1.0),
                        quality=Quality(
                            blur_score=_DIGITAL_BLUR_SCORE, resolution_ok=True, is_grayscale=False
                        ),
                        confidence=region_confidence
                        or ConfidenceBlock(
                            mean_rec=1.0,
                            p10_rec=1.0,
                            text_coverage=coverage,
                            low_conf_area_ratio=0.0,
                            handwriting_ratio=0.0,
                        ),
                        blocks=tuple(typed_blocks),
                    )
                work.route = route
                work.coverage = coverage
                return work

        for work in await asyncio.gather(*(examine(n) for n in range(1, n_pages + 1))):
            page_no = work.page_no
            provenance.extend(work.provenance)
            digital_layout_ms += work.layout_ms
            digital_layout_pages += int(work.layout_typed)
            digital_rule_ms += work.rule_ms
            digital_rules += work.rules
            digital_table_ms += work.table_ms
            digital_tables += work.tables
            digital_region_ms += work.region_ms
            if work.regions:
                digital_regions += work.regions
                digital_region_pages += 1
            if work.page is not None:
                by_page[page_no] = work.page
                self._store.write_page_ir(doc_id, page_no, canonical_json(work.page))
                await self._settle_page(
                    doc_id, page_no, pipeline, record, work.page, provenance, route=work.route
                )
            else:
                ocr_pages.append(page_no)
                await self._jobs.set_page(doc_id, page_no, route=work.route)
            event = PageEvent(
                page_no=page_no, route=work.route, confidence=work.coverage, triage=""
            )
            logger.info("page routed", extra={"doc_id": doc_id, **asdict(event)})

        if digital_layout_pages:
            logger.info(
                "digital pages typed by the layout stage",
                extra={
                    "doc_id": doc_id,
                    "typed_pages": digital_layout_pages,
                    "layout_ms": round(digital_layout_ms, 1),
                    "ms_per_page": round(digital_layout_ms / digital_layout_pages, 1),
                },
            )

        if digital_region_pages:
            logger.info(
                "raster regions found on digital pages",
                extra={
                    "doc_id": doc_id,
                    "pages_with_regions": digital_region_pages,
                    "regions": digital_regions,
                    "regions_ms": round(digital_region_ms, 1),
                },
            )
        if digital_region_ms > 0.0:
            provenance.append(
                ProvenanceEntry(
                    stage="regions",
                    engine="raster-regions",
                    version=_REGIONS_VERSION,
                    ms=digital_region_ms,
                    cost_inr=0.0,
                )
            )

        if digital_rule_ms > 0.0:
            provenance.append(
                ProvenanceEntry(
                    stage="rules",
                    engine="page-rules",
                    version=RAPID_LAYOUT_VERSION,
                    ms=digital_rule_ms,
                    cost_inr=0.0,
                )
            )

        if digital_tables:
            provenance.append(
                ProvenanceEntry(
                    stage="table",
                    engine="geometric",
                    version=GEOMETRIC_VERSION,
                    ms=digital_table_ms,
                    cost_inr=0.0,
                )
            )

        if ocr_pages:
            # Preserve the untouched display render as the `variant=original`
            # image before the worker overwrites the page PNG with post-prep.
            for page_no in ocr_pages:
                self._store.write_page_original_png(
                    doc_id, page_no, self._store.page_png_path(doc_id, page_no).read_bytes()
                )
            fallback_dims = {
                page_no: (geometries[page_no].width_px, geometries[page_no].height_px)
                for page_no in ocr_pages
            }
            pooled, all_ok = await self._run_pool_pages(
                record, path, "pdf", ocr_pages, deadline_ts, provenance, fallback_dims
            )
            by_page.update(pooled)
        else:
            all_ok = True

        pages = [by_page[page_no] for page_no in range(1, n_pages + 1)]
        return ("done" if all_ok else "partial"), pages

    def _classify_chain(
        self, stage: ResolvedStage, path: Path, provenance: list[ProvenanceEntry]
    ) -> tuple[PdfTextClassification, bool]:
        """Classify with the phase-03 fallback semantics; returns (result, used_fallback)."""

        def call(engine: PdfTextEngine) -> PdfTextClassification:
            return engine.classify(path)

        return self._chain(stage, "classify", call, provenance, force_fallback=False)

    def _extract_chain(
        self,
        stage: ResolvedStage,
        path: Path,
        geometries: Mapping[int, PageGeometry],
        used_fallback: bool,
        provenance: list[ProvenanceEntry],
    ) -> dict[int, list[Line]]:
        """Extract with the same chain; a document whose classification already fell
        back skips the primary — it has been judged unusable for this document."""

        def call(engine: PdfTextEngine) -> dict[int, list[Line]]:
            return engine.extract_lines(path, geometries)

        result, _ = self._chain(stage, "extract", call, provenance, force_fallback=used_fallback)
        return result

    def _chain[T](
        self,
        stage: ResolvedStage,
        stage_name: str,
        call: Callable[[PdfTextEngine], T],
        provenance: list[ProvenanceEntry],
        *,
        force_fallback: bool,
    ) -> tuple[T, bool]:
        fallback = cast(PdfTextEngine | None, stage.fallback)
        if not force_fallback:
            started = perf_counter()
            try:
                result = call(cast(PdfTextEngine, stage.engine))
            except EngineDegraded as exc:
                ms = (perf_counter() - started) * 1000.0
                self._record(provenance, stage_name, stage.engine_name, stage.engine, ms)
                if fallback is None or stage.fallback_name is None:
                    raise
                logger.warning(
                    "stage %s: primary engine %s degraded (%s) — running fallback %s",
                    stage_name,
                    stage.engine_name,
                    exc.reason,
                    stage.fallback_name,
                )
            except Exception as exc:
                ms = (perf_counter() - started) * 1000.0
                self._record(provenance, stage_name, stage.engine_name, stage.engine, ms)
                if fallback is None or stage.fallback_name is None:
                    raise
                logger.warning(
                    "stage %s: primary engine %s lost (%s: %s) — running fallback %s",
                    stage_name,
                    stage.engine_name,
                    type(exc).__name__,
                    exc,
                    stage.fallback_name,
                )
            else:
                ms = (perf_counter() - started) * 1000.0
                self._record(provenance, stage_name, stage.engine_name, stage.engine, ms)
                return result, False
        if fallback is None or stage.fallback_name is None:
            raise RuntimeError(f"stage {stage_name!r}: fallback required but none configured")
        started = perf_counter()
        result = call(fallback)
        ms = (perf_counter() - started) * 1000.0
        self._record(provenance, stage_name, stage.fallback_name, fallback, ms)
        return result, True

    @staticmethod
    def _record(
        provenance: list[ProvenanceEntry], stage: str, engine_name: str, engine: object, ms: float
    ) -> None:
        version = getattr(engine, "version", None)
        provenance.append(
            ProvenanceEntry(
                stage=stage,
                engine=engine_name,
                version=version if isinstance(version, str) else "unversioned",
                ms=ms,
                cost_inr=0.0,
            )
        )

    def _log_signals(
        self,
        doc_id: str,
        page: Page,
        *,
        route: str,
        status: str,
        decision: TriageDecision | None = None,
        escalation: Mapping[str, Any] | None = None,
    ) -> None:
        if self._signals is not None:
            self._signals.log_page(
                doc_id=doc_id,
                page=page,
                route=route,
                status=status,
                decision=decision,
                escalation=escalation,
            )

    # -- triage (stage 4, phase 12): decide → record → act ------------------------

    def _triage(
        self,
        pipeline: ResolvedPipeline,
        record: JobRecord,
        page: Page,
        provenance: list[ProvenanceEntry],
    ) -> TriageDecision | None:
        """Run the configured policy on an assembled page; ``None`` = no triage
        stage in this pipeline. Pure arithmetic over the IR (docs/08) — it runs
        on the orchestrator without leaving the event loop."""
        stage = pipeline.stages.get("triage")
        if stage is None:
            return None
        policy = cast(TriagePolicy, stage.engine)
        ctx = StageContext(
            doc_id=record.doc_id,
            trace_id=record.doc_id,
            config={
                "doc_type_hint": record.doc_type_hint,
                "doc_types": pipeline.doc_types,
                "page_no": page.page_no,
            },
            # A settled page's verdict must not be lost to the document deadline —
            # the content is already delivered; deciding about it is sub-ms.
            deadline=Deadline.never(),
            costs=CostAccumulator(),
            resources=ResourceRegistry(),
            logger=logger,
        )
        started = perf_counter()
        try:
            decision = policy.decide(page, ctx)
        except Exception:
            logger.exception(
                "triage policy failed — page flagged for review",
                extra={"doc_id": record.doc_id, "page_no": page.page_no},
            )
            decision = TriageDecision(action=TriageAction.review, trigger="triage_error")
        ms = (perf_counter() - started) * 1000.0
        self._record(provenance, "triage", stage.engine_name, stage.engine, ms)
        return decision

    async def _discover_raster_regions(
        self,
        path: Path,
        page_no: int,
        geom: PageGeometry,
        png_bytes: bytes,
        claimed: Sequence[BBox],
        rasterizer: RasterEngine,
        *,
        min_side_px: int,
        max_regions: int,
        doc_id: str,
    ) -> list[RasterRegion]:
        """Find a born-digital page's raster regions (phase 23, ADR 0020): the
        PDF's image objects, exact, plus connected components of ink that
        nothing in ``claimed`` (text-layer lines, rulings) accounts for."""
        try:
            boxes_pts = await asyncio.to_thread(rasterizer.image_boxes_pts, path, page_no)
        except Exception as exc:
            logger.warning(
                "image-object enumeration failed — ink components only",
                extra={
                    "doc_id": doc_id,
                    "page_no": page_no,
                    "error": f"{type(exc).__name__}: {exc}",
                },
            )
            boxes_pts = []
        image_boxes: list[BBox] = [
            (
                left * geom.scale,
                (geom.height_pts - top) * geom.scale,
                right * geom.scale,
                (geom.height_pts - bottom) * geom.scale,
            )
            for left, bottom, right, top in boxes_pts
        ]
        return await asyncio.to_thread(
            raster_regions,
            png_bytes,
            claimed,
            image_boxes,
            min_side_px=min_side_px,
            max_regions=max_regions,
        )

    async def _merge_raster_regions(
        self,
        doc_id: str,
        page_no: int,
        regions: Sequence[RasterRegion],
        blocks: list[Block],
        geom: PageGeometry,
        pipeline: ResolvedPipeline,
        deadline_ts: float,
        provenance: list[ProvenanceEntry],
    ) -> tuple[list[Block], PageOrigin, ConfidenceBlock | None, int]:
        """OCR a born-digital page's raster regions in a worker and merge
        additively (phase 23, ADR 0020).

        An image-object region is always read: its pixels are a raster the text
        layer cannot describe. An ink region that layout has since vouched for
        as a drawn figure, table, connector or rule is recorded through that
        block and not read again — its labels are already exact lines, and OCR
        would only deliver them a second time, worse.

        Returns the blocks with the region blocks appended, the page origin
        (``mixed`` iff an OCR line was added), the page confidence to use when
        it is mixed (``None`` keeps the digital block), and the region count.
        Every failure is soft and every region survives it: OCR unavailable or
        broken means the regions come back as line-less figures.
        """
        vouched = [block.bbox for block in blocks if block.type in _CLAIMED_BLOCK_TYPES]
        kept = [
            region
            for region in regions
            if region.source == "image"
            or not any(_inside_fraction(region.bbox, box) > 0.5 for box in vouched)
        ]
        if not kept:
            return blocks, PageOrigin.digital, None, 0
        png_path = self._store.page_png_path(doc_id, page_no)

        result: DigitalRegionsResult | None = None
        has_ocr = "detect" in pipeline.stages and "recognize" in pipeline.stages
        if not has_ocr:
            # A models-free install records the pictures and pays no worker
            # round trip for them — the fast path stays fast (ADR 0001).
            logger.info(
                "raster regions kept as figures — no OCR engines configured",
                extra={"doc_id": doc_id, "page_no": page_no, "regions": len(kept)},
            )
        elif self._pool is not None and png_path.is_file():
            result = await self._pool.run_digital_regions(
                doc_id,
                page_no,
                png_path,
                tuple(region.bbox for region in kept),
                pipeline.pipeline_version,
                deadline_ts,
            )
            provenance.extend(result.provenance)
            if result.failure_reason is not None:
                logger.info(
                    "raster regions kept as figures — OCR unavailable",
                    extra={
                        "doc_id": doc_id,
                        "page_no": page_no,
                        "regions": len(kept),
                        "reason": result.failure_reason,
                    },
                )

        floor: Any = None
        if "recognize" in pipeline.stages:
            floor = getattr(pipeline.stages["recognize"].engine, "rec_conf_floor", None)
        conf_floor = float(floor) if isinstance(floor, int | float) else LOW_CONF_FLOOR
        min_chars: Any = None
        if "triage" in pipeline.stages:
            min_chars = getattr(pipeline.stages["triage"].engine, "reject_min_chars", None)
        readable_min_chars = int(min_chars) if isinstance(min_chars, int | float) else 4

        merged = list(blocks)
        next_order = max((block.reading_order for block in blocks), default=-1) + 1
        ocr_lines: list[Line] = []
        for index, region in enumerate(kept):
            found: tuple[Line, ...] = ()
            if result is not None and index < len(result.lines):
                found = result.lines[index]
            if found and not _region_is_readable(found, conf_floor, readable_min_chars):
                # The page-level rule at region scope (docs/03, triage's
                # ``no_text_on_inked_page``): a picture on which detection found
                # a stroke or two that recognition cannot read is a picture. A
                # handwritten note reads differently — many characters, all
                # below the floor — and keeps its lines for triage to escalate.
                logger.info(
                    "raster region has no readable text — recorded as a figure",
                    extra={
                        "doc_id": doc_id,
                        "page_no": page_no,
                        "region": index,
                        "attempt": [(line.text, round(line.confidence, 2)) for line in found],
                    },
                )
                found = ()
            if found:
                ocr_lines.extend(found)
                for cluster in cluster_paragraph_blocks(page_no, list(found)):
                    suffix = cluster.block_id.rsplit("_", 1)[-1]
                    merged.append(
                        cluster.model_copy(
                            update={
                                "block_id": f"p{page_no}_r{index}_{suffix}",
                                "reading_order": next_order,
                            }
                        )
                    )
                    next_order += 1
            else:
                merged.append(
                    Block(
                        block_id=f"p{page_no}_r{index}",
                        type=BlockType.figure,
                        bbox=region.bbox,
                        reading_order=next_order,
                        origin=Origin.digital,
                        confidence=1.0,
                        lines=None,
                    )
                )
                next_order += 1
        if not ocr_lines:
            return merged, PageOrigin.digital, None, len(kept)

        all_lines = [line for block in merged for line in (block.lines or ())]
        confidence = compute_signals(
            all_lines, geom.width_px, geom.height_px, rec_conf_floor=conf_floor
        )
        logger.info(
            "raster regions read on a digital page",
            extra={
                "doc_id": doc_id,
                "page_no": page_no,
                "regions": len(kept),
                "ocr_lines": len(ocr_lines),
                "mean_rec": round(confidence.mean_rec, 3),
            },
        )
        return merged, PageOrigin.mixed, confidence, len(kept)

    async def _type_digital_regions(
        self,
        doc_id: str,
        page_no: int,
        lines: tuple[Line, ...],
        pipeline: ResolvedPipeline,
        deadline_ts: float,
    ) -> DigitalLayoutResult | None:
        """Region typing for one born-digital page, in a pool worker (ADR 0017).

        Returns ``None`` when typing is not available at all — no pool, no layout
        stage, no page raster — which is the ordinary state of a models-free
        install and must stay indistinguishable from the pre-phase-19 fast path.
        Every failure is soft: the caller falls back to ``group_blocks``.
        """
        pool = self._pool
        if pool is None or "layout" not in pipeline.stages:
            return None
        png_path = self._store.page_png_path(doc_id, page_no)
        if not png_path.is_file():
            return None
        result = await pool.run_digital_layout(
            doc_id, page_no, png_path, lines, pipeline.pipeline_version, deadline_ts
        )
        if result.failure_reason is not None:
            logger.info(
                "digital region typing unavailable — keeping untyped grouping",
                extra={
                    "doc_id": doc_id,
                    "page_no": page_no,
                    "reason": result.failure_reason,
                },
            )
        return result

    async def _settle_page(
        self,
        doc_id: str,
        page_no: int,
        pipeline: ResolvedPipeline,
        record: JobRecord,
        page: Page,
        provenance: list[ProvenanceEntry],
        *,
        route: str,
    ) -> str:
        """Triage an assembled page and settle its status slot; returns the final
        page status (``done`` or ``rejected``).

        An escalate decision schedules stage 5 (phase 13) and settles the slot
        immediately as ``done`` + ``escalation="running"``: the OCR content is
        already delivered, and the escalation only ever *improves* it. The task
        rewrites the page IR, the slot and the signals record when it lands.
        A pipeline with no ``escalate`` stage keeps the phase-12 behaviour —
        decision recorded, escalation skipped, document degraded.
        """
        decision = self._triage(pipeline, record, page, provenance)
        if decision is None:
            self._log_signals(doc_id, page, route=route, status="done")
            await self._jobs.set_page(doc_id, page_no, status="done", route=route, clear_stage=True)
            return "done"

        event = PageEvent(
            page_no=page_no,
            route=route,
            confidence=page.confidence.mean_rec,
            triage=decision.action.value,
        )
        logger.info(
            "page triaged",
            extra={"doc_id": doc_id, **asdict(event), "trigger": decision.trigger},
        )
        if decision.action is TriageAction.reject:
            # Post-OCR backstop (docs/03): input problem — never escalated.
            self._log_signals(doc_id, page, route=route, status="rejected", decision=decision)
            await self._jobs.set_page(
                doc_id,
                page_no,
                status="rejected",
                route=route,
                reason=decision.trigger,
                clear_stage=True,
                triage=decision.action.value,
                trigger=decision.trigger,
                findings=decision.findings,
            )
            return "rejected"

        escalation = None
        scheduled = False
        if decision.action is TriageAction.escalate_regions:
            scheduled = self._schedule_escalation(
                doc_id, page_no, pipeline, record, page, decision, route=route
            )
            escalation = "running" if scheduled else "skipped"
            if not scheduled:
                logger.info(
                    "escalation skipped — pipeline has no escalate stage",
                    extra={"doc_id": doc_id, "page_no": page_no, "action": decision.action.value},
                )
        if not scheduled:
            # A scheduled page logs its signals once, after the escalation
            # settles, so the record carries the outcome too (docs/03 pass 3).
            self._log_signals(doc_id, page, route=route, status="done", decision=decision)
        await self._jobs.set_page(
            doc_id,
            page_no,
            status="done",
            route=route,
            clear_stage=True,
            triage=decision.action.value,
            trigger=decision.trigger,
            findings=decision.findings,
            # An escalation nobody ran is not an accepted page: with no escalate
            # stage configured (the default since ADR 0023) the failing units are
            # flagged, never emitted as if certain (hard rule 12).
            review_required=decision.action is TriageAction.review
            or (decision.action is TriageAction.escalate_regions and not scheduled),
            escalation=escalation,
        )
        return "done"

    # -- escalation (stage 5, phase 13): schedule → call → merge → settle ---------

    def _schedule_escalation(
        self,
        doc_id: str,
        page_no: int,
        pipeline: ResolvedPipeline,
        record: JobRecord,
        page: Page,
        decision: TriageDecision,
        *,
        route: str,
    ) -> bool:
        """Start the page's escalation as a task; ``False`` = nothing to run.

        The task is owned by the per-document state and awaited before the IR is
        assembled, so an escalation can never outlive its document.
        """
        state = self._esc
        if state is None or "escalate" not in pipeline.stages:
            return False
        state.tasks.append(
            asyncio.create_task(
                self._run_escalation(doc_id, page_no, pipeline, record, page, decision, route),
                name=f"escalate-{doc_id}-p{page_no}",
            )
        )
        return True

    async def _drain_escalations(self, doc_id: str) -> None:
        """Await every scheduled escalation. A task that raised has already
        degraded its own page; log it and carry on — one provider hiccup never
        fails a document (docs/07)."""
        state = self._esc
        if state is None or not state.tasks:
            return
        results = await asyncio.gather(*state.tasks, return_exceptions=True)
        for result in results:
            if isinstance(result, BaseException):
                logger.error(
                    "escalation task failed",
                    exc_info=result,
                    extra={"doc_id": doc_id},
                )
        state.tasks.clear()

    async def _run_escalation(
        self,
        doc_id: str,
        page_no: int,
        pipeline: ResolvedPipeline,
        record: JobRecord,
        page: Page,
        decision: TriageDecision,
        route: str,
    ) -> None:
        state = self._esc
        assert state is not None
        stage = pipeline.stages["escalate"]
        runtime = self._escalation
        started = perf_counter()

        reason = self._escalation_blocker(record, state, runtime, stage.engine)
        reserved = 0
        if reason is not None:
            outcome = skipped_outcome(page, reason, considered=len(decision.regions))
        else:
            assert runtime is not None and runtime.client is not None
            reserved = max(0, min(state.regions_left, runtime.max_regions_per_page))
            state.regions_left -= reserved  # reserve before awaiting: pages overlap
            outcome = await self._call_escalator(
                doc_id, page_no, stage, record, page, decision, runtime, reserved, state
            )
            state.regions_left += reserved - len(outcome.escalations)
        ms = (perf_counter() - started) * 1000.0
        await self._settle_escalation(
            doc_id, page_no, stage, page, decision, outcome, route=route, ms=ms, state=state
        )

    def _escalation_blocker(
        self,
        record: JobRecord,
        state: _EscalationState,
        runtime: EscalationRuntime | None,
        engine: object,
    ) -> str | None:
        """Why this page will not reach the provider — ``None`` when it will.

        Every arm here is a *recorded* skip: the decision stays in the status
        document and the signals log, the page keeps its OCR content, and the
        document is served degraded (plan §7 row 5, docs/07).
        """
        if runtime is None or runtime.client is None:
            return runtime.disabled_reason if runtime else "escalation runtime unavailable"
        if record.escalation_mode == "off":
            return "escalation_off (submitted with escalation=off)"
        if not callable(getattr(engine, "run", None)):
            return "engine does not implement the escalation runner"
        if not runtime.breaker.allow():
            return "breaker_open"
        if state.regions_left <= 0:
            return "document_region_cap_reached"
        if monotonic() >= state.deadline_ts:
            return "deadline_exceeded"
        return None

    async def _call_escalator(
        self,
        doc_id: str,
        page_no: int,
        stage: ResolvedStage,
        record: JobRecord,
        page: Page,
        decision: TriageDecision,
        runtime: EscalationRuntime,
        budget: int,
        state: _EscalationState,
    ) -> EscalationOutcome:
        png_path = self._store.page_png_path(doc_id, page_no)
        try:
            page_png = await asyncio.to_thread(png_path.read_bytes)
        except OSError as exc:
            return skipped_outcome(page, f"page image unavailable: {exc}")

        resources = ResourceRegistry()
        resources.register(RESOURCE_CLIENT, runtime.client)
        resources.register(RESOURCE_PAGE_PNG, page_png)
        resources.register(RESOURCE_BREAKER, runtime.breaker)
        ctx = StageContext(
            doc_id=doc_id,
            trace_id=doc_id,
            config={
                "page_no": page_no,
                "doc_type_hint": record.doc_type_hint,
                # What this page may spend: the per-document cap and the
                # deployment ceiling, whichever bites first (§4.5).
                "region_budget": budget,
            },
            deadline=Deadline(expires_at=state.deadline_ts),
            costs=CostAccumulator(),
            resources=resources,
            logger=logger,
        )
        async with state.semaphore:
            try:
                return await cast(EscalatorEngine, stage.engine).run(page, decision, ctx)
            except Exception as exc:
                logger.exception(
                    "escalation engine failed — page degraded",
                    extra={"doc_id": doc_id, "page_no": page_no},
                )
                runtime.breaker.record_failure()
                return EscalationOutcome(
                    status="failed",
                    blocks=page.blocks,
                    escalations=(),
                    origin=page.origin,
                    reason=f"{type(exc).__name__}: {exc}",
                    review_required=True,
                    degraded=True,
                )

    async def _settle_escalation(
        self,
        doc_id: str,
        page_no: int,
        stage: ResolvedStage,
        page: Page,
        decision: TriageDecision,
        outcome: EscalationOutcome,
        *,
        route: str,
        ms: float,
        state: _EscalationState,
    ) -> None:
        """Persist the merged page, the provenance and the page slot."""
        settled = page
        if outcome.escalations:
            # docs/02 invariant 4: what was replaced stays retrievable.
            self._store.write_page_pre_escalation_ir(doc_id, page_no, canonical_json(page))
            settled = outcome.apply(page)
            state.pages[page_no] = settled
            self._store.write_page_ir(doc_id, page_no, canonical_json(settled))
            state.escalated_pages += 1
            state.escalated_regions += len(outcome.escalations)
        state.cost_inr += outcome.cost_inr
        state.provenance.append(
            ProvenanceEntry(
                stage="escalate",
                engine=stage.engine_name,
                # The result cites the prompt wording and the price table that
                # produced it, not just the engine (§4.2/§4.4).
                version=(
                    f"{getattr(stage.engine, 'version', 'unversioned')}"
                    f"+{PROMPT_TEMPLATE_VERSION}"
                    f"+price_table@{outcome.price_table_version or 'unpriced'}"
                ),
                ms=ms,
                cost_inr=outcome.cost_inr,
            )
        )
        summary: dict[str, Any] = {
            "status": outcome.status,
            "reason": outcome.reason,
            "considered": outcome.considered,
            "escalated": outcome.escalated,
            "deferred": outcome.deferred,
            "input_tokens": outcome.input_tokens,
            "output_tokens": outcome.output_tokens,
            "cost_inr": outcome.cost_inr,
            "disagreement": outcome.disagreement,
            "notes": list(outcome.notes),
            "ms": round(ms, 3),
        }
        logger.info("page escalated", extra={"doc_id": doc_id, "page_no": page_no, **summary})
        self._log_signals(
            doc_id, settled, route=route, status="done", decision=decision, escalation=summary
        )
        await self._jobs.set_page(
            doc_id,
            page_no,
            status="done",
            route=route,
            clear_stage=True,
            escalation=outcome.status,
            review_required=outcome.review_required or decision.action is TriageAction.review,
        )

    @staticmethod
    def _render_page(
        rasterizer: RasterEngine, path: Path, page_no: int, dpi: float
    ) -> tuple[bytes, int, int]:
        image = rasterizer.rasterize(path, page_no, dpi=dpi)
        return rasterizer.encode_png(image), image.width, image.height

    # -- image uploads (every page routes to OCR → pool prep) ---------------------

    async def _process_image(
        self,
        record: JobRecord,
        path: Path,
        provenance: list[ProvenanceEntry],
        deadline_ts: float,
    ) -> tuple[JobState, list[Page]]:
        doc_id = record.doc_id
        dims = record.page_dims
        if dims is None or len(dims) != record.n_pages:
            raise RuntimeError(f"ingest did not record page dimensions for {doc_id}")
        await self._jobs.init_pages(doc_id, [ROUTE_OCR] * record.n_pages)
        for page_no in range(1, record.n_pages + 1):
            event = PageEvent(page_no=page_no, route=ROUTE_OCR, confidence=0.0, triage="")
            logger.info("page routed", extra={"doc_id": doc_id, **asdict(event)})
        fallback_dims = {n: dims[n - 1] for n in range(1, record.n_pages + 1)}
        pooled, all_ok = await self._run_pool_pages(
            record,
            path,
            record.fmt,
            list(range(1, record.n_pages + 1)),
            deadline_ts,
            provenance,
            fallback_dims,
        )
        return ("done" if all_ok else "partial"), [pooled[n] for n in range(1, record.n_pages + 1)]

    # -- pool submission (stage 2 in workers; docs/07 shapes all of this) ---------

    async def _run_pool_pages(
        self,
        record: JobRecord,
        source_path: Path,
        kind: str,
        page_nos: Sequence[int],
        deadline_ts: float,
        provenance: list[ProvenanceEntry],
        fallback_dims: Mapping[int, tuple[int, int]],
    ) -> tuple[dict[int, Page], bool]:
        """Run raster pages through the worker pool; returns ``(pages, all_ok)``
        with a page per page_no and whether every page fully completed.

        In-flight is bounded by pool size (no overcommit — docs/07
        §backpressure). A crashed or failed page is marked ``failed`` with its
        reason and the rest continue (document ends ``partial``); a page whose
        pipeline has no OCR engines finishes ``pending_engine``.
        """
        doc_id = record.doc_id
        pool = self._pool
        results: dict[int, Page] = {}

        if pool is None:
            for page_no in page_nos:
                width, height = fallback_dims[page_no]
                results[page_no] = _pending_page(page_no, width, height, None)
                await self._jobs.set_page(
                    doc_id,
                    page_no,
                    status="pending_engine",
                    reason="worker pool unavailable",
                    clear_stage=True,
                )
            return results, False

        await self._jobs.set_stage_rollup(doc_id, "prep", "processing")
        started = perf_counter()
        semaphore = asyncio.Semaphore(pool.workers)

        async def run_one(page_no: int) -> tuple[int, WorkerPageResult | None, str | None]:
            async with semaphore:
                await self._jobs.set_page(doc_id, page_no, status="processing")
                try:
                    result = await pool.run_page(
                        doc_id,
                        page_no,
                        source_path,
                        kind,
                        record.pipeline_version,
                        deadline_ts,
                    )
                except WorkerCrashed as exc:
                    return page_no, None, str(exc)
                return page_no, result, None

        outcomes = await asyncio.gather(*(run_one(page_no) for page_no in page_nos))
        pipeline = self._resolved.get(record.pipeline_version)
        all_ok = True
        for page_no, result, crash_reason in outcomes:  # gather preserves page order
            if result is not None and result.page is not None:
                provenance.extend(result.provenance)
                results[page_no] = result.page
                self._store.write_page_ir(doc_id, page_no, canonical_json(result.page))
                if result.reject_reason is not None:
                    # Pre-OCR quality gate fired in the worker (phase 12): input
                    # problem — det/rec never ran (the provenance shows it).
                    all_ok = False
                    decision = TriageDecision(
                        action=TriageAction.reject, trigger=result.reject_reason
                    )
                    self._log_signals(
                        doc_id,
                        result.page,
                        route=ROUTE_OCR,
                        status="rejected",
                        decision=decision,
                    )
                    await self._jobs.set_page(
                        doc_id,
                        page_no,
                        status="rejected",
                        reason=result.reject_reason,
                        clear_stage=True,
                        triage=TriageAction.reject.value,
                        trigger=result.reject_reason,
                    )
                elif result.pending_reason is None and pipeline is not None:
                    settled = await self._settle_page(
                        doc_id,
                        page_no,
                        pipeline,
                        record,
                        result.page,
                        provenance,
                        route=ROUTE_OCR,
                    )
                    if settled != "done":
                        all_ok = False
                elif result.pending_reason is None:
                    self._log_signals(doc_id, result.page, route=ROUTE_OCR, status="done")
                    await self._jobs.set_page(doc_id, page_no, status="done", clear_stage=True)
                else:
                    all_ok = False
                    self._log_signals(doc_id, result.page, route=ROUTE_OCR, status="pending_engine")
                    await self._jobs.set_page(
                        doc_id,
                        page_no,
                        status="pending_engine",
                        reason=result.pending_reason,
                        clear_stage=True,
                    )
            else:
                all_ok = False
                if result is not None:
                    provenance.extend(result.provenance)
                reason = crash_reason if result is None else result.failure_reason
                width, height = fallback_dims[page_no]
                results[page_no] = _pending_page(page_no, width, height, None)
                self._log_signals(doc_id, results[page_no], route=ROUTE_OCR, status="failed")
                await self._jobs.set_page(
                    doc_id,
                    page_no,
                    status="failed",
                    reason=reason or "page failed in worker",
                    clear_stage=True,
                )
                logger.warning(
                    "page failed in pool",
                    extra={"doc_id": doc_id, "page_no": page_no, "reason": reason},
                )
        prep_ms = (perf_counter() - started) * 1000.0
        await self._jobs.set_stage_rollup(doc_id, "prep", "done", ms=prep_ms)
        return results, all_ok


__all__ = [
    "PENDING_REASON",
    "ROUTE_DIGITAL",
    "ROUTE_OCR",
    "Orchestrator",
    "group_blocks",
]
