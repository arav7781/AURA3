"""Pool-worker module — imported only inside spawn workers (phase 08, docs/07).

Import order is the whole point of this file and is enforced, not assumed
(CLAUDE.md rule 8): the module top level imports **stdlib only**, so that when
the spawn child unpickles :func:`worker_init` nothing heavy loads;
``worker_init`` then sets the BLAS pins *before* the first import of
numpy/cv2/onnxruntime (they read the env at load time), imports the engine
package, turns OpenCV threading off, builds the resolved pipelines from config,
warms up with one prep pass on a bundled fixture crop, and posts ``ready`` on
the progress queue. ``run_page`` rasterises/decodes **inside the worker** so
page pixel buffers never cross the process boundary — only the small,
pickle-friendly :class:`WorkerPageResult` does.

Module globals hold the per-process engine state: that is per-worker by design
(docs/07 — each worker owns its model instances), not the module-level state
docs/08 bans for engines.
"""

from __future__ import annotations

# pillow-heif ships no type stubs; the noise stays confined to the decode path here.
# pyright: reportMissingTypeStubs=false, reportUnknownMemberType=false
import logging
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:  # heavyweight types only — no runtime import before pinning
    from multiprocessing.queues import Queue as MpQueue

    import numpy as np
    import numpy.typing as npt

    from titanocr.ir import Block, Line, Page, ProvenanceEntry
    from titanocr.stages import PageImage, PageRunner, ResolvedPipeline

logger = logging.getLogger("titanocr.worker")

PIN_VARS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")
HEAVY_MODULES = ("cv2", "onnxruntime", "numpy")
_VENDOR_LOGGER_PREFIXES = ("RapidOCR", "RapidLayout", "rapidocr", "rapid_table", "rapid_layout")
"""Logger names the ONNX vendor packages create (see :func:`_quiet_vendor_logs`)."""
_VENDOR_LOGGERS = (
    "RapidOCR",
    "RapidLayout",
    "rapid_table.main",
    "rapid_table.model_processor.main",
    "rapid_table.inference_engine.base",
    "rapid_table.inference_engine.onnxruntime.main",
    "rapid_table.inference_engine.onnxruntime.provider_config",
    "rapid_layout.model_handler.main",
    "rapid_layout.model_handler.utils",
    "rapid_layout.inference_engine.base",
    "rapid_layout.inference_engine.onnxruntime.main",
    "rapid_layout.inference_engine.onnxruntime.provider_config",
)
"""The loggers the pinned vendor versions log through during session creation."""

BASE_WORKER_STAGES = ("rasterize", "prep")
"""Stages every worker must resolve (phase 08). A pipeline that cannot resolve
even these is skipped entirely."""

OCR_WORKER_STAGES = ("detect", "recognize")
"""The phase-09 OCR core. Resolved on top of the base set when the pipeline's
engines exist; when they don't (e.g. an engine name that is not registered),
the pipeline still serves prep and its pages finish ``pending_engine`` with
:data:`PENDING_REASON`."""

LAYOUT_WORKER_STAGES = ("layout", "table")
"""Phase-10/11 structure stages, tried richest-first on top of the OCR core:
layout+table, then layout alone (table candidates stay pending until phase 11),
then neither (paragraph clustering builds the blocks). A pipeline is never
dropped because a structure stage cannot resolve — structure degrades, OCR
does not (plan §7: never zero blocks)."""

WORKER_STAGES = BASE_WORKER_STAGES + OCR_WORKER_STAGES

_STAGE_TIERS = (
    WORKER_STAGES + LAYOUT_WORKER_STAGES,
    WORKER_STAGES + LAYOUT_WORKER_STAGES[:1],
    WORKER_STAGES,
    BASE_WORKER_STAGES,
)

PENDING_REASON = "ocr_unavailable (pipeline resolved without detect/recognize engines)"
"""Why a prepped page could not reach OCR — surfaced on the page slot."""

READY_EVENT = "worker_ready"
PAGE_EVENT = "page_stage"

REGION_UPSCALE = 2.0
"""A born-digital page renders at 150 DPI and the OCR route preps to 300: a
region crop is upscaled by this before detection so both routes show the
detector text at one size (phase 23, ADR 0020)."""

REGION_MARGIN_PX = 6
"""Context around a region crop, in page pixels, so a box that hugs its ink
still gives the detector an edge to see."""

_WARMUP_CROP_PX = 400


@dataclass(frozen=True)
class DigitalLayoutResult:
    """Typed regions for one born-digital page (phase 19, ADR 0017).

    The digital route has exact lines already — what it lacks is region typing,
    so a diagram's labels stop arriving as body text. Layout is a model session,
    so it runs here in a worker rather than in the orchestrator (hard rule 7).
    ``blocks`` empty with ``failure_reason`` set means the caller should keep its
    own untyped grouping: typing is an enhancement to the fast path, never a
    precondition for it.
    """

    page_no: int
    blocks: tuple[Block, ...]
    provenance: tuple[ProvenanceEntry, ...]
    failure_reason: str | None = None


@dataclass(frozen=True)
class DigitalRegionsResult:
    """OCR over the raster regions of one born-digital page (phase 23, ADR 0020).

    ``lines`` holds, per region and in request order, the ``origin=ocr`` lines
    found inside it, already in page space. An empty tuple means detection found
    no text there — the caller keeps that region as a line-less figure.
    ``failure_reason`` set means no region was OCR'd at all (no engines, deadline,
    crash); every region still comes back, as a figure. The picture is recorded
    either way — never dropped.
    """

    page_no: int
    lines: tuple[tuple[Line, ...], ...]
    provenance: tuple[ProvenanceEntry, ...]
    failure_reason: str | None = None


@dataclass(frozen=True)
class WorkerPageResult:
    """What crosses back to the parent: an assembled page or a failure reason,
    plus the worker-side provenance — never pixel buffers.

    ``pending_reason`` set (with a page present) means prep succeeded but the
    pipeline has no OCR engines — the orchestrator marks the page
    ``pending_engine`` instead of ``done``. ``reject_reason`` set (phase 12)
    means the post-prep quality gate stopped the page before det/rec ever ran
    (input problem, never escalated — docs/03); the page carries the measured
    quality and zero claimed text, and the provenance proves the prep-stop.
    """

    page_no: int
    page: Page | None
    failure_reason: str | None
    provenance: tuple[ProvenanceEntry, ...]
    pending_reason: str | None = None
    reject_reason: str | None = None


@dataclass
class _WorkerState:
    pipelines: dict[str, ResolvedPipeline]
    store: Any  # ArtifactStore — typed loosely to keep top-level imports stdlib-only
    queue: MpQueue[tuple[Any, ...]]
    pinned_before_import: bool
    warmup_ms: float


_worker_state: _WorkerState | None = None


def worker_init(
    pipeline_dir: str,
    models_dir: str,
    artifacts_dir: str,
    fixtures_dir: str,
    progress_queue: MpQueue[tuple[Any, ...]],
) -> None:
    """Executor initializer. Order matters; every step below is deliberate."""
    # 1. Pin BLAS thread pools BEFORE anything can import numpy/cv2/onnxruntime —
    #    they size their pools from these vars at import time (docs/07).
    pinned_before_import = not any(mod in sys.modules for mod in HEAVY_MODULES)
    for var in PIN_VARS:
        os.environ[var] = "1"
    _quiet_vendor_logs()

    # 2. Only now do the heavy imports (registers every engine).
    import cv2

    import titanocr.engines  # noqa: F401  # pyright: ignore[reportUnusedImport]
    from titanocr.api.artifacts import ArtifactStore
    from titanocr.stages import (
        PipelineConfigError,
        ResolvedPipeline,
        load_pipeline,
        resolve,
    )

    cv2.setNumThreads(0)

    # 3. Build the resolved pipelines this worker serves, straight from config.
    #    Configs the parent rejected at startup (hard rule 9) are skipped the
    #    same way here — a broken sibling file must not kill the pool. A
    #    pipeline whose OCR engines cannot resolve (unregistered name — e.g.
    #    a future-phase engine) still serves prep; its pages finish
    #    ``pending_engine`` honestly instead of dying here. Structure stages
    #    (layout/table) degrade tier by tier — an unresolvable layout engine
    #    must cost the paragraph-clustering path, never OCR itself.
    pipelines: dict[str, ResolvedPipeline] = {}
    for path in sorted(
        p for pattern in ("*.yaml", "*.yml") for p in Path(pipeline_dir).glob(pattern)
    ):
        try:
            config = load_pipeline(path)
        except PipelineConfigError as exc:
            logger.warning("worker skipping invalid pipeline config: %s", exc)
            continue
        resolved = None
        for tier in _STAGE_TIERS:
            try:
                resolved = resolve(config, only=tier)
                break
            except PipelineConfigError as exc:
                logger.warning(
                    "worker: stages %s unresolvable — trying a smaller set (%s)", tier, exc
                )
        if resolved is None:
            logger.warning("worker skipping invalid pipeline config: %s", path)
            continue
        # Triage resolves separately (phase 12): its quality_reject_reason gate
        # runs post-prep in this worker. Optional on purpose — a pipeline
        # without a resolvable triage engine simply has no pre-OCR gate, it
        # must never cost the OCR/structure tiers above.
        if "triage" in config.stages:
            try:
                triage_only = resolve(config, only=("triage",))
                resolved = ResolvedPipeline(
                    pipeline_version=resolved.pipeline_version,
                    stages={**resolved.stages, **triage_only.stages},
                    doc_types=resolved.doc_types,
                )
            except PipelineConfigError as exc:
                logger.warning("worker: triage unresolvable — no pre-OCR gate (%s)", exc)
        pipelines[f"{config.name}@{config.version}"] = resolved

    global _worker_state
    _worker_state = _WorkerState(
        pipelines=pipelines,
        store=ArtifactStore(Path(artifacts_dir)),
        queue=progress_queue,
        pinned_before_import=pinned_before_import,
        warmup_ms=0.0,
    )

    # 4. Warm-up: one inference-shaped pass through prep on a bundled fixture
    #    crop, so the first real page never pays cold-start cost (docs/07).
    started = time.perf_counter()
    warmup_error = _warm_up(Path(fixtures_dir))
    _worker_state.warmup_ms = (time.perf_counter() - started) * 1000.0
    _quiet_vendor_logs()

    # 5. Ready — /readyz stays 503 until every worker has posted this, and
    #    (phase 14 §4.3) a worker whose warm-up *inference* failed reports the
    #    reason: the process stays up and serving probes, the pod stays
    #    honestly unready until an operator fixes what the detail names.
    progress_queue.put(
        (READY_EVENT, os.getpid(), _worker_state.warmup_ms, pinned_before_import, warmup_error)
    )


def _quiet_vendor_logs() -> None:
    """Drop the ONNX vendors' INFO/DEBUG chatter, keep their warnings.

    Each vendor logger gets a coloured stderr handler of its own — added only to
    a logger that has none — and logs "Using engine_name: onnxruntime" once per
    session: unstructured lines in a JSON log stream. Run before the heavy
    imports, this gives the known loggers a WARNING-level stderr handler first;
    run again after warm-up, it raises the handler level of any vendor logger
    that exists by then (vendor code resets the *logger* level whenever it
    constructs an object, but handlers persist).
    """
    for name in _VENDOR_LOGGERS:
        vendor_logger = logging.getLogger(name)
        if not vendor_logger.handlers:
            vendor_logger.addHandler(logging.StreamHandler(sys.stderr))
    for name, candidate in list(logging.Logger.manager.loggerDict.items()):
        if isinstance(candidate, logging.Logger) and name.startswith(_VENDOR_LOGGER_PREFIXES):
            for handler in candidate.handlers:
                handler.setLevel(max(handler.level, logging.WARNING))


def _warm_up(fixtures_dir: Path) -> str | None:
    """Run each pipeline's prep engine once on a fixture crop (or a synthetic
    fallback when fixtures are not bundled — warm-up must never *crash* startup).

    Returns ``None`` when every engine warmed, else the first failure reason —
    reported to the parent, which fails readiness with it (§4.3).
    """
    import numpy as np

    from titanocr.stages import PageImage

    crop: Any = None
    fixture = fixtures_dir / "scanned_report.png"
    if fixture.is_file():
        import cv2

        pixels = cv2.imread(str(fixture), cv2.IMREAD_COLOR_RGB)
        if pixels is not None:
            crop = pixels[:_WARMUP_CROP_PX, :_WARMUP_CROP_PX]
    if crop is None:
        gradient = np.linspace(0, 255, _WARMUP_CROP_PX, dtype=np.uint8)
        crop = np.stack([np.tile(gradient, (_WARMUP_CROP_PX, 1))] * 3, axis=2)
        crop[100:110, 40:360] = 0  # a text-row-shaped bar so the mask paths run
    page = PageImage(width=int(crop.shape[1]), height=int(crop.shape[0]), dpi=None, pixels=crop)
    assert _worker_state is not None
    ctx = _make_ctx("warmup", None, exif_transposed=False)
    failure: str | None = None
    for version, pipeline in _worker_state.pipelines.items():
        prep = pipeline.stages.get("prep")
        if prep is None:
            continue
        detect = pipeline.stages.get("detect")
        recognize = pipeline.stages.get("recognize")
        try:
            prep_engine: Any = prep.engine
            warmed, _ = prep_engine.process(page, ctx)
            # Phase 09: exercise the ONNX sessions too — model load happens here,
            # inside warm-up (after the pins), never on the first production page.
            if detect is None or recognize is None:
                continue
            det_engine: Any = detect.engine
            rec_engine: Any = recognize.engine
            regions = det_engine.detect(warmed, ctx)
            if not regions:
                from titanocr.stages import Region

                regions = [Region(bbox=(10.0, 10.0, min(200.0, warmed.width - 1.0), 40.0))]
            rec_engine.recognize(warmed, regions[:2], ctx)
            # Structure stages: model sessions load here (after the pins), never
            # on the first production page. The table fallback (rapid-table)
            # warms too — a demo's first degraded table must not pay cold-start.
            for stage_key in ("layout", "table"):
                stage = pipeline.stages.get(stage_key)
                if stage is None:
                    continue
                for engine in (stage.engine, stage.fallback):
                    warm: Any = getattr(engine, "warm_up", None)
                    if callable(warm):
                        warm()
        except Exception as exc:
            # Warm-up must never *crash* startup — the process stays up so probes
            # keep answering — but it must not be swallowed either: the reason
            # travels to the parent and /readyz reports 503 naming it (§4.3).
            reason = f"{version}: {type(exc).__name__}: {exc}"
            logger.warning("OCR warm-up failed (%s) — worker reports unready", reason)
            failure = failure or reason
    return failure


def _make_ctx(
    doc_id: str, deadline_monotonic: float | None, *, exif_transposed: bool, page_no: int = 0
) -> Any:
    from titanocr.stages import (
        CostAccumulator,
        Deadline,
        ResourceRegistry,
        StageContext,
    )

    return StageContext(
        doc_id=doc_id,
        trace_id=doc_id,
        config={"exif_transposed": exif_transposed, "page_no": page_no},
        deadline=Deadline(expires_at=deadline_monotonic),
        costs=CostAccumulator(),
        resources=ResourceRegistry(),
        logger=logger,
    )


def worker_probe() -> dict[str, Any]:
    """Pinning/health probe — the §5 'asserted, not assumed' evidence, plus the
    RSS baseline the phase log records."""
    import resource

    import cv2

    assert _worker_state is not None, "worker_probe before worker_init"
    # ORT session evidence (phase 09 §5): the options every live OCR session was
    # actually built with, per pipeline and stage — asserted in tests.
    ort_sessions: dict[str, dict[str, Any]] = {}
    for version, pipeline in _worker_state.pipelines.items():
        for stage_key in ("detect", "recognize", "layout", "table"):
            stage = pipeline.stages.get(stage_key)
            if stage is None:
                continue
            info = getattr(stage.engine, "session_info", lambda: None)()
            if info is not None:
                ort_sessions[f"{version}:{stage_key}"] = info
            fb_info = getattr(stage.fallback, "session_info", lambda: None)()
            if fb_info is not None:
                ort_sessions[f"{version}:{stage_key}:fallback"] = fb_info
    return {
        "pid": os.getpid(),
        "env": {var: os.environ.get(var) for var in PIN_VARS},
        "cv2_num_threads": cv2.getNumThreads(),
        "pinned_before_import": _worker_state.pinned_before_import,
        "warmup_ms": _worker_state.warmup_ms,
        "ru_maxrss": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "pipelines": sorted(_worker_state.pipelines),
        "ort_sessions": ort_sessions,
    }


def worker_touch() -> int:
    """No-op used by the pool to force-spawn (and count) worker processes."""
    return os.getpid()


def run_page(
    doc_id: str,
    page_no: int,
    source_path: str,
    kind: str,
    pipeline_version: str,
    deadline_monotonic: float | None,
) -> WorkerPageResult:
    """Stage 2 for one raster page: rasterise/decode in-process, prep, artifacts.

    ``deadline_monotonic`` is a ``time.monotonic()`` timestamp from the parent —
    valid across processes on one host (CLOCK_MONOTONIC / mach_absolute_time are
    system-wide), which is what lets queue time count against the doc deadline.
    """
    from titanocr.stages import DeadlineExceeded

    assert _worker_state is not None, "run_page before worker_init"
    provenance: list[Any] = []
    try:
        pipeline = _worker_state.pipelines[pipeline_version]
    except KeyError:
        return WorkerPageResult(
            page_no=page_no,
            page=None,
            failure_reason=f"pipeline {pipeline_version!r} not resolved in worker",
            provenance=(),
        )
    try:
        return _run_page(
            doc_id, page_no, Path(source_path), kind, pipeline, deadline_monotonic, provenance
        )
    except DeadlineExceeded as exc:
        return WorkerPageResult(
            page_no=page_no,
            page=None,
            failure_reason=f"deadline exceeded: {exc}",
            provenance=tuple(provenance),
        )
    except Exception as exc:  # a page failure must never kill the worker
        logger.exception("page failed in worker", extra={"doc_id": doc_id, "page_no": page_no})
        return WorkerPageResult(
            page_no=page_no,
            page=None,
            failure_reason=f"{type(exc).__name__}: {exc}",
            provenance=tuple(provenance),
        )


def _run_page(
    doc_id: str,
    page_no: int,
    source_path: Path,
    kind: str,
    pipeline: ResolvedPipeline,
    deadline_monotonic: float | None,
    provenance: list[Any],
) -> WorkerPageResult:
    from time import perf_counter

    from titanocr.ir import ConfidenceBlock, Page, PageOrigin, ProvenanceEntry
    from titanocr.stages import DeadlineExceeded

    state = _worker_state
    assert state is not None
    queue = state.queue

    # -- decode / rasterise (inside the worker — buffers stay here) -------------
    stage_name = "raster" if kind == "pdf" else "decode"
    queue.put((PAGE_EVENT, doc_id, page_no, stage_name))
    started = perf_counter()
    raw_png: bytes | None = None
    if kind == "pdf":
        # No PNG of this render: the parent already stored the untouched display
        # render as the page's `original` variant (orchestrator, before submit).
        rasterize = pipeline.stages["rasterize"]
        engine: Any = rasterize.engine
        image = engine.rasterize(source_path, page_no)
        exif_transposed = False
        engine_name, engine_version = rasterize.engine_name, engine.version
    else:
        image, raw_png, exif_transposed = _decode_image(source_path, page_no)
        engine_name, engine_version = "pillow", _pillow_version()
    provenance.append(
        ProvenanceEntry(
            stage=stage_name,
            engine=engine_name,
            version=engine_version,
            ms=(perf_counter() - started) * 1000.0,
            cost_inr=0.0,
        )
    )
    if raw_png is not None:
        # PDFs keep the parent's untouched render as the original variant; image
        # uploads store the as-uploaded (pre-EXIF, pre-prep) decode here.
        state.store.write_page_original_png(doc_id, page_no, raw_png)

    # -- prep --------------------------------------------------------------------
    queue.put((PAGE_EVENT, doc_id, page_no, "prep"))
    ctx = _make_ctx(doc_id, deadline_monotonic, exif_transposed=exif_transposed, page_no=page_no)
    prep_stage = pipeline.stages["prep"]
    prep_engine: Any = prep_stage.engine
    started = perf_counter()
    try:
        prepped, record = prep_engine.process(image, ctx)
        prep_ms = (perf_counter() - started) * 1000.0
    except DeadlineExceeded:
        raise
    except Exception as exc:
        # Plan §7 row 2: prep failure = pass-through with applied=(), quality
        # still measured — the page continues to OCR, honestly un-prepped.
        prep_ms = (perf_counter() - started) * 1000.0
        logger.warning(
            "prep failed — passing page through un-prepped (%s: %s)",
            type(exc).__name__,
            exc,
            extra={"doc_id": doc_id, "page_no": page_no},
        )
        prepped = image
        record = _passthrough_record(image, exif_transposed=exif_transposed)
    provenance.append(
        ProvenanceEntry(
            stage="prep",
            engine=prep_stage.engine_name,
            version=str(getattr(prep_engine, "version", "unversioned")),
            ms=prep_ms,
            cost_inr=0.0,
        )
    )

    # -- post-prep PNG artifact (the page-space image the IR bboxes target) ------
    state.store.write_page_png(doc_id, page_no, _encode_png(prepped))

    # -- post-prep quality gate (phase 12): blur/resolution below floor is an
    #    input problem — the page stops here, before det/rec (provenance proves
    #    it), and is never escalated (docs/03 §when-escalation-isn't-the-answer).
    triage_stage = pipeline.stages.get("triage")
    if triage_stage is not None:
        gate = getattr(triage_stage.engine, "quality_reject_reason", None)
        reject_reason = gate(record.quality, prepped.width, prepped.height) if gate else None
        if reject_reason is not None:
            page = Page(
                page_no=page_no,
                width=prepped.width,
                height=prepped.height,
                dpi_estimate=prepped.dpi,
                origin=PageOrigin.ocr,
                prep=record.prep,
                quality=record.quality,
                confidence=ConfidenceBlock(
                    mean_rec=0.0,
                    p10_rec=0.0,
                    text_coverage=0.0,
                    low_conf_area_ratio=0.0,
                    handwriting_ratio=0.0,
                ),
                blocks=(),
            )
            return WorkerPageResult(
                page_no=page_no,
                page=page,
                failure_reason=None,
                provenance=tuple(provenance),
                reject_reason=str(reject_reason),
            )

    # -- OCR core (phase 09): detect → recognize → interim blocks → signals ------
    if "detect" in pipeline.stages and "recognize" in pipeline.stages:
        from titanocr.stages import PageRunner, StageEvent

        def emit(event: StageEvent) -> None:
            queue.put((PAGE_EVENT, doc_id, page_no, event.stage))

        queue.put((PAGE_EVENT, doc_id, page_no, "detect"))
        runner = PageRunner(pipeline, on_event=emit)
        page = runner.run(image, page_no, ctx, preprocessed=(prepped, record))
        provenance.extend(ctx.costs.snapshot())
        return WorkerPageResult(
            page_no=page_no, page=page, failure_reason=None, provenance=tuple(provenance)
        )

    # No OCR engines in this pipeline — the page is prepped, quality-measured,
    # and honestly ``pending_engine`` (zeroed confidence: nothing was recognised,
    # so nothing is claimed).
    page = Page(
        page_no=page_no,
        width=prepped.width,
        height=prepped.height,
        dpi_estimate=prepped.dpi,
        origin=PageOrigin.ocr,
        prep=record.prep,
        quality=record.quality,
        confidence=ConfidenceBlock(
            mean_rec=0.0,
            p10_rec=0.0,
            text_coverage=0.0,
            low_conf_area_ratio=0.0,
            handwriting_ratio=0.0,
        ),
        blocks=(),
    )
    return WorkerPageResult(
        page_no=page_no,
        page=page,
        failure_reason=None,
        provenance=tuple(provenance),
        pending_reason=PENDING_REASON,
    )


def run_digital_layout(
    doc_id: str,
    page_no: int,
    png_path: str,
    lines: tuple[Any, ...],
    pipeline_version: str,
    deadline_monotonic: float | None,
) -> DigitalLayoutResult:
    """Type one born-digital page's regions with the configured layout engine.

    Takes the display raster the orchestrator already rendered plus the exact
    lines the text layer already gave it, and returns blocks typed the same way
    the OCR route types them — same engine, same Protocol, same provenance.

    Never raises for a content reason. A missing layout stage, an unloadable
    model or an inference failure all come back as ``failure_reason`` with no
    blocks, and the caller keeps its untyped grouping: a born-digital page must
    still complete on a box with no models (ADR 0001's fast path stays intact).
    """
    from titanocr.engines.layout import decode_png_page
    from titanocr.stages import DeadlineExceeded, PageRunner

    assert _worker_state is not None, "run_digital_layout before worker_init"
    try:
        pipeline = _worker_state.pipelines[pipeline_version]
    except KeyError:
        return DigitalLayoutResult(
            page_no=page_no,
            blocks=(),
            provenance=(),
            failure_reason=f"pipeline {pipeline_version!r} not resolved in worker",
        )
    if "layout" not in pipeline.stages:
        return DigitalLayoutResult(
            page_no=page_no, blocks=(), provenance=(), failure_reason="no layout stage configured"
        )
    ctx = _make_ctx(doc_id, deadline_monotonic, exif_transposed=False, page_no=page_no)
    try:
        image = decode_png_page(Path(png_path).read_bytes())
        runner = PageRunner(pipeline)
        blocks = runner.build_blocks(image, list(lines), page_no, ctx)
        return DigitalLayoutResult(
            page_no=page_no,
            blocks=tuple(blocks),
            provenance=tuple(ctx.costs.snapshot()),
            failure_reason=None,
        )
    except DeadlineExceeded as exc:
        return DigitalLayoutResult(
            page_no=page_no,
            blocks=(),
            provenance=tuple(ctx.costs.snapshot()),
            failure_reason=f"deadline exceeded: {exc}",
        )
    except Exception as exc:  # typing is an enhancement — never fail the page for it
        logger.warning(
            "digital layout typing failed — keeping untyped grouping",
            extra={"doc_id": doc_id, "page_no": page_no, "error": f"{type(exc).__name__}: {exc}"},
        )
        return DigitalLayoutResult(
            page_no=page_no,
            blocks=(),
            provenance=tuple(ctx.costs.snapshot()),
            failure_reason=f"{type(exc).__name__}: {exc}",
        )


def run_digital_regions(
    doc_id: str,
    page_no: int,
    png_path: str,
    regions: tuple[tuple[float, float, float, float], ...],
    pipeline_version: str,
    deadline_monotonic: float | None,
) -> DigitalRegionsResult:
    """OCR the raster regions of one born-digital page (phase 23, ADR 0020).

    Takes the display raster the orchestrator already rendered and the regions
    it found, crops each, upscales it, and runs the pipeline's own detect +
    recognize over the crop — hard rule 1 at region scope: every raster region
    is read, and what comes back is the classification. Never raises for a
    content reason: no OCR engines, a deadline or an inference failure come back
    as ``failure_reason`` with every region intact, and the caller records each
    as a figure. A born-digital page must still complete on a box with no models.
    """
    from titanocr.engines.layout import decode_png_page
    from titanocr.stages import DeadlineExceeded, PageRunner

    assert _worker_state is not None, "run_digital_regions before worker_init"
    empty: tuple[tuple[Line, ...], ...] = tuple(() for _ in regions)
    try:
        pipeline = _worker_state.pipelines[pipeline_version]
    except KeyError:
        return DigitalRegionsResult(
            page_no=page_no,
            lines=empty,
            provenance=(),
            failure_reason=f"pipeline {pipeline_version!r} not resolved in worker",
        )
    if "detect" not in pipeline.stages or "recognize" not in pipeline.stages:
        return DigitalRegionsResult(
            page_no=page_no,
            lines=empty,
            provenance=(),
            failure_reason="no detect/recognize engines configured",
        )
    ctx = _make_ctx(doc_id, deadline_monotonic, exif_transposed=False, page_no=page_no)
    try:
        image = decode_png_page(Path(png_path).read_bytes())
        runner = PageRunner(pipeline)
        found = tuple(
            _ocr_region(runner, image, bbox, index, page_no, ctx)
            for index, bbox in enumerate(regions)
        )
        return DigitalRegionsResult(
            page_no=page_no,
            lines=found,
            provenance=tuple(ctx.costs.snapshot()),
            failure_reason=None,
        )
    except DeadlineExceeded as exc:
        return DigitalRegionsResult(
            page_no=page_no,
            lines=empty,
            provenance=tuple(ctx.costs.snapshot()),
            failure_reason=f"deadline exceeded: {exc}",
        )
    except Exception as exc:  # the pictures stay recorded — never fail the page for them
        logger.warning(
            "region OCR failed — keeping every region as a figure",
            extra={"doc_id": doc_id, "page_no": page_no, "error": f"{type(exc).__name__}: {exc}"},
        )
        return DigitalRegionsResult(
            page_no=page_no,
            lines=empty,
            provenance=tuple(ctx.costs.snapshot()),
            failure_reason=f"{type(exc).__name__}: {exc}",
        )


def _ocr_region(
    runner: PageRunner,
    image: PageImage,
    bbox: tuple[float, float, float, float],
    index: int,
    page_no: int,
    ctx: Any,
) -> tuple[Line, ...]:
    """Crop, upscale, detect + recognize, and map the lines back to page space."""
    import cv2
    import numpy as np

    from titanocr.ir import Origin
    from titanocr.stages import PageImage as RegionImage

    height, width = image.pixels.shape[:2]
    x0 = max(0, int(bbox[0]) - REGION_MARGIN_PX)
    y0 = max(0, int(bbox[1]) - REGION_MARGIN_PX)
    x1 = min(width, int(np.ceil(bbox[2])) + REGION_MARGIN_PX)
    y1 = min(height, int(np.ceil(bbox[3])) + REGION_MARGIN_PX)
    if x1 - x0 < 2 or y1 - y0 < 2:
        return ()
    scale = REGION_UPSCALE
    crop = image.pixels[y0:y1, x0:x1]
    up = cv2.resize(crop, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    region_image = RegionImage(
        width=int(up.shape[1]),
        height=int(up.shape[0]),
        dpi=(image.dpi or 150.0) * scale,
        pixels=np.ascontiguousarray(up, dtype=np.uint8),
    )
    lines = runner.recognize_region(region_image, page_no, ctx)

    def back(box: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
        bx0 = min(max(x0 + box[0] / scale, 0.0), float(width))
        by0 = min(max(y0 + box[1] / scale, 0.0), float(height))
        bx1 = min(max(x0 + box[2] / scale, bx0), float(width))
        by1 = min(max(y0 + box[3] / scale, by0), float(height))
        return (bx0, by0, bx1, by1)

    return tuple(
        line.model_copy(
            update={
                "line_id": f"p{page_no}_r{index}_l{i}",
                "bbox": back(line.bbox),
                "origin": Origin.ocr,
                "spans": tuple(sp.model_copy(update={"bbox": back(sp.bbox)}) for sp in line.spans),
            }
        )
        for i, line in enumerate(lines)
    )


def _passthrough_record(image: PageImage, *, exif_transposed: bool) -> Any:
    """Prep-failure fallback: no transforms, quality measured directly."""
    import cv2

    from titanocr.engines.prep import measure_ink_ratio
    from titanocr.ir import Prep, Quality
    from titanocr.stages import PrepRecord

    gray = cast(
        "npt.NDArray[np.uint8]",
        image.pixels if image.pixels.ndim == 2 else cv2.cvtColor(image.pixels, cv2.COLOR_RGB2GRAY),
    )
    return PrepRecord(
        prep=Prep(
            applied=("exif_transpose",) if exif_transposed else (),
            skew_deg=0.0,
            crop_bbox_in_original=None,
            scale=1.0,
        ),
        quality=Quality(
            blur_score=float(cv2.Laplacian(gray, cv2.CV_64F).var()),
            resolution_ok=True,
            is_grayscale=image.pixels.ndim == 2,
            ink_ratio=measure_ink_ratio(gray),
        ),
    )


def _decode_image(path: Path, page_no: int) -> tuple[PageImage, bytes, bool]:
    """Decode one frame of a raster upload: (EXIF-upright page, as-stored PNG,
    whether EXIF transposition was applied). Pillow's decompression-bomb guard
    stays active (plan §14) — a bomb raises and fails the page, loudly."""
    import io

    import numpy as np
    import pillow_heif
    from PIL import Image, ImageOps

    from titanocr.stages import PageImage

    pillow_heif.register_heif_opener()  # idempotent
    with Image.open(path) as img:
        if int(getattr(img, "n_frames", 1)) > 1:
            img.seek(page_no - 1)
        orientation = int(img.getexif().get(0x0112, 1))
        raw = img.convert("RGB")
        if orientation not in (0, 1):
            # Transpose the *opened* image (it still carries the EXIF tags the
            # RGB copy may have lost), then flatten to RGB.
            transposed = ImageOps.exif_transpose(img)
            assert transposed is not None
            upright = transposed.convert("RGB")
        else:
            upright = raw
        dpi_info = img.info.get("dpi")
    raw_buf = io.BytesIO()
    raw.save(raw_buf, format="PNG")
    pixels = np.asarray(upright, dtype=np.uint8)
    dpi: float | None = None
    if isinstance(dpi_info, tuple) and dpi_info:
        first = cast("tuple[object, ...]", dpi_info)[0]
        if isinstance(first, int | float) and float(first) > 0:
            dpi = float(first)
    page = PageImage(
        width=int(pixels.shape[1]), height=int(pixels.shape[0]), dpi=dpi, pixels=pixels
    )
    return page, raw_buf.getvalue(), orientation not in (0, 1)


def _encode_png(image: PageImage) -> bytes:
    import io

    from PIL import Image

    buf = io.BytesIO()
    Image.fromarray(image.pixels).save(buf, format="PNG")
    return buf.getvalue()


def _pillow_version() -> str:
    import PIL

    return str(PIL.__version__)


__all__ = [
    "BASE_WORKER_STAGES",
    "OCR_WORKER_STAGES",
    "PAGE_EVENT",
    "PENDING_REASON",
    "PIN_VARS",
    "READY_EVENT",
    "WORKER_STAGES",
    "WorkerPageResult",
    "run_page",
    "worker_init",
    "worker_probe",
    "worker_touch",
]
