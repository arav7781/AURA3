"""Demo-UI support routes (phase 07 §4.7): the bundled-samples row.

``GET /demo/samples`` lists the fixture documents; ``GET /demo/samples/{name}``
serves one file so the browser can re-upload it through the normal
``POST /v1/documents`` endpoint — the demo exercises the real API, there is no
special ingestion path. Only names enumerated from the fixtures directory are
served (no user-supplied value ever forms a path, plan §14); the static UI
itself is mounted separately in ``main.py``.
"""

import mimetypes
from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import FileResponse, JSONResponse, Response

router = APIRouter()

SAMPLE_SUFFIXES = frozenset({".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".webp", ".heic"})


def _sample_files(request: Request) -> dict[str, Path]:
    fixtures_dir: Path = request.app.state.settings.fixtures_dir
    if not fixtures_dir.is_dir():
        return {}
    return {
        p.name: p
        for p in sorted(fixtures_dir.iterdir())
        if p.is_file() and p.suffix.lower() in SAMPLE_SUFFIXES
    }


@router.get("/demo/samples")
async def list_samples(request: Request) -> Response:
    return JSONResponse(
        {
            "samples": [
                {"name": name, "bytes": path.stat().st_size, "url": f"/demo/samples/{name}"}
                for name, path in _sample_files(request).items()
            ]
        }
    )


@router.get("/demo/samples/{name}")
async def get_sample(request: Request, name: str) -> Response:
    path = _sample_files(request).get(name)
    if path is None:
        return JSONResponse(status_code=404, content={"detail": f"unknown sample {name!r}"})
    media_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return FileResponse(path, media_type=media_type, filename=path.name)


__all__ = ["SAMPLE_SUFFIXES", "router"]
