"""In-memory job table + bounded queue + dedupe index (plan §6, docs/07 §backpressure).

The table **is** the progress transport (ADR 0003 #2): the orchestrator updates
per-page ``stage`` fields as work proceeds, and ``GET /v1/documents/{id}``
serialises the record — cheap enough to poll at 500 ms, no IO involved.

Admission is bounded on *non-terminal* documents (queued + processing), not just
the queue backlog: a document being processed is still held work, and "never
accept work you cannot hold" (docs/07) is about held work. Full → callers answer
503 + ``Retry-After``.

Dedupe: ``(content_hash, pipeline_version, doc_type_hint, escalation_mode) →
doc_id`` — idempotent resubmission returns the existing document (whole-file
sha256, ADR 0003 #6; the hint joined the key in phase 12 because it changes
triage, the escalation mode in phase 13 because it changes what is delivered:
``off`` yields the degraded OCR-only result). A restart loses
non-terminal jobs and this index (accepted for v1, plan P2); terminal artifacts
survive on disk.
"""

import asyncio
import time
import uuid
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any, Literal

JobState = Literal["queued", "processing", "done", "partial", "failed", "rejected"]
PageStatus = Literal["queued", "processing", "done", "failed", "pending_engine", "rejected"]
"""``pending_engine``: the page routed to a stage that is not built yet (phase 06 —
OCR pages wait for phase 09); ``reason`` on the slot says which. The document ends
``partial``, honestly, instead of pretending the page was processed.
``rejected`` (phase 12): an input-problem page — blur/resolution below floor
pre-OCR, or the post-OCR no-text-on-inked-page backstop; never escalated."""

TERMINAL_STATES: frozenset[str] = frozenset({"done", "partial", "failed", "rejected"})


class QueueFullError(Exception):
    """Bounded admission exceeded — the route layer answers 503 + Retry-After."""


class UnknownDocumentError(KeyError):
    """No job record for that doc_id."""


@dataclass
class PageSlot:
    page_no: int
    status: PageStatus = "queued"
    route: str | None = None
    stage: str | None = None
    reason: str | None = None
    # Phase 12 — the triage verdict, exactly as decided (recorded even when the
    # escalation itself is skipped; phase 13 replaces the skip, not the record).
    triage: str | None = None
    trigger: str | None = None
    findings: tuple[str, ...] = ()
    review_required: bool = False
    escalation: str | None = None
    """Stage-5 outcome for the page (phase 13): ``running`` while a call is in
    flight, then ``done`` · ``partial`` (a unit failed or hit the cap) ·
    ``failed`` · ``skipped`` (no key, escalation off, breaker open, deadline
    gone). Anything but ``done`` marks the document ``degraded``."""


@dataclass
class StageRollup:
    stage: str
    status: Literal["queued", "processing", "done", "failed"]
    ms: float | None = None


@dataclass
class JobRecord:
    doc_id: str
    content_hash: str
    pipeline_version: str
    filename: str
    mime: str
    size_bytes: int
    fmt: str = "pdf"
    n_pages: int = 1
    page_dims: tuple[tuple[int, int], ...] | None = None
    ingest_ms: float = 0.0
    doc_type_hint: str = "auto"
    escalation_mode: str = "auto"
    """``auto`` (escalate when triage says so) or ``off`` (record the decision,
    never call a provider — the submit-form switch, plan §6)."""

    degraded: bool = False
    """At least one escalation did not fully happen — skipped (no key,
    escalation off, breaker open, deadline gone) or failed. The document is
    served, honestly marked as less than it should be."""
    state: JobState = "queued"
    pages: list[PageSlot] = field(default_factory=list[PageSlot])
    stages: list[StageRollup] = field(default_factory=list[StageRollup])
    totals_ms: float | None = None
    totals_cost_inr: float = 0.0
    escalated_pages: int = 0
    reject_reason: str | None = None
    created_at: float = field(default_factory=time.time)
    started_at: float | None = None
    finished_at: float | None = None

    def status_document(self) -> dict[str, Any]:
        """The poll payload of plan §6 — field names and shape are the contract."""
        return {
            "doc_id": self.doc_id,
            "status": self.state,
            "pipeline": self.pipeline_version,
            "content_hash": self.content_hash,
            "doc_type_hint": self.doc_type_hint,
            "degraded": self.degraded,
            "pages": [
                {
                    "page_no": p.page_no,
                    "status": p.status,
                    "route": p.route,
                    "stage": p.stage,
                    "reason": p.reason,
                    "triage": p.triage,
                    "trigger": p.trigger,
                    "findings": list(p.findings),
                    "review_required": p.review_required,
                    "escalation": p.escalation,
                }
                for p in self.pages
            ],
            "stages": [{"stage": s.stage, "status": s.status, "ms": s.ms} for s in self.stages],
            "totals": {
                "ms": self.totals_ms,
                "cost_inr": self.totals_cost_inr,
                "escalated_pages": self.escalated_pages,
            },
            "links": {
                "ir": f"/v1/documents/{self.doc_id}/ir",
                "markdown": f"/v1/documents/{self.doc_id}/markdown",
            },
            "reject_reason": self.reject_reason,
        }


class JobManager:
    def __init__(self, queue_max: int) -> None:
        self._queue_max = queue_max
        self._lock = asyncio.Lock()
        self._jobs: dict[str, JobRecord] = {}
        self._dedupe: dict[tuple[str, str, str, str], str] = {}
        # Transport only — admission is bounded by the non-terminal count under the
        # lock, so this queue must never reject a put (a finished-but-unconsumed job
        # would otherwise block a legitimately admitted one).
        self._queue: asyncio.Queue[str] = asyncio.Queue()

    async def submit(
        self,
        *,
        content_hash: str,
        pipeline_version: str,
        filename: str,
        mime: str,
        size_bytes: int,
        fmt: str = "pdf",
        n_pages: int = 1,
        page_dims: tuple[tuple[int, int], ...] | None = None,
        ingest_ms: float = 0.0,
        doc_type_hint: str = "auto",
        escalation_mode: str = "auto",
    ) -> tuple[JobRecord, bool]:
        """Admit a document; returns ``(record, created)``.

        ``created=False`` is a dedupe hit — the existing record is returned as-is.
        Raises :class:`QueueFullError` when non-terminal documents ≥ queue_max.
        The hint and the escalation mode are part of the dedupe key (phases
        12/13): the same bytes can triage differently under another hint, and
        ``escalation=off`` deliberately produces a degraded result — neither may
        be served from a cache built under the other.
        """
        async with self._lock:
            key = (content_hash, pipeline_version, doc_type_hint, escalation_mode)
            existing = self._dedupe.get(key)
            if existing is not None:
                return self._jobs[existing], False
            pending = sum(1 for j in self._jobs.values() if j.state not in TERMINAL_STATES)
            if pending >= self._queue_max:
                raise QueueFullError(
                    f"queue full: {pending} document(s) in flight (max {self._queue_max})"
                )
            doc_id = str(uuid.uuid4())
            record = JobRecord(
                doc_id=doc_id,
                content_hash=content_hash,
                pipeline_version=pipeline_version,
                filename=filename,
                mime=mime,
                size_bytes=size_bytes,
                fmt=fmt,
                n_pages=n_pages,
                page_dims=page_dims,
                ingest_ms=ingest_ms,
                doc_type_hint=doc_type_hint,
                escalation_mode=escalation_mode,
            )
            self._jobs[doc_id] = record
            self._dedupe[key] = doc_id
            self._queue.put_nowait(doc_id)
            return record, True

    def get(self, doc_id: str) -> JobRecord:
        try:
            return self._jobs[doc_id]
        except KeyError:
            raise UnknownDocumentError(doc_id) from None

    def known(self, doc_id: str) -> bool:
        return doc_id in self._jobs

    async def next_doc(self, timeout_s: float) -> str | None:
        """Next queued doc_id, or ``None`` after ``timeout_s`` of quiet."""
        try:
            return await asyncio.wait_for(self._queue.get(), timeout=timeout_s)
        except TimeoutError:
            return None

    def queue_empty(self) -> bool:
        return self._queue.empty()

    async def mark_processing(self, doc_id: str) -> None:
        async with self._lock:
            record = self.get(doc_id)
            record.state = "processing"
            record.started_at = time.time()

    async def init_pages(self, doc_id: str, routes: Sequence[str]) -> None:
        """One slot per page, each with its route (``digital``/``ocr``, phase 06 §4.5)."""
        async with self._lock:
            self.get(doc_id).pages = [
                PageSlot(page_no=n, route=route) for n, route in enumerate(routes, start=1)
            ]

    async def set_page(
        self,
        doc_id: str,
        page_no: int,
        *,
        status: PageStatus | None = None,
        route: str | None = None,
        stage: str | None = None,
        reason: str | None = None,
        clear_stage: bool = False,
        triage: str | None = None,
        trigger: str | None = None,
        findings: tuple[str, ...] | None = None,
        review_required: bool | None = None,
        escalation: str | None = None,
    ) -> None:
        """Update a page slot — this write is what a poll observes as live progress."""
        async with self._lock:
            record = self.get(doc_id)
            for slot in record.pages:
                if slot.page_no == page_no:
                    if status is not None:
                        slot.status = status
                    if route is not None:
                        slot.route = route
                    if stage is not None:
                        slot.stage = stage
                    if reason is not None:
                        slot.reason = reason
                    if clear_stage:
                        slot.stage = None
                    if triage is not None:
                        slot.triage = triage
                    if trigger is not None:
                        slot.trigger = trigger
                    if findings is not None:
                        slot.findings = findings
                    if review_required is not None:
                        slot.review_required = review_required
                    if escalation is not None:
                        slot.escalation = escalation
                    return
            raise UnknownDocumentError(f"{doc_id} has no page {page_no}")

    async def note_page_stage(self, doc_id: str, page_no: int, stage: str) -> None:
        """Fold a worker progress event (phase 08) into the slot's ``stage`` field.

        Only pages still in flight are touched: worker events race the final
        result (the queue drains on its own thread), and a late event must not
        resurrect a stage chip on a page already settled by the orchestrator.
        """
        async with self._lock:
            record = self.get(doc_id)
            for slot in record.pages:
                if slot.page_no == page_no:
                    if slot.status in ("queued", "processing"):
                        slot.status = "processing"
                        slot.stage = stage
                    return
            raise UnknownDocumentError(f"{doc_id} has no page {page_no}")

    async def set_stage_rollup(
        self,
        doc_id: str,
        stage: str,
        status: Literal["queued", "processing", "done", "failed"],
        ms: float | None = None,
    ) -> None:
        async with self._lock:
            record = self.get(doc_id)
            for entry in record.stages:
                if entry.stage == stage:
                    entry.status = status
                    entry.ms = ms
                    return
            record.stages.append(StageRollup(stage=stage, status=status, ms=ms))

    async def finish(
        self,
        doc_id: str,
        state: JobState,
        *,
        totals_ms: float | None = None,
        totals_cost_inr: float = 0.0,
        escalated_pages: int = 0,
        reject_reason: str | None = None,
        degraded: bool = False,
    ) -> None:
        async with self._lock:
            record = self.get(doc_id)
            record.state = state
            record.totals_ms = totals_ms
            record.totals_cost_inr = totals_cost_inr
            record.escalated_pages = escalated_pages
            record.reject_reason = reject_reason
            record.degraded = degraded
            record.finished_at = time.time()


__all__ = [
    "TERMINAL_STATES",
    "JobManager",
    "JobRecord",
    "JobState",
    "PageSlot",
    "PageStatus",
    "QueueFullError",
    "StageRollup",
    "UnknownDocumentError",
]
