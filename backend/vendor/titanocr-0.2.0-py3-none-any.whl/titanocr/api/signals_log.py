"""Per-page signals JSONL — the offline threshold-fitting record (docs/03).

One line per processed page, **every page, accepted or not** (including digital
ones): thresholds must be re-fittable offline without re-running OCR
(docs/03 §bootstrapping, pass 1). Files roll daily: ``var/signals/YYYY-MM-DD.jsonl``
(UTC). Since phase 12 every record also carries the triage decision + trigger +
structural findings, so the docs/03 dashboard columns (route mix, escalation
reason ranked) are derivable from this file alone.

Writes happen only from the orchestrator task (single writer), each line flushed
whole, so readers never see torn records.
"""

import json
import logging
import time
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from titanocr.ir import Page
from titanocr.stages import SIGNALS_VERSION, TriageDecision

logger = logging.getLogger("titanocr.signals")


def signal_record(
    *,
    doc_id: str,
    page: Page,
    route: str,
    status: str,
    decision: TriageDecision | None = None,
    escalation: Mapping[str, Any] | None = None,
    ts: float | None = None,
) -> dict[str, Any]:
    """One page's signal record — shared by the service log and the histogram
    batch script (eval/scripts/confidence_histogram.py) so offline artifacts and
    production logs stay one format."""
    now = time.time() if ts is None else ts
    entry: dict[str, Any] = {
        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(now)),
        "doc_id": doc_id,
        "page_no": page.page_no,
        "route": route,
        "status": status,
        "origin": page.origin.value,
        "signals_version": SIGNALS_VERSION,
        "confidence": page.confidence.model_dump(mode="json"),
        "quality": page.quality.model_dump(mode="json"),
        "n_blocks": len(page.blocks),
        "n_lines": sum(len(b.lines) for b in page.blocks if b.lines is not None),
    }
    if decision is not None:
        entry["triage"] = {
            "action": decision.action.value,
            "trigger": decision.trigger,
            "findings": list(decision.findings),
            "n_regions": len(decision.regions),
        }
    else:
        entry["triage"] = None
    # Phase 13: the escalation outcome rides along on the same line — status,
    # spend and the OCR-vs-VLM disagreement, which is docs/03 pass 3's
    # threshold-refitting signal and the health metric that matters.
    entry["escalation"] = dict(escalation) if escalation is not None else None
    return entry


class SignalsLog:
    def __init__(self, root: Path) -> None:
        self.root = root

    def log_page(
        self,
        *,
        doc_id: str,
        page: Page,
        route: str,
        status: str,
        decision: TriageDecision | None = None,
        escalation: Mapping[str, Any] | None = None,
    ) -> None:
        """Append one page's signal record; never raises (logging must not fail
        a document)."""
        now = time.time()
        entry = signal_record(
            doc_id=doc_id,
            page=page,
            route=route,
            status=status,
            decision=decision,
            escalation=escalation,
            ts=now,
        )
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            path = self.root / (time.strftime("%Y-%m-%d", time.gmtime(now)) + ".jsonl")
            with path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n")
        except OSError as exc:
            logger.warning("signals log write failed", extra={"error": str(exc)})


__all__ = ["SignalsLog", "signal_record"]
