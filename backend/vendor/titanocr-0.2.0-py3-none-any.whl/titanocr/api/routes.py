"""HTTP routes — implementation_plan.md §6, verbatim; poll-based, no streaming.

Submission is fire-and-forget-then-poll: ``POST /v1/documents`` answers 202 with
links, the client polls the status document (~500 ms while active) and fetches
per-page IR artifacts as pages complete. Uploads are untrusted (plan §14): the
body streams to a temp file under a hard size cap, the format comes from magic
bytes (never the extension or client mime), and the server-generated ``doc_id``
is the only value that ever touches a path.
"""

import asyncio
import logging
import tempfile
import uuid
from pathlib import Path
from time import perf_counter
from typing import Annotated, Any, cast

from fastapi import APIRouter, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, Response

from titanocr.api.artifacts import ArtifactStore
from titanocr.api.escalation import EscalationRuntime
from titanocr.api.ingest import IngestRejected, inspect_upload, sniff_format
from titanocr.api.jobs import TERMINAL_STATES, JobManager, JobRecord, QueueFullError
from titanocr.fields import available_labels, extract_fields
from titanocr.ir import DocumentIR, file_sha256
from titanocr.render_md import RenderOptions, ir_to_markdown
from titanocr.stages import DEFAULT_REGISTRY, STAGE_TO_KIND, EngineRegistry, PipelineConfig

logger = logging.getLogger("titanocr.api")

router = APIRouter()

RETRY_AFTER_S = "5"
_CHUNK = 1 << 20
_SNIFF_LEN = 16

_DOC_TYPE_HINTS = frozenset({"report", "note", "auto"})
_ESCALATION_MODES = frozenset({"auto", "off"})


def _jobs(request: Request) -> JobManager:
    jobs: JobManager = request.app.state.jobs
    return jobs


def _store(request: Request) -> ArtifactStore:
    store: ArtifactStore = request.app.state.store
    return store


def _pipelines(request: Request) -> dict[str, PipelineConfig]:
    pipelines: dict[str, PipelineConfig] = request.app.state.pipelines
    return pipelines


def _error(status_code: int, detail: str, **extra: Any) -> JSONResponse:
    return JSONResponse(status_code=status_code, content={"detail": detail, **extra})


def _submit_body(record: JobRecord) -> dict[str, Any]:
    doc = record.status_document()
    return {"doc_id": record.doc_id, "status": record.state, "links": doc["links"]}


@router.post("/v1/documents", status_code=202)
async def submit_document(
    request: Request,
    file: Annotated[UploadFile, File()],
    pipeline: Annotated[str, Form()] = "default",
    doc_type_hint: Annotated[str, Form()] = "auto",
    escalation: Annotated[str, Form()] = "auto",
) -> Response:
    if request.app.state.draining:
        return JSONResponse(
            status_code=503,
            content={"detail": "service is shutting down"},
            headers={"Retry-After": RETRY_AFTER_S},
        )
    if doc_type_hint not in _DOC_TYPE_HINTS:
        return _error(422, f"doc_type_hint must be one of {sorted(_DOC_TYPE_HINTS)}")
    if escalation not in _ESCALATION_MODES:
        return _error(422, f"escalation must be one of {sorted(_ESCALATION_MODES)}")
    pipelines = _pipelines(request)
    config = pipelines.get(pipeline)
    if config is None:
        return _error(422, f"unknown pipeline {pipeline!r} — loaded pipelines: {sorted(pipelines)}")

    max_bytes: int = request.app.state.settings.upload_max_bytes
    store = _store(request)
    store.ensure_root()
    incoming = store.root / ".incoming"
    incoming.mkdir(parents=True, exist_ok=True)

    size = 0
    detected: str | None = None
    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(dir=incoming, delete=False) as tmp:
            tmp_path = Path(tmp.name)
            while chunk := await file.read(_CHUNK):
                if size == 0:
                    detected = sniff_format(chunk[:_SNIFF_LEN])
                    if detected is None:
                        return _error(
                            415,
                            "unsupported format — accepted (by content, not extension): "
                            "PDF, JPEG, PNG, TIFF, WebP, HEIC",
                        )
                size += len(chunk)
                if size > max_bytes:
                    return _error(413, f"upload exceeds {max_bytes // (1024 * 1024)} MB limit")
                tmp.write(chunk)
        if size == 0 or detected is None:
            return _error(415, "empty upload")

        # Stage 0 (ingest): page enumeration + caps + encrypted-PDF reject, then the
        # whole-file hash — off the event loop; the measured ms lands in provenance.
        ingest_started = perf_counter()
        try:
            ingested = await asyncio.to_thread(
                inspect_upload,
                tmp_path,
                detected,
                page_cap=request.app.state.settings.page_cap,
            )
        except IngestRejected as exc:
            logger.info("upload rejected at ingest", extra={"reason": exc.reason})
            return _error(422, exc.reason)
        content_hash = await asyncio.to_thread(file_sha256, tmp_path)
        ingest_ms = (perf_counter() - ingest_started) * 1000.0

        filename = file.filename or f"upload.{ingested.ext}"
        try:
            record, created = await _jobs(request).submit(
                content_hash=content_hash,
                pipeline_version=f"{config.name}@{config.version}",
                filename=filename,
                mime=ingested.mime,
                size_bytes=size,
                fmt=ingested.fmt,
                n_pages=ingested.n_pages,
                page_dims=ingested.page_dims,
                ingest_ms=ingest_ms,
                doc_type_hint=doc_type_hint,
                escalation_mode=escalation,
            )
        except QueueFullError as exc:
            return JSONResponse(
                status_code=503,
                content={"detail": str(exc)},
                headers={"Retry-After": RETRY_AFTER_S},
            )
        if not created:
            logger.info("dedupe hit", extra={"doc_id": record.doc_id})
            return JSONResponse(status_code=200, content=_submit_body(record))
        store.store_original(record.doc_id, ingested.ext, tmp_path)
        tmp_path = None
        logger.info(
            "document accepted",
            extra={"doc_id": record.doc_id, "bytes": size, "format": detected},
        )
        return JSONResponse(status_code=202, content=_submit_body(record))
    finally:
        if tmp_path is not None:
            tmp_path.unlink(missing_ok=True)


@router.get("/v1/documents/{doc_id}")
async def get_status(request: Request, doc_id: str) -> Response:
    jobs = _jobs(request)
    if not jobs.known(doc_id):
        return _error(404, f"unknown document {doc_id!r}")
    return JSONResponse(jobs.get(doc_id).status_document())


def _not_ready(record: JobRecord) -> JSONResponse:
    return JSONResponse(status_code=404, content={"status": record.state})


@router.get("/v1/documents/{doc_id}/ir")
async def get_ir(request: Request, doc_id: str) -> Response:
    jobs = _jobs(request)
    if not jobs.known(doc_id):
        return _error(404, f"unknown document {doc_id!r}")
    record = jobs.get(doc_id)
    path = _store(request).ir_path(doc_id)
    if record.state not in TERMINAL_STATES or not path.is_file():
        return _not_ready(record)
    return FileResponse(path, media_type="application/json")


@router.get("/v1/documents/{doc_id}/markdown")
async def get_markdown(request: Request, doc_id: str, anchors: bool = False) -> Response:
    """The Markdown projection of the document IR.

    ``anchors=1`` re-projects the *same* IR with a ``<!-- block: {block_id} -->``
    comment before every block, so a consumer can map rendered text back to the
    IR block that produced it — and from there to its bbox, confidence and
    origin. The demo UI reads this variant to link a box on the page image to
    the text it produced, in both directions. The stored artifact, and what
    every other caller gets, is unchanged; anchors are addressing, never
    content (Markdown is still a projection, never an extraction source).
    """
    jobs = _jobs(request)
    if not jobs.known(doc_id):
        return _error(404, f"unknown document {doc_id!r}")
    record = jobs.get(doc_id)
    store = _store(request)
    if anchors:
        # Rendered on demand from the IR rather than stored: pure, cheap and
        # deterministic, and it keeps one Markdown artifact on disk per document.
        ir_path = store.ir_path(doc_id)
        if record.state not in TERMINAL_STATES or not ir_path.is_file():
            return _not_ready(record)
        ir = DocumentIR.model_validate_json(ir_path.read_bytes())
        return PlainTextResponse(
            ir_to_markdown(ir, RenderOptions(block_anchors=True)), media_type="text/markdown"
        )
    path = store.markdown_path(doc_id)
    if record.state not in TERMINAL_STATES or not path.is_file():
        return _not_ready(record)
    return PlainTextResponse(path.read_text(encoding="utf-8"), media_type="text/markdown")


MAX_FIELDS = 64
"""A request asking for more names than this is not a lookup, it is a scrape."""


@router.post("/v1/documents/{doc_id}/fields")
async def post_fields(request: Request, doc_id: str) -> Response:
    """Named fields, as JSON key-value, each with the OCR it was read from.

    Body: ``{"fields": ["PNR", "Total Fare"], "include_raw_ocr": false}``.
    ``GET`` with no body is not offered on purpose — field names contain
    spaces, slashes and colons, and a query string is the wrong place for
    document text.

    Every hit carries ``value`` plus the provenance the IR already holds for it:
    ``raw_text`` (what the engine actually read), ``bbox``, ``confidence``,
    ``origin``, ``page_no`` and ``block_id``. A name whose label is not printed
    on the page comes back ``value: null`` with a reason — never a guess
    (hard rule 12). ``include_raw_ocr`` adds the document's full line-level
    transcription alongside, so one response carries both the answer and the
    text it was taken from.

    Extraction is a *consumer* of the IR, not a pipeline stage (ADR 0013): this
    reads the finished artifact and cannot influence what the engine read.
    """
    jobs = _jobs(request)
    if not jobs.known(doc_id):
        return _error(404, f"unknown document {doc_id!r}")
    record = jobs.get(doc_id)
    ir_path = _store(request).ir_path(doc_id)
    if record.state not in TERMINAL_STATES or not ir_path.is_file():
        return _not_ready(record)
    try:
        parsed: Any = await request.json()
    except Exception:
        return _error(422, 'body must be JSON: {"fields": ["name", ...]}')
    if not isinstance(parsed, dict):
        return _error(422, "body must be a JSON object")
    body = cast("dict[str, Any]", parsed)
    raw_names: Any = body.get("fields")
    if not isinstance(raw_names, list) or not raw_names:
        return _error(422, "'fields' must be a non-empty list of names")
    items = cast("list[Any]", raw_names)
    if len(items) > MAX_FIELDS:
        return _error(422, f"at most {MAX_FIELDS} fields per request, got {len(items)}")
    names = [n for n in items if isinstance(n, str) and n.strip()]
    if not names:
        return _error(422, "'fields' must hold at least one non-empty name")

    ir = DocumentIR.model_validate_json(ir_path.read_bytes())
    result = extract_fields(ir, names, include_raw_ocr=bool(body.get("include_raw_ocr")))
    payload = result.as_json()
    # A miss is far easier to act on with the list of names that would have
    # worked, so an all-miss response says what the document does offer.
    if payload["found"] == 0:
        payload["available_labels"] = list(available_labels(ir))[:200]
    return JSONResponse(payload)


@router.get("/v1/documents/{doc_id}/fields/labels")
async def get_field_labels(request: Request, doc_id: str) -> Response:
    """Every label this document prints — the vocabulary ``/fields`` accepts."""
    jobs = _jobs(request)
    if not jobs.known(doc_id):
        return _error(404, f"unknown document {doc_id!r}")
    record = jobs.get(doc_id)
    ir_path = _store(request).ir_path(doc_id)
    if record.state not in TERMINAL_STATES or not ir_path.is_file():
        return _not_ready(record)
    ir = DocumentIR.model_validate_json(ir_path.read_bytes())
    labels = available_labels(ir)
    return JSONResponse({"doc_id": doc_id, "count": len(labels), "labels": list(labels)})


@router.get("/v1/documents/{doc_id}/pages/{page_no}/ir")
async def get_page_ir(
    request: Request, doc_id: str, page_no: int, variant: str = "final"
) -> Response:
    """Per-page IR — available as soon as that page completes (the UI's live-boxes source).

    ``variant=pre_escalation`` serves the page as OCR delivered it, kept
    whenever a VLM escalation replaced blocks (docs/02 invariant 4 — the
    pre-escalation content is never lost). 404 when the page was never
    escalated; the OCR-vs-VLM diff in the demo reads exactly this pair.
    """
    if variant not in ("final", "pre_escalation"):
        return _error(422, "variant must be 'final' or 'pre_escalation'")
    jobs = _jobs(request)
    if not jobs.known(doc_id):
        return _error(404, f"unknown document {doc_id!r}")
    record = jobs.get(doc_id)
    store = _store(request)
    path = (
        store.page_pre_escalation_ir_path(doc_id, page_no)
        if variant == "pre_escalation"
        else store.page_ir_path(doc_id, page_no)
    )
    if not path.is_file():
        return _not_ready(record)
    return FileResponse(path, media_type="application/json")


@router.get("/v1/documents/{doc_id}/pages/{page_no}/image")
async def get_page_image(
    request: Request, doc_id: str, page_no: int, variant: str = "prep"
) -> Response:
    if variant not in ("prep", "original"):
        return _error(422, "variant must be 'prep' or 'original'")
    jobs = _jobs(request)
    if not jobs.known(doc_id):
        return _error(404, f"unknown document {doc_id!r}")
    record = jobs.get(doc_id)
    store = _store(request)
    # `prep` is the page-space image the IR bboxes target (plan §7 coordinate
    # rule): the post-prep PNG for pool-processed pages, the display render for
    # digital pages (which have no prep). `original` serves the untouched
    # render/decode where one was preserved (phase 08) and falls back to the
    # page PNG for digital pages, where the two are the same image.
    path = store.page_png_path(doc_id, page_no)
    if variant == "original":
        original = store.page_original_png_path(doc_id, page_no)
        if original.is_file():
            path = original
    if not path.is_file():
        return _not_ready(record)
    return FileResponse(path, media_type="image/png")


@router.get("/v1/pipelines")
async def list_pipelines(request: Request) -> Response:
    pipelines = _pipelines(request)
    return JSONResponse(
        {
            "pipelines": [
                {"name": c.name, "version": c.version, "id": f"{c.name}@{c.version}"}
                for c in sorted(pipelines.values(), key=lambda c: c.name)
            ]
        }
    )


@router.get("/healthz")
async def healthz() -> Response:
    """Process alive — always cheap, independent of worker saturation (docs/07 §probes)."""
    return JSONResponse({"status": "ok"})


@router.get("/readyz")
async def readyz(request: Request) -> Response:
    """The startup self-check, reported check by check (phase 14 §4.3).

    Four gates, each named in the body so an operator never has to read logs to
    learn *what* is missing: pipeline configs parse and resolve against the
    registry, every referenced model is present with a matching checksum (done
    once at startup — server variants are ~85 MB and probes are frequent), the
    artifacts dir is writable *now* (re-probed per call), and every pool worker
    is warm with its warm-up inference having succeeded (docs/07 §warm-up: a
    cold pod that passes readiness times out on its first burst).

    Escalation *state* is reported but never fails the check (docs/07 §failure
    isolation — a provider outage degrades documents, it must not take the pod
    out of service). Escalation *config* is different: a pipeline that declares
    an ``escalate`` stage with no endpoint configured is a startup config error
    and fails ``pipeline_config`` (hard rule 9, ADR 0023 — the stage is opt-in,
    so declaring it and not configuring it can only be a mistake). Unresolvable
    engine names for stages this build does not implement stay informational in
    ``missing_engines``.
    """
    checks: list[dict[str, Any]] = []
    errors: list[str] = []

    def record(name: str, details: list[str], *, fatal: bool = True, **extra: Any) -> None:
        checks.append({"check": name, "ok": not details, "details": details, **extra})
        if fatal:
            errors.extend(details)

    pipelines = _pipelines(request)
    config_errors: list[str] = list(request.app.state.pipeline_errors)
    if not pipelines and not config_errors:
        config_errors.append(
            f"no pipeline configs found in {request.app.state.settings.pipeline_dir}"
        )
    missing = _missing_engines(pipelines, DEFAULT_REGISTRY)
    record(
        "pipeline_config",
        config_errors,
        pipelines=sorted(f"{c.name}@{c.version}" for c in pipelines.values()),
        missing_engines=missing,
    )
    record("models", list(request.app.state.model_errors))

    store = _store(request)
    artifact_errors: list[str] = []
    try:
        store.ensure_root()
        probe = store.root / f".readyz-{uuid.uuid4().hex}"
        probe.write_bytes(b"")
        probe.unlink()
    except OSError as exc:
        artifact_errors.append(f"artifacts dir not writable: {exc}")
    record("artifacts_dir", artifact_errors, path=str(store.root))

    pool = request.app.state.pool
    workers: dict[str, Any] | None = None
    worker_errors: list[str] = []
    if pool is not None:
        warmup_failures = pool.warmup_failures
        workers = {
            "ready": pool.ready_count,
            "total": pool.workers,
            "crashes": pool.crash_count,
            "warmup_failures": {
                str(pid): reason for pid, reason in sorted(warmup_failures.items())
            },
        }
        if pool.last_error is not None:
            worker_errors.append(f"worker pool: {pool.last_error}")
        elif not pool.ready:
            worker_errors.append(
                f"worker pool warming: {pool.ready_count}/{pool.workers} workers ready"
            )
        worker_errors.extend(
            f"worker {pid} warm-up inference failed: {reason}"
            for pid, reason in sorted(warmup_failures.items())
        )
    elif pipelines:
        worker_errors.append("worker pool not started")
    record("workers", worker_errors, workers=workers)

    escalation: EscalationRuntime | None = getattr(request.app.state, "escalation", None)
    status = escalation.status() if escalation is not None else None
    checks.append({"check": "escalation", "ok": True, "details": [], "escalation": status})

    body: dict[str, Any] = {
        "ready": not errors,
        "pipelines": sorted(f"{c.name}@{c.version}" for c in pipelines.values()),
        "missing_engines": missing,
        "workers": workers,
        "escalation": status,
        "checks": checks,
        "errors": errors,
    }
    return JSONResponse(status_code=200 if not errors else 503, content=body)


def _missing_engines(
    pipelines: dict[str, PipelineConfig], registry: EngineRegistry
) -> dict[str, list[str]]:
    """Engine names each pipeline references that nothing has registered (yet)."""
    missing: dict[str, list[str]] = {}
    for config in pipelines.values():
        absent: list[str] = []
        for stage_key, spec in config.stages.items():
            kind = STAGE_TO_KIND[stage_key]
            names = registry.names(kind)
            for engine in (spec.engine, spec.fallback):
                if engine is not None and engine not in names:
                    absent.append(f"{stage_key}:{engine}")
        if absent:
            missing[f"{config.name}@{config.version}"] = sorted(absent)
    return missing


__all__ = ["RETRY_AFTER_S", "router"]
