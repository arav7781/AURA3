"""HTTP surface (phase 05)."""
