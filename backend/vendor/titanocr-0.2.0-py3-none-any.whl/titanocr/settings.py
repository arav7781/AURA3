"""Runtime settings — the env table of implementation_plan.md §13, validated at startup.

Pipeline YAML is the *what*; these are the *how much*. Every value is logged at
startup with secrets redacted (:meth:`Settings.redacted`). The ``OCR_VLM_*``
group configures the escalation stage (phase 13): endpoint/model/key plus the
caps, timeouts and breaker limits that keep a provider from blocking or
out-spending the pipeline (docs/07 §failure isolation).
"""

import os
from pathlib import Path
from typing import Any

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


def _default_workers() -> int:
    return max(1, (os.cpu_count() or 2) - 1)


class Settings(BaseSettings):
    """Env-driven service configuration (prefix ``OCR_``, plan §13 defaults)."""

    model_config = SettingsConfigDict(env_prefix="OCR_", frozen=True)

    workers: int = Field(default_factory=_default_workers, ge=1)
    """Pool size (phase 08); ``workers x intra_op(=1) <= CPU limit``."""

    queue_max: int = Field(default=32, ge=1)
    """Bounded admission: queued + processing documents past this → 503 + Retry-After."""

    upload_max_mb: int = Field(default=50, ge=1)
    page_cap: int = Field(default=200, ge=1)
    doc_deadline_s: float = Field(default=300, gt=0)
    pipeline_dir: Path = Path("pipelines")
    models_dir: Path = Path("models")
    artifacts_dir: Path = Path("var/artifacts")
    signals_dir: Path = Path("var/signals")
    """Per-page signals JSONL, one file per UTC day (docs/03 — logged for every
    page so triage thresholds can be re-fit offline without re-running OCR)."""
    fixtures_dir: Path = Path("fixtures/documents")
    """Bundled sample documents the demo UI's samples row lists (phase 07);
    clicked samples upload through the normal ``POST /v1/documents`` path."""
    log_level: str = "INFO"

    vlm_base_url: str | None = None
    vlm_model: str | None = None
    vlm_api_key: SecretStr | None = None
    """All three unset-safe: without base_url + model + key the escalator records
    its decisions, skips every call and marks the document ``degraded`` (plan P5 —
    the demo works without secrets)."""

    vlm_max_regions_per_page: int = Field(default=3, ge=0)
    """Deployment ceiling on the docs/03 escalation budget. The pipeline's own
    ``max_regions_per_page`` is the config default; the smaller of the two wins,
    so an environment can tighten spend without editing a pipeline."""

    vlm_max_regions_per_doc: int = Field(default=12, ge=0)
    """Per-document region cap (phase 13 §4.5) — a malformed batch upload must
    not be able to run up the bill (docs/03 §the escalation budget)."""

    vlm_concurrency: int = Field(default=2, ge=1)
    """In-flight escalation calls per document (phase 13 §4.6)."""

    vlm_timeout_s: float = Field(default=60, gt=0)
    vlm_max_retries: int = Field(default=2, ge=0)
    """Bounded retries with backoff on 429/5xx; never unbounded (docs/07)."""

    vlm_breaker_threshold: int = Field(default=5, ge=1)
    vlm_breaker_cooldown_s: float = Field(default=60, gt=0)

    @property
    def upload_max_bytes(self) -> int:
        return self.upload_max_mb * 1024 * 1024

    def redacted(self) -> dict[str, Any]:
        """Startup-loggable dump: secrets replaced, paths stringified."""
        out: dict[str, Any] = {}
        for name, value in self.model_dump().items():
            if isinstance(value, SecretStr):
                value = "***redacted***"
            elif isinstance(value, Path):
                value = str(value)
            out[name] = value
        return out


__all__ = ["Settings"]
