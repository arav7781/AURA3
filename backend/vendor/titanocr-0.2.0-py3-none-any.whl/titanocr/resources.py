"""Where the shipped configuration lives: inside a wheel, or in a source checkout.

The pipeline YAMLs and the model manifest are repository files (``pipelines/``,
``models/MANIFEST.json``) that the wheel build copies into ``titanocr/_resources/``
(``pyproject.toml`` force-include). A source checkout has no ``_resources`` and
reads the repository files directly, so ``uv run`` and an installed wheel see the
same bytes and neither needs the other.
"""

from pathlib import Path

_PACKAGE_DIR = Path(__file__).resolve().parent
_WHEEL_RESOURCES = _PACKAGE_DIR / "_resources"


def source_checkout_root() -> Path | None:
    """The repository root when running from a source checkout, else ``None``."""
    root = _PACKAGE_DIR.parent.parent  # src/titanocr -> repository root
    if (root / "pyproject.toml").is_file() and (root / "pipelines").is_dir():
        return root
    return None


def _resource(*parts: str) -> Path:
    shipped = _WHEEL_RESOURCES.joinpath(*parts)
    if shipped.exists():
        return shipped
    root = source_checkout_root()
    if root is not None and root.joinpath(*parts).exists():
        return root.joinpath(*parts)
    raise FileNotFoundError(
        f"titanocr resource {'/'.join(parts)} not found in {_WHEEL_RESOURCES} or a source "
        "checkout — the installation is incomplete"
    )


def pipelines_dir() -> Path:
    """The directory of shipped pipeline configs (``default.yaml``, ``with-vlm.yaml``)."""
    return _resource("pipelines")


def model_manifest_path() -> Path:
    """The model manifest: every model's URL and pinned sha256."""
    return _resource("models", "MANIFEST.json")


__all__ = ["model_manifest_path", "pipelines_dir", "source_checkout_root"]
