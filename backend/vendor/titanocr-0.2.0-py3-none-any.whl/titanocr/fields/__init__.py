"""Named-field lookup over the Document IR (ADR 0013).

A consumer of the IR, in the same layer as ``render_md``: it imports ``ir`` and
nothing else, and runs after a document is finished. See
:mod:`titanocr.fields.extract` for the four lookup rules and why each one
abstains rather than guesses.
"""

from titanocr.fields.extract import (
    EXTRACTOR_VERSION,
    ExtractionResult,
    FieldHit,
    Provenance,
    available_labels,
    extract_fields,
    normalise,
)

__all__ = [
    "EXTRACTOR_VERSION",
    "ExtractionResult",
    "FieldHit",
    "Provenance",
    "available_labels",
    "extract_fields",
    "normalise",
]
