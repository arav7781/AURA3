"""Named-field lookup over the Document IR (ADR 0013).

You name the fields you want; this finds each one in the IR and hands back its
value **with the pixels it came from** — raw OCR text, bbox, confidence, origin,
page and block. That is the whole point: a value without provenance is a bare
string, and the IR exists precisely so no value is ever that (hard rule 3).

This is a *consumer* of the IR, not a pipeline stage. It imports ``ir`` and
nothing else, sits in the same layer as ``render_md``, and runs after a document
is finished — it cannot influence what the engine reads. Adding it moves a line
CLAUDE.md had drawn at "downstream extraction is permanently out of scope"; ADR
0013 records that decision and its limits.

**How a field is found.** Four deterministic strategies, tried in this order,
and the first that matches wins. Every one of them is a lookup of a *label the
document actually prints* — none infers a value from meaning:

1. ``kv`` block rows — the IR's own ``label: value`` type.
2. Table cells — a label cell with its value in the neighbouring cell, right
   first (``| PNR | 8606244147 |``) then below (a column heading over its value).
3. Inline ``label: value`` inside one line (``Transaction ID: 1000043377042``).
4. Spatial neighbour — a label line with the value to its right on the same
   band, or centred beneath it, which is how a form without ruling reads.

**Abstention is the default.** A field whose label is not printed on the page
comes back ``value: null`` with a reason, never a guess (hard rule 12). Label
matching is exact-after-normalisation first, then a contains/prefix match, then
nothing — no fuzzy scoring, no nearest-neighbour, because a wrong value that
looks confident is worse than an honest miss.

Deterministic by construction: blocks and lines are walked in IR order, ties
break on geometry, and the same IR always produces byte-identical output.
"""

import re
from collections.abc import Iterable, Iterator, Sequence
from dataclasses import dataclass
from typing import Any

from titanocr.ir import Block, BlockType, Cell, DocumentIR, Line, Page

EXTRACTOR_VERSION = "fields-1.0"
"""Bumped whenever a strategy changes what a given IR yields — the output names
it, so a stored result always says which rules produced it."""

BBox = tuple[float, float, float, float]

_PUNCT = re.compile(r"[^\w\s]+", re.UNICODE)
_WS = re.compile(r"\s+")
_INLINE_KV = re.compile(r"^\s*(?P<label>[^:]{1,64}?)\s*[::]\s*(?P<value>\S.*)$")


def normalise(text: str) -> str:
    """A label reduced to what makes it the same label.

    Case, punctuation and run-length of whitespace are all things a document
    varies freely — ``PNR / Roll No.`` and ``pnr roll no`` name one field. The
    words and their order are what carry the identity, so those are what is kept.
    """
    return _WS.sub(" ", _PUNCT.sub(" ", text.casefold())).strip()


@dataclass(frozen=True)
class Provenance:
    """Where a value came from, in the terms the IR uses everywhere else."""

    page_no: int
    block_id: str
    bbox: BBox
    confidence: float
    origin: str
    raw_text: str
    """The OCR text of the unit the value was read from, verbatim and untrimmed
    of anything but surrounding whitespace — the answer to "what did the engine
    actually see", which is the half of this that is not a guess."""

    label_text: str
    label_bbox: BBox | None


@dataclass(frozen=True)
class FieldHit:
    name: str
    value: str | None
    strategy: str | None = None
    """Which of the four rules found it — ``kv`` · ``table_cell`` · ``inline`` ·
    ``neighbour`` — so a surprising answer can be traced to the rule that gave it."""

    provenance: Provenance | None = None
    reason: str | None = None
    """Why there is no value. Set only when ``value`` is None."""

    alternatives: tuple[Provenance, ...] = ()
    """Other places the same label was found. A label printed twice is a real
    ambiguity in the document; reporting the first and listing the rest is more
    honest than picking one silently."""

    def as_json(self) -> dict[str, Any]:
        if self.value is None:
            return {"value": None, "reason": self.reason or "not found"}
        assert self.provenance is not None
        out: dict[str, Any] = {
            "value": self.value,
            "strategy": self.strategy,
            "raw_text": self.provenance.raw_text,
            "confidence": round(self.provenance.confidence, 4),
            "origin": self.provenance.origin,
            "page_no": self.provenance.page_no,
            "block_id": self.provenance.block_id,
            "bbox": [round(v, 1) for v in self.provenance.bbox],
            "label": {
                "text": self.provenance.label_text,
                "bbox": (
                    [round(v, 1) for v in self.provenance.label_bbox]
                    if self.provenance.label_bbox
                    else None
                ),
            },
        }
        if self.alternatives:
            out["alternatives"] = [
                {
                    "value": p.raw_text,
                    "page_no": p.page_no,
                    "block_id": p.block_id,
                    "bbox": [round(v, 1) for v in p.bbox],
                    "confidence": round(p.confidence, 4),
                }
                for p in self.alternatives
            ]
        return out


@dataclass
class _Candidate:
    strategy: str
    value: str
    prov: Provenance


@dataclass(frozen=True)
class ExtractionResult:
    doc_id: str
    """Stringified at construction: the IR carries a UUID and this is a JSON
    payload, so the conversion belongs here rather than at every call site."""

    fields: tuple[FieldHit, ...]
    raw_ocr: tuple[dict[str, Any], ...] = ()
    extractor_version: str = EXTRACTOR_VERSION
    ir_version: str = ""

    def as_json(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "doc_id": self.doc_id,
            "extractor_version": self.extractor_version,
            "ir_version": self.ir_version,
            "fields": {hit.name: hit.as_json() for hit in self.fields},
            "found": sum(1 for hit in self.fields if hit.value is not None),
            "requested": len(self.fields),
        }
        if self.raw_ocr:
            out["raw_ocr"] = list(self.raw_ocr)
        return out


# -- the four strategies ---------------------------------------------------------


def _lines_of(block: Block) -> tuple[Line, ...]:
    return block.lines or ()


def _prov(
    page: Page,
    block: Block,
    bbox: BBox,
    confidence: float,
    origin: str,
    raw: str,
    label: str,
    label_bbox: BBox | None,
) -> Provenance:
    return Provenance(
        page_no=page.page_no,
        block_id=block.block_id,
        bbox=bbox,
        confidence=confidence,
        origin=origin,
        raw_text=raw,
        label_text=label,
        label_bbox=label_bbox,
    )


def _inline_candidates(page: Page, block: Block) -> Iterator[tuple[str, _Candidate]]:
    """Rule 3 (and rule 1, since a ``kv`` block's rows are the same shape).

    One line carrying ``label: value``. The first colon splits — a value may
    contain colons (a time, a URL), a label may not, and that asymmetry is what
    makes the split safe.
    """
    strategy = "kv" if block.type is BlockType.kv else "inline"
    for line in _lines_of(block):
        m = _INLINE_KV.match(line.text)
        if not m:
            continue
        label, value = m.group("label").strip(), m.group("value").strip()
        if not label or not value:
            continue
        yield (
            normalise(label),
            _Candidate(
                strategy,
                value,
                _prov(
                    page,
                    block,
                    line.bbox,
                    line.confidence,
                    str(line.origin),
                    line.text.strip(),
                    label,
                    line.bbox,
                ),
            ),
        )


def _row_cells(grid: dict[tuple[int, int], Cell], row: int) -> list[Cell]:
    """Populated cells of one row, left to right."""
    return sorted(
        (c for (r, _), c in grid.items() if r == row and c.text.strip()),
        key=lambda c: c.col,
    )


def _table_value_for(grid: dict[tuple[int, int], Cell], cell: Cell) -> Cell | None:
    """The cell that holds this label's value, or None.

    Three shapes, because a real form uses all three and picking the wrong one
    returns a neighbouring *label* as if it were a value:

    1. **The cell immediately right**, when it has text — ``Invoice Number |
       PS238…``, and equally ``Wall Thickness | 10.9 | mm``, a record row whose
       first column is its label.
    2. **The only other populated cell in the row**, when the one to the right is
       empty — ``Ticket Fare | | ₹790.00``, where the blank is the form's own
       spacing and not a column of its own.
    3. **The cell below**, when the right is empty and the row holds three or
       more labels — ``PNR | Train No./Name | Class`` is a heading band, and its
       values are underneath.

    Order is the whole rule, and both orderings were wrong before this one: rule
    3 ahead of rule 1 reads a data row's next *column* as its value (``Wall
    Thickness`` → ``Bore Diameter``), and rule 3 ahead of rule 2 reads the label
    under ``Ticket Fare`` as its value. Right-first with a populated-neighbour
    test is what separates them, because a heading band in a geometric table is
    sparse — the engine's column boundaries come from ink, so headings do not sit
    shoulder to shoulder.
    """
    right = grid.get((cell.row, cell.col + cell.col_span))
    if right is not None and right.text.strip():
        return right
    row = _row_cells(grid, cell.row)
    others = [c for c in row if c is not cell]
    if len(others) == 1:
        return others[0]
    below = grid.get((cell.row + cell.row_span, cell.col))
    if len(row) >= 3 and below is not None and below.text.strip():
        return below
    return None


def _table_candidates(page: Page, block: Block) -> Iterator[tuple[str, _Candidate]]:
    """Rule 2: a label cell paired with the cell that holds its value."""
    table = block.table
    if table is None:
        return
    grid = {(c.row, c.col): c for c in table.cells}
    for cell in table.cells:
        label = cell.text.strip()
        if not label:
            continue
        value_cell = _table_value_for(grid, cell)
        if value_cell is None:
            continue
        yield (
            normalise(label),
            _Candidate(
                "table_cell",
                value_cell.text.strip(),
                _prov(
                    page,
                    block,
                    value_cell.bbox,
                    value_cell.confidence,
                    str(value_cell.origin),
                    value_cell.text.strip(),
                    label,
                    cell.bbox,
                ),
            ),
        )


_COLONS = ":\uff1a"
"""ASCII and fullwidth colon — a CJK-authored form prints the second one."""

_ROW_BAND = 0.6
"""Two lines belong to one visual row when their y-centres are within this
fraction of the taller line's height — the same rule the renderer groups rows by."""

_MAX_GAP_RATIO = 6.0
"""A value further than this many label-heights away is not this label's value."""


def _neighbour_candidates(page: Page, block: Block) -> Iterator[tuple[str, _Candidate]]:
    """Rule 4: an unruled form — the label with its value beside or beneath it.

    Only fires for a label that ends in a colon or is followed by exactly one
    line in its band. Without that, every word on a page becomes a label for the
    word next to it.
    """
    lines = sorted(_lines_of(block), key=lambda ln: (ln.bbox[1], ln.bbox[0]))
    for i, line in enumerate(lines):
        label = line.text.strip()
        if not label or _INLINE_KV.match(line.text):
            continue  # rule 3 owns this one
        stripped = label.rstrip(_COLONS).strip()
        if not stripped:
            continue
        height = max(1.0, line.bbox[3] - line.bbox[1])
        centre = (line.bbox[1] + line.bbox[3]) / 2.0
        # Everything to the right on this band, gap ignored — the *count* is what
        # says whether this is a label with a value or one cell of a value row,
        # and a distance cut applied before counting would hide the third cell
        # and turn a row of values into a label/value pair.
        same_band = [
            other
            for other in lines[i + 1 :]
            if abs((other.bbox[1] + other.bbox[3]) / 2.0 - centre) <= _ROW_BAND * height
            and other.bbox[0] >= line.bbox[2]
        ]
        if not label.endswith(tuple(_COLONS)) and len(same_band) != 1:
            continue
        if not same_band:
            continue
        value_line = same_band[0]
        if value_line.bbox[0] - line.bbox[2] > _MAX_GAP_RATIO * height:
            continue  # too far to be this label's value
        yield (
            normalise(stripped),
            _Candidate(
                "neighbour",
                value_line.text.strip(),
                _prov(
                    page,
                    block,
                    value_line.bbox,
                    value_line.confidence,
                    str(value_line.origin),
                    value_line.text.strip(),
                    stripped,
                    line.bbox,
                ),
            ),
        )


def _index(ir: DocumentIR) -> dict[str, list[_Candidate]]:
    """Every ``label -> value`` the document prints, keyed by normalised label.

    Built once per extraction and walked in IR order, so the first candidate for
    a label is always the earliest one on the page — a stable answer rather than
    whichever strategy happened to run first.
    """
    index: dict[str, list[_Candidate]] = {}
    for page in ir.pages:
        for block in page.blocks:
            producers: Iterable[Iterator[tuple[str, _Candidate]]] = (
                _inline_candidates(page, block),
                _table_candidates(page, block),
                _neighbour_candidates(page, block),
            )
            for producer in producers:
                for key, candidate in producer:
                    if not key:
                        continue
                    index.setdefault(key, []).append(candidate)
    return index


_STRATEGY_RANK = {"kv": 0, "table_cell": 1, "inline": 2, "neighbour": 3}


def _match(index: dict[str, list[_Candidate]], name: str) -> tuple[list[_Candidate], str | None]:
    """Candidates for a requested field name, and why there are none.

    Exact normalised equality first. Failing that, a label that *contains* the
    request as a whole-word run (``pnr`` finds ``pnr roll no``) — but only when
    exactly one label does, because two matches mean the request is ambiguous
    and answering either would be a coin toss presented as a fact.
    """
    key = normalise(name)
    if not key:
        return [], "empty field name"
    if key in index:
        return index[key], None
    words = key.split()
    hits = [label for label in index if _contains_words(label.split(), words)]
    if len(hits) == 1:
        return index[hits[0]], None
    if len(hits) > 1:
        return [], f"ambiguous — {len(hits)} labels match ({', '.join(sorted(hits)[:4])})"
    return [], "no label on the page matches this name"


def _contains_words(label_words: Sequence[str], wanted: Sequence[str]) -> bool:
    """Is ``wanted`` a contiguous run of whole words inside ``label_words``?"""
    n = len(wanted)
    if not n or n > len(label_words):
        return False
    span = len(label_words) - n + 1
    return any(list(label_words[i : i + n]) == list(wanted) for i in range(span))


def extract_fields(
    ir: DocumentIR, names: Sequence[str], *, include_raw_ocr: bool = False
) -> ExtractionResult:
    """Look up ``names`` in ``ir``. Order in equals order out; misses are misses.

    ``include_raw_ocr`` adds every recognised line of the document — text, bbox,
    confidence, origin — beside the fields, so one response carries both the
    answer and the transcription it was taken from.
    """
    index = _index(ir)
    hits: list[FieldHit] = []
    for name in names:
        candidates, reason = _match(index, name)
        if not candidates:
            hits.append(FieldHit(name=name, value=None, reason=reason))
            continue
        ordered = sorted(candidates, key=lambda c: _STRATEGY_RANK.get(c.strategy, 9))
        best = ordered[0]
        hits.append(
            FieldHit(
                name=name,
                value=best.value,
                strategy=best.strategy,
                provenance=best.prov,
                alternatives=tuple(c.prov for c in ordered[1:]),
            )
        )
    return ExtractionResult(
        doc_id=str(ir.doc_id),
        fields=tuple(hits),
        raw_ocr=tuple(_raw_ocr(ir)) if include_raw_ocr else (),
        ir_version=str(ir.ir_version),
    )


def _raw_ocr(ir: DocumentIR) -> Iterator[dict[str, Any]]:
    """Every recognised line, in reading order, with its provenance."""
    for page in ir.pages:
        for block in sorted(page.blocks, key=lambda b: b.reading_order):
            for line in _lines_of(block):
                yield {
                    "page_no": page.page_no,
                    "block_id": block.block_id,
                    "block_type": str(block.type),
                    "text": line.text,
                    "bbox": [round(v, 1) for v in line.bbox],
                    "confidence": round(line.confidence, 4),
                    "origin": str(line.origin),
                }


def available_labels(ir: DocumentIR) -> tuple[str, ...]:
    """Every label this document offers, sorted — what you can ask for.

    A field lookup that returns nothing is far easier to act on when the answer
    comes with the list of names that *would* have worked.
    """
    return tuple(sorted(_index(ir)))


__all__ = [
    "EXTRACTOR_VERSION",
    "ExtractionResult",
    "FieldHit",
    "Provenance",
    "available_labels",
    "extract_fields",
    "normalise",
]
