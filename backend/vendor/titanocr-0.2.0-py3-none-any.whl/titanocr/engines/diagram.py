"""Drawn connectors: the arrows and lines that join a diagram's boxes (IR 1.6,
ADR 0012).

A diagram's meaning is in its edges. Its boxes carry the nouns and OCR reads
them fine; what says *Ingress feeds the account apps* is a stroke with a head on
one end, and until this module existed nothing in the pipeline looked at it — an
architecture diagram transcribed to a bag of labels in roughly the right places,
with every relationship silently gone.

``engines/layout.py`` already finds long straight ink (:func:`find_page_rules`),
and that is enough for a section divider or the side of a box. It is not enough
for a connector: a real one bends around obstacles, curves, ends in an
arrowhead, and is usually neither horizontal nor vertical for most of its
length. So this is a different question asked of the same pixels — *which ink is
a stroke that goes from somewhere to somewhere* — and it is answered
geometrically, with no model and no sampling, so two runs over one page give
byte-identical output.

The pass, in order:

1. **Binarise**, then erase what is already accounted for: every recognised
   line's box (text strokes are thin too, and there are thousands of them), and
   every ``avoid`` box (a table's grid is the table's).
2. **Split thin ink from thick.** Opening with a square kernel keeps only ink
   thicker than a stroke: filled shapes, icons, solid arrowheads. Subtracting it
   leaves the strokes — and hands the arrowheads over as a separate mask, which
   is exactly what step 5 needs them for.
3. **Bridge dashes.** A dashed connector is one relationship drawn as twelve
   components; closing over a gap the width of a dash makes it one again.
4. **Keep the open strokes.** A component with a hole is a closed shape — a box,
   a circle, a ring — and a box is not a connector. Components too short, too
   wide for a stroke, or too indirect to be going anywhere are dropped the same
   way.
5. **Centre-line and heads.** The medial path comes from pairing the two sides
   of the component's own contour, which follows a bend or a curve without any
   assumption that a connector is straight; each end is then checked against the
   thick mask for the blob that is an arrowhead.

Everything is a threshold on measured geometry, and every threshold is a
constructor argument: a connector this pass is not sure about is not emitted,
because inventing an edge invents a claim about the document (hard rule 12).
"""

from collections.abc import Sequence
from dataclasses import dataclass, replace
from itertools import pairwise
from typing import Any

import cv2
import numpy as np
import numpy.typing as npt

from titanocr.ir import Block, BlockType, Connector, Line, Origin
from titanocr.stages import PageImage

BBox = tuple[float, float, float, float]
Point = tuple[float, float]

CONNECTOR_VERSION = "connectors-1"


@dataclass(frozen=True)
class DiagramNode:
    """A thing a diagram's arrows point at: one drawn shape and its labels.

    ``bbox`` is the shape, which is what an arrow actually touches — it stops at
    the box edge, one to three label-heights from the words inside it — and
    ``line_ids`` are the labels that belong to it, in reading order, so a node
    drawn with a code above a name (``RS`` over ``RevenueSplit``) is **one**
    anchor rather than two competing ones.
    """

    bbox: BBox
    line_ids: tuple[str, ...]

    @property
    def anchor(self) -> str | None:
        """The label that names this node: its first, which is the code or title
        a diagram puts at the top of a box."""
        return self.line_ids[0] if self.line_ids else None


@dataclass(frozen=True)
class DrawnConnector:
    """One stroke that joins two places on the page.

    ``path`` is the medial line, page-space, start to end; ``head_start`` /
    ``head_end`` say which ends carry an arrowhead. A connector with neither is
    a plain join — a leader line, a bracket, an undirected edge — and is kept as
    one, because "these two things are connected" is a real finding even when
    the drawing does not say which way it points.
    """

    path: tuple[Point, ...]
    head_start: bool
    head_end: bool
    from_rule: int | None = None
    """Index into the ``straight`` candidates this connector was promoted from,
    if any — the caller drops that rule, so the ink is modelled once."""

    @property
    def bbox(self) -> BBox:
        xs = [p[0] for p in self.path]
        ys = [p[1] for p in self.path]
        return (min(xs), min(ys), max(xs), max(ys))

    @property
    def length(self) -> float:
        return sum(float(np.hypot(b[0] - a[0], b[1] - a[1])) for a, b in pairwise(self.path))


def find_connectors(
    page: PageImage,
    lines: Sequence[Line] = (),
    avoid: Sequence[BBox] = (),
    straight: Sequence[BBox] = (),
    *,
    max_stroke_frac: float = 0.004,
    min_length_frac: float = 0.015,
    dash_gap_frac: float = 0.0,
    text_pad_frac: float = 0.001,
    head_radius_mult: float = 10.0,
    min_directness: float = 0.55,
    simplify_frac: float = 0.004,
    max_connectors: int = 400,
) -> list[DrawnConnector]:
    """Connectors drawn on ``page``, longest first.

    ``avoid`` is ink already modelled elsewhere — a table's grid, and the plain
    rules the layout pass found — and is erased before anything is measured, so
    no stroke is counted twice. ``straight`` are those rules *again*, offered as
    candidates: a rule with an arrowhead on one end is not a division of the
    page, it is an arrow that happens to be straight, and the only thing that
    separates the two is the blob at its end. Promoting it here (with
    ``from_rule`` set, so the caller drops the rule) is what keeps the simple
    case from falling between the two passes.

    Fractions are of the page's larger side, so the same numbers hold at any
    render DPI. ``max_connectors`` is a ceiling on work, not a judgement: a page
    that produces more strokes than that is texture, not a diagram.
    """
    gray = page.pixels if page.pixels.ndim == 2 else cv2.cvtColor(page.pixels, cv2.COLOR_RGB2GRAY)
    h, w = gray.shape
    span = float(max(h, w))
    if h < 16 or w < 16:
        return []

    binv = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 15, 10
    ).astype(np.uint8, copy=False)
    pad = max(1, int(text_pad_frac * span))
    _erase(binv, [ln.bbox for ln in lines], pad)
    _erase(binv, avoid, 0)

    # How thick a stroke is on *this* page, measured (:func:`_stroke_width`).
    # ``max_stroke_frac`` stays as the ceiling it was always meant to be: a page
    # fraction cannot know a drawing's line weight, and when it guesses high
    # every following step is wrong — measured on a flow diagram rendered at
    # 5700 px, the fraction gave 22 px against an actual 4 px stroke, so the
    # opening kernel below came out at 45 px and erased the whole thick mask,
    # arrowheads included. No head was found on any page (docs/notes/arrows.md).
    measured = _stroke_width(binv)
    max_stroke = max(2, min(int(max_stroke_frac * span), round(2.0 * measured)))
    thick = cv2.morphologyEx(
        binv, cv2.MORPH_OPEN, np.ones((2 * max_stroke + 1, 2 * max_stroke + 1), dtype=np.uint8)
    ).astype(np.uint8, copy=False)
    thin = cv2.subtract(binv, thick).astype(np.uint8, copy=False)
    heads = _head_mask(np.asarray(gray, dtype=np.uint8), lines, avoid, pad, measured)
    # The straight candidates are deliberately *not* erased from the strokes.
    # Erasing them made every straight arrow depend on `_promote_straight`
    # finding a head, and when head detection missed, the arrow was gone from
    # both paths at once: measured on a flow diagram, 7 edges through the engine
    # directly against 3 through the pipeline that supplies the candidates. A
    # straight arrow is a stroke like any other and the contour path reads it
    # (and its head) correctly; promotion below stays as a second chance for
    # what that path missed, de-duplicated against what it found.
    thin = _bridge_dashes(thin, int(dash_gap_frac * span))

    min_length = max(8.0, min_length_frac * span)
    found, raw_hierarchy = cv2.findContours(thin, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    # RETR_CCOMP gives `[next, prev, first_child, parent]` per contour. An entry
    # with a parent is a hole's boundary; one with a child is a shape *with* a
    # hole, which is a box and not a connector.
    hierarchy: Any = raw_hierarchy
    out: list[DrawnConnector] = []
    for idx, found_contour in enumerate(found):
        if len(out) >= max_connectors:
            break
        if hierarchy is None or hierarchy[0][idx][3] != -1:
            continue
        if hierarchy[0][idx][2] != -1:
            continue
        contour = np.asarray(found_contour, dtype=np.int32)
        connector = _connector_from_contour(
            contour,
            thick,
            max_stroke=max_stroke,
            min_length=min_length,
            min_directness=min_directness,
            simplify=max(2.0, simplify_frac * span),
            head_radius=head_radius_mult * max_stroke,
            heads=heads,
        )
        if connector is not None:
            out.append(connector)
    # A stroke the contour path found that *is* one of the straight candidates
    # carries that candidate's index, so a caller emitting rule blocks still
    # knows which rule this arrow supersedes (ADR 0012) — the promotion path
    # below used to be the only way that got set.
    out = [_tagged(c, straight) for c in out]
    out.extend(
        _promote_straight(straight, heads, head_radius_mult * max_stroke, min_length, found=out)
    )
    out.sort(key=lambda c: (-c.length, c.bbox))
    return out


def _promote_straight(
    straight: Sequence[BBox],
    thick: npt.NDArray[np.uint8],
    head_radius: float,
    min_length: float,
    found: Sequence[DrawnConnector] = (),
) -> list[DrawnConnector]:
    """Rules that end in an arrowhead, re-read as the arrows they are.

    A second chance for straight arrows the contour path missed. Anything it
    already found is skipped — the strokes are no longer erased before that
    path runs, so without the check one arrow would come back twice.
    """
    out: list[DrawnConnector] = []
    for idx, (x0, y0, x1, y1) in enumerate(straight):
        if any(_overlaps((x0, y0, x1, y1), c.bbox) for c in found):
            continue
        horizontal = (x1 - x0) >= (y1 - y0)
        cy, cx = (y0 + y1) / 2.0, (x0 + x1) / 2.0
        start, end = ((x0, cy), (x1, cy)) if horizontal else ((cx, y0), (cx, y1))
        if float(np.hypot(end[0] - start[0], end[1] - start[1])) < min_length:
            continue
        head_start = _head_near(thick, start, head_radius)
        head_end = _head_near(thick, end, head_radius)
        if not head_start and not head_end:
            continue
        out.append(
            DrawnConnector(
                path=(start, end), head_start=head_start, head_end=head_end, from_rule=idx
            )
        )
    return out


def find_nodes(
    page: PageImage,
    lines: Sequence[Line],
    *,
    min_saturation: int = 90,
    min_value: int = 60,
    max_dark_value: int = 90,
    min_area_frac: float = 0.00005,
    max_area_frac: float = 0.2,
    caption_gap_mult: float = 1.6,
) -> list[DiagramNode]:
    """The diagram's nodes: drawn shapes, each with the labels that belong to it.

    Endpoint resolution needs *nodes*, not labels, and the two differ in exactly
    the ways that were breaking it. A node box holds a code **and** a name
    (``RS`` over ``RevenueSplit``), so anchoring to labels offers two rivals
    where the drawing has one thing. And an arrow touches the **box**, stopping
    one to three label-heights short of the words inside — so a label-sized snap
    misses long arrows entirely, while a snap wide enough to catch them
    swallows a group container's title instead.

    A node is found by its **fill**. Diagram tools draw nodes as filled shapes in
    saturated colour, and the things that are *not* nodes on the same page are
    exactly the things without one: a group container is a pale wash, an edge
    label is bare text, an arrow is thin grey. Measured on the reported diagram,
    saturation alone separates all nine node boxes from every container title and
    edge label, and it does so identically at thresholds from 60 to 120 — a
    plateau that wide is a real signal, not a tuned number.

    Labels attach two ways: **inside** the shape (a box's own caption) or
    **under** it within ``caption_gap_mult`` label-heights (an icon's caption —
    a database drum, a user glyph, a logo, which is how a diagram names a shape
    it cannot write inside). A shape that gathers no label is not a node here:
    it may be decoration, and a nameless anchor cannot make an edge readable.
    """
    pixels = page.pixels
    if pixels.ndim != 3:
        return []
    hsv = cv2.cvtColor(pixels, cv2.COLOR_RGB2HSV)
    saturated = (hsv[:, :, 1] >= min_saturation) & (hsv[:, :, 2] >= min_value)
    # ...and shapes drawn in black rather than colour. A diagram mixes the two
    # freely — the reported one has nine colour-filled boxes beside a black user
    # glyph — and an arrow points at both kinds. Ink this dark is a fill, not a
    # stroke: strokes are erased by the opening below, text by its own boxes.
    dark = (hsv[:, :, 2] <= max_dark_value).astype(np.uint8) * 255
    # Dark *text* is dark fill by that test, and a paragraph is not a node, so the
    # labels are cut out of this half only. The saturated half needs no such cut:
    # a caption written on a colour box is light, so it is already a hole in the
    # fill, and the closing below joins the box back across it. Cutting both
    # halves is what split `OT` from `OYO/TreeboBooking System` and lost `EC`
    # outright — the erase punched each box apart at its own caption.
    _erase(dark, [ln.bbox for ln in lines], 0)
    filled = np.maximum(saturated.astype(np.uint8) * 255, dark)
    # Close over the label sitting on top of the fill, so a box whose text
    # punches a hole through it stays one shape.
    span = float(max(page.width, page.height))
    k = max(3, int(0.005 * span) | 1)
    filled = cv2.morphologyEx(filled, cv2.MORPH_CLOSE, np.ones((k, k), dtype=np.uint8))

    page_area = float(page.width * page.height)
    count, _, stats, _ = cv2.connectedComponentsWithStats(filled)
    shapes: list[BBox] = []
    for i in range(1, count):
        x, y, w, h, area = (
            float(stats[i, c])
            for c in (
                cv2.CC_STAT_LEFT,
                cv2.CC_STAT_TOP,
                cv2.CC_STAT_WIDTH,
                cv2.CC_STAT_HEIGHT,
                cv2.CC_STAT_AREA,
            )
        )
        if area < min_area_frac * page_area or w * h > max_area_frac * page_area:
            continue
        shapes.append((x, y, x + w, y + h))

    ordered = sorted(lines, key=lambda ln: (ln.bbox[1], ln.bbox[0]))
    claimed: set[str] = set()
    nodes: list[DiagramNode] = []
    for shape in sorted(shapes, key=lambda b: _area(b)):
        inside = [
            ln for ln in ordered if _contains(shape, _centre(ln.bbox)) and ln.line_id not in claimed
        ]
        if not inside:
            inside = _caption_below(shape, ordered, claimed, caption_gap_mult)
        if not inside:
            continue
        claimed.update(ln.line_id for ln in inside)
        nodes.append(DiagramNode(bbox=shape, line_ids=tuple(ln.line_id for ln in inside)))
    return sorted(nodes, key=lambda n: (n.bbox[1], n.bbox[0]))


def _caption_below(
    shape: BBox, lines: Sequence[Line], claimed: set[str], gap_mult: float
) -> list[Line]:
    """The label a shape is named by when it cannot be written inside it.

    An icon — a database drum, a user glyph, a logo — carries its name beneath
    it. Only labels horizontally overlapping the shape and within a couple of
    their own heights below it qualify, so a node lower down the page is not
    captured as this one's caption.
    """
    out: list[Line] = []
    for line in lines:
        if line.line_id in claimed:
            continue
        height = max(line.bbox[3] - line.bbox[1], 1.0)
        gap = line.bbox[1] - shape[3]
        if not 0 <= gap <= gap_mult * height:
            continue
        if min(shape[2], line.bbox[2]) <= max(shape[0], line.bbox[0]):
            continue
        out.append(line)
    return out


def _centre(bbox: BBox) -> Point:
    return ((bbox[0] + bbox[2]) / 2.0, (bbox[1] + bbox[3]) / 2.0)


def _tagged(connector: DrawnConnector, straight: Sequence[BBox]) -> DrawnConnector:
    """Mark a connector with the straight candidate it is, if it is one."""
    if connector.from_rule is not None:
        return connector
    for idx, box in enumerate(straight):
        if _overlaps(box, connector.bbox):
            return replace(connector, from_rule=idx)
    return connector


def _overlaps(a: BBox, b: BBox) -> bool:
    """Do these boxes share any area? Used to keep one arrow from being
    emitted twice, once by each path that can find it."""
    return min(a[2], b[2]) > max(a[0], b[0]) and min(a[3], b[3]) > max(a[1], b[1])


def _bridge_dashes(thin: npt.NDArray[np.uint8], gap: int) -> npt.NDArray[np.uint8]:
    """Join a dashed stroke's segments without joining it to its neighbours.

    Closing with a square kernel does bridge the dashes, and on a page with any
    density it also welds every stroke to the box it points at. Measured on a
    cloud-architecture diagram: a 13 px square closing took 46 separable strokes
    down to 3, because each arrow merged into the component it touched and the
    merged component then had a hole in it (a box) and was skipped as a shape.

    Closing along each axis separately bridges what a dash gap is — a break
    *along* the stroke — and leaves a perpendicular neighbour a pixel away
    untouched, because a 1-px-tall kernel cannot reach it.

    Off by default all the same, and this is the reason: an arrow is drawn *to* a
    box, stopping a few pixels short of it, so any bridging at all is as likely
    to weld the arrow to its target as to mend a dash. On the same diagram a 4 px
    directional closing still cost 39 of the 46 strokes. A caller reading pages
    of dashed schematics can turn it on; the default abstains.
    """
    if gap < 2:
        return thin
    horizontal = cv2.morphologyEx(thin, cv2.MORPH_CLOSE, np.ones((1, gap), dtype=np.uint8))
    vertical = cv2.morphologyEx(thin, cv2.MORPH_CLOSE, np.ones((gap, 1), dtype=np.uint8))
    return cv2.bitwise_or(horizontal, vertical).astype(np.uint8, copy=False)


def _erase(mask: npt.NDArray[np.uint8], boxes: Sequence[BBox], pad: int) -> None:
    h, w = mask.shape
    for x0, y0, x1, y1 in boxes:
        r0, r1 = max(0, int(y0) - pad), min(h, int(np.ceil(y1)) + pad)
        c0, c1 = max(0, int(x0) - pad), min(w, int(np.ceil(x1)) + pad)
        if r1 > r0 and c1 > c0:
            mask[r0:r1, c0:c1] = 0


def _connector_from_contour(
    contour: npt.NDArray[np.int32],
    thick: npt.NDArray[np.uint8],
    *,
    max_stroke: int,
    min_length: float,
    min_directness: float,
    simplify: float,
    head_radius: float,
    heads: npt.NDArray[np.uint8],
) -> DrawnConnector | None:
    points = contour.reshape(-1, 2).astype(np.float64)
    if len(points) < 8:
        return None
    x0, y0 = points.min(axis=0)
    x1, y1 = points.max(axis=0)
    if float(np.hypot(x1 - x0, y1 - y0)) < min_length:
        return None
    area = float(cv2.contourArea(contour))
    perimeter = float(cv2.arcLength(contour, True))
    if perimeter <= 0.0:
        return None
    # A stroke's outline is its length there and back, so half the perimeter is
    # the length and area/length is the width. A blob fails both ways at once:
    # it is too wide for a stroke and too full for its own outline.
    stroke_len = perimeter / 2.0
    if stroke_len < min_length or area / stroke_len > max_stroke * 2.0:
        return None
    medial = _medial_path(points)
    if medial is None:
        return None
    centre, widths = medial
    simplified = cv2.approxPolyDP(
        centre.astype(np.float32).reshape(-1, 1, 2), simplify, False
    ).reshape(-1, 2)
    if len(simplified) < 2:
        return None
    path = tuple((float(px), float(py)) for px, py in simplified)
    if _directness(path) < min_directness:
        return None
    head_start = _head_near(heads, path[0], head_radius) or _widens_at(widths, at_start=True)
    head_end = _head_near(heads, path[-1], head_radius) or _widens_at(widths, at_start=False)
    # An arrow's tip is its head, and the head is solid, so it was subtracted
    # from the strokes before this contour was traced — the medial path stops
    # where the head begins, a head-length short of what the arrow points at.
    # Measured on the reported diagram, that is most of the gap between a tip and
    # its target box. Reaching through the head puts the endpoint where a reader
    # sees it.
    path = _through_head(path, heads, head_radius, at_start=head_start, at_end=head_end)
    return DrawnConnector(path=path, head_start=head_start, head_end=head_end)


def _through_head(
    path: tuple[Point, ...],
    heads: npt.NDArray[np.uint8],
    radius: float,
    *,
    at_start: bool,
    at_end: bool,
) -> tuple[Point, ...]:
    """Move an arrow's endpoints out to the far side of their heads."""
    points = list(path)
    if at_start and len(points) >= 2:
        points[0] = _reach_through(points[0], points[1], heads, radius)
    if at_end and len(points) >= 2:
        points[-1] = _reach_through(points[-1], points[-2], heads, radius)
    return tuple(points)


def _reach_through(tip: Point, inward: Point, heads: npt.NDArray[np.uint8], radius: float) -> Point:
    """Walk outward from ``tip``, away from ``inward``, while the head mask is
    still under foot — the last point on it is the arrow's real point."""
    dx, dy = tip[0] - inward[0], tip[1] - inward[1]
    length = float(np.hypot(dx, dy))
    if length <= 0.0:
        return tip
    ux, uy = dx / length, dy / length
    h, w = heads.shape
    furthest = tip
    for step in range(1, int(radius) + 1):
        x, y = tip[0] + ux * step, tip[1] + uy * step
        xi, yi = int(x), int(y)
        if not (0 <= xi < w and 0 <= yi < h):
            break
        if heads[yi, xi]:
            furthest = (x, y)
    return furthest


def _directness(path: tuple[Point, ...]) -> float:
    """End-to-end distance over path length: 1.0 is a straight line.

    A connector goes *from* somewhere *to* somewhere. It may bend twice around
    an obstacle and still spend most of its length getting there, so an
    orthogonal dog-leg scores about 0.7 and a gentle curve above 0.9. Artwork
    does not: the outline of a cube icon, a cylinder, a cloud — the strokes that
    dominate a cloud-architecture diagram — doubles back on itself and scores
    near zero. Measured on one: this single ratio is what separates 60-odd icon
    outlines from the arrows drawn between them.
    """
    total = sum(float(np.hypot(b[0] - a[0], b[1] - a[1])) for a, b in pairwise(path))
    if total <= 0.0:
        return 0.0
    span = float(np.hypot(path[-1][0] - path[0][0], path[-1][1] - path[0][1]))
    return span / total


_HEAD_WIDTH_MULT = 1.8
"""How much wider than the stroke itself the ink must get near an end before
that end counts as an arrowhead."""

_HEAD_SAMPLE_FRAC = 0.15
"""The fraction of the stroke, measured from an end, that an arrowhead may
occupy. Past that a widening is the stroke changing weight, not a head."""


def _widens_at(widths: npt.NDArray[np.float64], *, at_start: bool) -> bool:
    """Does the stroke flare out at this end?

    An arrowhead drawn as two strokes — the common open chevron — stays thin
    everywhere, so the thick mask never sees it; what gives it away is that the
    ink is two to four times wider just short of the tip than along the shaft.
    The width profile is free: it is the distance between the two contour points
    that were paired to find each centre point, so the medial construction has
    already measured it.

    The very last sample is skipped: at the tip the two sides of the contour
    meet, so the width there is ~0 by construction and says nothing.
    """
    if len(widths) < 6:
        return False
    shaft = float(np.median(widths))
    if shaft <= 0.0:
        return False
    window = max(2, int(_HEAD_SAMPLE_FRAC * len(widths)))
    near = widths[1 : window + 1] if at_start else widths[-window - 1 : -1]
    return bool(near.size and float(near.max()) >= _HEAD_WIDTH_MULT * shaft)


def _medial_path(
    points: npt.NDArray[np.float64],
) -> tuple[npt.NDArray[np.float64], npt.NDArray[np.float64]] | None:
    """The line down the middle of a stroke, from its outline.

    A stroke's contour runs out along one side and back along the other, so the
    two sides paired up and averaged give the centre — a construction that
    follows a bend or a curve exactly as drawn, with no straight-line assumption
    anywhere in it. The ends are found by the standard double sweep (farthest
    point from the centroid, then farthest from that), which is exact for the
    long thin shapes this is applied to.

    Returns the centre line and, alongside it, the distance between each pair —
    the stroke's local width, which is what :func:`_widens_at` reads to find an
    arrowhead that was drawn thin.
    """
    centroid = points.mean(axis=0)
    first = int(np.argmax(((points - centroid) ** 2).sum(axis=1)))
    second = int(np.argmax(((points - points[first]) ** 2).sum(axis=1)))
    i, j = sorted((first, second))
    side_a = points[i : j + 1]
    side_b = np.concatenate((points[j:], points[: i + 1]))[::-1]
    if len(side_a) < 2 or len(side_b) < 2:
        return None
    samples = int(np.clip(min(len(side_a), len(side_b)), 2, 64))
    a = _resample(side_a, samples)
    b = _resample(side_b, samples)
    return (a + b) / 2.0, np.hypot(*(a - b).T)


def _resample(side: npt.NDArray[np.float64], samples: int) -> npt.NDArray[np.float64]:
    """``samples`` points spread evenly along a polyline by arc length."""
    deltas = np.diff(side, axis=0)
    lengths: npt.NDArray[np.float64] = np.hypot(deltas[:, 0], deltas[:, 1])
    steps: npt.NDArray[np.float64] = np.concatenate(
        (np.zeros(1, dtype=np.float64), np.cumsum(lengths))
    )
    total = float(steps[-1])
    if total <= 0.0:
        return np.repeat(side[:1], samples, axis=0)
    wanted: npt.NDArray[np.float64] = np.linspace(0.0, total, samples)
    xs = np.asarray(np.interp(wanted, steps, side[:, 0]), dtype=np.float64)
    ys = np.asarray(np.interp(wanted, steps, side[:, 1]), dtype=np.float64)
    return np.stack([xs, ys], axis=1)


def _stroke_width(binv: npt.NDArray[np.uint8]) -> float:
    """The page's own line weight, in pixels.

    The distance transform gives, at every ink pixel, its distance to the
    nearest background pixel; on the centre line of a stroke that is half the
    stroke's width, and the median over all ink is a robust estimate of it
    because a drawing is mostly strokes. Measured rather than assumed because a
    fraction of the page size is not a line weight: the same diagram exported at
    two DPIs has one line weight in points and two in pixels, and the fraction is
    right for neither.
    """
    dist = cv2.distanceTransform(binv, cv2.DIST_L2, 5)
    values = dist[dist > 0]
    if values.size == 0:
        return 2.0
    return max(2.0, 2.0 * float(np.median(values)))


def _head_mask(
    gray: npt.NDArray[np.uint8],
    lines: Sequence[Line],
    avoid: Sequence[BBox],
    pad: int,
    stroke: float,
    *,
    min_area_mult: float = 2.0,
    max_area_mult: float = 200.0,
) -> npt.NDArray[np.uint8]:
    """Where the solid blobs small enough to be arrowheads are.

    Two things separate this from the thick mask the strokes were split off:

    **A head is solid, and the text binarisation does not keep solids solid.**
    An adaptive mean threshold responds to edges, which is right for glyphs and
    wrong for a filled triangle: at any size the interior is flat, so the head
    comes back as an outline and there is no blob to find. Otsu keeps a filled
    shape filled, so heads are read on that.

    **A head is small.** Otsu also keeps a diagram's *node boxes* filled, and an
    arrow ends at a box by construction — so an untested "solid ink near the
    endpoint" test answers yes for every arrow at both ends. Size is the
    distinction and it is a wide margin, not a knife edge: on the measured
    diagram the heads run 300-3000 px against 16000-72000 for the boxes. The
    gate is stated in stroke widths so it holds at any DPI.
    """
    solid = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1].astype(
        np.uint8, copy=False
    )
    _erase(solid, [ln.bbox for ln in lines], pad)
    _erase(solid, avoid, 0)
    # Open wider than the stroke, so the line a head sits on dissolves and the
    # head is left standing alone. Without this the two are one component — the
    # arrow *including* its shaft — and no size gate can pick the head out of it.
    k = 2 * max(1, round(stroke)) + 1
    solid = cv2.morphologyEx(solid, cv2.MORPH_OPEN, np.ones((k, k), dtype=np.uint8)).astype(
        np.uint8, copy=False
    )
    n, labelled, stats, _ = cv2.connectedComponentsWithStats(solid)
    lo, hi = min_area_mult * stroke * stroke, max_area_mult * stroke * stroke
    heads = np.zeros_like(solid)
    for i in range(1, n):
        if lo <= float(stats[i, cv2.CC_STAT_AREA]) <= hi:
            heads[labelled == i] = 255
    return heads


def _head_near(thick: npt.NDArray[np.uint8], point: Point, radius: float) -> bool:
    """Is there a solid blob at this end — an arrowhead?

    A filled head is thicker than the stroke it terminates, so it is exactly
    what the thick mask kept when the stroke was separated out. Presence of ink
    within a few stroke widths of the endpoint is the whole test: shape is not
    checked, because a head is drawn as a triangle, a chevron, a diamond or a
    disc depending on the tool, and all of them are ink where the line stops.
    """
    h, w = thick.shape
    r = max(2, int(radius))
    c0, c1 = max(0, int(point[0]) - r), min(w, int(point[0]) + r + 1)
    r0, r1 = max(0, int(point[1]) - r), min(h, int(point[1]) + r + 1)
    if c1 <= c0 or r1 <= r0:
        return False
    return bool(np.any(thick[r0:r1, c0:c1]))


_ANCHORABLE = frozenset({BlockType.paragraph, BlockType.header, BlockType.kv, BlockType.figure})
"""What an arrow can point *at*: something with a name. A rule and another
connector are ink, not things; a table is a grid whose cells an endpoint cannot
choose between, so an arrow landing on one anchors to nothing rather than to a
guess."""


def connector_blocks(
    connectors: Sequence[DrawnConnector],
    blocks: Sequence[Block],
    page_no: int,
    *,
    snap_frac: float = 0.02,
    page_span: float,
    require_named_ends: bool = True,
    require_figure: bool = True,
    nodes: Sequence[DiagramNode] = (),
) -> list[Block]:
    """Drawn connectors as IR blocks, ends resolved to what they join.

    An endpoint anchors to the thing that contains it, else to the nearest one
    within ``snap_frac`` of the page — an arrow is drawn *to* a box, stopping a
    few pixels short of it, so exact containment would resolve almost nothing.
    Past that distance the end anchors to nothing and stays ``None``: an edge to
    a guessed endpoint is a relationship the document never stated (hard rule
    12), and the path is still there for anyone who wants to look.

    **Ends anchor to nodes when the page has them** (:func:`find_nodes`) — the
    drawn shape an arrow actually touches, carrying every label written on it, so
    a box captioned ``RS`` over ``RevenueSplit`` is one anchor and an arrow that
    stops at its edge still finds it. Where nodes were found they are the *only*
    anchors: any label is nearer some stroke than the box it runs to, so keeping
    labels as a fallback re-admits the container titles and edge labels that node
    detection exists to exclude. Label anchoring remains for pages with no
    detected nodes at all.

    **Ends anchor to labels, not only to blocks** (IR 1.7, ADR 0016), and on a
    diagram that is the only anchoring that says anything. A layout model types
    a whole diagram as one ``figure``, so every arrow drawn inside it starts and
    ends in that same block — and the rule below, that both ends in one block is
    a stroke of the block's own artwork, then discards every real arrow on the
    page. Measured on a flow diagram: 14 connectors found, **all 14 dropped**.
    The labels are the named things an arrow actually joins (``NE`` to ``LP``),
    so they are what an end resolves against; the block anchors are still filled
    in, and the artwork rule now applies only when neither end found a label.

    A label lying *along* the stroke is not an endpoint — it is the edge's own
    name (``commission``, ``targeted offers``), and it is recorded as
    ``label_line_id`` instead, which is what makes the edge readable as a
    sentence rather than a bare pair.

    ``require_figure`` (default) keeps an edge only when the stroke lies inside a
    ``figure`` region. An arrow is a thing a *drawing* contains, and a page with
    no drawing on it has no arrows — but it does have long strokes: measured, a
    note with a signature rule emitted two edges, one of them joining its
    letterhead to its date across the printed line between them. Nothing about
    the stroke itself says it is not an arrow; what says so is that the page is a
    letter. So the region the layout stage already identified is the gate, and a
    diagram the layout stage failed to type as a figure loses its arrows rather
    than a letter gaining some (hard rule 12).

    ``require_named_ends`` (default) emits only edges that name **both** ends.
    A connector's whole purpose is to say that *this* relates to *that*; with one
    end unresolved it states nothing a consumer can act on, and that is precisely
    the shape a false positive takes. Measured over four non-diagram pages, the
    strokes that survive on an ordinary document — a signature flourish, a
    printed box corner — almost never name two things, while on the flow diagram
    every edge found did: **7 of 7 named both ends, against 1 across all four
    ordinary pages**. That margin is what lets the arrow pass be on by default
    (ADR 0016) without putting invented relationships on documents that have
    none (hard rule 12).
    """
    snap = snap_frac * page_span
    targets = [b for b in blocks if b.type in _ANCHORABLE]
    labels = [ln for b in blocks for ln in (b.lines or ())]
    drawings = [b.bbox for b in blocks if b.type is BlockType.figure]
    out: list[Block] = []
    for i, conn in enumerate(connectors):
        if require_figure and not any(
            _contains(box, conn.path[0]) and _contains(box, conn.path[-1]) for box in drawings
        ):
            continue
        start = _anchor(conn.path[0], targets, snap)
        end = _anchor(conn.path[-1], targets, snap)
        on_path = _label_on_path(conn.path, labels)
        excluded = on_path.line_id if on_path else None
        endpoints = [ln for ln in labels if ln.line_id != excluded]
        if nodes:
            # Where the page has nodes, they are the only things an arrow joins.
            # Falling back to any nearby label re-admits exactly what node
            # detection exists to exclude: a group container's title, and an
            # edge's own label, both of which sit closer to a stroke than the
            # box it runs to. Measured, the fallback produced
            # "Cross-Sale Engine -> RS" (a container) and "NE -> NudgeEngine"
            # (one node's two captions) on the reported diagram.
            from_line = _anchor_node(conn.path[0], nodes, excluded)
            to_line = _anchor_node(conn.path[-1], nodes, excluded)
        else:
            from_line = _anchor_line(conn.path[0], endpoints, snap)
            to_line = _anchor_line(conn.path[-1], endpoints, snap)
        if from_line is not None and from_line == to_line:
            continue  # both ends on one label: a stroke of that label's artwork
        if from_line is None and to_line is None and start is not None and start == end:
            continue  # nothing named at either end, inside one block: artwork
        if require_named_ends and (from_line is None or to_line is None):
            continue  # half a relationship is not one
        out.append(
            Block(
                block_id=f"p{page_no}_c{i}",
                type=BlockType.connector,
                bbox=conn.bbox,
                reading_order=0,  # the caller reassigns over the merged set
                origin=Origin.digital if _is_digital(blocks) else Origin.ocr,
                confidence=1.0,
                connector=Connector(
                    path=conn.path,
                    head_start=conn.head_start,
                    head_end=conn.head_end,
                    from_block_id=start,
                    to_block_id=end,
                    from_line_id=from_line,
                    to_line_id=to_line,
                    label_line_id=on_path.line_id if on_path is not None else None,
                ),
            )
        )
    return out


def _is_digital(blocks: Sequence[Block]) -> bool:
    """Which route produced this page — a connector carries no text, so its
    origin is a statement about where the finding came from, nothing more."""
    return any(b.origin is Origin.digital for b in blocks)


def _anchor(point: Point, targets: Sequence[Block], snap: float) -> str | None:
    inside = [b for b in targets if _contains(b.bbox, point)]
    if inside:
        return min(inside, key=lambda b: _area(b.bbox)).block_id
    near = [(_distance(b.bbox, point), b.block_id) for b in targets]
    if not near:
        return None
    distance, block_id = min(near)
    return block_id if distance <= snap else None


def _anchor_node(
    point: Point, nodes: Sequence[DiagramNode], excluded: str | None, *, reach_frac: float = 0.5
) -> str | None:
    """The node an endpoint touches, named by its first label.

    An arrow is drawn *to* a shape and stops short of it twice over: once by the
    gap a drawing tool leaves, and again because the arrowhead is solid and was
    subtracted from the strokes, so the medial path ends where the head begins.
    Measured on the reported diagram, a tip sits 0 to 0.6 of the target box's
    shorter side away from it. The reach is therefore a fraction of the shape's
    own size — which scales with the node rather than with the page, so a long
    arrow into a big box resolves while a stray stroke beside a small one does
    not.
    """
    best: tuple[float, str] | None = None
    for node in nodes:
        anchor = node.anchor
        if anchor is None or anchor == excluded:
            continue
        distance = _distance(node.bbox, point)
        reach = reach_frac * min(node.bbox[2] - node.bbox[0], node.bbox[3] - node.bbox[1])
        if distance <= reach and (best is None or distance < best[0]):
            best = (distance, anchor)
    return None if best is None else best[1]


def _anchor_line(point: Point, labels: Sequence[Line], snap: float) -> str | None:
    """The label an endpoint lands on — the smallest containing it, else the
    nearest one *close on its own scale*.

    The page-fraction snap :func:`_anchor` uses is right for a block and far too
    generous for a label: at 2% of a 5700 px page it reaches 114 px, several
    times the height of the words it is choosing between, so an endpoint in open
    space acquires whichever label happens to be nearest and the edge is
    invented (hard rule 12). A label's own height is the scale that means
    something — an arrow that stops at a word stops within a line of it — so the
    reach is a small multiple of that, and an end near nothing stays ``None``.
    """
    inside = [ln for ln in labels if _contains(ln.bbox, point)]
    if inside:
        return min(inside, key=lambda ln: _area(ln.bbox)).line_id
    best: tuple[float, str] | None = None
    for label in labels:
        reach = min(snap, _LABEL_SNAP_MULT * max(label.bbox[3] - label.bbox[1], 1.0))
        distance = _distance(label.bbox, point)
        if distance <= reach and (best is None or distance < best[0]):
            best = (distance, label.line_id)
    return None if best is None else best[1]


_LABEL_SNAP_MULT = 1.2
"""How far past a label an endpoint may stop and still be pointing at it, in
label heights. Measured: the page-fraction snap reached 114 px on a 5700 px flow
diagram and joined labels metres apart on the page."""


def _label_on_path(path: Sequence[Point], labels: Sequence[Line]) -> Line | None:
    """The label written *on* this stroke, if one is.

    An edge label sits against the middle of the stroke, not at either end —
    ``commission`` on the arrow from ``NE`` to ``LP``. Taking it for an endpoint
    would lose both the edge's name and its real target, so the interior of the
    path is checked separately and the nearest label to it wins, provided it is
    nearer the middle than either end.
    """
    if len(path) < 2:
        return None
    interior = path[1:-1] or (_midpoint(path[0], path[-1]),)
    best: tuple[float, Line] | None = None
    for label in labels:
        distance = min(_distance(label.bbox, point) for point in interior)
        ends = min(_distance(label.bbox, path[0]), _distance(label.bbox, path[-1]))
        if distance >= ends:
            continue
        height = max(label.bbox[3] - label.bbox[1], 1.0)
        if distance > height and (best is None or distance >= best[0]):
            continue
        if best is None or distance < best[0]:
            best = (distance, label)
    return None if best is None else best[1]


def _midpoint(a: Point, b: Point) -> Point:
    return ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)


def _contains(bbox: BBox, point: Point) -> bool:
    return bbox[0] <= point[0] <= bbox[2] and bbox[1] <= point[1] <= bbox[3]


def _area(bbox: BBox) -> float:
    return max(bbox[2] - bbox[0], 0.0) * max(bbox[3] - bbox[1], 0.0)


def _distance(bbox: BBox, point: Point) -> float:
    dx = max(bbox[0] - point[0], 0.0, point[0] - bbox[2])
    dy = max(bbox[1] - point[1], 0.0, point[1] - bbox[3])
    return float(np.hypot(dx, dy))


__all__ = [
    "CONNECTOR_VERSION",
    "DiagramNode",
    "DrawnConnector",
    "connector_blocks",
    "find_connectors",
    "find_nodes",
]
