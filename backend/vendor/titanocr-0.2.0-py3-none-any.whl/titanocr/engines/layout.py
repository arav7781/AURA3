"""Layout analysis & reading order (phase 10): the ``rapid-layout`` engine.

rapid_layout + ONNXRuntime quarantine: nothing outside this module imports either
vendor for layout purposes (docs/08). Like ``engines/rapidocr.py``, the wrapper
feeds a pre-built, pinned ONNX session through the library's model handlers
instead of letting the package build its own — its download machinery is never
reachable and the session options are ours (``intra_op=1, inter_op=1,
SEQUENTIAL``, docs/07). The model is an explicit local path from the pipeline
config, fetched and pinned by ``make models``; a missing file fails engine
construction, which fails readiness (hard rule 9). rapid-layout is exact-pinned
in pyproject because the handler classes are internal API.

The model only proposes *regions with classes*; everything that makes them IR
blocks is pure geometry below, in deliberate order:

1. class → :class:`BlockType` via :data:`DEFAULT_CLASS_MAP` (plan §7 row
   "3 layout"); unknown classes become ``paragraph`` with a logged note — never
   dropped.
2. line → region assignment: containment first, else highest IoA, else nearest
   region within a gap ceiling, else the line seeds an orphan paragraph block
   (via the phase-09 clustering). **No recognised line is ever discarded.**
3. text-dense figure: a ``figure`` region packed with recognised text rows is a
   mis-classification, re-typed ``paragraph``. The PP models call a page they
   cannot read as body text an ``image``/``figure`` — a photographed
   handwritten page is the case that surfaced it (docs/notes) — and that region
   then swallows every line on the page.
4. kv heuristic: a top-of-page paragraph block whose rows are x-aligned
   ``label: value`` pairs is re-typed ``kv``. Conservative — a false kv is worse
   than a plain paragraph.
5. furniture: model header/footer classes are trusted only near the page edges;
   a small paragraph block fully inside the top/bottom band is re-typed
   header/footer positionally. (Cross-page repetition, the "repeats across
   pages" refinement, needs a document-level pass — noted in the phase log as a
   follow-up; this stage is per-page by design.)
6. box tightening: no block's box may claim another block's content
   (:func:`_tighten_to_content`). Model boxes overlap, and a box covering a
   neighbour's rows is both false provenance and a page that draws on top of
   itself.
7. recursive XY-cut reading order over the final block boxes: cut the larger
   whitespace valley, vertical-first on ties (multi-column), ``reading_order``
   dense from 0.

A table region becomes ``Block(type=table, table=PENDING_TABLE, lines=...)``
(IR 1.1, ADR 0004) — the table stage (phase 11) replaces the placeholder.

A **visual** region (``figure``/``image``/``chart``/``header_image``/
``footer_image`` → ``figure``, ``seal`` → ``signature``) is kept even when it
holds no recognised lines (IR 1.4, ADR 0010): a logo has no text by
construction, and its bbox *is* the finding — dropping it would lose the page's
structure. Such a block carries ``lines=None``, ``origin="ocr"`` and the
model's detection score as its confidence. A *text* region with no lines is
still dropped; an empty paragraph would be a fabricated claim.

Degrade contract: an inference *error* raises :class:`EngineDegraded` so the
runner's clustering path takes over with provenance evidence; an *empty* model
output on a page that has lines degrades to the same clustering inside the
engine (logged), so ``analyze`` never returns zero blocks for a page with lines
— the layout contract suite asserts exactly that. A page with *no* lines yields
its visual regions if the model found any, else nothing.
"""

# rapid_layout ships no type stubs; the vendor noise stays confined to this module.
# pyright: reportMissingTypeStubs=false, reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false, reportUnknownArgumentType=false
# pyright: reportAttributeAccessIssue=false

import re
from collections.abc import Sequence
from dataclasses import dataclass, replace
from importlib.metadata import version as _dist_version
from itertools import pairwise
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import numpy.typing as npt
import onnxruntime as ort  # pyright: ignore[reportMissingModuleSource]

from titanocr.engines.diagram import connector_blocks, find_connectors, find_nodes
from titanocr.ir import Block, BlockType, Line, Origin
from titanocr.stages import (
    PARAGRAPH_GAP_RATIO,
    PENDING_TABLE,
    EngineDegraded,
    PageImage,
    StageContext,
    cluster_paragraph_blocks,
    is_section_heading,
    register,
)

RAPID_LAYOUT_VERSION = _dist_version("rapid-layout")

BBox = tuple[float, float, float, float]

DEFAULT_CLASS_MAP: dict[str, BlockType] = {
    # cdla + PP-DocLayout body text flavours → paragraph
    "text": BlockType.paragraph,
    "reference": BlockType.paragraph,
    "reference_content": BlockType.paragraph,
    "abstract": BlockType.paragraph,
    "content": BlockType.paragraph,
    "footnote": BlockType.paragraph,
    "vision_footnote": BlockType.paragraph,
    "aside_text": BlockType.paragraph,
    "vertical_text": BlockType.paragraph,
    # Mathematics (IR 1.8, ADR 0018). Typed `formula` so every stage that guesses
    # structure can skip it by what it *is* rather than by a geometric threshold a
    # differently-typeset equation might slip past. `formula_number` stays a
    # paragraph here and is merged into the formula sharing its y-band by
    # `attach_formula_numbers`; one that matches no formula survives as a
    # paragraph rather than being dropped.
    "equation": BlockType.formula,
    "display_formula": BlockType.formula,
    "inline_formula": BlockType.formula,
    "formula_number": BlockType.paragraph,
    "algorithm": BlockType.paragraph,
    "figure_caption": BlockType.paragraph,
    "table_caption": BlockType.paragraph,
    "figure_title": BlockType.paragraph,
    "table_title": BlockType.paragraph,
    "chart_title": BlockType.paragraph,
    # headings
    "title": BlockType.header,
    "doc_title": BlockType.header,
    "paragraph_title": BlockType.header,
    # structure
    "table": BlockType.table,
    "figure": BlockType.figure,
    "image": BlockType.figure,
    "chart": BlockType.figure,
    "header_image": BlockType.figure,
    "footer_image": BlockType.figure,
    # page furniture (position-gated in _apply_furniture_rules)
    "header": BlockType.header,
    "footer": BlockType.footer,
    "number": BlockType.footer,
    # signature/stamp
    "seal": BlockType.signature,
}
"""Model class → BlockType (plan §7). ``header``/``footer``/``number`` are
furniture candidates — accepted only near the matching page edge."""

_VISUAL_BLOCK_TYPES = frozenset({BlockType.figure, BlockType.signature, BlockType.rule})
"""Non-text-by-construction block types: a region of one of these is kept even
when it holds no recognised lines — its bbox is the finding (IR 1.4 ADR 0010 for
figure/signature, IR 1.5 ADR 0011 for rule)."""

_FURNITURE_CLASSES = {"header": BlockType.header, "footer": BlockType.footer}


@dataclass(frozen=True)
class _Draft:
    """A block under construction, before XY-cut assigns its reading order.

    ``confidence`` is the mean line confidence for a text block and the layout
    model's detection score for a line-less visual one — the two are not
    interchangeable, which is why it rides along rather than being re-derived.
    """

    type: BlockType
    bbox: BBox
    lines: tuple[Line, ...]
    confidence: float

    def retyped(self, block_type: BlockType) -> "_Draft":
        return replace(self, type=block_type)


_KV_ROW_RE = re.compile(r"^\s*([^:]{1,32}?)\s*:\s*(\S.*)$")
"""``label: value`` — short label, non-empty value; first colon splits."""

_ROW_GROUP_RATIO = 0.6
"""Lines whose y-centres are within this fraction of the median line height
belong to one visual row (same rule as the fixture truth helper)."""


def _pinned_session_options() -> Any:
    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 1
    opts.inter_op_num_threads = 1
    opts.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    opts.log_severity_level = 4
    return opts


def _resolve_model_path(model_path: str) -> Path:
    path = Path(model_path)
    if not path.is_file():
        raise FileNotFoundError(
            f"model file not found: {path} — models are fetched by `make models` "
            "and never downloaded at runtime (plan §12)"
        )
    return path


def _to_bgr(pixels: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    if pixels.ndim == 2:
        converted = cv2.cvtColor(pixels, cv2.COLOR_GRAY2BGR)
    else:
        converted = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR)
    return converted.astype(np.uint8, copy=False)


class _PinnedSession:
    """The narrow session facade rapid_layout's handlers actually use, backed by
    a session built with our pinned options (the library's ``OrtInferSession``
    builds its own and offers no passthrough)."""

    def __init__(self, session: Any) -> None:
        self._session = session

    def __call__(self, input_content: Any) -> Any:
        names = [v.name for v in self._session.get_inputs()]
        batch = input_content if isinstance(input_content, list) else [input_content]
        outputs = [v.name for v in self._session.get_outputs()]
        return self._session.run(outputs, dict(zip(names, batch, strict=False)))

    @property
    def characters(self) -> list[str]:
        return self.get_character_list()

    def get_character_list(self, key: str = "character") -> list[str]:
        meta = self._session.get_modelmeta().custom_metadata_map
        return list(meta[key].splitlines())

    def have_key(self, key: str = "character") -> bool:
        return key in self._session.get_modelmeta().custom_metadata_map


@register("layout", "rapid-layout")
class RapidLayoutEngine:
    """PP-family layout model → typed, reading-ordered IR blocks."""

    def __init__(
        self,
        model_path: str,
        model_type: str = "pp_layout_cdla",
        conf_thresh: float = 0.5,
        iou_thresh: float = 0.5,
        containment_ratio: float = 0.7,
        min_ioa: float = 0.05,
        orphan_gap_ratio: float = 1.5,
        kv_top_frac: float = 0.4,
        kv_min_rows: int = 2,
        kv_min_row_frac: float = 0.8,
        kv_align_frac: float = 0.02,
        figure_text_min_rows: int = 4,
        figure_text_min_coverage: float = 0.35,
        furniture_band_frac: float = 0.08,
        furniture_max_rows: int = 2,
        model_band_frac: float = 0.16,
        detect_rules: bool = False,
        rule_min_width_frac: float = 0.12,
        rule_max_thickness_frac: float = 0.006,
        rule_vertical: bool = True,
        rule_min_height_frac: float = 0.04,
        detect_connectors: bool = False,
    ) -> None:
        if not model_type.startswith("pp"):
            raise ValueError(
                f"unsupported layout model_type {model_type!r} — the engine wraps the "
                "PP-family handlers (pp_layout_* / pp_doc_layout*); DocLayout-YOLO is "
                "AGPL and excluded by hard rule 13"
            )
        self.model_path = _resolve_model_path(model_path)
        self.model_type = model_type
        self.conf_thresh = conf_thresh
        self.iou_thresh = iou_thresh
        self.containment_ratio = containment_ratio
        self.min_ioa = min_ioa
        self.orphan_gap_ratio = orphan_gap_ratio
        self.kv_top_frac = kv_top_frac
        self.kv_min_rows = kv_min_rows
        self.kv_min_row_frac = kv_min_row_frac
        self.kv_align_frac = kv_align_frac
        self.figure_text_min_rows = figure_text_min_rows
        self.figure_text_min_coverage = figure_text_min_coverage
        self.furniture_band_frac = furniture_band_frac
        self.furniture_max_rows = furniture_max_rows
        self.model_band_frac = model_band_frac
        self.detect_rules = detect_rules
        self.rule_min_width_frac = rule_min_width_frac
        self.rule_max_thickness_frac = rule_max_thickness_frac
        self.rule_vertical = rule_vertical
        self.rule_min_height_frac = rule_min_height_frac
        self.detect_connectors = detect_connectors
        self.version = f"rapid-layout-{RAPID_LAYOUT_VERSION}+{self.model_path.stem}"
        self._session: Any = None
        self._session_options: Any = None
        self._handler: Any = None

    # -- model plumbing ---------------------------------------------------------

    def _get_session(self) -> Any:
        if self._session is None:
            self._session_options = _pinned_session_options()
            self._session = ort.InferenceSession(
                str(self.model_path),
                sess_options=self._session_options,
                providers=["CPUExecutionProvider"],
            )
        return self._session

    def session_info(self) -> dict[str, Any] | None:
        """Pinning evidence (None until first inference creates the session)."""
        if self._session is None or self._session_options is None:
            return None
        return {
            "model": self.model_path.name,
            "intra_op_num_threads": self._session_options.intra_op_num_threads,
            "inter_op_num_threads": self._session_options.inter_op_num_threads,
            "execution_mode": self._session_options.execution_mode.name,
            "providers": list(self._session.get_providers()),
        }

    def _get_handler(self) -> Any:
        if self._handler is None:
            # The handlers annotate `session: InferSession` but only use the
            # call/characters surface _PinnedSession provides.
            session: Any = _PinnedSession(self._get_session())
            if not session.have_key():
                raise RuntimeError(
                    f"layout model {self.model_path.name} carries no embedded label list — "
                    "wrong model file (the pinned rapid-layout ONNX exports embed it)"
                )
            labels = session.characters
            if self.model_type.startswith("pp_doc_layout"):
                from rapid_layout.model_handler.pp_doc_layout.main import (
                    PPDocLayoutModelHandler,
                )

                self._handler = PPDocLayoutModelHandler(
                    labels, self.conf_thresh, self.iou_thresh, session
                )
            else:
                from rapid_layout.model_handler.pp.main import PPModelHandler

                self._handler = PPModelHandler(labels, self.conf_thresh, self.iou_thresh, session)
        return self._handler

    def warm_up(self) -> None:
        """Create the session + handler now (worker init, after the pins)."""
        self._get_handler()

    # -- the stage --------------------------------------------------------------

    def analyze(self, page: PageImage, lines: Sequence[Line], ctx: StageContext) -> list[Block]:
        ctx.deadline.check()
        page_no = _page_no(ctx)
        try:
            regions = self._infer(page)
        except Exception as exc:
            raise EngineDegraded(f"layout inference failed: {type(exc).__name__}: {exc}") from exc
        if not lines:
            # IR 1.4 (ADR 0010): a page with no recognised text is not
            # necessarily an empty page — it may be a logo, a photo or a
            # full-page chart. Keep whatever visual regions the model found;
            # only a page with neither text nor visual regions yields nothing.
            visual = [r for r in regions if DEFAULT_CLASS_MAP.get(r[1]) in _VISUAL_BLOCK_TYPES]
            if not visual and not self._page_rules(page, lines, (), ctx):
                return []
            return self._build_blocks(page, lines, visual, page_no, ctx)
        if not regions:
            ctx.logger.warning(
                "layout model found no regions on a page with %d line(s) — "
                "degrading to paragraph clustering inside the engine",
                len(lines),
            )
            return cluster_paragraph_blocks(page_no, lines)
        return self._build_blocks(page, lines, regions, page_no, ctx)

    def _infer(self, page: PageImage) -> list[tuple[BBox, str, float]]:
        result = self._get_handler()(_to_bgr(page.pixels))
        regions: list[tuple[BBox, str, float]] = []
        boxes = result.boxes if result.boxes is not None else []
        names = result.class_names if result.class_names is not None else []
        scores = result.scores if result.scores is not None else []
        for box, name, score in zip(boxes, names, scores, strict=True):
            x0 = float(np.clip(min(box[0], box[2]), 0, page.width))
            x1 = float(np.clip(max(box[0], box[2]), 0, page.width))
            y0 = float(np.clip(min(box[1], box[3]), 0, page.height))
            y1 = float(np.clip(max(box[1], box[3]), 0, page.height))
            if x1 <= x0 or y1 <= y0:
                continue
            regions.append(((x0, y0, x1, y1), str(name), float(np.clip(score, 0.0, 1.0))))
        regions.sort(key=lambda r: (r[0][1], r[0][0]))
        return regions

    def _build_blocks(
        self,
        page: PageImage,
        lines: Sequence[Line],
        regions: list[tuple[BBox, str, float]],
        page_no: int,
        ctx: StageContext,
    ) -> list[Block]:
        median_h = _median_line_height(lines)
        assigned, orphans = assign_lines_to_regions(
            lines,
            [r[0] for r in regions],
            containment_ratio=self.containment_ratio,
            min_ioa=self.min_ioa,
            gap_ceiling=self.orphan_gap_ratio * median_h,
        )

        drafts: list[_Draft] = []
        for idx, (bbox, class_name, score) in enumerate(regions):
            region_lines = assigned.get(idx, [])
            block_type = DEFAULT_CLASS_MAP.get(class_name)
            if block_type is None:
                ctx.logger.warning(
                    "layout class %r not in the mapping table — typed paragraph (never dropped)",
                    class_name,
                )
                block_type = BlockType.paragraph
            if not region_lines:
                # IR 1.4 (ADR 0010): a visual region holds no text by
                # construction — a logo, chart, photo or stamp. Keep it: its
                # bbox *is* the finding, and dropping it silently loses the
                # document's structure. A text region with no lines stays
                # dropped — an empty paragraph would be a fabricated claim.
                if block_type not in _VISUAL_BLOCK_TYPES:
                    ctx.logger.debug(
                        "layout region %s (%s) holds no recognised lines — dropped",
                        bbox,
                        class_name,
                    )
                    continue
                ctx.logger.debug(
                    "layout region %s (%s) kept as a line-less %s block",
                    bbox,
                    class_name,
                    block_type.value,
                )
                drafts.append(_Draft(block_type, bbox, (), score))
                continue
            block_type = self._gate_furniture_class(class_name, block_type, bbox, page, ctx)
            ordered = order_lines(region_lines, median_h)
            mean_conf = sum(ln.confidence for ln in ordered) / len(ordered)
            drafts.append(_Draft(block_type, _union_bbox(bbox, ordered), tuple(ordered), mean_conf))

        for orphan_block in cluster_paragraph_blocks(page_no, orphans):
            assert orphan_block.lines is not None
            conf = sum(ln.confidence for ln in orphan_block.lines) / len(orphan_block.lines)
            drafts.append(_Draft(BlockType.paragraph, orphan_block.bbox, orphan_block.lines, conf))

        drafts = [
            d.retyped(self._retype_text_dense_figure(d.type, d.bbox, d.lines, ctx))
            if d.lines
            else d
            for d in drafts
        ]
        drafts = [
            d.retyped(self._retype_kv(d.type, d.bbox, d.lines, page)) if d.lines else d
            for d in drafts
        ]
        drafts = [
            d.retyped(self._retype_positional_furniture(d.type, d.bbox, d.lines, page))
            if d.lines
            else d
            for d in drafts
        ]

        rules = self._page_rules(page, lines, drafts, ctx)
        rule_drafts = (
            [_Draft(BlockType.rule, bbox, (), coverage) for bbox, coverage in rules]
            if self.detect_rules
            else []
        )
        drafts.extend(rule_drafts)
        drafts = _attach_formula_numbers(drafts)
        drafts = _tighten_to_content(drafts)

        order = xy_cut_order([d.bbox for d in drafts])
        blocks: list[Block] = []
        for reading_order, draft_idx in enumerate(order):
            draft = drafts[draft_idx]
            blocks.append(
                Block(
                    block_id=f"p{page_no}_b{reading_order}",
                    type=draft.type,
                    bbox=draft.bbox,
                    reading_order=reading_order,
                    # A line-less visual block has no recognised text to average:
                    # its confidence is the layout model's detection score, and
                    # its origin is `ocr` — it is a raster-derived finding.
                    origin=draft.lines[0].origin if draft.lines else Origin.ocr,
                    confidence=min(1.0, max(0.0, draft.confidence)),
                    lines=tuple(draft.lines) if draft.lines else None,
                    table=PENDING_TABLE if draft.type is BlockType.table else None,
                )
            )
        assert blocks, "unreachable: every line is assigned or orphan-clustered"
        return self._with_connectors(page, lines, blocks, [bbox for bbox, _ in rules], ctx)

    def _with_connectors(
        self,
        page: PageImage,
        lines: Sequence[Line],
        blocks: list[Block],
        rules: Sequence[BBox],
        ctx: StageContext,
    ) -> list[Block]:
        """The page's drawn arrows, as blocks (IR 1.6, ADR 0012).

        **Off unless the pipeline turns it on**, and the reason is measured, not
        cautious by habit: on a cloud-architecture diagram (the sample in
        docs/notes) the pass emitted 10 strokes with heads on them, of which 2
        were arrows — the rest were stock-icon artwork — while missing most of
        the arrows actually drawn. Clean line diagrams —
        flowcharts, block diagrams, anything drawn with strokes rather than
        stock icons — come out exactly right, ends and heads included. Until the
        golden set can say which kind of page a caller has (phase 16), a wrong
        edge is a claimed relationship the document never made (hard rule 12),
        so the default abstains and the knob is one line of pipeline config.

        A layout model types a diagram ``figure`` and stops there: the region is
        found, its labels are read, and every arrow inside it — which is where a
        diagram keeps its meaning — is left in the pixels. This asks the raster
        the separate question ``engines/diagram`` answers, and merges the result
        through the same XY-cut the rest of the page went through, so a
        connector lands in reading order rather than after everything.

        Detection is an enhancement: a failure logs and leaves the page's blocks
        exactly as they were.
        """
        if not self.detect_connectors:
            return blocks
        try:
            drawn = find_connectors(
                page,
                lines,
                avoid=[b.bbox for b in blocks if b.type is BlockType.table],
                straight=rules,
            )
            connectors = connector_blocks(
                drawn,
                blocks,
                _page_no(ctx),
                page_span=float(max(page.width, page.height)),
                nodes=find_nodes(page, lines),
            )
        except Exception as exc:  # pragma: no cover - never the page
            ctx.logger.warning("connector detection failed (%s) — page keeps its blocks", exc)
            return blocks
        if not connectors:
            return blocks
        promoted = {c.from_rule for c in drawn if c.from_rule is not None}
        kept = [b for b in blocks if not _is_promoted_rule(b, rules, promoted)]
        merged = [*kept, *connectors]
        order = xy_cut_order([b.bbox for b in merged])
        return [
            merged[idx].model_copy(update={"reading_order": reading_order})
            for reading_order, idx in enumerate(order)
        ]

    def _page_rules(
        self,
        page: PageImage,
        lines: Sequence[Line],
        drafts: Sequence[_Draft],
        ctx: StageContext,
    ) -> list[tuple[BBox, float]]:
        """Long straight ink — a *signal*, not a finding (ADR 0014).

        ADR 0011 made every such run an IR block. Measured against a picture,
        that is wrong far more often than it is right: a 1600x420 marketing
        banner — photographic background, a skyline, one line of text — yields
        **152 rules, 151 of them vertical**, one per building edge and hair
        strand, and the projection fills with ``***`` breaks nobody drew
        (docs/notes/banner-phantom-rules.md). The detector cannot tell a drawn
        division from textured artwork, because at the level it works — adaptive
        threshold plus morphology — they are the same pixels.

        And a plain line is worth little even when it is real. An **arrow** is a
        relationship the document states, which is why ``engines/diagram`` reads
        it and emits it; a bare line says only that ink is there, while what a
        caller wants found is the text and its regions. So the geometry stays —
        two things genuinely need it, arrow candidates (a straight stroke with a
        head *is* an arrow; only the head tells them apart) and the ruled-table
        lattice on the digital path — and what the default drops is the claim.

        ``detect_rules`` turns emission back on for a pipeline whose pages are
        documents rather than pictures. Table grids are excluded either way: the
        table stage already models that ink, and emitting it again would count
        the same line twice.
        """
        if not (self.detect_rules or self.detect_connectors):
            return []
        avoid = [d.bbox for d in drafts if d.type is BlockType.table]
        try:
            found = find_page_rules(
                page,
                lines,
                avoid,
                min_width_frac=self.rule_min_width_frac,
                max_thickness_frac=self.rule_max_thickness_frac,
                vertical=self.rule_vertical,
                min_height_frac=self.rule_min_height_frac,
            )
        except Exception as exc:  # detection is an enhancement, never the page
            ctx.logger.warning("rule detection failed (%s) — page keeps its text blocks", exc)
            return []
        return found

    def _split_region(self, draft: _Draft, median_h: float, page: PageImage) -> list[_Draft]:
        """Break one model region into the blocks it actually contains.

        The layout models are coarse on documents outside their training domain:
        a CDLA model reading a résumé returns a single ``text`` box spanning
        every project entry, which projects as one run-on paragraph and loses
        the document's structure entirely. Two cuts recover it, both purely
        geometric so no model retraining is involved:

        1. **Section headings** — an ALL-CAPS line short and narrow enough to be
           a section title (``EDUCATION``, ``EXPERIENCE``) starts a new block and
           becomes a ``header``. This is the same rule the digital fast path has
           always applied; it simply never ran on the raster path.
        2. **Vertical gaps** — a gap larger than ``PARAGRAPH_GAP_RATIO`` x the
           median line height separates entries, the same threshold the
           clustering degrade path uses.

        Visual and table blocks are returned untouched: a table's rows are the
        table stage's business, and a line-less figure has nothing to split.
        """
        if draft.type in _VISUAL_BLOCK_TYPES or draft.type is BlockType.table:
            return [draft]
        if not draft.lines:
            return [draft]

        page_text_width = float(page.width)
        if len(draft.lines) == 1:
            # Nothing to split, but a lone section title still needs its type —
            # a model that boxes "EXPERIENCE" on its own hands us a one-line
            # region, and calling that a paragraph loses the section.
            if draft.type is BlockType.paragraph and is_section_heading(
                draft.lines[0], page_text_width
            ):
                return [draft.retyped(BlockType.header)]
            return [draft]

        groups: list[tuple[BlockType, list[Line]]] = []
        current: list[Line] = []
        for prev, line in zip((None, *draft.lines[:-1]), draft.lines, strict=True):
            heading = is_section_heading(line, page_text_width)
            gapped = (
                prev is not None and (line.bbox[1] - prev.bbox[3]) > PARAGRAPH_GAP_RATIO * median_h
            )
            if current and (heading or gapped):
                groups.append((draft.type, current))
                current = []
            if heading:
                groups.append((BlockType.header, [line]))
                continue
            current.append(line)
        if current:
            groups.append((draft.type, current))

        if len(groups) <= 1:
            return [draft]
        return [
            _Draft(
                block_type,
                _lines_bbox(group),
                tuple(group),
                sum(ln.confidence for ln in group) / len(group),
            )
            for block_type, group in groups
        ]

    def _gate_furniture_class(
        self, class_name: str, block_type: BlockType, bbox: BBox, page: PageImage, ctx: StageContext
    ) -> BlockType:
        """Trust a model furniture class only near the matching page edge —
        PP-DocLayout is known to call signature areas ``footer`` mid-page."""
        if class_name not in _FURNITURE_CLASSES and class_name != "number":
            return block_type
        band = self.model_band_frac * page.height
        if class_name in ("header",) and bbox[3] <= band:
            return BlockType.header
        if class_name in ("footer", "number") and bbox[1] >= page.height - band:
            return BlockType.footer
        if class_name == "number" and bbox[3] <= band:
            return BlockType.header
        ctx.logger.warning(
            "layout class %r at %s is not near its page edge — typed paragraph", class_name, bbox
        )
        return BlockType.paragraph

    def _retype_text_dense_figure(
        self, block_type: BlockType, bbox: BBox, block_lines: tuple[Line, ...], ctx: StageContext
    ) -> BlockType:
        """A ``figure`` region packed with recognised text is a mis-classification.

        The PP layout models type a page whose script they do not read as body
        text — handwriting, a phone photo of a ruled page — as ``image``, and
        the region then swallows every line on the page. Downstream that is not
        a cosmetic mistake: the projection replaces a figure with a placeholder,
        so an entire page of confidently recognised text can vanish from the
        Markdown (docs/notes/handwritten-sample-findings.md).

        Two geometric signals separate the mistake from a real figure, both
        computed on the *recognised lines*, never on the picture: a real chart,
        photo or logo carries a handful of short scattered labels, while a text
        region is mostly covered by its own text. Deliberately conservative —
        a mis-typed figure loses a picture placeholder, a mis-typed page loses
        the page.
        """
        if block_type is not BlockType.figure:
            return block_type
        rows = _visual_rows(block_lines, _median_line_height(block_lines))
        if len(rows) < self.figure_text_min_rows:
            return block_type
        area = max((bbox[2] - bbox[0]) * (bbox[3] - bbox[1]), 1.0)
        text_area = sum((ln.bbox[2] - ln.bbox[0]) * (ln.bbox[3] - ln.bbox[1]) for ln in block_lines)
        coverage = min(text_area / area, 1.0)
        if coverage < self.figure_text_min_coverage:
            return block_type
        ctx.logger.info(
            "figure region %s carries %d text rows covering %.2f of its area — "
            "typed paragraph (layout mis-classification, text kept)",
            bbox,
            len(rows),
            coverage,
        )
        return BlockType.paragraph

    def _retype_kv(
        self, block_type: BlockType, bbox: BBox, block_lines: tuple[Line, ...], page: PageImage
    ) -> BlockType:
        if block_type is not BlockType.paragraph:
            return block_type
        if bbox[1] > self.kv_top_frac * page.height:
            return block_type
        rows = _visual_rows(block_lines, _median_line_height(block_lines))
        if len(rows) < self.kv_min_rows:
            return block_type
        matches = [row for row in rows if _KV_ROW_RE.match(_row_text(row))]
        if len(matches) < self.kv_min_rows:
            return block_type
        if len(matches) / len(rows) < self.kv_min_row_frac:
            return block_type
        starts = [min(ln.bbox[0] for ln in row) for row in matches]
        if max(starts) - min(starts) > self.kv_align_frac * page.width:
            return block_type
        return BlockType.kv

    def _retype_positional_furniture(
        self, block_type: BlockType, bbox: BBox, block_lines: tuple[Line, ...], page: PageImage
    ) -> BlockType:
        if block_type is not BlockType.paragraph:
            return block_type
        rows = _visual_rows(block_lines, _median_line_height(block_lines))
        if len(rows) > self.furniture_max_rows:
            return block_type
        band = self.furniture_band_frac * page.height
        if bbox[3] <= band:
            return BlockType.header
        if bbox[1] >= page.height - band:
            return BlockType.footer
        return block_type


# -- pure geometry (model-independent; unit-tested without models) ---------------


def _is_promoted_rule(block: Block, rules: Sequence[BBox], promoted: set[int]) -> bool:
    """Was this rule block re-read as an arrow? Then the arrow carries its ink."""
    if block.type is not BlockType.rule:
        return False
    return any(block.bbox == rules[i] for i in promoted if i < len(rules))


def _page_no(ctx: StageContext) -> int:
    value = ctx.config.get("page_no", 0)
    return value if isinstance(value, int) else 0


def _median_line_height(lines: Sequence[Line]) -> float:
    if not lines:
        return 1.0
    heights = sorted(ln.bbox[3] - ln.bbox[1] for ln in lines)
    return max(heights[len(heights) // 2], 1.0)


def _intersection_area(a: BBox, b: BBox) -> float:
    w = min(a[2], b[2]) - max(a[0], b[0])
    h = min(a[3], b[3]) - max(a[1], b[1])
    return max(0.0, w) * max(0.0, h)


def _bbox_gap(a: BBox, b: BBox) -> float:
    """Euclidean gap between two boxes (0 when they touch or overlap)."""
    dx = max(0.0, max(a[0], b[0]) - min(a[2], b[2]))
    dy = max(0.0, max(a[1], b[1]) - min(a[3], b[3]))
    return float(np.hypot(dx, dy))


def find_page_rules(
    page: PageImage,
    lines: Sequence[Line],
    avoid: Sequence[BBox],
    *,
    min_width_frac: float,
    max_thickness_frac: float,
    vertical: bool = True,
    min_height_frac: float = 0.04,
) -> list[tuple[BBox, float]]:
    """Long straight ink — horizontal runs and vertical strokes.

    A **signal**, not a finding: what this returns feeds the ruled-table lattice
    and the arrow pass's straight-candidate list. Emitting it as ``rule`` blocks
    is off by default (ADR 0014) — see :meth:`RapidLayoutEngine._page_rules` for
    the measured reason.

    Long thin ink runs, found by opening the inverted page with a wide 1-px-tall
    kernel (and a tall 1-px-wide one for the vertical pass) — the same morphology
    ``engines/tables.py`` uses to decide whether a table is bordered, applied to
    the page instead of one region.

    Vertical strokes matter because they are the sides of things: the box around
    a component in an architecture diagram, a column divider, a bracket. Without
    them a diagram's boxes vanish and only their tops and bottoms survive.

    Conservative by design: a fabricated rule invents a division the document
    does not have. A run survives only if it is long, thin, outside every
    ``avoid`` box (table grids, already modelled) and — for horizontal runs — not
    an underline tracking a recognised line. Returns ``(bbox, coverage)``.
    """
    pixels = page.pixels
    gray = pixels if pixels.ndim == 2 else cv2.cvtColor(pixels, cv2.COLOR_RGB2GRAY)
    h, w = gray.shape
    if h < 8 or w < 8:
        return []
    binv = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 15, 10
    )

    out: list[tuple[BBox, float]] = []
    max_thickness = max(1.0, max_thickness_frac * max(h, w))

    for axis in ("h", "v") if vertical else ("h",):
        if axis == "h":
            kernel = np.ones((1, max(16, int(w * min_width_frac))), dtype=np.uint8)
        else:
            kernel = np.ones((max(16, int(h * min_height_frac)), 1), dtype=np.uint8)
        mask = cv2.morphologyEx(binv, cv2.MORPH_OPEN, kernel)
        n, _, stats, _ = cv2.connectedComponentsWithStats(
            mask.astype(np.uint8, copy=False), connectivity=8
        )
        for i in range(1, n):
            x = float(stats[i, cv2.CC_STAT_LEFT])
            y = float(stats[i, cv2.CC_STAT_TOP])
            rw = float(stats[i, cv2.CC_STAT_WIDTH])
            rh = float(stats[i, cv2.CC_STAT_HEIGHT])
            if axis == "h":
                if rw < min_width_frac * w or rh > max_thickness:
                    continue
                coverage = min(1.0, rw / w)
            else:
                if rh < min_height_frac * h or rw > max_thickness:
                    continue
                coverage = min(1.0, rh / h)
            bbox = (x, y, x + rw, y + rh)
            if any(_vertically_within(bbox, box) for box in avoid):
                continue
            # Only a horizontal run can be an underline; a vertical stroke beside
            # text is a bracket or a box edge, never decoration of the words.
            if axis == "h" and any(_is_underline(bbox, ln.bbox) for ln in lines):
                continue
            out.append((bbox, coverage))
    out.sort(key=lambda r: (r[0][1], r[0][0]))
    return out


RULE_MIN_WIDTH_FRAC = 0.12
RULE_MAX_THICKNESS_FRAC = 0.006
RULE_MIN_HEIGHT_FRAC = 0.04
"""Defaults shared with the digital fast path, which has no engine instance to
read its constructor params from."""


def _content_bbox(draft: _Draft) -> BBox | None:
    """The box the draft's own recognised text occupies, or None if it has no text.

    A line-less visual block has no content to tighten to — its box *is* the
    finding — so it neither shrinks nor forces anything else to.
    """
    if not draft.lines:
        return None
    return (
        min(ln.bbox[0] for ln in draft.lines),
        min(ln.bbox[1] for ln in draft.lines),
        max(ln.bbox[2] for ln in draft.lines),
        max(ln.bbox[3] for ln in draft.lines),
    )


FORMULA_NUMBER_MAX_WIDTH_FRAC = 0.25
"""How wide a region beside a formula may be and still be read as its number.
An equation number is a couple of glyphs in the margin; anything approaching the
formula's own width is content sitting alongside it, not a label on it."""

FORMULA_NUMBER_BAND_FRAC = 0.5
"""How much of the narrower region's height must overlap the formula's for the
two to count as one visual row."""


def _attach_formula_numbers(drafts: Sequence[_Draft]) -> list[_Draft]:
    """Merge an equation number into the formula it belongs to (IR 1.8).

    A numbered display equation is typeset as two things a layout model sees
    separately: the mathematics, and ``(7)`` flushed to the margin. Measured on a
    real paper, cdla returns the second as its own tiny ``text`` region at the
    right edge — *not* as ``formula_number``, which is a class it does not emit —
    so the relation has to be geometric, and it is the same one phase 19 settled
    for the renderer: **they share a y-band**.

    A candidate must sit beside a formula, overlap it vertically, and be narrow.
    Anything else stays exactly where it was: a region that matches no formula is
    never dropped and never re-typed, because a wrong merge would move real
    content into a block that claims to be mathematics.
    """
    formulae = [i for i, d in enumerate(drafts) if d.type is BlockType.formula]
    if not formulae:
        return list(drafts)
    merged_into: dict[int, list[Line]] = {}
    consumed: set[int] = set()
    for idx, draft in enumerate(drafts):
        if draft.type is BlockType.formula or not draft.lines:
            continue
        width = draft.bbox[2] - draft.bbox[0]
        height = draft.bbox[3] - draft.bbox[1]
        for f_idx in formulae:
            formula = drafts[f_idx]
            f_width = formula.bbox[2] - formula.bbox[0]
            if width > FORMULA_NUMBER_MAX_WIDTH_FRAC * f_width:
                continue
            # Beside it, not inside it: a run within the formula's own x-range is
            # part of the mathematics and was already assigned to that region.
            if draft.bbox[0] < formula.bbox[2]:
                continue
            overlap = min(draft.bbox[3], formula.bbox[3]) - max(draft.bbox[1], formula.bbox[1])
            if overlap < FORMULA_NUMBER_BAND_FRAC * max(height, 1.0):
                continue
            merged_into.setdefault(f_idx, []).extend(draft.lines)
            consumed.add(idx)
            break
    if not consumed:
        return list(drafts)
    out: list[_Draft] = []
    for idx, draft in enumerate(drafts):
        if idx in consumed:
            continue
        extra = merged_into.get(idx)
        if extra is None:
            out.append(draft)
            continue
        lines = tuple(sorted([*draft.lines, *extra], key=lambda ln: (ln.bbox[1], ln.bbox[0])))
        out.append(replace(draft, bbox=_union_bbox(draft.bbox, lines), lines=lines))
    return out


def _tighten_to_content(drafts: Sequence[_Draft]) -> list[_Draft]:
    """No block's box may claim another block's content.

    A layout model's boxes are approximate and they overlap: on a reservation
    slip it returned three table regions where the second started 300 px above
    its own first row, inside the first region's passenger list. The *lines*
    were assigned correctly — containment and IoA sort that out — but the boxes
    kept the model's extents, so two blocks each claimed a band of pixels only
    one of them had any content in.

    That is wrong twice over. The bbox is the provenance of everything the block
    carries (hard rule 3), and a box covering a neighbour's rows is a false
    claim about where its own text came from. And anything that draws the page
    from its boxes — the demo's layout view, a table's row grid — puts two
    blocks in the same place and the page renders on top of itself.

    The fix is the smallest one that is also principled: where two boxes overlap
    but their contents do not, the boundary moves to the middle of the gap
    between them. Neither box can lose a pixel of its own content (the midpoint
    lies in the gap by construction), and no box grows. Contents that genuinely
    interleave — a caption inside a figure's region — are left alone: that is
    real geometry, not model slop.
    """
    boxes = [list(d.bbox) for d in drafts]
    content = [_content_bbox(d) for d in drafts]
    for i, ci in enumerate(content):
        if ci is None:
            continue
        for j in range(i + 1, len(content)):
            cj = content[j]
            if cj is None:
                continue
            if _intersection_area(tuple(boxes[i]), tuple(boxes[j])) <= 0:  # type: ignore[arg-type]
                continue
            if _intersection_area(ci, cj) > 0:
                continue
            if ci[3] <= cj[1]:  # i's text sits above j's
                mid = 0.5 * (ci[3] + cj[1])
                boxes[i][3] = min(boxes[i][3], mid)
                boxes[j][1] = max(boxes[j][1], mid)
            elif cj[3] <= ci[1]:
                mid = 0.5 * (cj[3] + ci[1])
                boxes[j][3] = min(boxes[j][3], mid)
                boxes[i][1] = max(boxes[i][1], mid)
            elif ci[2] <= cj[0]:  # i's text sits left of j's
                mid = 0.5 * (ci[2] + cj[0])
                boxes[i][2] = min(boxes[i][2], mid)
                boxes[j][0] = max(boxes[j][0], mid)
            elif cj[2] <= ci[0]:
                mid = 0.5 * (cj[2] + ci[0])
                boxes[j][2] = min(boxes[j][2], mid)
                boxes[i][0] = max(boxes[i][0], mid)
    return [
        replace(draft, bbox=(box[0], box[1], box[2], box[3]))
        for draft, box in zip(drafts, boxes, strict=True)
    ]


def decode_png_page(png: bytes) -> PageImage:
    """Shared PNG → :class:`PageImage` for the digital path's pixel-level checks.

    Decoding lives in this module because the imaging dependencies are
    quarantined to it (docs/08); the digital fast path has no worker-side
    :class:`PageImage` of its own, only the display raster the orchestrator
    already rendered.
    """
    import io

    from PIL import Image

    with Image.open(io.BytesIO(png)) as img:
        pixels = np.asarray(img.convert("RGB"), dtype=np.uint8)
    return PageImage(
        width=int(pixels.shape[1]), height=int(pixels.shape[0]), dpi=None, pixels=pixels
    )


def find_rules_on_page(
    page: PageImage,
    lines: Sequence[Line],
    avoid: Sequence[BBox],
) -> list[tuple[BBox, float]]:
    """:func:`find_page_rules` at the digital path's thresholds.

    A born-digital page never reaches the OCR worker, so nothing there ever looks
    at its pixels; but its diagrams and tables are drawn, not written, and only
    the pixels show them. The orchestrator already has the display raster in
    hand, so it decodes that once (:func:`decode_png_page`) and passes the page
    here rather than re-rendering.
    """
    return find_page_rules(
        page,
        lines,
        avoid,
        min_width_frac=RULE_MIN_WIDTH_FRAC,
        max_thickness_frac=RULE_MAX_THICKNESS_FRAC,
        min_height_frac=RULE_MIN_HEIGHT_FRAC,
    )


def find_rules_in_png(
    png: bytes,
    lines: Sequence[Line],
    avoid: Sequence[BBox],
) -> list[tuple[BBox, float]]:
    """:func:`find_rules_on_page` over encoded bytes, for callers with no page."""
    return find_rules_on_page(decode_png_page(png), lines, avoid)


UNCLAIMED_INK_MIN_INK_FRAC = 0.0005
"""Below this fraction of page pixels being ink at all, the page is judged
near-blank and the ratio (0 ink claimed of ~0 ink total) is meaningless noise —
skip the check rather than divide by a speck."""


def unclaimed_ink_fraction(png: bytes, claimed: Sequence[BBox]) -> float:
    """How much of the page's ink sits outside every box the text layer claims.

    Two independent PDF text-extraction libraries derive their output from the
    same underlying content stream. When the stream itself doesn't expose a run
    of text — the case that surfaced this: a PowerPoint export puts each shape's
    caption inside a nested Form XObject neither ``pdf-inspector`` nor
    ``pypdfium2`` walks into — both parsers agree on the same *incomplete*
    answer. The digital route's coverage gate cross-checks one parser's char
    count against the other's, which is exactly blind to two parsers sharing one
    blind spot: they agree, and they are both wrong.

    This looks at the rendered pixels instead of a second parser's opinion. Ink
    that exists on the page but sits outside every line the text layer actually
    delivered is content the extraction missed, whatever the two parsers say
    about each other — six boxes of caption text with real dark pixels inside
    them, and a text layer that produced zero lines for that entire region, is
    exactly what this catches and the coverage gate cannot.

    Conservative by construction, matching hard rule 12: a legitimate photo
    with no caption also reads as "unclaimed ink" here, and routes to OCR too.
    That is the safe direction to be wrong in — a page that gets read twice
    costs CPU; a page whose real content silently vanished does not get a
    second chance. ``max_unclaimed_ink_frac`` is pipeline config for exactly
    this trade-off.
    """
    binv = _ink_mask(png)
    ink_total = int(np.count_nonzero(binv))
    if ink_total < UNCLAIMED_INK_MIN_INK_FRAC * binv.size:
        return 0.0
    mask = _claimed_mask(binv.shape, claimed)
    unclaimed = int(np.count_nonzero(cv2.bitwise_and(binv, cv2.bitwise_not(mask))))
    return unclaimed / ink_total


def _ink_mask(png: bytes) -> npt.NDArray[np.uint8]:
    """The rendered page's ink, binarised (adaptive mean threshold, inverted so
    ink is 255). Shared by the page-level ratio and the region finder so the
    two never disagree about what counts as ink."""
    page = decode_png_page(png)
    gray = page.pixels if page.pixels.ndim == 2 else cv2.cvtColor(page.pixels, cv2.COLOR_RGB2GRAY)
    binv = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 25, 15
    )
    return np.asarray(binv, dtype=np.uint8)


def _claimed_mask(shape: tuple[int, ...], claimed: Sequence[BBox]) -> npt.NDArray[np.uint8]:
    mask = np.zeros(shape[:2], dtype=np.uint8)
    h, w = mask.shape
    for x0, y0, x1, y1 in claimed:
        r0, r1 = max(0, int(y0)), min(h, int(np.ceil(y1)))
        c0, c1 = max(0, int(x0)), min(w, int(np.ceil(x1)))
        if r1 > r0 and c1 > c0:
            mask[r0:r1, c0:c1] = 255
    return mask


@dataclass(frozen=True)
class RasterRegion:
    """One raster region of a born-digital page (phase 23, ADR 0020).

    ``source`` says how it was found: ``"image"`` — an image object the PDF
    itself declares, exact and always read; ``"ink"`` — a connected component
    of ink nothing claimed, which layout may later vouch for as a drawn figure
    whose labels are already exact text (then it is recorded, not read again).
    """

    bbox: BBox
    source: str


REGION_MIN_SIDE_PX = 20
"""A raster region narrower or shorter than this, in page pixels, is a speck."""

REGION_MAX_PER_PAGE = 16
"""Regions OCR'd per born-digital page, largest first — the budget for the pass."""

REGION_MAX_AREA_FRAC = 0.6
"""A region covering more of the page than this is the page, not a region on
it: a scanned page with a stub text layer is the 35 % valve's case, not this one."""

REGION_MAX_CLAIMED_FRAC = 0.25
"""An image with more than this fraction of its area under text-layer boxes is
a background the text is printed *over* — OCR'ing it would read the exact text
a second time, worse."""

REGION_RULE_FRAC = 0.25
"""A straight run of ink at least this fraction of the page side long is a
division — a letterhead rule, a table border, a form's box — and is lifted
out before components are grown: otherwise it bridges the pictures it sits
between into one region spanning the page (measured on the hybrid fixture:
a logo, the letterhead rule and a vector mark came back as one 1008 px band)."""

TEXT_ROW_COVER = 0.2
"""A row of an ink candidate counts as a text row when claimed boxes cover more
than this fraction of the candidate's width. A picture's ink stops at such a
row — a diagram whose strokes run beside body text must not carry that text
into its region and have it read a second time (measured on the paper's page
5: six exact lines came back again as OCR) — while a dilation edge that merely
touches a neighbouring line does not cut the picture in two."""

CLAIMED_GROW_PX = 2.0
"""Claimed boxes are grown by this much on every side before the region pass
reads them: a glyph's anti-aliased edge and a rule's last row sit just outside
the box the text layer or the rule finder reported, and a one-pixel line of
such ink is enough to pass a density floor as a "picture"."""

REGION_MIN_INK_DENSITY = 0.01
"""Unclaimed ink a region must hold, as a fraction of its area. A blank margin
of a background image, or the empty strip between two text rows, is not a
picture however its box came about."""

REGION_MERGE_FRAC = 0.02
"""Morphological kernel, as a fraction of the page's longer side: ink this close
together is one region — the letters of a wordmark, the strokes of a stamp. At
2 % (~25 px on a 150-DPI A4 render) a wordmark's letters and its words merge;
text lines are claimed before this runs, so nothing here can swallow text."""


def _clamp_box(box: BBox, w: int, h: int) -> BBox:
    x0, y0, x1, y1 = box
    x0, x1 = min(max(x0, 0.0), float(w)), min(max(x1, 0.0), float(w))
    y0, y1 = min(max(y0, 0.0), float(h)), min(max(y1, 0.0), float(h))
    return (x0, y0, max(x1, x0), max(y1, y0))


def _box_area(box: BBox) -> float:
    return max(0.0, box[2] - box[0]) * max(0.0, box[3] - box[1])


def _inside_frac(inner: BBox, outer: BBox) -> float:
    """Fraction of ``inner``'s area lying inside ``outer``."""
    w = min(inner[2], outer[2]) - max(inner[0], outer[0])
    h = min(inner[3], outer[3]) - max(inner[1], outer[1])
    area = _box_area(inner)
    return (max(0.0, w) * max(0.0, h) / area) if area > 0 else 0.0


def _mask_frac(mask: npt.NDArray[np.uint8], box: BBox) -> float:
    """Fraction of ``box`` that ``mask`` marks."""
    h, w = mask.shape
    r0, r1 = max(0, int(box[1])), min(h, int(np.ceil(box[3])))
    c0, c1 = max(0, int(box[0])), min(w, int(np.ceil(box[2])))
    if r1 <= r0 or c1 <= c0:
        return 0.0
    window = mask[r0:r1, c0:c1]
    return float(np.count_nonzero(window)) / float(window.size)


def _slice_at_text_rows(box: BBox, cmask: npt.NDArray[np.uint8], min_side_px: int) -> list[BBox]:
    """Split an ink candidate at the text rows it spans; the runs of non-text
    rows at least ``min_side_px`` tall are what remains of it."""
    h, w = cmask.shape
    r0, r1 = max(0, int(box[1])), min(h, int(np.ceil(box[3])))
    c0, c1 = max(0, int(box[0])), min(w, int(np.ceil(box[2])))
    if r1 <= r0 or c1 <= c0:
        return []
    cover = np.count_nonzero(cmask[r0:r1, c0:c1], axis=1) / float(c1 - c0)
    text_row = [bool(v) for v in (cover > TEXT_ROW_COVER).tolist()]
    if not any(text_row):
        return [box]
    pieces: list[BBox] = []
    start: int | None = None
    for i, is_text in enumerate([*text_row, True]):
        if not is_text and start is None:
            start = i
        elif is_text and start is not None:
            if i - start >= min_side_px:
                pieces.append((box[0], float(r0 + start), box[2], float(r0 + i)))
            start = None
    return pieces


def raster_regions(
    png: bytes,
    claimed: Sequence[BBox],
    image_boxes: Sequence[BBox],
    *,
    min_side_px: int = REGION_MIN_SIDE_PX,
    max_regions: int = REGION_MAX_PER_PAGE,
    max_area_frac: float = REGION_MAX_AREA_FRAC,
    max_claimed_frac: float = REGION_MAX_CLAIMED_FRAC,
    merge_frac: float = REGION_MERGE_FRAC,
) -> list[RasterRegion]:
    """The raster regions of a born-digital page — what on it is a picture, a
    stamp, a pasted scan, a wordmark — for the digital route to OCR (phase 23,
    ADR 0020). Page-space pixel boxes, top-to-bottom then left-to-right, each
    tagged with its source (``"image"`` object or unclaimed ``"ink"``).

    Two sources, the exact one first. ``image_boxes`` are the PDF's own image
    objects: no model decided they exist. Then the connected components of ink
    that nothing ``claimed`` — no text-layer line, ruling or layout-typed visual
    block — closed and dilated by ``merge_frac`` of the page so the letters of
    a wordmark or the strokes of a stamp are one region, not thirty. That is the
    mask :func:`unclaimed_ink_fraction` already builds, kept as regions instead
    of collapsed to a ratio; it is what finds a *vector* logo, which is not an
    image object at all.

    Three exclusions, each a measured shape rather than a threshold on a
    distribution: below ``min_side_px`` a component is a speck; above
    ``max_area_frac`` of the page a box is the page itself (the whole-page
    valve's case); an image with more than ``max_claimed_frac`` of its area
    under text-layer boxes is a background the text is printed *over*, and
    reading it would deliver the exact text a second time, worse. A component
    mostly inside an accepted region is that region. ``max_regions`` caps the
    pass, largest first — the budget hard rule 12 asks a fallback to have.
    """
    binv = _ink_mask(png)
    h, w = binv.shape
    page_area = float(w * h)
    grown = [
        (x0 - CLAIMED_GROW_PX, y0 - CLAIMED_GROW_PX, x1 + CLAIMED_GROW_PX, y1 + CLAIMED_GROW_PX)
        for x0, y0, x1, y1 in claimed
    ]
    cmask = _claimed_mask(binv.shape, grown)
    unclaimed_ink = np.asarray(cv2.bitwise_and(binv, cv2.bitwise_not(cmask)), dtype=np.uint8)
    regions: list[RasterRegion] = []

    def accept(candidate: BBox, source: str) -> None:
        box = _clamp_box(candidate, w, h)
        if box[2] - box[0] < min_side_px or box[3] - box[1] < min_side_px:
            return
        if _box_area(box) > max_area_frac * page_area:
            return
        if _mask_frac(cmask, box) > max_claimed_frac:
            return
        if _mask_frac(unclaimed_ink, box) < REGION_MIN_INK_DENSITY:
            return
        if source == "ink" and any(_inside_frac(text, box) > 0.5 for text in claimed):
            # Text lines were subtracted before the ink was grown; a component
            # that still holds one bridged across it — not a picture.
            return
        if any(_inside_frac(box, kept.bbox) > 0.5 for kept in regions):
            return
        regions.append(RasterRegion(bbox=box, source=source))

    for box in image_boxes:
        # An image whose bounds run under text-layer lines — a margin
        # decoration, a background — keeps only its text-free bands: the text
        # inside it is exact already (measured on the paper's page 5, where a
        # margin image reaching under two body lines had them read again).
        for piece in _slice_at_text_rows(_clamp_box(box, w, h), cmask, min_side_px):
            accept(piece, "image")

    ink_total = int(np.count_nonzero(binv))
    if ink_total >= UNCLAIMED_INK_MIN_INK_FRAC * binv.size:
        taken = _claimed_mask(binv.shape, [*grown, *(r.bbox for r in regions)])
        free = cv2.bitwise_and(binv, cv2.bitwise_not(taken))
        # Lift page divisions out before growing: a rule is not a picture and
        # must not join the pictures on either side of it into one.
        h_len = max(15, int(REGION_RULE_FRAC * w))
        v_len = max(15, int(REGION_RULE_FRAC * h))
        ruled = cv2.bitwise_or(
            cv2.morphologyEx(
                free, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (h_len, 1))
            ),
            cv2.morphologyEx(
                free, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, v_len))
            ),
        )
        free = cv2.bitwise_and(free, cv2.bitwise_not(ruled))
        k = max(3, round(merge_frac * max(w, h)) | 1)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (k, k))
        grown = cv2.dilate(cv2.morphologyEx(free, cv2.MORPH_CLOSE, kernel), kernel)
        n, _labels, stats, _centroids = cv2.connectedComponentsWithStats(grown, connectivity=8)
        shrink = float(k // 2)
        candidates: list[tuple[int, BBox]] = []
        for i in range(1, int(n)):
            x, y, bw, bh, area = (int(v) for v in stats[i])
            candidates.append((area, (x + shrink, y + shrink, x + bw - shrink, y + bh - shrink)))
        candidates.sort(key=lambda c: (-c[0], c[1]))
        for _area, box in candidates:
            clipped = _clamp_box(box, w, h)
            if _mask_frac(cmask, clipped) > max_claimed_frac:
                # Text-dominated ink — a table's cell borders, underlines, the
                # tails of glyphs — is not a picture, and slicing it would only
                # carve text-free slivers out of a text block.
                continue
            for piece in _slice_at_text_rows(clipped, cmask, min_side_px):
                accept(piece, "ink")

    return sorted(regions[:max_regions], key=lambda r: (r.bbox[1], r.bbox[0]))


def _vertically_within(inner: BBox, outer: BBox) -> bool:
    """``inner``'s vertical centre lies within ``outer`` and they overlap in x."""
    cy = (inner[1] + inner[3]) / 2.0
    return outer[1] <= cy <= outer[3] and inner[0] < outer[2] and outer[0] < inner[2]


_UNDERLINE_OVERHANG = 0.25
"""How far a rule may extend past the text it underlines, as a fraction of that
text's width, before it stops being an underline and becomes a division."""


def _is_underline(rule: BBox, line: BBox) -> bool:
    """Is ``rule`` decoration belonging to ``line`` rather than a page division?

    Vertical overlap alone is not enough, and assuming it was is what hid every
    section rule on a résumé: a heading's box often extends down over the rule
    beneath it, so a full-width divider under a short heading looked like that
    heading's underline. A real underline also tracks the text horizontally — it
    runs under the words and stops. One that shoots well past them, margin to
    margin, is dividing the page no matter which box it happens to sit inside.
    """
    if not _vertically_within(rule, line):
        return False
    text_width = max(1.0, line[2] - line[0])
    overhang = max(0.0, line[0] - rule[0]) + max(0.0, rule[2] - line[2])
    return overhang <= _UNDERLINE_OVERHANG * text_width


def _lines_bbox(lines: Sequence[Line]) -> BBox:
    """Union of the lines' own boxes — the bbox of a block carved out of a
    larger region, which must not inherit the region's full extent."""
    return (
        min(ln.bbox[0] for ln in lines),
        min(ln.bbox[1] for ln in lines),
        max(ln.bbox[2] for ln in lines),
        max(ln.bbox[3] for ln in lines),
    )


def _union_bbox(region: BBox, lines: Sequence[Line]) -> BBox:
    """Region bbox grown to contain every assigned line (IoA/nearest assignment
    can attach lines that stick out of the model's region)."""
    x0 = min(region[0], *(ln.bbox[0] for ln in lines))
    y0 = min(region[1], *(ln.bbox[1] for ln in lines))
    x1 = max(region[2], *(ln.bbox[2] for ln in lines))
    y1 = max(region[3], *(ln.bbox[3] for ln in lines))
    return (x0, y0, x1, y1)


def assign_lines_to_regions(
    lines: Sequence[Line],
    regions: Sequence[BBox],
    *,
    containment_ratio: float = 0.7,
    min_ioa: float = 0.05,
    gap_ceiling: float = 0.0,
) -> tuple[dict[int, list[Line]], list[Line]]:
    """Assign every line to at most one region; the rest are orphans.

    Order of preference per line (phase 10 §4.3): containment (line centre inside
    the region and ≥ ``containment_ratio`` of the line's area covered), else the
    region with the highest intersection-over-line-area above ``min_ioa``, else
    the nearest region within ``gap_ceiling``. Lines are never discarded — the
    caller turns orphans into paragraph blocks. Conservation holds by
    construction: every input line appears exactly once across the outputs.
    """
    assigned: dict[int, list[Line]] = {}
    orphans: list[Line] = []
    for line in lines:
        area = max(
            (line.bbox[2] - line.bbox[0]) * (line.bbox[3] - line.bbox[1]),
            1e-6,
        )
        cx = (line.bbox[0] + line.bbox[2]) / 2.0
        cy = (line.bbox[1] + line.bbox[3]) / 2.0
        best_idx: int | None = None
        best_ioa = 0.0
        contained_idx: int | None = None
        contained_ioa = 0.0
        for idx, region in enumerate(regions):
            ioa = _intersection_area(line.bbox, region) / area
            centre_inside = region[0] <= cx <= region[2] and region[1] <= cy <= region[3]
            if centre_inside and ioa >= containment_ratio and ioa > contained_ioa:
                contained_idx, contained_ioa = idx, ioa
            if ioa > best_ioa:
                best_idx, best_ioa = idx, ioa
        if contained_idx is not None:
            assigned.setdefault(contained_idx, []).append(line)
            continue
        if best_idx is not None and best_ioa >= min_ioa:
            assigned.setdefault(best_idx, []).append(line)
            continue
        if gap_ceiling > 0.0 and regions:
            gaps = [(_bbox_gap(line.bbox, region), idx) for idx, region in enumerate(regions)]
            gap, idx = min(gaps)
            if gap <= gap_ceiling:
                assigned.setdefault(idx, []).append(line)
                continue
        orphans.append(line)
    return assigned, orphans


def _visual_rows(lines: Sequence[Line], median_h: float) -> list[list[Line]]:
    ordered = sorted(lines, key=lambda ln: ((ln.bbox[1] + ln.bbox[3]) / 2.0, ln.bbox[0]))
    rows: list[list[Line]] = []
    for line in ordered:
        centre = (line.bbox[1] + line.bbox[3]) / 2.0
        if rows:
            last = rows[-1]
            last_centre = sum((ln.bbox[1] + ln.bbox[3]) / 2.0 for ln in last) / len(last)
            if abs(centre - last_centre) <= _ROW_GROUP_RATIO * median_h:
                last.append(line)
                continue
        rows.append([line])
    for row in rows:
        row.sort(key=lambda ln: ln.bbox[0])
    return rows


def _row_text(row: Sequence[Line]) -> str:
    return " ".join(ln.text for ln in row if ln.text)


def order_lines(lines: Sequence[Line], median_h: float) -> list[Line]:
    """Reading order within a block: visual rows top to bottom, left to right."""
    return [line for row in _visual_rows(lines, median_h) for line in row]


def xy_cut_order(boxes: Sequence[BBox]) -> list[int]:
    """Recursive XY-cut: indices of ``boxes`` in reading order.

    At every level the projection gap ("whitespace valley") is computed on both
    axes over the group's boxes; the larger valley is cut, vertical-first on ties
    (multi-column pages: a column gap and a row gap of equal size must read the
    left column first). No valley → top-to-bottom, left-to-right.
    """
    order: list[int] = []

    def recurse(group: list[int]) -> None:
        if len(group) <= 1:
            order.extend(group)
            return
        x_gap, x_cut = _largest_valley([(boxes[i][0], boxes[i][2]) for i in group])
        y_gap, y_cut = _largest_valley([(boxes[i][1], boxes[i][3]) for i in group])
        if x_gap <= 0.0 and y_gap <= 0.0:
            order.extend(sorted(group, key=lambda i: (boxes[i][1], boxes[i][0])))
            return
        if x_gap >= y_gap:
            first = [i for i in group if (boxes[i][0] + boxes[i][2]) / 2.0 < x_cut]
            second = [i for i in group if i not in first]
        else:
            first = [i for i in group if (boxes[i][1] + boxes[i][3]) / 2.0 < y_cut]
            second = [i for i in group if i not in first]
        recurse(first)
        recurse(second)

    recurse(list(range(len(boxes))))
    return order


def _largest_valley(intervals: list[tuple[float, float]]) -> tuple[float, float]:
    """Largest gap between the merged projection intervals: (size, cut position).

    Size 0 means the projection is a single solid run — no valley to cut.
    """
    merged: list[list[float]] = []
    for lo, hi in sorted(intervals):
        if merged and lo <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], hi)
        else:
            merged.append([lo, hi])
    best_size, best_cut = 0.0, 0.0
    for prev, nxt in pairwise(merged):
        size = nxt[0] - prev[1]
        if size > best_size:
            best_size, best_cut = size, (prev[1] + nxt[0]) / 2.0
    return best_size, best_cut


__all__ = [
    "DEFAULT_CLASS_MAP",
    "RAPID_LAYOUT_VERSION",
    "RapidLayoutEngine",
    "assign_lines_to_regions",
    "decode_png_page",
    "find_page_rules",
    "find_rules_in_png",
    "find_rules_on_page",
    "order_lines",
    "unclaimed_ink_fraction",
    "xy_cut_order",
]
