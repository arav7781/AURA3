"""Engine implementations, one module per concern; vendor imports quarantined here.

Importing this package registers every engine implementation with the default
registry (the ``@register`` decorators run at import time); pipeline configs then
select them by name — nothing imports an implementation class directly (docs/08).
"""

from titanocr.engines import (
    images,
    layout,
    pdftext,
    prep,
    rapidocr,
    raster,
    tables,
    triage,
    vlm,
)

__all__ = [
    "images",
    "layout",
    "pdftext",
    "prep",
    "rapidocr",
    "raster",
    "tables",
    "triage",
    "vlm",
]
