"""VLM escalation (stage 5) — registry name ``vlm-openai-compat`` (docs/03, ADR 0003 #3).

The escalation path is the only place this system pays a model to *read pixels*,
and every design choice here exists to keep that spend narrow, grounded and
auditable:

- **Crop to the escalated unit.** Input tokens scale with pixels, so the request
  carries the region rectangle (plus a margin), never the page, never the
  document (docs/03 §policy).
- **Always attach the OCR output as context.** The prompt carries the region's
  own recognised lines *with geometry* and the surrounding accepted blocks, and
  frames the task as *correct and complete this transcription* — the model is
  never asked to read a page cold. docs/03 calls this the single
  highest-leverage detail in the design; it is what makes a small escalation
  model competitive and what cuts hallucination where we are most exposed.
- **Additive merge.** New blocks carry ``origin="vlm"``; the ids they replaced
  are recorded in ``page.escalations[]`` and the pre-escalation page IR is kept
  as an artifact, so the OCR-vs-VLM diff (docs/03's disagreement-rate health
  metric) is always reconstructable (docs/02 invariant 4).
- **Never block the pipeline on a provider** (docs/07 §failure isolation): caps
  bound the spend per page and per document, a consecutive-failure circuit
  breaker bounds the damage of an unhealthy endpoint, and every skip/failure
  degrades that unit only — the document is still served, honestly marked.

``Escalator`` is the only async Protocol (docs/08): it does IO and runs in the
parent orchestrator, never inside a pool worker. The engine itself stays pure
over the IR — the provider client, the page PNG and the (process-wide) circuit
breaker are injected through ``ctx.resources`` (docs/08 rule 5), so nothing here
holds module-level state and a fake client is the entire test setup.

**The confidence written on VLM blocks is a prior, not a measurement.** The
provider returns no calibrated per-line score, so ``confidence_prior`` (config,
default 0.85) is written verbatim and named to admit it. docs/03 pass 3 (OCR vs
VLM disagreement on real traffic) is the eventual calibration source.
"""

import asyncio
import base64
import io
import json
import logging
from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass
from difflib import SequenceMatcher
from time import monotonic, perf_counter
from typing import Any, Protocol, cast, runtime_checkable

import httpx
from PIL import Image

from titanocr.ir import (
    Block,
    BlockType,
    Escalation,
    EscalationCost,
    Line,
    Origin,
    Page,
    PageOrigin,
    Span,
)
from titanocr.stages import (
    DeadlineExceeded,
    Region,
    ResourceNotRegistered,
    StageContext,
    TriageDecision,
    register,
)

logger = logging.getLogger("titanocr.vlm")

VLM_ENGINE_VERSION = "1.0"

PROMPT_TEMPLATE_VERSION = "escalation_prompt@v1"
"""Versioned prompt template — recorded in provenance, so a result always cites
the wording that produced it (§4.2). Changing the template bumps this."""

RESOURCE_CLIENT = "vlm_client"
RESOURCE_PAGE_PNG = "page_png"
RESOURCE_BREAKER = "vlm_breaker"
"""``ctx.resources`` keys the orchestrator injects (docs/08 rule 5)."""

RESPONSE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "lines": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {"text": {"type": "string"}},
                "required": ["text"],
                "additionalProperties": False,
            },
        },
        "notes": {"type": "string"},
    },
    "required": ["lines"],
    "additionalProperties": False,
}
"""``{lines: [{text}], notes?}`` (§4.2) — sent as ``response_format`` where the
provider supports it and restated in the prompt where it does not."""

_MIN_CROP_PX = 24
_CONTEXT_BLOCKS = 6
_CONTEXT_CHARS = 160


class VLMError(Exception):
    """Provider failure for one escalation unit, after the adapter's retries.

    Caught per region: that region degrades, the rest of the page (and the
    document) carries on — docs/07 §failure isolation.
    """


@dataclass(frozen=True)
class VLMUsage:
    """Token counts **as reported by the provider** (rule 10: measured usage,
    never folk numbers). Unit prices are config; these are not."""

    input_tokens: int
    output_tokens: int


@dataclass(frozen=True)
class VLMResult:
    parsed_json: Mapping[str, Any]
    usage: VLMUsage
    model: str
    attempts: int = 1


@runtime_checkable
class VLMClient(Protocol):
    """The provider seam (§4.1). One implementation ships in v1 (ADR 0003 #3);
    a provider-native adapter is a bounded follow-up behind this same protocol."""

    provider: str
    model: str

    async def complete(
        self,
        image_png: bytes,
        prompt: str,
        response_schema: Mapping[str, Any],
        *,
        timeout_s: float | None = None,
    ) -> VLMResult: ...


# -- provider adapter ---------------------------------------------------------------

_RETRY_STATUS = frozenset({408, 409, 425, 429, 500, 502, 503, 504})

_REASK_SUFFIX = (
    "\n\nYour previous reply was not valid JSON. Reply with the JSON object only — "
    "no prose, no markdown fences."
)


def _strip_fences(text: str) -> str:
    """Tolerate ```json fenced replies from providers that ignore the schema."""
    stripped = text.strip()
    if not stripped.startswith("```"):
        return stripped
    body = stripped.split("\n", 1)[1] if "\n" in stripped else ""
    if body.rstrip().endswith("```"):
        body = body.rstrip()[: -len("```")]
    return body.strip()


class OpenAICompatClient:
    """``POST {base_url}/chat/completions`` with a b64 ``image_url`` part.

    Deterministic by construction (docs/09 outcome C): ``temperature=0`` and
    ``top_p=1`` on **every** call — any variance on the escalated path is the
    provider's, not ours. Retries are bounded and only fire on 429/5xx and
    transport errors; a reply that is not JSON despite the constraints buys
    exactly one re-ask, then becomes a :class:`VLMError` for that unit (§4.1).
    """

    provider = "openai-compatible"

    def __init__(
        self,
        *,
        base_url: str,
        model: str,
        api_key: str,
        timeout_s: float = 60.0,
        max_retries: int = 2,
        max_output_tokens: int = 1500,
        use_json_schema: bool = True,
        backoff_s: float = 0.5,
        transport: httpx.AsyncBaseTransport | None = None,
        sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout_s = timeout_s
        self.max_retries = max_retries
        self.max_output_tokens = max_output_tokens
        self.backoff_s = backoff_s
        self._json_schema = use_json_schema
        self._api_key = api_key
        self._sleep = sleep
        self._client = httpx.AsyncClient(
            transport=transport,
            timeout=httpx.Timeout(timeout_s),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )
        self.calls = 0
        """Provider calls actually attempted — asserted by the no-key test."""

    @property
    def url(self) -> str:
        return f"{self.base_url}/chat/completions"

    async def aclose(self) -> None:
        await self._client.aclose()

    def _payload(
        self, image_png: bytes, prompt: str, response_schema: Mapping[str, Any]
    ) -> dict[str, Any]:
        b64 = base64.b64encode(image_png).decode("ascii")
        payload: dict[str, Any] = {
            "model": self.model,
            # Determinism knobs, on every single call (§5).
            "temperature": 0,
            "top_p": 1,
            "max_tokens": self.max_output_tokens,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{b64}"},
                        },
                    ],
                }
            ],
        }
        if self._json_schema:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "escalation_transcription",
                    "strict": False,
                    "schema": dict(response_schema),
                },
            }
        return payload

    async def complete(
        self,
        image_png: bytes,
        prompt: str,
        response_schema: Mapping[str, Any],
        *,
        timeout_s: float | None = None,
    ) -> VLMResult:
        body, attempts = await self._request(image_png, prompt, response_schema, timeout_s)
        parsed = self._parse(body)
        if parsed is None:
            # One re-ask, then this unit is a provider failure (§4.1).
            body, extra = await self._request(
                image_png, prompt + _REASK_SUFFIX, response_schema, timeout_s
            )
            attempts += extra
            parsed = self._parse(body)
        if parsed is None:
            raise VLMError("provider returned non-JSON content twice")
        return VLMResult(
            parsed_json=parsed,
            usage=_usage_of(body),
            model=str(body.get("model") or self.model),
            attempts=attempts,
        )

    async def _request(
        self,
        image_png: bytes,
        prompt: str,
        response_schema: Mapping[str, Any],
        timeout_s: float | None,
    ) -> tuple[Mapping[str, Any], int]:
        timeout = httpx.Timeout(self.timeout_s if timeout_s is None else max(1.0, timeout_s))
        attempts = 0
        last: str = "no attempt made"
        for attempt in range(self.max_retries + 1):
            payload = self._payload(image_png, prompt, response_schema)
            attempts += 1
            self.calls += 1
            try:
                resp = await self._client.post(self.url, json=payload, timeout=timeout)
            except httpx.HTTPError as exc:
                last = f"{type(exc).__name__}: {exc}"
            else:
                if resp.status_code < 300:
                    return cast(Mapping[str, Any], resp.json()), attempts
                last = f"HTTP {resp.status_code}: {resp.text[:300]}"
                if resp.status_code == 400 and self._json_schema and "response_format" in resp.text:
                    # Provider does not do json_schema — fall back to the
                    # prompt-enforced contract for the rest of this process.
                    logger.warning("provider rejected response_format — prompt-enforced JSON only")
                    self._json_schema = False
                    continue
                if resp.status_code not in _RETRY_STATUS:
                    raise VLMError(last)
            if attempt < self.max_retries:
                await self._sleep(self.backoff_s * (2**attempt))
        raise VLMError(f"provider unavailable after {attempts} attempt(s) — {last}")

    @staticmethod
    def _parse(body: Mapping[str, Any]) -> Mapping[str, Any] | None:
        choices = body.get("choices")
        if not isinstance(choices, list) or not choices:
            return None
        message = cast(Mapping[str, Any], cast(list[Any], choices)[0]).get("message")
        if not isinstance(message, Mapping):
            return None
        content = cast(Mapping[str, Any], message).get("content")
        if not isinstance(content, str):
            return None
        try:
            parsed: Any = json.loads(_strip_fences(content))
        except ValueError:
            return None
        if not isinstance(parsed, Mapping):
            return None
        return cast(Mapping[str, Any], parsed)


def _usage_of(body: Mapping[str, Any]) -> VLMUsage:
    """Provider usage block; the two common key spellings are both accepted."""
    usage = body.get("usage")
    if not isinstance(usage, Mapping):
        return VLMUsage(input_tokens=0, output_tokens=0)
    block = cast(Mapping[str, Any], usage)

    def pick(*names: str) -> int:
        for name in names:
            value = block.get(name)
            if isinstance(value, int | float):
                return int(value)
        return 0

    return VLMUsage(
        input_tokens=pick("prompt_tokens", "input_tokens"),
        output_tokens=pick("completion_tokens", "output_tokens"),
    )


# -- circuit breaker (docs/07 §failure isolation) ------------------------------------


class CircuitBreaker:
    """Consecutive-failure breaker with a cooldown. Process-wide, injected.

    Open ⇒ escalation is skipped fast and the document is marked ``degraded``:
    *never block the pipeline on a provider*. The clock is injected so the
    cooldown is testable without sleeping.
    """

    def __init__(
        self,
        threshold: int = 5,
        cooldown_s: float = 60.0,
        clock: Callable[[], float] = monotonic,
    ) -> None:
        self.threshold = threshold
        self.cooldown_s = cooldown_s
        self._clock = clock
        self._failures = 0
        self._opened_at: float | None = None

    @property
    def failures(self) -> int:
        return self._failures

    def allow(self) -> bool:
        """True when calls may proceed; closes the breaker once cooldown elapsed."""
        if self._opened_at is None:
            return True
        if self._clock() - self._opened_at >= self.cooldown_s:
            logger.info("vlm circuit breaker closing after cooldown")
            self._opened_at = None
            self._failures = 0
            return True
        return False

    @property
    def state(self) -> str:
        return "open" if self._opened_at is not None else "closed"

    def record_success(self) -> None:
        self._failures = 0
        self._opened_at = None

    def record_failure(self) -> None:
        self._failures += 1
        if self._opened_at is None and self._failures >= self.threshold:
            self._opened_at = self._clock()
            logger.warning(
                "vlm circuit breaker opened",
                extra={"failures": self._failures, "cooldown_s": self.cooldown_s},
            )

    def snapshot(self) -> dict[str, Any]:
        """Informational ``/readyz`` detail — never a readiness failure (§4.5)."""
        remaining = 0.0
        if self._opened_at is not None:
            remaining = max(0.0, self.cooldown_s - (self._clock() - self._opened_at))
        return {
            "state": self.state,
            "failures": self._failures,
            "threshold": self.threshold,
            "cooldown_remaining_s": round(remaining, 3),
        }


# -- crop + prompt (§4.2) ------------------------------------------------------------


def crop_region(page_png: bytes, bbox: tuple[float, float, float, float], margin: float) -> bytes:
    """Crop the post-prep page PNG to ``bbox`` + ``margin``, clamped to the image.

    Never sends the whole page when a region will do (docs/03); a degenerate
    rectangle is grown to :data:`_MIN_CROP_PX` so the provider always receives
    something legible.
    """
    with Image.open(io.BytesIO(page_png)) as img:
        width, height = img.size
        x0 = max(0.0, bbox[0] - margin)
        y0 = max(0.0, bbox[1] - margin)
        x1 = min(float(width), bbox[2] + margin)
        y1 = min(float(height), bbox[3] + margin)
        if x1 - x0 < _MIN_CROP_PX:
            x1 = min(float(width), x0 + _MIN_CROP_PX)
            x0 = max(0.0, x1 - _MIN_CROP_PX)
        if y1 - y0 < _MIN_CROP_PX:
            y1 = min(float(height), y0 + _MIN_CROP_PX)
            y0 = max(0.0, y1 - _MIN_CROP_PX)
        crop = img.convert("RGB").crop((int(x0), int(y0), int(x1), int(y1)))
        buf = io.BytesIO()
        crop.save(buf, format="PNG")
        return buf.getvalue()


def _bbox_str(bbox: tuple[float, float, float, float]) -> str:
    return f"[{int(bbox[0])},{int(bbox[1])},{int(bbox[2])},{int(bbox[3])}]"


def _overlaps(a: tuple[float, float, float, float], b: tuple[float, float, float, float]) -> float:
    """Area of ``a`` covered by ``b``, as a fraction of ``a`` (0 when disjoint)."""
    ix0, iy0 = max(a[0], b[0]), max(a[1], b[1])
    ix1, iy1 = min(a[2], b[2]), min(a[3], b[3])
    if ix1 <= ix0 or iy1 <= iy0:
        return 0.0
    area = (a[2] - a[0]) * (a[3] - a[1])
    return 0.0 if area <= 0 else ((ix1 - ix0) * (iy1 - iy0)) / area


PROMPT_HEADER = (
    "You are correcting an existing OCR transcription of one region of a document. "
    "The attached image is a crop of that region "
    "from the page the OCR ran on.\n"
)

PROMPT_TASK = (
    "Task: return the corrected and completed transcription of the text visible in the "
    "attached crop, in reading order, one entry per visual text line.\n"
    "Rules:\n"
    "- Correct what the OCR got wrong and add what it missed; keep what it got right.\n"
    "- Transcribe verbatim: do not translate, expand abbreviations, normalise units or "
    "reformat numbers.\n"
    "- Transcribe only text that is visible in the crop. Never invent content, and never "
    "repeat the surrounding context below.\n"
    "- If part of the region is genuinely illegible, transcribe what is legible and say so "
    "in `notes`.\n"
    'Reply with JSON only: {"lines": [{"text": "..."}], "notes": "optional"}.'
)


def build_prompt(
    page: Page, region: Region, replaced_ids: Sequence[str], *, include_context: bool = False
) -> str:
    """The grounded escalation prompt: the crop's own OCR text and geometry.

    ``include_context`` adds the accepted text *around* the region, which
    docs/03 asks for as grounding and ADR 0023 makes opt-in: text the engine
    read confidently is data the operator did not ask to send anywhere, so the
    default is to send the failing region's own transcription and nothing else.

    Deterministic: block/line ordering and number formatting are fixed, so the
    same IR always produces byte-identical prompt text.
    """
    parts: list[str] = [PROMPT_HEADER]
    parts.append(
        f"Page {page.page_no} is {page.width}x{page.height} px; the crop covers region "
        f"{_bbox_str(region.bbox)} of it (origin top-left, pixels)."
    )

    replaced = set(replaced_ids)
    region_lines: list[Line] = []
    for block in page.blocks:
        if block.block_id not in replaced:
            continue
        region_lines.extend(block.lines or ())
    region_lines.sort(key=lambda line: (line.bbox[1], line.bbox[0]))

    if region_lines:
        parts.append(
            "OCR transcription of this region (bbox, recognition confidence, text) — "
            "this is what you are correcting:"
        )
        parts.append(
            "\n".join(
                f"  {_bbox_str(line.bbox)} conf={line.confidence:.2f} {line.text!r}"
                for line in region_lines
            )
        )
    else:
        parts.append("The OCR produced no usable text for this region.")

    context = _context_lines(page, region, replaced) if include_context else []
    if context:
        parts.append(
            "Accepted OCR text around the region, for context only (do not re-transcribe it):"
        )
        parts.append("\n".join(context))

    parts.append(PROMPT_TASK)
    return "\n\n".join(parts)


def _context_lines(page: Page, region: Region, replaced: set[str]) -> list[str]:
    """Nearest surrounding blocks, compact: type, bbox, truncated text."""
    cx = (region.bbox[0] + region.bbox[2]) / 2.0
    cy = (region.bbox[1] + region.bbox[3]) / 2.0
    scored: list[tuple[float, str]] = []
    for block in page.blocks:
        if block.block_id in replaced:
            continue
        text = " ".join(line.text for line in block.lines or () if line.text).strip()
        if not text:
            continue
        bx = (block.bbox[0] + block.bbox[2]) / 2.0
        by = (block.bbox[1] + block.bbox[3]) / 2.0
        distance = abs(by - cy) + abs(bx - cx) * 0.5
        if len(text) > _CONTEXT_CHARS:
            text = text[:_CONTEXT_CHARS] + "…"
        scored.append((distance, f"  {block.type.value} {_bbox_str(block.bbox)} {text!r}"))
    scored.sort(key=lambda item: (item[0], item[1]))
    return [line for _, line in scored[:_CONTEXT_BLOCKS]]


# -- outcomes -------------------------------------------------------------------------


@dataclass(frozen=True)
class RegionOutcome:
    """What happened to one escalation unit."""

    region: Region
    status: str
    """``done`` · ``failed`` (provider) · ``empty`` (no text returned, content kept)
    · ``skipped`` (breaker/deadline/cap)."""

    replaced_block_ids: tuple[str, ...] = ()
    texts: tuple[str, ...] = ()
    notes: str | None = None
    usage: VLMUsage = VLMUsage(0, 0)
    cost_inr: float = 0.0
    model: str = ""
    reason: str | None = None
    disagreement: float | None = None
    """1 - similarity between the OCR text it replaced and the VLM text
    (docs/03 pass 3: the disagreement rate is the health metric that matters)."""


@dataclass(frozen=True)
class EscalationOutcome:
    """Everything the orchestrator needs to settle a page after escalation."""

    status: str
    """``done`` · ``partial`` (some unit failed) · ``failed`` · ``skipped``."""

    blocks: tuple[Block, ...]
    escalations: tuple[Escalation, ...]
    origin: PageOrigin
    regions: tuple[RegionOutcome, ...] = ()
    reason: str | None = None
    considered: int = 0
    escalated: int = 0
    deferred: int = 0
    review_required: bool = False
    degraded: bool = False
    input_tokens: int = 0
    output_tokens: int = 0
    cost_inr: float = 0.0
    ms: float = 0.0
    prompt_version: str = PROMPT_TEMPLATE_VERSION
    price_table_version: str = ""

    @property
    def disagreement(self) -> float | None:
        values = [r.disagreement for r in self.regions if r.disagreement is not None]
        return sum(values) / len(values) if values else None

    @property
    def notes(self) -> tuple[str, ...]:
        """What the model said about its own reading ("the quantity is smudged").

        The IR has nowhere honest to put free-form model commentary, so it goes
        to the log and the signals record rather than being dropped — an
        uncertainty statement is exactly the thing a review queue wants.
        """
        return tuple(r.notes for r in self.regions if r.notes)

    def apply(self, page: Page) -> Page:
        """The merged page (docs/02 invariant 4 — additive, never lossy)."""
        return page.model_copy(
            update={
                "blocks": self.blocks,
                "escalations": page.escalations + self.escalations,
                "origin": self.origin,
            }
        )


def skipped_outcome(page: Page, reason: str, *, considered: int = 0) -> EscalationOutcome:
    """No call was made (no key, escalation off, breaker open, deadline gone).

    The page keeps its OCR content unchanged and the document is marked
    ``degraded`` + review-flagged (plan §7 row 5) — the exact phase-12
    behaviour, now reached through one named path.
    """
    return EscalationOutcome(
        status="skipped",
        blocks=page.blocks,
        escalations=(),
        origin=page.origin,
        reason=reason,
        considered=considered,
        review_required=True,
        degraded=True,
    )


# -- the engine -----------------------------------------------------------------------


@register("escalator", "vlm-openai-compat")
class VLMEscalator:
    """docs/03 escalation as a stage: crop → grounded prompt → merge → cost.

    Thresholds and knobs are pipeline YAML (hard rule 9). Everything that is
    deployment- or secret-shaped (endpoint, key, breaker limits, per-document
    cap, concurrency) arrives through ``ctx`` from the service settings — the
    engine never reads env or globals.
    """

    version: str = VLM_ENGINE_VERSION

    def __init__(
        self,
        max_regions_per_page: int = 3,
        crop_margin_px: float = 24.0,
        confidence_prior: float = 0.85,
        price_table_version: str = "unpriced",
        prices: Mapping[str, Mapping[str, float]] | None = None,
        replace_min_coverage: float = 0.6,
        send_context: bool = False,
    ) -> None:
        self.max_regions_per_page = max_regions_per_page
        self.crop_margin_px = crop_margin_px
        self.confidence_prior = confidence_prior
        self.price_table_version = price_table_version
        self.prices: Mapping[str, Mapping[str, float]] = prices or {}
        self.replace_min_coverage = replace_min_coverage
        self.send_context = send_context
        """Send the accepted text *around* a region as grounding. Off by default
        (ADR 0023): only the failing region's own transcription leaves with the
        crop, so an operator who enables escalation knows exactly what is sent."""

    # -- Protocol conformance (docs/08): the merged blocks for the page -------------

    async def escalate(
        self, page: Page, decision: TriageDecision, ctx: StageContext
    ) -> list[Block]:
        outcome = await self.run(page, decision, ctx)
        return list(outcome.blocks)

    # -- the richer entry point the orchestrator uses -------------------------------

    async def run(
        self, page: Page, decision: TriageDecision, ctx: StageContext
    ) -> EscalationOutcome:
        """Escalate one page's failing units and return the merged outcome.

        Per-unit failures degrade that unit only; the page always comes back
        with content (worst case: exactly what OCR delivered).
        """
        started = perf_counter()
        client = ctx.resources.get(RESOURCE_CLIENT, VLMClient)
        page_png = ctx.resources.get(RESOURCE_PAGE_PNG, bytes)
        breaker = _breaker_of(ctx)

        units = self._units(page, decision)
        budget = self._budget(ctx)
        selected, deferred = units[:budget], units[budget:]
        if deferred:
            logger.info(
                "escalation cap reached — remaining regions flagged for review",
                extra={
                    "doc_id": ctx.doc_id,
                    "page_no": page.page_no,
                    "escalated": len(selected),
                    "deferred": len(deferred),
                },
            )

        results: list[RegionOutcome] = []
        stop_reason: str | None = None
        for region in selected:
            replaced_ids = self._replaced_ids(page, region)
            if stop_reason is not None:
                results.append(RegionOutcome(region=region, status="skipped", reason=stop_reason))
                continue
            if not breaker.allow():
                stop_reason = "breaker_open"
                results.append(RegionOutcome(region=region, status="skipped", reason=stop_reason))
                continue
            try:
                ctx.deadline.check()
            except DeadlineExceeded as exc:
                stop_reason = f"deadline_exceeded: {exc}"
                results.append(RegionOutcome(region=region, status="skipped", reason=stop_reason))
                continue
            results.append(
                await self._escalate_region(page, region, replaced_ids, client, page_png, ctx)
            )
            if results[-1].status == "failed":
                breaker.record_failure()
            elif results[-1].status in ("done", "empty"):
                breaker.record_success()

        for region in deferred:
            results.append(RegionOutcome(region=region, status="skipped", reason="over_cap"))

        blocks, escalations = self._merge(page, results, client)
        origin = _page_origin(page, blocks)
        escalated = sum(1 for r in results if r.status == "done")
        failed = [r for r in results if r.status in ("failed", "empty")]
        status = "done"
        if escalated == 0 and (failed or stop_reason is not None):
            status = "failed" if failed else "skipped"
        elif failed or deferred or stop_reason is not None:
            status = "partial"
        return EscalationOutcome(
            status=status,
            blocks=blocks,
            escalations=escalations,
            origin=origin,
            regions=tuple(results),
            reason=stop_reason,
            considered=len(units),
            escalated=escalated,
            deferred=len(deferred),
            # Anything we could not transcribe is content nobody has verified:
            # flag it rather than emitting it as if certain (docs/01 rule 3).
            review_required=bool(failed or deferred or stop_reason is not None),
            degraded=bool(failed or stop_reason is not None),
            input_tokens=sum(r.usage.input_tokens for r in results),
            output_tokens=sum(r.usage.output_tokens for r in results),
            cost_inr=sum(r.cost_inr for r in results),
            ms=(perf_counter() - started) * 1000.0,
            price_table_version=self.price_table_version,
        )

    # -- units, budget, replacement targets -----------------------------------------

    def _units(self, page: Page, decision: TriageDecision) -> list[Region]:
        """The escalation units, narrowest first (docs/03 §granularity).

        Always the triage rectangles, ordered worst-confidence-first so a cap
        spends the budget where the OCR is least trustworthy. There is no
        page-sized unit and no synthesising one here (ADR 0023): a page whose
        page-level signals failed arrives with its failing regions already
        grown, and what the engine read confidently never leaves the machine.
        """
        del page
        return sorted(decision.regions, key=lambda r: (r.confidence, r.bbox[1], r.bbox[0]))

    def _budget(self, ctx: StageContext) -> int:
        """Per-page cap (pipeline YAML) tightened by whatever budget the caller
        has left — the deployment ceiling and the per-document cap (§4.5)."""
        remaining = ctx.config.get("region_budget")
        budget = self.max_regions_per_page
        if isinstance(remaining, int) and not isinstance(remaining, bool):
            budget = min(budget, max(0, remaining))
        return budget

    def _replaced_ids(self, page: Page, region: Region) -> tuple[str, ...]:
        """Blocks this unit replaces: the ids triage grew the region from, or —
        for a synthetic region — the blocks it geometrically covers."""
        if region.block_ids:
            known = {block.block_id for block in page.blocks}
            return tuple(bid for bid in region.block_ids if bid in known)
        return tuple(
            block.block_id
            for block in page.blocks
            if _overlaps(block.bbox, region.bbox) >= self.replace_min_coverage
        )

    # -- one provider call ------------------------------------------------------------

    async def _escalate_region(
        self,
        page: Page,
        region: Region,
        replaced_ids: tuple[str, ...],
        client: VLMClient,
        page_png: bytes,
        ctx: StageContext,
    ) -> RegionOutcome:
        prompt = build_prompt(page, region, replaced_ids, include_context=self.send_context)
        try:
            crop = crop_region(page_png, region.bbox, self.crop_margin_px)
        except Exception as exc:  # a broken artifact must not kill the document
            logger.warning(
                "escalation crop failed", extra={"doc_id": ctx.doc_id, "error": str(exc)}
            )
            return RegionOutcome(
                region=region,
                status="failed",
                replaced_block_ids=replaced_ids,
                reason=f"crop_failed: {type(exc).__name__}",
            )
        timeout = ctx.deadline.remaining()
        try:
            result = await client.complete(
                crop,
                prompt,
                RESPONSE_SCHEMA,
                timeout_s=None if timeout == float("inf") else timeout,
            )
        except VLMError as exc:
            logger.warning(
                "escalation call failed",
                extra={"doc_id": ctx.doc_id, "page_no": page.page_no, "error": str(exc)},
            )
            return RegionOutcome(
                region=region,
                status="failed",
                replaced_block_ids=replaced_ids,
                reason=str(exc)[:200],
            )
        texts = _texts_of(result.parsed_json)
        cost = self.price(result.model, result.usage)
        if not texts:
            # Nothing came back: keep the OCR content rather than blanking it.
            return RegionOutcome(
                region=region,
                status="empty",
                replaced_block_ids=replaced_ids,
                usage=result.usage,
                cost_inr=cost,
                model=result.model,
                reason="provider returned no lines",
            )
        notes = result.parsed_json.get("notes")
        return RegionOutcome(
            region=region,
            status="done",
            replaced_block_ids=replaced_ids,
            texts=texts,
            notes=notes if isinstance(notes, str) and notes.strip() else None,
            usage=result.usage,
            cost_inr=cost,
            model=result.model,
            disagreement=_disagreement(page, replaced_ids, texts),
        )

    # -- cost (§4.4: measured usage x a versioned price table) ------------------------

    def price(self, model: str, usage: VLMUsage) -> float:
        """INR for one call. Tokens are measured; only the unit prices are
        config, and they carry a version (``price_table@date`` in provenance).
        An unpriced model costs 0.0 **and says so in the log** — a folk number
        would be worse than a missing one (hard rule 10)."""
        entry = self.prices.get(model)
        if entry is None:
            if usage.input_tokens or usage.output_tokens:
                logger.warning(
                    "no price table entry — cost recorded as 0",
                    extra={"model": model, "price_table": self.price_table_version},
                )
            return 0.0
        per_in = float(entry.get("input_inr_per_1k", 0.0))
        per_out = float(entry.get("output_inr_per_1k", 0.0))
        return (usage.input_tokens / 1000.0) * per_in + (usage.output_tokens / 1000.0) * per_out

    # -- additive merge (docs/02 invariant 4) -----------------------------------------

    def _merge(
        self, page: Page, results: Sequence[RegionOutcome], client: VLMClient
    ) -> tuple[tuple[Block, ...], tuple[Escalation, ...]]:
        """Replace the escalated blocks with ``origin="vlm"`` blocks and record
        what was replaced. Nothing is dropped silently: a failed, empty or
        skipped unit leaves the original blocks exactly where they were."""
        by_id = {block.block_id: block for block in page.blocks}
        claimed: set[str] = set()
        new_blocks: list[Block] = []
        escalations: list[Escalation] = []
        next_order = max((block.reading_order for block in page.blocks), default=-1) + 1

        for index, result in enumerate(results):
            if result.status != "done":
                continue
            replaced = [
                by_id[bid]
                for bid in result.replaced_block_ids
                if bid in by_id and bid not in claimed
            ]
            claimed.update(block.block_id for block in replaced)
            order = min((block.reading_order for block in replaced), default=next_order)
            if not replaced:
                next_order += 1
            new_blocks.append(self._vlm_block(page, index, result, replaced, order))
            escalations.append(
                Escalation(
                    region_bbox=result.region.bbox,
                    trigger=_trigger_of(result),
                    signals=_signals_of(result),
                    provider=client.provider,
                    model=result.model or client.model,
                    replaced_block_ids=tuple(block.block_id for block in replaced),
                    cost=EscalationCost(
                        input_tokens=result.usage.input_tokens,
                        output_tokens=result.usage.output_tokens,
                        inr=result.cost_inr,
                    ),
                )
            )

        kept = [block for block in page.blocks if block.block_id not in claimed]
        merged = sorted(kept + new_blocks, key=lambda block: block.reading_order)
        return tuple(merged), tuple(escalations)

    def _vlm_block(
        self,
        page: Page,
        index: int,
        result: RegionOutcome,
        replaced: Sequence[Block],
        order: int,
    ) -> Block:
        """One block per escalated unit.

        Every VLM line carries the **region** bbox: line-level geometry from a
        VLM is fiction, and the IR must not claim geometry nobody measured
        (docs/02 invariant 1 wants honest geometry, not invented precision).
        """
        bbox = result.region.bbox
        handwritten = any(line.is_handwritten for block in replaced for line in block.lines or ())
        lines = tuple(
            Line(
                line_id=f"p{page.page_no}_v{index}_l{i}",
                bbox=bbox,
                text=text,
                confidence=self.confidence_prior,
                origin=Origin.vlm,
                is_handwritten=handwritten,
                spans=(Span(text=text, bbox=bbox, confidence=self.confidence_prior),),
            )
            for i, text in enumerate(result.texts)
        )
        return Block(
            block_id=f"p{page.page_no}_v{index}",
            type=BlockType.paragraph,
            bbox=bbox,
            reading_order=order,
            origin=Origin.vlm,
            confidence=self.confidence_prior,
            lines=lines,
        )


# -- helpers --------------------------------------------------------------------------


def _breaker_of(ctx: StageContext) -> CircuitBreaker:
    """The injected process-wide breaker; a private one when nobody injected it
    (a single-call unit test has nothing to protect)."""
    try:
        return ctx.resources.get(RESOURCE_BREAKER, CircuitBreaker)
    except ResourceNotRegistered:
        return CircuitBreaker()


def _texts_of(parsed: Mapping[str, Any]) -> tuple[str, ...]:
    raw = parsed.get("lines")
    if not isinstance(raw, list):
        return ()
    texts: list[str] = []
    for item in cast(list[Any], raw):
        if isinstance(item, str):
            text = item
        elif isinstance(item, Mapping):
            value = cast(Mapping[str, Any], item).get("text")
            text = value if isinstance(value, str) else ""
        else:
            text = ""
        if text.strip():
            texts.append(text.strip())
    return tuple(texts)


def _replaced_text(page: Page, replaced_ids: Sequence[str]) -> str:
    ids = set(replaced_ids)
    return " ".join(
        line.text for block in page.blocks if block.block_id in ids for line in block.lines or ()
    ).strip()


def _disagreement(page: Page, replaced_ids: Sequence[str], texts: Sequence[str]) -> float | None:
    """1 - similarity(OCR text, VLM text) for the unit — docs/03 pass 3's
    health metric, computed where both texts exist."""
    before = _replaced_text(page, replaced_ids)
    after = " ".join(texts).strip()
    if not before and not after:
        return None
    return round(1.0 - SequenceMatcher(None, before, after).ratio(), 4)


def _trigger_of(result: RegionOutcome) -> str:
    return "low_conf_region" if result.region.block_ids else "escalated_region"


def _signals_of(result: RegionOutcome) -> dict[str, float]:
    signals = {"region_confidence": round(result.region.confidence, 4)}
    if result.disagreement is not None:
        signals["disagreement"] = result.disagreement
    return signals


def _page_origin(page: Page, blocks: Sequence[Block]) -> PageOrigin:
    """``mixed`` the moment VLM text lands on a page (docs/02 §why origin at
    three levels) — the page always retains its OCR/digital pass, so ``mixed``
    is the honest label even when every block was replaced."""
    if any(block.origin is Origin.vlm for block in blocks):
        return PageOrigin.mixed
    return page.origin


__all__ = [
    "PROMPT_TEMPLATE_VERSION",
    "RESOURCE_BREAKER",
    "RESOURCE_CLIENT",
    "RESOURCE_PAGE_PNG",
    "RESPONSE_SCHEMA",
    "VLM_ENGINE_VERSION",
    "CircuitBreaker",
    "EscalationOutcome",
    "OpenAICompatClient",
    "RegionOutcome",
    "VLMClient",
    "VLMError",
    "VLMEscalator",
    "VLMResult",
    "VLMUsage",
    "build_prompt",
    "crop_region",
    "skipped_outcome",
]
