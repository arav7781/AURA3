"""Image prep (stage 2) — OpenCV quarantine; registry name ``opencv-default``.

The chain of implementation_plan.md §7 row 2, each applied step recorded in
``PrepRecord`` so page-space maps back to the original upload (docs/02
invariant 3): EXIF transpose (performed at decode, recorded here) →
greyscale-if-needed → confident-quadrilateral perspective correction → deskew →
dark-border auto-crop → light denoise (param-gated) → DPI normalise. Quality
(``blur_score``, ``resolution_ok``, ``is_grayscale``) is always measured, even
when every transform is skipped — triage (phase 12) reads it.

Skips are the honest default: perspective only fires on a *confident* quad
(area + convexity gates), deskew only past ``deskew_min_deg``, crop only on
near-black scanner borders. ``page.prep.skew_deg``/``scale``/
``crop_bbox_in_original`` record only transforms actually applied — the record
is the inverse mapping, not a measurement log; measured-but-skipped values go to
the stage logger. Full dewarp is v1.1 (phase plan §3); binarisation is available
but default-off (rec models prefer grey).
"""

# OpenCV ships imprecise stubs; the pyright noise stays in this vendor module.
# pyright: reportUnknownMemberType=false, reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false

from typing import Any, cast

import cv2
import numpy as np
import numpy.typing as npt

from titanocr.ir import Prep, Quality
from titanocr.stages import PageImage, PrepRecord, StageContext, register

_GRAY_CHROMA_MEAN = 2.0
_GRAY_CHROMA_P99 = 16.0
"""A 3-channel image whose per-pixel chroma stays under these is achromatic —
converted to true greyscale (no information lost) and flagged ``is_grayscale``."""

_DARK_BORDER_MEAN = 60.0
"""Rows/cols darker than this (mean) at the page edge are scanner-bed border."""

_DARK_BORDER_STD = 12.0
"""...and flat. A scanner bed is featureless; a row with glyphs on it varies,
whatever its mean. This is what stops the trim walking into a dark page's
content, which is the way it fails that costs text."""

_LIGHT_PAGE_MEAN = 110.0
"""What the trim has to *find* for the trim to mean anything: a page brighter
than this behind the dark edge. A scanner bed frames a white document, so the
document clears it easily; a dark poster does not, and on a dark poster "dark
edge" describes the artwork rather than a border (see :meth:`_crop_dark_borders`)."""

_MIN_TEXT_HEIGHT_PX = 16.0
"""Post-prep median glyph height below this → ``resolution_ok=False``."""

_GLYPH_H_MIN, _GLYPH_H_MAX = 4, 200
_GLYPH_MIN_AREA = 8
"""Connected-component filters for glyph-height estimation (DPI normalise)."""

_INK_MIN_STD = 10.0
"""Below this grayscale contrast the page is flat (blank sheet, uniform fill) and
Otsu would threshold noise — ``ink_ratio`` reads 0.0 instead of a random split."""


def measure_ink_ratio(gray: npt.NDArray[np.uint8]) -> float:
    """Fraction of pixels the Otsu ink mask marks as ink (IR 1.3, ADR 0006).

    Public because the worker's prep-failure pass-through record measures it the
    same way — one definition, two call sites.
    """
    if float(gray.std()) < _INK_MIN_STD:
        return 0.0
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    return float(np.count_nonzero(binary)) / float(binary.size)


def _as_gray(pixels: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    if pixels.ndim == 2:
        return pixels
    return cast(npt.NDArray[np.uint8], cv2.cvtColor(pixels, cv2.COLOR_RGB2GRAY))


def _chroma(pixels: npt.NDArray[np.uint8]) -> tuple[float, float]:
    """(mean, p99) of per-pixel channel spread; (0, 0) for single-channel input."""
    if pixels.ndim == 2:
        return 0.0, 0.0
    spread = pixels.max(axis=2).astype(np.int16) - pixels.min(axis=2).astype(np.int16)
    return float(spread.mean()), float(np.percentile(spread, 99))


def estimate_skew_deg(gray: npt.NDArray[np.uint8], *, inside_form: bool = False) -> float:
    """Text-mask skew estimate: merge glyphs into row blobs, take the median
    ``minAreaRect`` angle of wide blobs. 0.0 when no credible text rows exist.

    Public because the golden tests re-run it on prep output to assert the
    residual skew (phase plan §4.6).
    """
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(15, gray.shape[1] // 60), 3))
    rows_mask = cv2.dilate(binary, kernel)
    min_w = gray.shape[1] / 15.0
    # When the page-quad guard identified a form border enclosing the body,
    # exterior-only contours see marginal stamps/scanner edges, not that body.
    # Otherwise retain the established population: mixing in nested contours
    # indiscriminately biases estimates with glyph holes and ruled cells.
    mode = cv2.RETR_LIST if inside_form else cv2.RETR_EXTERNAL
    contours, _ = cv2.findContours(rows_mask, mode, cv2.CHAIN_APPROX_SIMPLE)
    angles: list[float] = []
    for contour in contours:
        (_, _), (rw, rh), angle = cv2.minAreaRect(contour)
        if rw < rh:
            rw, rh = rh, rw
            angle -= 90.0
        if rh <= 0 or rw < min_w or rw < 4.0 * rh:
            continue
        while angle <= -45.0:
            angle += 90.0
        while angle > 45.0:
            angle -= 90.0
        angles.append(angle)
    if not angles:
        return 0.0
    angles.sort()
    return angles[len(angles) // 2]


def _order_quad(quad: npt.NDArray[np.float32]) -> npt.NDArray[np.float32]:
    """Order 4 points top-left, top-right, bottom-right, bottom-left."""
    sums = quad.sum(axis=1)
    diffs = np.diff(quad, axis=1).ravel()
    return np.array(
        [
            quad[int(np.argmin(sums))],
            quad[int(np.argmin(diffs))],
            quad[int(np.argmax(sums))],
            quad[int(np.argmax(diffs))],
        ],
        dtype=np.float32,
    )


def _find_confident_quad(
    gray: npt.NDArray[np.uint8],
    min_area_ratio: float,
    max_area_ratio: float,
    *,
    protect_content: bool = True,
) -> npt.NDArray[np.float32] | None:
    """Largest external contour that approximates a convex quadrilateral within
    the area gates — a page photographed against a background. ``None`` = skip."""
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150)
    edges = cv2.dilate(edges, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    page_area = float(gray.shape[0] * gray.shape[1])
    contour = max(contours, key=cv2.contourArea)
    area_ratio = cv2.contourArea(contour) / page_area
    if not min_area_ratio <= area_ratio <= max_area_ratio:
        return None
    hull = cv2.convexHull(contour)
    approx = cv2.approxPolyDP(hull, 0.02 * cv2.arcLength(hull, True), True)
    if len(approx) != 4 or not cv2.isContourConvex(approx):
        return None
    quad = approx.reshape(4, 2).astype(np.float32)
    # Solidity: the contour must actually fill its quad, not be a sprawling blob.
    if cv2.contourArea(contour) / max(cv2.contourArea(approx), 1.0) < 0.9:
        return None
    if protect_content and _text_outside_quad(gray, quad):
        return None
    return _order_quad(quad)


def _text_outside_quad(gray: npt.NDArray[np.uint8], quad: npt.NDArray[np.float32]) -> bool:
    """Refuse a page crop when it would discard a cluster of glyph-sized ink.

    A large ruled form box also passes convexity/area tests. Unlike a page
    boundary it has labels outside it. Ignore large connected background regions
    and long rules; require three separated glyph-like components, with their
    centres clear of the edge, so border antialiasing cannot veto a real photo.
    This is conservative geometry, not a handwriting/text classifier.
    """
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    count, _, stats, centroids = cv2.connectedComponentsWithStats(binary, connectivity=8)
    outside = 0
    for i in range(1, count):
        height = int(stats[i, cv2.CC_STAT_HEIGHT])
        width = int(stats[i, cv2.CC_STAT_WIDTH])
        area = int(stats[i, cv2.CC_STAT_AREA])
        if not (_GLYPH_H_MIN <= height <= min(_GLYPH_H_MAX, gray.shape[0] // 10)):
            continue
        if area < _GLYPH_MIN_AREA or width > 10 * height or height > 10 * width:
            continue
        centre = (float(centroids[i, 0]), float(centroids[i, 1]))
        if cv2.pointPolygonTest(quad, centre, True) < -max(2.0, height / 4):
            outside += 1
            if outside >= 3:
                return True
    return False


def _median_glyph_height(gray: npt.NDArray[np.uint8]) -> float:
    """Median connected-component height of glyph-sized components; 0.0 = no text."""
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    n, _, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    heights = [
        int(stats[i, cv2.CC_STAT_HEIGHT])
        for i in range(1, n)
        if _GLYPH_H_MIN <= stats[i, cv2.CC_STAT_HEIGHT] <= _GLYPH_H_MAX
        and stats[i, cv2.CC_STAT_AREA] >= _GLYPH_MIN_AREA
        and stats[i, cv2.CC_STAT_WIDTH] <= 10 * stats[i, cv2.CC_STAT_HEIGHT]
    ]
    if not heights:
        return 0.0
    heights.sort()
    return float(heights[len(heights) // 2])


@register("prep", "opencv-default")
class OpencvPrep:
    """Deterministic OpenCV prep chain (single-threaded; docs/07 pinning)."""

    version: str = f"opencv-{cv2.__version__}+content-guard-v3"

    def __init__(
        self,
        target_dpi: float = 300.0,
        target_text_height_px: float = 40.0,
        min_scale: float = 0.5,
        max_scale: float = 3.0,
        deskew_min_deg: float = 0.3,
        deskew_max_deg: float = 15.0,
        perspective_min_area_ratio: float = 0.4,
        perspective_max_area_ratio: float = 0.98,
        denoise: bool = False,
        binarize: bool = False,
        cls_model_path: str | None = None,
        cls_thresh: float = 0.9,
        cls_max_rows: int = 12,
    ) -> None:
        self.target_dpi = target_dpi
        self.target_text_height_px = target_text_height_px
        self.min_scale = min_scale
        self.max_scale = max_scale
        self.deskew_min_deg = deskew_min_deg
        self.deskew_max_deg = deskew_max_deg
        self.perspective_min_area_ratio = perspective_min_area_ratio
        self.perspective_max_area_ratio = perspective_max_area_ratio
        self.denoise = denoise
        self.binarize = binarize
        self.cls_max_rows = cls_max_rows
        # Flip-180 correction post-deskew (phase 09 §4.3): the PP-LCNet textline
        # orientation classifier, wired in via config. It lives in
        # engines/rapidocr.py (the ONNX vendor quarantine); constructing it here
        # validates the model path at startup (hard rule 9), the session itself
        # is created lazily in the worker after the pins.
        self._cls = None
        if cls_model_path is not None:
            from titanocr.engines.rapidocr import PpocrTextlineCls

            self._cls = PpocrTextlineCls(cls_model_path, cls_thresh=cls_thresh)
        # Determinism + pinning: OpenCV must never fan out its own threads
        # (docs/07 thread arithmetic). Idempotent; the worker initializer also
        # sets it before any engine exists.
        cv2.setNumThreads(0)

    def _cap_to_target_dpi(self, wanted: float, page_dpi: float | None, ctx: StageContext) -> float:
        """Bound the glyph-height rescale so the post-prep page never exceeds
        ``target_dpi`` — but only when the page's DPI is actually known.

        The glyph-height rule exists to *rescue* input whose resolution we cannot
        know (a phone photo of a page). Applied to a raster we rendered ourselves
        it does the opposite of help: interpolating a 300-DPI render up to 750 DPI
        invents pixels that carry no information the recogniser can use, while
        recognition cost grows with the square of the scale — and the detector
        immediately throws the extra pixels away again at ``max_side_len``. A
        300-DPI page already sits in PP-OCRv5's trained band (~40 px glyphs at
        10 pt), so the cap costs no accuracy.

        Pages of unknown DPI (``page.dpi is None`` — phone photos, EXIF-less
        uploads) are untouched: the full rescue still applies to them.
        """
        if page_dpi is None or page_dpi <= 0 or self.target_dpi <= 0:
            return wanted
        ceiling = self.target_dpi / page_dpi
        if wanted <= ceiling:
            return wanted
        capped = max(self.min_scale, ceiling)
        ctx.logger.debug(
            "prep: glyph-height rescale x%.3f capped to x%.3f — page is already %.0f dpi "
            "(target_dpi %.0f); upscaling a known-dpi render only costs recognition time",
            wanted,
            capped,
            page_dpi,
            self.target_dpi,
        )
        return capped

    def process(self, page: PageImage, ctx: StageContext) -> tuple[PageImage, PrepRecord]:
        ctx.deadline.check()
        pixels = page.pixels
        applied: list[str] = []
        skew_deg = 0.0
        scale = 1.0
        crop_bbox: tuple[float, float, float, float] | None = None

        # 1. EXIF transpose happens at decode time (the file is gone by now);
        #    the worker signals it via ctx.config so the record stays complete.
        if bool(ctx.config.get("exif_transposed")):
            applied.append("exif_transpose")

        # 2. Greyscale decision: convert only when achromatic (no information lost).
        chroma_mean, chroma_p99 = _chroma(pixels)
        is_grayscale = pixels.ndim == 2 or (
            chroma_mean < _GRAY_CHROMA_MEAN and chroma_p99 < _GRAY_CHROMA_P99
        )
        if is_grayscale and pixels.ndim == 3:
            pixels = _as_gray(pixels)
            applied.append("grayscale")

        # 3. Confident-quadrilateral perspective correction (else skip cleanly).
        ctx.deadline.check()
        quad = _find_confident_quad(
            _as_gray(pixels),
            self.perspective_min_area_ratio,
            self.perspective_max_area_ratio,
            protect_content=False,
        )
        inside_form = quad is not None and _text_outside_quad(_as_gray(pixels), quad)
        if inside_form:
            quad = None
        if quad is not None:
            pixels = self._warp_perspective(pixels, quad)
            x0, y0 = quad.min(axis=0)
            x1, y1 = quad.max(axis=0)
            crop_bbox = (float(max(x0, 0.0)), float(max(y0, 0.0)), float(x1), float(y1))
            applied.append(f"perspective:{','.join(f'{v:.1f}' for pt in quad for v in pt)}")
        else:
            ctx.logger.debug("prep: no confident quad — perspective skipped")

        # 4. Deskew: text-row minAreaRect angle, applied past the threshold.
        ctx.deadline.check()
        measured = estimate_skew_deg(_as_gray(pixels), inside_form=inside_form)
        if self.deskew_min_deg < abs(measured) <= self.deskew_max_deg:
            pixels = self._rotate(pixels, measured)
            skew_deg = measured
            applied.append(f"deskew:{measured:.2f}")
        elif measured != 0.0:
            ctx.logger.debug("prep: measured skew %.2f° outside gates — not corrected", measured)

        # 4b. Flip-180 correction (post-deskew): deskew makes text rows
        #     horizontal but cannot tell up from down; the textline orientation
        #     classifier votes over sampled rows and a clear 180° majority flips
        #     the page (self-inverse transform, recorded like every other).
        if self._cls is not None:
            ctx.deadline.check()
            if self._page_is_upside_down(pixels, ctx):
                pixels = cast(npt.NDArray[np.uint8], cv2.rotate(pixels, cv2.ROTATE_180))
                applied.append("rotate180")

        # 5. Dark-border auto-crop (scanner-bed edges only; perspective already
        #    extracted the page, so the two never both fire).
        if quad is None:
            cropped, bbox = self._crop_dark_borders(pixels)
            if bbox is not None:
                pixels = cropped
                crop_bbox = bbox
                applied.append(f"crop:{','.join(f'{v:.0f}' for v in bbox)}")

        # 6. Light denoise, param-gated (fastNlMeans is seconds-per-page; off by default).
        if self.denoise:
            ctx.deadline.check()
            if pixels.ndim == 2:
                pixels = cast(npt.NDArray[np.uint8], cv2.fastNlMeansDenoising(pixels, h=7))
            else:
                pixels = cast(
                    npt.NDArray[np.uint8], cv2.fastNlMeansDenoisingColored(pixels, h=7, hColor=7)
                )
            applied.append("denoise")

        # 7. DPI normalise: scale so the median glyph height ≈ target (clamped).
        ctx.deadline.check()
        glyph_h = _median_glyph_height(_as_gray(pixels))
        if glyph_h > 0:
            wanted = self.target_text_height_px / glyph_h
            wanted = min(self.max_scale, max(self.min_scale, wanted))
            wanted = self._cap_to_target_dpi(wanted, page.dpi, ctx)
            if abs(wanted - 1.0) > 0.05:
                interpolation = cv2.INTER_CUBIC if wanted > 1.0 else cv2.INTER_AREA
                pixels = cast(
                    npt.NDArray[np.uint8],
                    cv2.resize(pixels, None, fx=wanted, fy=wanted, interpolation=interpolation),
                )
                scale = wanted
                applied.append(f"dpi_normalise:x{wanted:.3f}")

        if self.binarize:
            gray = _as_gray(pixels)
            pixels = cast(
                npt.NDArray[np.uint8],
                cv2.adaptiveThreshold(
                    gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 15
                ),
            )
            applied.append("binarize")

        final = np.ascontiguousarray(pixels, dtype=np.uint8)
        final_gray = _as_gray(final)
        blur_score = float(cv2.Laplacian(final_gray, cv2.CV_64F).var())
        final_glyph_h = _median_glyph_height(final_gray)
        quality = Quality(
            blur_score=blur_score,
            resolution_ok=final_glyph_h == 0.0 or final_glyph_h >= _MIN_TEXT_HEIGHT_PX,
            is_grayscale=is_grayscale,
            ink_ratio=measure_ink_ratio(final_gray),
        )
        prep = Prep(
            applied=tuple(applied),
            skew_deg=skew_deg,
            crop_bbox_in_original=crop_bbox,
            scale=scale,
        )
        out = PageImage(
            width=int(final.shape[1]),
            height=int(final.shape[0]),
            dpi=page.dpi * scale if page.dpi is not None else None,
            pixels=final,
        )
        return out, PrepRecord(prep=prep, quality=quality)

    def _page_is_upside_down(self, pixels: npt.NDArray[np.uint8], ctx: StageContext) -> bool:
        """Majority vote of the textline orientation classifier over sampled
        text-row crops; conservative — flips only on a clear 180° majority."""
        assert self._cls is not None
        crops = self._text_row_crops(pixels, self.cls_max_rows)
        if len(crops) < 2:
            return False
        votes = self._cls.classify(crops)
        flipped = sum(
            1 for label, score in votes if label == "180" and score >= self._cls.cls_thresh
        )
        upright = sum(1 for label, score in votes if label == "0" and score >= self._cls.cls_thresh)
        ctx.logger.debug(
            "prep cls vote: %d x 180deg vs %d x 0deg over %d rows", flipped, upright, len(crops)
        )
        # Abstentions are still sampled rows: two confident 180 votes out of
        # twelve are not a page majority, even when the other ten abstain.
        return flipped >= 2 and flipped > len(crops) / 2

    @staticmethod
    def _text_row_crops(
        pixels: npt.NDArray[np.uint8], max_rows: int
    ) -> list[npt.NDArray[np.uint8]]:
        """Widest text-row crops (BGR, deterministic order) for the classifier —
        the same morphology the deskew estimate uses to find rows."""
        gray = _as_gray(pixels)
        _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (max(15, gray.shape[1] // 60), 3))
        rows_mask = cv2.dilate(binary, kernel)
        contours, _ = cv2.findContours(rows_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        min_w = gray.shape[1] / 15.0
        rects: list[tuple[int, int, int, int]] = []
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            if h < 8 or w < min_w or w < 3 * h:
                continue
            rects.append((x, y, w, h))
        rects.sort(key=lambda r: (-r[2], r[1], r[0]))  # widest first, then stable by position
        if pixels.ndim == 2:
            bgr = cv2.cvtColor(pixels, cv2.COLOR_GRAY2BGR)
        else:
            bgr = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR)
        crops = [np.ascontiguousarray(bgr[y : y + h, x : x + w]) for x, y, w, h in rects[:max_rows]]
        return cast(list[npt.NDArray[np.uint8]], crops)

    @staticmethod
    def _warp_perspective(
        pixels: npt.NDArray[np.uint8], quad: npt.NDArray[np.float32]
    ) -> npt.NDArray[np.uint8]:
        tl, tr, br, bl = quad
        width = round(max(float(np.linalg.norm(tr - tl)), float(np.linalg.norm(br - bl))))
        height = round(max(float(np.linalg.norm(bl - tl)), float(np.linalg.norm(br - tr))))
        width, height = max(width, 1), max(height, 1)
        target = np.array(
            [[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]], dtype=np.float32
        )
        matrix = cv2.getPerspectiveTransform(quad, target)
        return cast(
            npt.NDArray[np.uint8],
            cv2.warpPerspective(
                pixels,
                matrix,
                (width, height),
                flags=cv2.INTER_CUBIC,
                borderMode=cv2.BORDER_REPLICATE,
            ),
        )

    @staticmethod
    def _rotate(pixels: npt.NDArray[np.uint8], angle_deg: float) -> npt.NDArray[np.uint8]:
        """Rotate by ``-angle_deg`` (undoing the measured skew), canvas expanded."""
        h, w = pixels.shape[:2]
        centre = (w / 2.0, h / 2.0)
        matrix = cv2.getRotationMatrix2D(centre, angle_deg, 1.0)
        cos, sin = abs(matrix[0, 0]), abs(matrix[0, 1])
        new_w = round(w * cos + h * sin)
        new_h = round(h * cos + w * sin)
        matrix[0, 2] += new_w / 2.0 - centre[0]
        matrix[1, 2] += new_h / 2.0 - centre[1]
        return cast(
            npt.NDArray[np.uint8],
            cv2.warpAffine(
                pixels,
                matrix,
                (new_w, new_h),
                flags=cv2.INTER_CUBIC,
                borderMode=cv2.BORDER_REPLICATE,
            ),
        )

    @staticmethod
    def _crop_dark_borders(
        pixels: npt.NDArray[np.uint8],
    ) -> tuple[npt.NDArray[np.uint8], tuple[float, float, float, float] | None]:
        """Trim near-black scanner-bed rows/cols from the edges; ``None`` = nothing to trim.

        The trim exists for one situation: a light document photographed or
        scanned against a dark bed, where the dark frame is not part of the page.
        It has to *check* that situation holds, because on a page that is itself
        dark the edge test is true everywhere and the trim eats content — up to
        a quarter of the page from each side, which is what the loops below are
        bounded at. Measured on a dark marketing poster (1200x3000, navy
        background): it cropped to ``(70, 316, 1131, 2765)``, taking 316 px off
        the top, and the title lived in those pixels
        (docs/notes/dark-page-crop.md).

        So the guard is the trim's own premise, stated: what remains after the
        trim must look like a light page (:data:`_LIGHT_PAGE_MEAN`), and must be
        clearly brighter than the border being removed. A dark page has no
        scanner bed to lose and keeps every pixel.
        """
        gray = _as_gray(pixels)
        h, w = gray.shape
        row_means = gray.mean(axis=1)
        col_means = gray.mean(axis=0)
        row_stds = gray.std(axis=1)
        col_stds = gray.std(axis=0)

        def is_bed(mean: Any, std: Any) -> bool:
            """Dark *and* featureless — the two together are what a bed is."""
            return float(mean) < _DARK_BORDER_MEAN and float(std) < _DARK_BORDER_STD

        top = 0
        while top < h // 4 and is_bed(row_means[top], row_stds[top]):
            top += 1
        bottom = h
        while bottom > h - h // 4 and is_bed(row_means[bottom - 1], row_stds[bottom - 1]):
            bottom -= 1
        left = 0
        while left < w // 4 and is_bed(col_means[left], col_stds[left]):
            left += 1
        right = w
        while right > w - w // 4 and is_bed(col_means[right - 1], col_stds[right - 1]):
            right -= 1
        if (top, left, bottom, right) == (0, 0, h, w):
            return pixels, None
        if bottom <= top or right <= left:
            return pixels, None
        kept = gray[top:bottom, left:right]
        kept_mean = float(kept.mean())
        border_mean = float(np.mean([m for m in (*row_means[:top], *col_means[:left])] or [0.0]))
        if kept_mean < _LIGHT_PAGE_MEAN or kept_mean <= 2.0 * border_mean:
            # Not a light page behind a dark edge — a dark page. Nothing to trim.
            return pixels, None
        return (
            pixels[top:bottom, left:right],
            (float(left), float(top), float(right), float(bottom)),
        )


__all__ = ["OpencvPrep", "estimate_skew_deg", "measure_ink_ratio"]
