"""pypdfium2 engines: page rasterisation + the pdfium text fallback (phase 06).

Vendor quarantine for pypdfium2 (BSD-3). Two engines register here:

- ``rasterizer:pdfium`` — renders PDF pages to :class:`PageImage` (the display
  raster now, the OCR-path raster from phase 08) and encodes PNGs.
- ``pdftext:pdfium-text`` — the fallback for the digital fast path: pdfium
  charboxes clustered chars → words → lines. Coarse but positioned, used when
  pdf-inspector errors or reports low classify confidence.

pdfium is **not thread-safe**: every entry point here serialises on a module
lock. That is safe for v1 (one orchestrator loop + one ingest call at a time)
and is not engine state — engines themselves stay stateless.

Documents that cannot be opened raise :class:`EncryptedPdfError` /
:class:`PdfOpenError` — loud failures, never silent truncation (ADR 0001 §V3).
"""

# pypdfium2 ships no py.typed marker; unknown-member noise is confined to this
# vendor-quarantine module.
# pyright: reportUnknownMemberType=false, reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false, reportMissingTypeStubs=false

import io
import threading
from collections.abc import Mapping
from pathlib import Path
from typing import cast

import numpy as np
import numpy.typing as npt
import pypdfium2 as pdfium
import pypdfium2.raw as pdfium_c
from PIL import Image
from pypdfium2.version import PYPDFIUM_INFO

from titanocr.engines.pdftext import (
    LINE_MIN_OVERLAP_RATIO,
    PageGeometry,
    PdfTextClassification,
    PositionedText,
    cluster_into_lines,
    median_or,
    overlap_ratio,
)
from titanocr.ir import Line, PdfClass
from titanocr.stages import PageImage, register

_PDFIUM_LOCK = threading.Lock()
"""pdfium has no thread safety; all use in this process funnels through here."""

_IMAGE_WALK_DEPTH = 4
"""How many levels of form XObject :meth:`PdfiumRasterizer.image_boxes_pts`
walks into. A logo is routinely wrapped in one; a nesting deeper than a few
levels is a generated document's own business."""

_PYPDFIUM_VERSION = str(PYPDFIUM_INFO)

_POINTS_PER_INCH = 72.0


class PdfOpenError(Exception):
    """pdfium could not open the document (malformed beyond recovery)."""


class EncryptedPdfError(PdfOpenError):
    """The document is password-protected — rejected at ingest (422, plan §14)."""


def _open(pdf_path: Path) -> pdfium.PdfDocument:
    """Open under the module lock (caller must hold it), mapping pdfium error codes."""
    try:
        return pdfium.PdfDocument(pdf_path)
    except pdfium.PdfiumError as exc:
        if getattr(exc, "err_code", None) == pdfium_c.FPDF_ERR_PASSWORD:
            raise EncryptedPdfError("PDF is encrypted (password-protected)") from exc
        raise PdfOpenError(f"pdfium could not open the PDF: {exc}") from exc


def pdf_page_count(pdf_path: Path) -> int:
    """Page count for ingest (stage 0). Raises on encrypted/unreadable PDFs."""
    with _PDFIUM_LOCK:
        doc = _open(pdf_path)
        try:
            return len(doc)
        finally:
            doc.close()


def _centre_band(centre: float, height: float) -> tuple[float, float]:
    """A text row's band: its seed glyph's centre, widened to the page's median
    glyph height so an unusually short or tall glyph cannot resize the row."""
    return (centre - height / 2.0, centre + height / 2.0)


def _page_chars(
    textpage: object, n_chars: int
) -> list[tuple[str, tuple[float, float, float, float]]]:
    """(char, charbox) pairs; charboxes are PDF points, origin bottom-left."""
    chars: list[tuple[str, tuple[float, float, float, float]]] = []
    for i in range(n_chars):
        code = pdfium_c.FPDFText_GetUnicode(textpage, i)
        ch = chr(code)
        box = cast("pdfium.PdfTextPage", textpage).get_charbox(i)
        chars.append((ch, (box[0], box[1], box[2], box[3])))
    return chars


@register("rasterizer", "pdfium")
class PdfiumRasterizer:
    """PDF page → :class:`PageImage` (RGB uint8) + PNG encoding + page metrics.

    ``text_char_counts`` lives here because pdfium is the *reference* for the
    digital path's anti-truncation check (phase 06 §4.5): whichever pdftext
    engine produced the lines, coverage is measured against pdfium's independent
    character count.
    """

    version: str = _PYPDFIUM_VERSION

    def __init__(self, dpi: float = 300.0) -> None:
        self.dpi = dpi

    def rasterize(self, pdf_path: Path, page_no: int, dpi: float | None = None) -> PageImage:
        render_dpi = self.dpi if dpi is None else dpi
        with _PDFIUM_LOCK:
            doc = _open(pdf_path)
            try:
                page = doc[page_no - 1]
                # pypdfium2's stub declares scale as int; floats are supported.
                bitmap = page.render(scale=render_dpi / _POINTS_PER_INCH)  # pyright: ignore[reportArgumentType]
                pixels = cast(npt.NDArray[np.uint8], np.asarray(bitmap.to_numpy(), dtype=np.uint8))
            finally:
                doc.close()
        height, width = pixels.shape[0], pixels.shape[1]
        return PageImage(width=width, height=height, dpi=render_dpi, pixels=pixels)

    def encode_png(self, image: PageImage) -> bytes:
        buf = io.BytesIO()
        Image.fromarray(image.pixels).save(buf, format="PNG")
        return buf.getvalue()

    def page_sizes_pts(self, pdf_path: Path) -> list[tuple[float, float]]:
        with _PDFIUM_LOCK:
            doc = _open(pdf_path)
            try:
                return [doc[i].get_size() for i in range(len(doc))]
            finally:
                doc.close()

    def text_char_counts(self, pdf_path: Path) -> list[int]:
        """Non-whitespace text-layer characters per page — the coverage reference."""
        with _PDFIUM_LOCK:
            doc = _open(pdf_path)
            try:
                counts: list[int] = []
                for i in range(len(doc)):
                    textpage = doc[i].get_textpage()
                    n = textpage.count_chars()
                    counts.append(
                        sum(
                            1
                            for j in range(n)
                            if not chr(pdfium_c.FPDFText_GetUnicode(textpage, j)).isspace()
                        )
                    )
                return counts
            finally:
                doc.close()

    def image_boxes_pts(
        self, pdf_path: Path, page_no: int
    ) -> list[tuple[float, float, float, float]]:
        """Bounds of every image object on the page, in PDF points as
        ``(left, bottom, right, top)`` — the exact source of raster regions on
        the digital route (phase 23, ADR 0020). No model, no threshold: the page
        says where its pictures are. Walks into form XObjects; a degenerate or
        unreadable bound is skipped.
        """
        with _PDFIUM_LOCK:
            doc = _open(pdf_path)
            try:
                page = doc[page_no - 1]
                boxes: list[tuple[float, float, float, float]] = []
                for obj in page.get_objects(max_depth=_IMAGE_WALK_DEPTH):
                    if pdfium_c.FPDFPageObj_GetType(obj.raw) != pdfium_c.FPDF_PAGEOBJ_IMAGE:
                        continue
                    try:
                        left, bottom, right, top = obj.get_bounds()
                    except pdfium.PdfiumError:
                        continue
                    if right > left and top > bottom:
                        boxes.append((float(left), float(bottom), float(right), float(top)))
                return boxes
            finally:
                doc.close()


@register("pdftext", "pdfium-text")
class PdfiumTextEngine:
    """Text-layer fallback: pdfium charboxes → words → lines (phase 06 §4.6).

    Same informal interface as :class:`~titanocr.engines.pdftext.PdfInspectorEngine`
    so the orchestrator's fallback chain treats them interchangeably. Classification
    here is a deterministic character count (a page with no text layer needs OCR),
    reported with confidence 1.0 — there is no heuristic to be unsure about.
    """

    version: str = _PYPDFIUM_VERSION

    def __init__(
        self,
        digital_render_dpi: float = 150.0,
        min_text_coverage: float = 0.95,
        line_min_overlap_ratio: float = LINE_MIN_OVERLAP_RATIO,
        word_gap_ratio: float = 0.35,
        block_gap_ratio: float = 1.8,
    ) -> None:
        self.digital_render_dpi = digital_render_dpi
        self.min_text_coverage = min_text_coverage
        self.line_min_overlap_ratio = line_min_overlap_ratio
        self.word_gap_ratio = word_gap_ratio
        self.block_gap_ratio = block_gap_ratio

    def classify(self, pdf_path: Path) -> PdfTextClassification:
        with _PDFIUM_LOCK:
            doc = _open(pdf_path)
            try:
                needing: set[int] = set()
                for i in range(len(doc)):
                    textpage = doc[i].get_textpage()
                    n = textpage.count_chars()
                    has_text = any(
                        not chr(pdfium_c.FPDFText_GetUnicode(textpage, j)).isspace()
                        for j in range(n)
                    )
                    if not has_text:
                        needing.add(i + 1)
                page_count = len(doc)
            finally:
                doc.close()
        if not needing:
            pdf_type = PdfClass.TextBased
        elif len(needing) == page_count:
            pdf_type = PdfClass.Scanned
        else:
            pdf_type = PdfClass.Mixed
        return PdfTextClassification(
            pdf_type=pdf_type,
            confidence=1.0,
            page_count=page_count,
            pages_needing_ocr=frozenset(needing),
        )

    def extract_lines(
        self, pdf_path: Path, geometries: Mapping[int, PageGeometry]
    ) -> dict[int, list[Line]]:
        with _PDFIUM_LOCK:
            doc = _open(pdf_path)
            try:
                chars_by_page = {page_no: self._chars(doc, page_no) for page_no in geometries}
            finally:
                doc.close()
        return {
            page_no: cluster_into_lines(
                self._words(chars_by_page[page_no]),
                geom,
                page_no,
                min_overlap_ratio=self.line_min_overlap_ratio,
            )
            for page_no, geom in geometries.items()
        }

    def _chars(
        self, doc: pdfium.PdfDocument, page_no: int
    ) -> list[tuple[str, tuple[float, float, float, float]]]:
        textpage = doc[page_no - 1].get_textpage()
        return [
            (ch, box)
            for ch, box in _page_chars(textpage, textpage.count_chars())
            if not ch.isspace()
        ]

    def _words(
        self, chars: list[tuple[str, tuple[float, float, float, float]]]
    ) -> list[PositionedText]:
        """Cluster chars into words: same text row, x-gap below ``word_gap_ratio`` x height."""
        if not chars:
            return []
        median_h = median_or([box[3] - box[1] for _, box in chars], 1.0)

        def centre_y(box: tuple[float, float, float, float]) -> float:
            return (box[1] + box[3]) / 2.0

        ordered = sorted(chars, key=lambda c: (-centre_y(c[1]), c[1][0]))
        rows: list[list[tuple[str, tuple[float, float, float, float]]]] = [[ordered[0]]]
        # The band belongs to the row, not to the last glyph accepted into it:
        # comparing each char to its predecessor lets a row walk down the page one
        # small step at a time, which is exactly how a stacked column of cell text
        # collapses into one line (see `cluster_into_lines` for the measured case).
        # The band is the seed's centre widened to the page's median glyph height,
        # so an unusually short or tall glyph cannot resize it.
        band = _centre_band(centre_y(ordered[0][1]), median_h)
        for ch in ordered[1:]:
            box = ch[1]
            if overlap_ratio(box[1], box[3], *band) >= self.line_min_overlap_ratio:
                rows[-1].append(ch)
            else:
                rows.append([ch])
                band = _centre_band(centre_y(box), median_h)

        words: list[PositionedText] = []
        for row in rows:
            row.sort(key=lambda c: c[1][0])
            # Word gap scales with this row's glyph height, not the page median —
            # a 20 pt heading otherwise splits into letters against a 9 pt body.
            row_h = median_or([box[3] - box[1] for _, box in row], median_h)
            gap = self.word_gap_ratio * row_h
            current: list[tuple[str, tuple[float, float, float, float]]] = [row[0]]
            for ch in row[1:]:
                if ch[1][0] - current[-1][1][2] > gap:
                    words.append(self._word(current))
                    current = [ch]
                else:
                    current.append(ch)
            words.append(self._word(current))
        return words

    @staticmethod
    def _word(chars: list[tuple[str, tuple[float, float, float, float]]]) -> PositionedText:
        x0 = min(box[0] for _, box in chars)
        y0 = min(box[1] for _, box in chars)
        x1 = max(box[2] for _, box in chars)
        y1 = max(box[3] for _, box in chars)
        return PositionedText(
            text="".join(ch for ch, _ in chars), x=x0, y=y0, width=x1 - x0, height=y1 - y0
        )


__all__ = [
    "EncryptedPdfError",
    "PdfOpenError",
    "PdfiumRasterizer",
    "PdfiumTextEngine",
    "pdf_page_count",
]
