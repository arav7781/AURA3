"""Triage policy (stage 4) — registry name ``confidence-v1``.

The docs/03 §policy decision table, implemented verbatim and evaluated per page;
the orchestrator acts on the returned :class:`TriageDecision` (docs/08: the stage
is pure over the IR — it never touches the job table or the escalator itself).

The five arms, in table order:

1. ``origin == digital`` and ``text_coverage > 0.95`` → **accept** (exact by
   construction — no further checks).
2. ``mean_rec ≥ τ_high`` and ``p10_rec ≥ τ_floor`` and structure_ok → **accept**.
3. ``mean_rec ≥ τ_high`` but isolated low-confidence regions exist →
   **escalate_regions** (block-aligned region growing, everything else accepted).
4. ``mean_rec < τ_low`` or ``handwriting_ratio > τ_hw`` → **escalate_regions** over
   every part of the page the recogniser did not read confidently (ADR 0023: a
   page is never one unit), or **review** when there is nothing to point at.
5. otherwise (the grey band) → **review** = accept + ``review_required`` (the
   "re-check after stage 6" arm has no stage 6 yet — the flag is its honest v1
   rendering).

Structural sanity (docs/03 §signals) fires independently of confidence and is
gated per ``doc_type_hint`` through the pipeline's ``doc_types:`` section
(carried in ``ctx.config``): any hit lifts an accept to at least **review**;
combined with grey-band confidence it lifts to **escalate_regions**. Those
combination rules live here, in the policy, never in the orchestrator.

Two input-problem gates return **reject** instead of escalating (docs/03
§when-escalation-isn't-the-answer — paying a VLM to read an unreadable page is
waste): :meth:`ConfidenceV1.quality_reject_reason` is the *pre-OCR* gate the
pool worker calls post-prep (blur / resolution floors — provenance then proves
det/rec never ran), and the *post-OCR* backstop inside :meth:`decide` catches
near-zero recognised text on a page whose ink mask says it is not blank.

Every threshold is a constructor param, i.e. pipeline YAML (hard rule 9 —
changing a threshold is a config change, never a code change). The defaults are
**provisional placeholders** until real-document histograms exist (docs/03
§bootstrapping, passes 1-3 own the fitting); deliberately conservative —
escalate too much rather than too little.
"""

import re
from collections.abc import Mapping
from typing import Any, cast

from titanocr.ir import Line, Page, PageOrigin, Quality, Table
from titanocr.stages import (
    Region,
    StageContext,
    TriageAction,
    TriageDecision,
    register,
)

CONFIDENCE_V1_VERSION = "1.0"

_DATE_RE = re.compile(
    r"""
    \b\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}\b        # 05/08/2026, 5-8-26
    | \b\d{4}[-/.]\d{1,2}[-/.]\d{1,2}\b        # 2026-08-05
    | \b\d{1,2}[-\s][A-Za-z]{3,9}[-\s]\d{2,4}\b  # 05-Aug-2026, 5 August 26
    """,
    re.VERBOSE,
)
"""Date-shaped token (docs/03: a `note`-profile doc with none anywhere is suspect)."""

_NUMERIC_CELL_RE = re.compile(r"^[<>≤≥~±+-]?\d[\d,.]*\s*%?$")
"""A body cell that reads as a measurement value."""

_NUMERIC_HEADER_TOKENS = ("result", "value", "count", "level", "qty", "quantity", "measured")
"""Header words that declare a column numeric; a header containing a digit or
``%`` (units like ``10^9/L``) declares it too."""


def _numeric_header(text: str) -> bool:
    lowered = text.lower()
    return any(tok in lowered for tok in _NUMERIC_HEADER_TOKENS) or bool(re.search(r"[\d%]", text))


def _numeric_cell(text: str) -> bool:
    return bool(_NUMERIC_CELL_RE.match(text.strip()))


def _page_lines(page: Page) -> list[Line]:
    """Every recognised line on the page — table blocks carry theirs too (IR 1.1)."""
    lines: list[Line] = []
    for block in page.blocks:
        if block.lines:
            lines.extend(block.lines)
    return lines


def _nonws_chars(lines: list[Line]) -> int:
    return sum(1 for line in lines for ch in line.text if not ch.isspace())


def _table_column_findings(table: Table, min_ratio: float) -> list[str]:
    """Columns whose header says numeric while < ``min_ratio`` of the non-empty
    body cells parse as numbers (docs/03: unparseable values under a numeric
    header)."""
    findings: list[str] = []
    header_rows = set(table.header_rows)
    if not header_rows:
        return findings
    for col in range(table.n_cols):
        headers = [
            c.text
            for c in table.cells
            if c.row in header_rows and c.col <= col < c.col + c.col_span
        ]
        if not any(_numeric_header(h) for h in headers if h.strip()):
            continue
        body = [
            c.text.strip()
            for c in table.cells
            if c.row not in header_rows and c.col == col and c.text.strip()
        ]
        if not body:
            continue
        parsed = sum(1 for text in body if _numeric_cell(text))
        if parsed / len(body) < min_ratio:
            findings.append(f"numeric_column_unparseable:col{col}")
    return findings


@register("triage", "confidence-v1")
class ConfidenceV1:
    """docs/03 §policy as configuration-driven code (see module docstring)."""

    version: str = CONFIDENCE_V1_VERSION

    def __init__(
        self,
        tau_high: float = 0.92,
        tau_low: float = 0.70,
        tau_hw: float = 0.40,
        tau_floor: float = 0.5,
        digital_coverage_min: float = 0.95,
        region_margin_px: float = 12.0,
        reject_blur_floor: float = 6.0,
        reject_min_side_px: int = 320,
        reject_min_chars: int = 4,
        struct_min_chars: int = 25,
        min_ink_ratio: float = 0.02,
    ) -> None:
        self.tau_high = tau_high
        self.tau_low = tau_low
        self.tau_hw = tau_hw
        self.tau_floor = tau_floor
        self.digital_coverage_min = digital_coverage_min
        self.region_margin_px = region_margin_px
        self.reject_blur_floor = reject_blur_floor
        self.reject_min_side_px = reject_min_side_px
        self.reject_min_chars = reject_min_chars
        self.struct_min_chars = struct_min_chars
        self.min_ink_ratio = min_ink_ratio

    # -- pre-OCR quality gate (called by the pool worker, post-prep) --------------

    def quality_reject_reason(self, quality: Quality, width: int, height: int) -> str | None:
        """Input-problem verdict on a prepped page, before any OCR runs.

        Blur is only judged on a page whose ink mask says there is something to
        read — a blank page has a near-zero Laplacian too, and "confidently
        empty" (OCR finds nothing, page accepted) is the honest outcome there,
        not a reject.
        """
        inked = quality.ink_ratio is not None and quality.ink_ratio >= self.min_ink_ratio
        if inked and quality.blur_score < self.reject_blur_floor:
            return (
                f"blur_below_floor (blur_score {quality.blur_score:.1f} < {self.reject_blur_floor})"
            )
        if min(width, height) < self.reject_min_side_px:
            return (
                f"resolution_below_floor (min side {min(width, height)}px "
                f"< {self.reject_min_side_px}px)"
            )
        return None

    # -- the decision table --------------------------------------------------------

    def decide(self, page: Page, ctx: StageContext) -> TriageDecision:
        sig = page.confidence
        lines = _page_lines(page)
        n_chars = _nonws_chars(lines)
        ink = page.quality.ink_ratio
        signals: dict[str, float] = {
            "mean_rec": sig.mean_rec,
            "p10_rec": sig.p10_rec,
            "text_coverage": sig.text_coverage,
            "low_conf_area_ratio": sig.low_conf_area_ratio,
            "handwriting_ratio": sig.handwriting_ratio,
            "n_lines": float(len(lines)),
            "n_chars": float(n_chars),
        }
        if ink is not None:
            signals["ink_ratio"] = ink

        # Arm 1 — digital text layer is exact by construction. No further checks.
        if page.origin is PageOrigin.digital and sig.text_coverage > self.digital_coverage_min:
            return TriageDecision(
                action=TriageAction.accept, trigger="digital_exact", signals=signals
            )

        # Post-OCR reject backstop: near-zero recognised text on a non-blank page
        # is an input problem — reject, never escalate (docs/03).
        if n_chars < self.reject_min_chars and ink is not None and ink >= self.min_ink_ratio:
            return TriageDecision(
                action=TriageAction.reject, trigger="no_text_on_inked_page", signals=signals
            )

        findings = self._structural_findings(page, lines, n_chars, ink, ctx)
        structure_ok = not findings

        if sig.mean_rec >= self.tau_high:
            low_lines = [line for line in lines if line.confidence < self.tau_floor]
            if low_lines:
                # Arm 3 — isolated low-confidence regions; the rest is accepted as-is.
                regions = self._grow_regions(page, low_lines)
                return TriageDecision(
                    action=TriageAction.escalate_regions,
                    regions=regions,
                    trigger="low_conf_regions",
                    signals={**signals, "n_regions": float(len(regions))},
                    findings=tuple(findings),
                )
            if sig.p10_rec >= self.tau_floor and structure_ok:
                # Arm 2 — confident and structurally sane.
                return TriageDecision(
                    action=TriageAction.accept, trigger="confident", signals=signals
                )
            # High-confidence garbage is real (docs/03): a structural hit on a
            # confident page is at least a review, never a silent accept.
            return TriageDecision(
                action=TriageAction.review,
                trigger="structural:" + ",".join(findings),
                signals=signals,
                findings=tuple(findings),
            )

        if sig.mean_rec < self.tau_low or sig.handwriting_ratio > self.tau_hw:
            # Arm 4 — the page as a whole cannot be trusted, so its *unreadable
            # parts* are the units (ADR 0023). The page itself is never one.
            trigger = (
                "mean_rec_below_tau_low"
                if sig.mean_rec < self.tau_low
                else "handwriting_ratio_above_tau_hw"
            )
            return self._page_failure(page, lines, trigger, signals, findings)

        # Arm 5 — the grey band. A structural hit on top escalates (the docs/03
        # combination rule); clean grey band is accept + review_required.
        if findings:
            return self._page_failure(
                page,
                lines,
                "grey_band+structural:" + ",".join(findings),
                signals,
                findings,
            )
        return TriageDecision(action=TriageAction.review, trigger="grey_band", signals=signals)

    def _page_failure(
        self,
        page: Page,
        lines: list[Line],
        trigger: str,
        signals: Mapping[str, float],
        findings: list[str],
    ) -> TriageDecision:
        """A page-level failure, expressed as the units it is actually about.

        Everything below ``tau_high`` — what the recogniser did not read
        confidently — is grown into block-aligned regions and escalated;
        anything above it was read and stays on this machine (ADR 0023). A page
        with nothing to point at (no lines, or every line confident while the
        page-level signal failed) is a ``review``: there is no crop that would
        answer the question, and abstention is the honest state (hard rule 12).
        """
        failing = [line for line in lines if line.confidence < self.tau_high]
        regions = self._grow_regions(page, failing) if failing else ()
        if not regions:
            return TriageDecision(
                action=TriageAction.review,
                trigger=trigger,
                signals=signals,
                findings=tuple(findings),
            )
        return TriageDecision(
            action=TriageAction.escalate_regions,
            regions=regions,
            trigger=trigger,
            signals={**signals, "n_regions": float(len(regions))},
            findings=tuple(findings),
        )

    # -- structural sanity (docs/03 §signals — independent of confidence) ----------

    def _structural_findings(
        self,
        page: Page,
        lines: list[Line],
        n_chars: int,
        ink: float | None,
        ctx: StageContext,
    ) -> list[str]:
        hint = str(ctx.config.get("doc_type_hint", "auto"))
        doc_types: Any = ctx.config.get("doc_types")
        knobs: Mapping[str, Any] = {}
        if isinstance(doc_types, Mapping):
            candidate: Any = cast("Mapping[str, Any]", doc_types).get(hint)
            if isinstance(candidate, Mapping):
                knobs = cast("Mapping[str, Any]", candidate)

        findings: list[str] = []
        tables = [b for b in page.blocks if b.table is not None]

        if bool(knobs.get("require_table")) and not tables:
            findings.append("report_no_table")

        min_ratio = knobs.get("numeric_column_min_ratio")
        if isinstance(min_ratio, int | float):
            for block in tables:
                if block.table is None or block.table_failed:
                    continue
                findings.extend(_table_column_findings(block.table, float(min_ratio)))

        if bool(knobs.get("require_date")) and not any(
            _DATE_RE.search(line.text) for line in lines
        ):
            findings.append("note_no_date")

        if any(b.table_failed for b in page.blocks):
            findings.append("table_failed_blocks")

        # Generic, every doc type: detection/recognition collapsed on a page the
        # prep ink mask says is non-trivially inked.
        if n_chars < self.struct_min_chars and ink is not None and ink >= self.min_ink_ratio:
            findings.append("low_char_count_with_ink")
        return findings

    # -- region growing (block-aligned; phase 12 §8 risk note) ----------------------

    def _grow_regions(self, page: Page, low_lines: list[Line]) -> tuple[Region, ...]:
        """Cluster low-confidence lines into escalation rectangles.

        Block-aligned: low lines are grouped by the block that carries them, the
        cluster bbox is the union of the member lines plus ``region_margin_px``,
        clamped to the page; overlapping clusters merge. Confidence is the mean
        of the member lines, and every contributing block id rides along — the
        escalator replaces exactly those blocks (phase 13), so the narrowest
        failing unit stays exact instead of being re-derived geometrically.
        """
        low_ids = {line.line_id for line in low_lines}
        clusters: list[tuple[list[float], list[float], list[str]]] = []  # (bbox, confs, block_ids)
        for block in page.blocks:
            members = [line for line in block.lines or () if line.line_id in low_ids]
            if not members:
                continue
            x0 = min(line.bbox[0] for line in members) - self.region_margin_px
            y0 = min(line.bbox[1] for line in members) - self.region_margin_px
            x1 = max(line.bbox[2] for line in members) + self.region_margin_px
            y1 = max(line.bbox[3] for line in members) + self.region_margin_px
            bbox = [
                max(0.0, x0),
                max(0.0, y0),
                min(float(page.width), x1),
                min(float(page.height), y1),
            ]
            clusters.append((bbox, [line.confidence for line in members], [block.block_id]))

        merged: list[tuple[list[float], list[float], list[str]]] = []
        for bbox, confs, block_ids in sorted(clusters, key=lambda c: (c[0][1], c[0][0])):
            for existing, existing_confs, existing_ids in merged:
                if (
                    bbox[0] < existing[2]
                    and existing[0] < bbox[2]
                    and bbox[1] < existing[3]
                    and existing[1] < bbox[3]
                ):
                    existing[0] = min(existing[0], bbox[0])
                    existing[1] = min(existing[1], bbox[1])
                    existing[2] = max(existing[2], bbox[2])
                    existing[3] = max(existing[3], bbox[3])
                    existing_confs.extend(confs)
                    existing_ids.extend(block_ids)
                    break
            else:
                merged.append((bbox, confs, block_ids))
        return tuple(
            Region(
                bbox=(bbox[0], bbox[1], bbox[2], bbox[3]),
                confidence=sum(confs) / len(confs),
                block_ids=tuple(block_ids),
            )
            for bbox, confs, block_ids in merged
        )


__all__ = ["CONFIDENCE_V1_VERSION", "ConfidenceV1"]
