"""PP-OCRv5 detection / recognition / textline-orientation engines (phase 09).

RapidOCR + ONNXRuntime quarantine: nothing outside this module imports either
vendor for OCR purposes (docs/08). The wrappers are deliberately narrow — the
RapidOCR Python API churns between package flavours (plan §8 risk), so only
three of its components are touched (``TextDetector``, ``TextRecognizer``,
``TextClassifier``) and each is fed a pre-built ONNX session instead of a config
that could trigger RapidOCR's own model download machinery. Models are **explicit
local paths** from the pipeline config, fetched and pinned by ``make models``
(plan §12); a missing file fails engine construction, which fails readiness
(hard rule 9) — no code path downloads at runtime.

Sessions are created lazily on first inference so the parent process can
construct (= config-validate) engines at startup without paying model RSS; the
pool workers create the real sessions during warm-up, after the BLAS pins.
Session options are pinned to ``intra_op=1, inter_op=1, SEQUENTIAL`` (docs/07 —
the pool owns parallelism) and reported via :meth:`session_info` so tests assert
them from a live worker rather than assuming.
"""

# RapidOCR ships no type stubs; the vendor noise stays confined to this module.
# pyright: reportMissingTypeStubs=false, reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false, reportUnknownArgumentType=false
# pyright: reportAttributeAccessIssue=false

from collections.abc import Sequence
from importlib.metadata import version as _dist_version
from math import isfinite
from pathlib import Path
from typing import Any, cast

import cv2
import numpy as np
import numpy.typing as npt
import onnxruntime as ort  # pyright: ignore[reportMissingModuleSource]

from titanocr.ir import Line, Origin, Span
from titanocr.stages import PageImage, Region, StageContext, register

RAPIDOCR_VERSION = _dist_version("rapidocr")

DEFAULT_REC_CONF_FLOOR = 0.5
"""Per-line confidence floor for the signal formulas (plan §7 row 3½); the
pipeline overrides it via the ``rec_conf_floor`` param on the recognizer."""


class _ComponentCfg:
    """The mapping/attribute hybrid RapidOCR components read their config from.

    RapidOCR normally passes an OmegaConf node (``cfg.get(...)``, ``cfg[...]``
    and ``cfg.attr`` all used interchangeably); OmegaConf cannot hold an ONNX
    session object, so this minimal stand-in carries one via the library's own
    ``session`` passthrough (OrtInferSession accepts a pre-built session and
    skips its download/model-path logic entirely).
    """

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __getattr__(self, key: str) -> Any:
        try:
            return self._data[key]
        except KeyError as exc:  # pragma: no cover - config bug surface
            raise AttributeError(key) from exc


def _pinned_session_options() -> Any:
    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 1
    opts.inter_op_num_threads = 1
    opts.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    opts.log_severity_level = 4
    return opts


def _resolve_model_path(model_path: str) -> Path:
    path = Path(model_path)
    if not path.is_file():
        raise FileNotFoundError(
            f"model file not found: {path} — models are fetched by `make models` "
            "and never downloaded at runtime (plan §12)"
        )
    return path


def _to_bgr(pixels: npt.NDArray[np.uint8]) -> npt.NDArray[np.uint8]:
    """PageImage carries RGB (or grayscale); PP-OCR preprocessing expects the
    OpenCV BGR convention (plan §8: crop channel order is a classic CER bug)."""
    if pixels.ndim == 2:
        converted = cv2.cvtColor(pixels, cv2.COLOR_GRAY2BGR)
    else:
        converted = cv2.cvtColor(pixels, cv2.COLOR_RGB2BGR)
    return converted.astype(np.uint8, copy=False)


def _enclosed_indexes(
    box: tuple[float, float, float, float],
    others: Sequence[tuple[float, float, float, float]],
    frac: float,
) -> list[int]:
    """Which of ``others`` does ``box`` contain, by ``frac`` of their own area?

    The mirror of :func:`_covered_fraction`, and the necessary one: a coarse box
    drawn around a headline is mostly the gaps between its letters, so *it* is
    barely covered while the fragments inside it are wholly enclosed.
    """
    inside: list[int] = []
    for idx, other in enumerate(others):
        area = max((other[2] - other[0]) * (other[3] - other[1]), 1e-6)
        w = min(box[2], other[2]) - max(box[0], other[0])
        h = min(box[3], other[3]) - max(box[1], other[1])
        if w > 0 and h > 0 and (w * h) / area >= frac:
            inside.append(idx)
    return inside


def _covered_fraction(
    box: tuple[float, float, float, float],
    others: Sequence[tuple[float, float, float, float]],
) -> float:
    """How much of ``box`` the ``others`` already cover, 0..1.

    Summed intersections rather than a rasterised union: detector boxes for one
    page are near-disjoint by construction, so the sum only errs upward where
    they do overlap, and erring upward here means *discarding* a duplicate
    rather than emitting one — the safe direction for a rescue pass.
    """
    area = max((box[2] - box[0]) * (box[3] - box[1]), 1e-6)
    covered = 0.0
    for other in others:
        w = min(box[2], other[2]) - max(box[0], other[0])
        h = min(box[3], other[3]) - max(box[1], other[1])
        if w > 0 and h > 0:
            covered += w * h
    return min(covered / area, 1.0)


_PAD_GRAY = 128
"""Neutral grey: what PP-OCR's own batch padding is after its normalisation
((x/255 - 0.5)/0.5 = 0 at x = 127.5)."""


def _pad_right(crop: npt.NDArray[np.uint8], ratio: float) -> npt.NDArray[np.uint8]:
    """``crop`` with ``ratio`` of its width in neutral grey appended on the right."""
    extra = round(crop.shape[1] * ratio)
    if extra <= 0:
        return crop
    return cv2.copyMakeBorder(
        crop, 0, 0, 0, extra, cv2.BORDER_CONSTANT, value=(_PAD_GRAY, _PAD_GRAY, _PAD_GRAY)
    ).astype(np.uint8, copy=False)


def _order_quad(pts: npt.NDArray[np.float32]) -> npt.NDArray[np.float32]:
    """Four points as top-left, top-right, bottom-right, bottom-left."""
    by_x = pts[np.argsort(pts[:, 0], kind="stable")]
    left, right = by_x[:2], by_x[2:]
    tl, bl = left[np.argsort(left[:, 1], kind="stable")]
    tr, br = right[np.argsort(right[:, 1], kind="stable")]
    return np.array([tl, tr, br, bl], dtype=np.float32)


class _SessionHolder:
    """Shared lazy-session plumbing for the three engine wrappers."""

    def __init__(self, model_path: str) -> None:
        self.model_path = _resolve_model_path(model_path)
        self._session: Any = None
        self._session_options: Any = None

    def _get_session(self) -> Any:
        if self._session is None:
            self._session_options = _pinned_session_options()
            self._session = ort.InferenceSession(
                str(self.model_path),
                sess_options=self._session_options,
                providers=["CPUExecutionProvider"],
            )
        return self._session

    def session_info(self) -> dict[str, Any] | None:
        """The pinning evidence: the options the live session was built with
        (None until first inference creates the session)."""
        if self._session is None or self._session_options is None:
            return None
        return {
            "model": self.model_path.name,
            "intra_op_num_threads": self._session_options.intra_op_num_threads,
            "inter_op_num_threads": self._session_options.inter_op_num_threads,
            "execution_mode": self._session_options.execution_mode.name,
            "providers": list(self._session.get_providers()),
        }


@register("detector", "ppocr-v5-det")
class PpocrV5Det(_SessionHolder):
    """PP-OCRv5 DBNet-style text detection; polygons → axis-aligned Regions.

    The raw quadrilaterals are debug-logged, not put into the IR (docs/02 keeps
    bboxes axis-aligned; deskew has already made lines horizontal).
    """

    def __init__(
        self,
        model_path: str,
        box_thresh: float = 0.5,
        thresh: float = 0.3,
        unclip_ratio: float = 1.6,
        limit_side_len: int = 736,
        limit_type: str = "min",
        max_candidates: int = 1000,
        max_side_len: int = 1600,
        rescue_scale: float = 0.5,
        rescue_min_height_mult: float = 1.8,
        rescue_overlap_frac: float = 0.4,
    ) -> None:
        super().__init__(model_path)
        self.box_thresh = box_thresh
        self.thresh = thresh
        self.unclip_ratio = unclip_ratio
        self.limit_side_len = limit_side_len
        self.limit_type = limit_type
        self.max_candidates = max_candidates
        self.max_side_len = max_side_len
        self.rescue_scale = rescue_scale
        """Second detection pass at this fraction of the primary scale, for text
        too large for the primary pass to see (0 disables it). See
        :meth:`_rescue_regions` for the measured reason."""
        self.rescue_min_height_mult = rescue_min_height_mult
        """A rescued box must be this many times the median height of what the
        primary pass found. The band the primary pass covers is defined by its
        own output, not by the page size — a banner and an A4 scan disagree by
        an order of magnitude on what "big" means in pixels."""
        self.rescue_overlap_frac = rescue_overlap_frac
        """A rescued box this covered by primary boxes is the same text seen
        twice, or a merge of several lines, and is dropped."""
        self.version = f"rapidocr-{RAPIDOCR_VERSION}+{self.model_path.stem}"
        self._component: Any = None
        self._rescue_component: Any = None

    def _get_component(self, limit_side_len: int | None = None) -> Any:
        """The vendor detector, one per inference size.

        The rescue pass needs the *same weights* at a smaller inference size, so
        it gets its own component over the same pinned ONNX session — the session
        is the expensive, thread-pinned thing (docs/07); a component is a
        pre/post-processing wrapper around it.
        """
        if limit_side_len is not None and limit_side_len != self.limit_side_len:
            if self._rescue_component is None:
                self._rescue_component = self._build_component(limit_side_len)
            return self._rescue_component
        if self._component is None:
            self._component = self._build_component(self.limit_side_len)
        return self._component

    def _build_component(self, limit_side_len: int) -> Any:
        from rapidocr.ch_ppocr_det.main import TextDetector
        from rapidocr.utils.typings import EngineType

        cfg = _ComponentCfg(
            {
                "engine_type": EngineType.ONNXRUNTIME,
                "session": self._get_session(),
                "limit_side_len": limit_side_len,
                "limit_type": self.limit_type,
                "mean": [0.5, 0.5, 0.5],
                "std": [0.5, 0.5, 0.5],
                "thresh": self.thresh,
                "box_thresh": self.box_thresh,
                "max_candidates": self.max_candidates,
                "unclip_ratio": self.unclip_ratio,
                "use_dilation": True,
                "score_mode": "fast",
            }
        )
        return TextDetector(cast("dict[str, Any]", cfg))

    def warm_up(self) -> None:
        """Create the session + component now (worker init, after the pins)."""
        self._get_component()

    def detect(self, page: PageImage, ctx: StageContext) -> list[Region]:
        ctx.deadline.check()
        bgr = _to_bgr(page.pixels)
        # Detection-side downscale cap: DBNet localises fine well below the
        # DPI-normalised rec resolution, and quadratic det cost on a 6000 px
        # page is pure waste. Boxes are mapped back to page space; rec crops
        # stay at full resolution, so accuracy lives where it matters.
        det_scale = 1.0
        longest = max(page.width, page.height)
        if self.max_side_len > 0 and longest > self.max_side_len:
            det_scale = self.max_side_len / longest
            bgr = cv2.resize(
                bgr,
                (max(1, round(page.width * det_scale)), max(1, round(page.height * det_scale))),
                interpolation=cv2.INTER_AREA,
            ).astype(np.uint8, copy=False)
        regions = self._boxes(self._get_component()(bgr), det_scale, page, ctx)
        rescued, superseded = self._rescue_regions(bgr, det_scale, regions, page, ctx)
        kept = [r for i, r in enumerate(regions) if i not in superseded]
        return kept + rescued

    def _boxes(
        self, result: Any, det_scale: float, page: PageImage, ctx: StageContext
    ) -> list[Region]:
        """One detector result → page-space regions."""
        regions: list[Region] = []
        boxes = result.boxes if result.boxes is not None else []
        scores = result.scores if result.scores is not None else []
        for quad, score in zip(boxes, scores, strict=True):
            pts = np.asarray(quad, dtype=np.float64) / det_scale
            x0 = float(np.clip(pts[:, 0].min(), 0, page.width))
            x1 = float(np.clip(pts[:, 0].max(), 0, page.width))
            y0 = float(np.clip(pts[:, 1].min(), 0, page.height))
            y1 = float(np.clip(pts[:, 1].max(), 0, page.height))
            if x1 <= x0 or y1 <= y0:
                continue
            ctx.logger.debug(
                "det polygon %s -> bbox (%.1f, %.1f, %.1f, %.1f)", pts.tolist(), x0, y0, x1, y1
            )
            regions.append(
                Region(
                    bbox=(x0, y0, x1, y1),
                    confidence=float(np.clip(score, 0.0, 1.0)),
                    quad=tuple((float(x), float(y)) for x, y in pts),
                )
            )
        return regions

    def _rescue_regions(
        self,
        bgr: npt.NDArray[np.uint8],
        det_scale: float,
        primary: Sequence[Region],
        page: PageImage,
        ctx: StageContext,
    ) -> tuple[list[Region], set[int]]:
        """A second pass at a coarser scale — the text that is too *big* to see.

        A detector has a size band, and one inference scale cannot hold every
        glyph size a page mixes. Measured on a 1600x420 banner whose title is
        ~150 px tall: at the primary scale the title produces no box at all,
        while every coarser scale finds it (a 178-192 px box) —
        docs/notes/banner-phantom-rules.md. The subtitle beside it is read fine
        either way. So the failure is not "hard text", it is *scale*: a headline,
        a poster, a scanned certificate, a slide title — anything whose type is
        set several times body size — falls out of the band the primary pass
        covers, and finding where the text is on a page is the engine's first
        obligation, before anything downstream can be right.

        The pass is deliberately narrow, because a coarse pass also merges
        neighbouring body lines into one box, and a merged crop recognises as
        garbage:

        1. **Big only.** A rescued box under ``rescue_min_height_mult`` x the
           median height of the primary boxes is dropped — small text is the
           primary pass's job and it does it better. Measuring against the
           primary output rather than the page is what makes one threshold hold
           for a 1600x420 banner and a 2481x3508 scan at once. A page where the
           primary pass found *nothing* has no band to be outside of, so
           everything the coarse pass finds is kept: that is the poster whose
           only text is the headline.
        2. **New only** — and how much of a coarse box the primary boxes
           *explain* is what says whether it is new. Measured on the banner:
           the coarse box over the title is **16%** covered by what the primary
           pass found there, while its boxes over the subtitle rows are
           **87-100%** covered. That gap is the whole signal, and it is not an
           accident of these pages: a row the primary pass read is a row its
           boxes fill, and a row it could not read at this scale leaves the
           coarse box mostly empty.

           So a box ``rescue_overlap_frac`` or more covered is a row already
           read — dropped, whether the coarse pass merged several lines into it
           (the real failure mode of a coarse pass) or simply saw the same line
           again.

        3. **Fragments the rescue replaces are removed.** The primary pass does
           not fail *cleanly* on a headline. It returns pieces: on the banner, a
           box reading ``00`` across the ``CO`` of ``CORTEX`` and another over
           part of the ``AI``. Emitting those beside the rescue's ``AI CORTEX``
           is what produced ``AI A CORTEX C`` — one text row delivered twice, at
           two scales, interleaved by reading order. A kept rescue therefore
           supersedes every primary box it encloses: those boxes account for
           under ``rescue_overlap_frac`` of it by the test just applied, so they
           are pieces of the row it read whole.

        Deterministic: fixed scale, fixed thresholds, same pinned session, no
        sampling — two runs give byte-identical boxes.
        """
        if not (0.0 < self.rescue_scale < 1.0):
            return [], set()
        ctx.deadline.check()
        h, w = bgr.shape[:2]
        coarse = cv2.resize(
            bgr,
            (max(1, round(w * self.rescue_scale)), max(1, round(h * self.rescue_scale))),
            interpolation=cv2.INTER_AREA,
        )
        # The vendor's own preprocessing scales the short side up to
        # `limit_side_len`, which would undo the downscale — and undo the point
        # of the pass. It moves with the scale.
        limit = max(32, round(self.limit_side_len * self.rescue_scale))
        component = self._get_component(limit)
        found = self._boxes(component(coarse), det_scale * self.rescue_scale, page, ctx)
        heights = sorted(p.bbox[3] - p.bbox[1] for p in primary)
        min_height = self.rescue_min_height_mult * heights[len(heights) // 2] if heights else 0.0
        others = [p.bbox for p in primary]
        rescued: list[Region] = []
        superseded: set[int] = set()
        for r in found:
            if (r.bbox[3] - r.bbox[1]) < min_height:
                continue
            if _covered_fraction(r.bbox, others) >= self.rescue_overlap_frac:
                continue
            rescued.append(r)
            superseded.update(_enclosed_indexes(r.bbox, others, self.rescue_overlap_frac))
        if rescued:
            ctx.logger.info(
                "rescue pass at %.2fx: %d region(s) the primary scale could not read "
                "whole, superseding %d fragment(s)",
                self.rescue_scale,
                len(rescued),
                len(superseded),
            )
        return rescued, superseded


class _RecReader(_SessionHolder):
    """One PP-OCR recognition model: its session, component and batched reads."""

    def __init__(self, model_path: str, batch_size: int = 8, pad_ratio: float = 0.0) -> None:
        super().__init__(model_path)
        if type(batch_size) is not int or batch_size < 1:
            raise ValueError("batch_size must be a positive integer")
        if not isfinite(pad_ratio) or not 0 <= pad_ratio <= 2:
            raise ValueError("pad_ratio must be between 0 and 2")
        self.batch_size = batch_size
        self.pad_ratio = pad_ratio
        self._component: Any = None

    def _get_component(self) -> Any:
        if self._component is None:
            from rapidocr.ch_ppocr_rec.main import TextRecognizer
            from rapidocr.utils.typings import EngineType

            cfg = _ComponentCfg(
                {
                    "engine_type": EngineType.ONNXRUNTIME,
                    "session": self._get_session(),
                    "rec_batch_num": self.batch_size,
                    "rec_img_shape": [3, 48, 320],
                    "rec_keys_path": None,
                    "lang_type": "ch",
                    "font_path": None,
                }
            )
            component = TextRecognizer(cast("dict[str, Any]", cfg))
            if not component.session.have_key():
                raise RuntimeError(
                    f"rec model {self.model_path.name} carries no embedded character dict — "
                    "wrong model file (the pinned RapidOCR ONNX exports embed it)"
                )
            self._component = component
        return self._component

    def warm_up(self) -> None:
        self._get_component()

    def _recognize_crops(
        self, crops: Sequence[npt.NDArray[np.uint8]], ctx: StageContext
    ) -> list[tuple[str, float]]:
        """Recognise a bounded batch, restoring input order after width sorting."""
        if not crops:
            return []
        ctx.deadline.check()
        from rapidocr.ch_ppocr_rec.typings import TextRecInput

        # Batch by similar aspect ratio, not in reading order. PP-OCR resizes every
        # crop to height 48 and pads the batch to its widest member, so mixing a
        # "2026" date with a full-width bullet line makes all eight pay the wide
        # one's cost. Sorting collapses that waste (this is what PaddleOCR's own
        # recogniser does). The key is (ratio, index), so the order is a total
        # order over the crops and reruns stay byte-identical (plan §determinism).
        # With ``batch_size`` 1 (ADR 0026) each crop is read alone and the
        # padding a wide line needs comes from ``pad_ratio`` instead of from
        # whichever neighbours happened to share its batch.
        order = sorted(
            range(len(crops)),
            key=lambda i: (crops[i].shape[1] / max(1, crops[i].shape[0]), i),
        )

        results: list[tuple[str, float]] = [("", 0.0)] * len(crops)
        component = self._get_component()
        for start in range(0, len(order), self.batch_size):
            ctx.deadline.check()
            idxs = order[start : start + self.batch_size]
            batch = [_pad_right(crops[i], self.pad_ratio) for i in idxs]
            result = component(TextRecInput(img=batch))
            txts = result.txts if result.txts is not None else [""] * len(batch)
            for i, (text, score) in zip(idxs, zip(txts, result.scores, strict=True), strict=True):
                results[i] = (str(text), float(np.clip(score, 0.0, 1.0)))

        return results


@register("recognizer", "ppocr-v5-rec")
class PpocrV5Rec(_RecReader):
    """PP-OCRv5 CTC recognition over batched region crops.

    One span per line: PP-OCR rec yields no word geometry, and docs/02 says
    consumers must not assume span count > 1. Every detected region yields a
    line — including empty-text ones — because "detection succeeded, recognition
    produced nothing credible" is exactly the signal triage keys off.

    ``second_model_path`` adds a second recogniser that reads every crop too;
    its reading replaces the primary one only when it is nonempty and scores
    more than ``second_min_gain`` above it (a tie keeps the primary). The two
    PP-OCRv5 recognisers fail in different places — measured on real lab
    reports, the multilingual model reads isolated ``%`` as a full-width percent sign
    and drops letters in small print, the English one collapses on some very
    wide or low-contrast lines — and each is *unconfident* where it fails
    (docs/notes/lab-reports-2026-09-26.md). The box never moves; only which
    model's transcription of it is kept.
    """

    def __init__(
        self,
        model_path: str,
        batch_size: int = 8,
        rec_conf_floor: float = DEFAULT_REC_CONF_FLOOR,
        vertical_retry: bool = True,
        vertical_aspect_ratio: float = 1.5,
        orientation_min_gain: float = 0.05,
        max_orientation_crops: int = 32,
        second_model_path: str | None = None,
        second_min_gain: float = 0.0,
        rectify_min_deg: float = 0.0,
        rectify_min_drift: float = 0.0,
        pad_ratio: float = 0.0,
    ) -> None:
        super().__init__(model_path, batch_size, pad_ratio)
        if not isfinite(rec_conf_floor) or not 0 <= rec_conf_floor <= 1:
            raise ValueError("rec_conf_floor must be between 0 and 1")
        if type(vertical_retry) is not bool:
            raise ValueError("vertical_retry must be a boolean")
        if not isfinite(vertical_aspect_ratio) or vertical_aspect_ratio <= 1:
            raise ValueError("vertical_aspect_ratio must be finite and greater than 1")
        if not isfinite(orientation_min_gain) or not 0 <= orientation_min_gain <= 1:
            raise ValueError("orientation_min_gain must be between 0 and 1")
        if type(max_orientation_crops) is not int or max_orientation_crops < 0:
            raise ValueError("max_orientation_crops must be a nonnegative integer")
        if not isfinite(second_min_gain) or not 0 <= second_min_gain <= 1:
            raise ValueError("second_min_gain must be between 0 and 1")
        if not isfinite(rectify_min_deg) or not 0 <= rectify_min_deg < 45:
            raise ValueError("rectify_min_deg must be in [0, 45); 0 disables rectification")
        if not isfinite(rectify_min_drift) or rectify_min_drift < 0:
            raise ValueError("rectify_min_drift must be a nonnegative number")
        self.rec_conf_floor = rec_conf_floor
        self.vertical_retry = vertical_retry
        self.vertical_aspect_ratio = vertical_aspect_ratio
        self.orientation_min_gain = orientation_min_gain
        self.max_orientation_crops = max_orientation_crops
        self.second_min_gain = second_min_gain
        self.rectify_min_deg = rectify_min_deg
        self.rectify_min_drift = rectify_min_drift
        self._second = (
            _RecReader(second_model_path, batch_size, pad_ratio)
            if second_model_path is not None
            else None
        )
        self.version = f"rapidocr-{RAPIDOCR_VERSION}+{self.model_path.stem}+orientation-v1"
        if self._second is not None:
            self.version += f"+second-{self._second.model_path.stem}-v1"
        if self.pad_ratio > 0:
            self.version += f"+pad-{self.pad_ratio:g}-v1"
        if self.rectify_min_deg > 0:
            self.version += (
                f"+rectify-{self.rectify_min_deg:g}deg-{self.rectify_min_drift:g}drift-v1"
            )

    def warm_up(self) -> None:
        self._get_component()
        if self._second is not None:
            self._second.warm_up()

    def recognize(
        self, page: PageImage, regions: Sequence[Region], ctx: StageContext
    ) -> list[Line]:
        ctx.deadline.check()
        if not regions:
            return []
        bgr = _to_bgr(page.pixels)
        crops: list[npt.NDArray[np.uint8]] = []
        kept: list[Region] = []
        for region in regions:
            x0, y0, x1, y1 = region.bbox
            r0, r1 = max(0, int(np.floor(y0))), min(page.height, int(np.ceil(y1)))
            c0, c1 = max(0, int(np.floor(x0))), min(page.width, int(np.ceil(x1)))
            if r1 <= r0 or c1 <= c0:
                continue
            rectified = self._rectified(bgr, region)
            crops.append(
                rectified if rectified is not None else np.ascontiguousarray(bgr[r0:r1, c0:c1])
            )
            kept.append(region)

        results = self._recognize_crops(crops, ctx)
        if self._second is not None:
            self._second_opinion(crops, results, ctx)
        if self.vertical_retry:
            self._retry_vertical(crops, results, ctx)

        lines: list[Line] = []
        for idx, (region, (text, confidence)) in enumerate(zip(kept, results, strict=True)):
            lines.append(
                Line(
                    line_id=f"l{idx}",
                    bbox=region.bbox,
                    text=text,
                    confidence=confidence,
                    origin=Origin.ocr,
                    is_handwritten=False,
                    spans=(Span(text=text, bbox=region.bbox, confidence=confidence),),
                )
            )
        return lines

    def _rectified(
        self, bgr: npt.NDArray[np.uint8], region: Region
    ) -> npt.NDArray[np.uint8] | None:
        """The region's quadrilateral warped flat, when its line is slanted enough.

        ``None`` — use the axis-aligned crop — unless rectification is on, the
        detector gave a quad, its top and bottom edges tilt by at least
        ``rectify_min_deg`` on average, *and* the text drifts vertically across
        the line by at least ``rectify_min_drift`` of the line's own height. An
        axis-aligned box around a long tilted line is mostly background above
        and below the text, and the recogniser reads its glyphs at a slant; the
        perspective warp is PaddleOCR's own crop. The drift gate matters as much
        as the angle: a detector's angle on a short box is mostly noise, and a
        short box barely drifts however it tilts — warping it only risks glyphs.
        Upright lines — nearly all of them after deskew — are untouched.
        """
        if self.rectify_min_deg <= 0 or region.quad is None or len(region.quad) != 4:
            return None
        pts = _order_quad(np.asarray(region.quad, dtype=np.float32))
        top, bottom = pts[1] - pts[0], pts[2] - pts[3]
        tilt = (
            np.degrees(np.arctan2(top[1], top[0])) + np.degrees(np.arctan2(bottom[1], bottom[0]))
        ) / 2.0
        if abs(tilt) < self.rectify_min_deg:
            return None
        width = int(np.rint(max(np.linalg.norm(top), np.linalg.norm(bottom))))
        height = int(np.rint(max(np.linalg.norm(pts[3] - pts[0]), np.linalg.norm(pts[2] - pts[1]))))
        if width < 2 or height < 2:
            return None
        drift = width * abs(np.tan(np.radians(tilt))) / height
        if drift < self.rectify_min_drift:
            return None
        target = np.array([[0, 0], [width, 0], [width, height], [0, height]], dtype=np.float32)
        matrix = cv2.getPerspectiveTransform(pts, target)
        warped = cv2.warpPerspective(
            bgr,
            matrix,
            (width, height),
            flags=cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_REPLICATE,
        )
        return np.ascontiguousarray(warped.astype(np.uint8, copy=False))

    def _second_opinion(
        self,
        crops: Sequence[npt.NDArray[np.uint8]],
        results: list[tuple[str, float]],
        ctx: StageContext,
    ) -> None:
        """Keep the second recogniser's reading wherever it is the surer one.

        Runs before the vertical retry, so a tall crop both models read upright
        still gets its quarter-turn attempt against the better upright score.
        """
        assert self._second is not None
        readings = self._second._recognize_crops(crops, ctx)
        for i, (text, confidence) in enumerate(readings):
            original_text, original_score = results[i]
            if text.strip() and confidence > original_score + self.second_min_gain:
                results[i] = (text, confidence)
                ctx.logger.debug(
                    "recognize: crop %d second opinion %r %.4f replaces %r %.4f",
                    i,
                    text,
                    confidence,
                    original_text,
                    original_score,
                )

    def _retry_vertical(
        self,
        crops: Sequence[npt.NDArray[np.uint8]],
        results: list[tuple[str, float]],
        ctx: StageContext,
    ) -> None:
        """Try both vertical directions without moving the source-page boxes.

        Keep the original unless a nonempty candidate clears the confidence
        floor and improves its score by the configured margin. This is model
        evidence, not proof of correctness; triage still evaluates the result.
        Lowest-confidence tall crops get the bounded retry budget first.
        """
        ctx.deadline.check()
        candidates = sorted(
            (
                i
                for i, crop in enumerate(crops)
                if crop.shape[0] / max(1, crop.shape[1]) >= self.vertical_aspect_ratio
            ),
            key=lambda i: (results[i][1], i),
        )[: self.max_orientation_crops]
        rotated = [np.ascontiguousarray(np.rot90(crops[i], k)) for i in candidates for k in (1, 3)]
        readings = self._recognize_crops(rotated, ctx)
        for offset, i in enumerate(candidates):
            pair = readings[2 * offset : 2 * offset + 2]
            best = max(range(2), key=lambda j: pair[j][1])
            text, confidence = pair[best]
            original_score = results[i][1]
            if (
                text.strip()
                and confidence >= self.rec_conf_floor
                and confidence > original_score + self.orientation_min_gain
            ):
                results[i] = (text, confidence)
                ctx.logger.debug(
                    "recognize: crop %d rotated %ddeg CCW; score %.4f -> %.4f",
                    i,
                    90 if best == 0 else 270,
                    original_score,
                    confidence,
                )


class PpocrTextlineCls(_SessionHolder):
    """PP-LCNet textline orientation (0°/180°) classifier.

    Not a registry stage of its own: it is wired into the prep chain (flip-180
    correction post-deskew, plan §7 row 2) by ``opencv-default`` via its
    ``cls_model_path`` param. Kept here because it is RapidOCR/ONNX vendor code.
    """

    def __init__(self, model_path: str, cls_thresh: float = 0.9, batch_size: int = 6) -> None:
        super().__init__(model_path)
        self.cls_thresh = cls_thresh
        self.batch_size = batch_size
        self.version = f"rapidocr-{RAPIDOCR_VERSION}+{self.model_path.stem}"
        self._component: Any = None

    def _get_component(self) -> Any:
        if self._component is None:
            from rapidocr.ch_ppocr_cls.main import TextClassifier
            from rapidocr.utils.typings import EngineType, OCRVersion

            cfg = _ComponentCfg(
                {
                    "engine_type": EngineType.ONNXRUNTIME,
                    "session": self._get_session(),
                    "ocr_version": OCRVersion.PPOCRV5,
                    "cls_batch_num": self.batch_size,
                    "cls_thresh": self.cls_thresh,
                    "label_list": ["0", "180"],
                }
            )
            self._component = TextClassifier(cast("dict[str, Any]", cfg))
        return self._component

    def warm_up(self) -> None:
        self._get_component()

    def classify(self, crops: Sequence[npt.NDArray[np.uint8]]) -> list[tuple[str, float]]:
        """(label, score) per crop; crops are 3-channel BGR text-row images."""
        if not crops:
            return []
        result = self._get_component()([np.ascontiguousarray(c) for c in crops])
        assert result.cls_res is not None
        return [(str(label), float(score)) for label, score in result.cls_res]


__all__ = [
    "DEFAULT_REC_CONF_FLOOR",
    "RAPIDOCR_VERSION",
    "PpocrTextlineCls",
    "PpocrV5Det",
    "PpocrV5Rec",
]
