"""Table structure recognition (phase 11): the ``geometric`` engine and its
``rapid-table`` fallback.

Geometric reconstruction is primary (docs/01 §component selection): most lab
reports are ruled or well-aligned, and a lattice/clustering reconstruction is
deterministic, explainable and CPU-cheap. Two strategies, picked per block by
ruling-line evidence:

- **Ruled** — adaptive threshold → morphology with long H/V kernels → ruling
  masks → intersection lattice → cell grid; a missing interior rule segment
  merges cells into ``row_span``/``col_span``.
- **Borderless** — column starts from 1-D clustering of unit left edges (with
  the projection profile of unit x-intervals as the boundary evidence), rows
  from y-clustering; a unit that straddles a column boundary by more than the
  overlap threshold becomes a ``col_span``.

Both strategies produce the same :class:`GridCell` grid and feed the same
:func:`assemble_table` cell assignment (max intersection-over-area, multi-line
cells joined with ``\\n``, **empty cells preserved** — column alignment is the
point, docs/02). The digital fast path reuses the borderless functions over
positioned-item boxes directly (ADR 0001 §2 — no raster ops needed); only the
unit source differs.

Quality gate: ``grid_coverage`` (fraction of the block's units assigned to
cells) below ``min_grid_coverage``, or a degenerate grid for a multi-line
block, raises :class:`EngineDegraded` — the runner then hands the same call to
the configured fallback (both attempts in provenance). The fallback wraps
rapid_table's SLANet-plus model: like ``engines/layout.py`` it feeds a
pre-built, pinned ONNX session (``intra_op=1, inter_op=1, SEQUENTIAL``) through
the library's internal handler (the ``cfg["session"]`` passthrough), so the
package's own download machinery is unreachable; the model file is an explicit
local path fetched and pinned by ``make models``. rapid-table is exact-pinned
in pyproject because those handler classes are internal API. The model's
HTML-structure logic points ``(row_start, row_end, col_start, col_end)`` become
the same :class:`GridCell` grid and run through the same assembly.
"""

# rapid_table ships no type stubs; the vendor noise stays confined to this module.
# pyright: reportMissingTypeStubs=false, reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false, reportUnknownArgumentType=false
# pyright: reportAttributeAccessIssue=false

import re
from bisect import bisect_right
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from importlib.metadata import version as _dist_version
from itertools import pairwise
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import numpy.typing as npt

from titanocr.ir import BBox, Block, BlockType, Cell, Line, Origin, Span, Table
from titanocr.stages import EngineDegraded, PageImage, StageContext, register

GEOMETRIC_VERSION = "geometric-1"
RAPID_TABLE_VERSION = _dist_version("rapid-table")

_DIGIT_RE = re.compile(r"\d")


@dataclass(frozen=True)
class TextUnit:
    """The unit of cell assignment: an OCR line (raster path) or a positioned
    span (digital path) — bbox + text + confidence + origin."""

    bbox: BBox
    text: str
    confidence: float
    origin: Origin


@dataclass(frozen=True)
class GridCell:
    """One cell slot of a reconstructed grid, before text assignment."""

    row: int
    col: int
    row_span: int
    col_span: int
    bbox: BBox


def units_from_lines(lines: Sequence[Line]) -> list[TextUnit]:
    """OCR path: one unit per recognised line."""
    return [
        TextUnit(bbox=ln.bbox, text=ln.text, confidence=ln.confidence, origin=ln.origin)
        for ln in lines
    ]


def split_wide_gap_lines(blocks: Sequence[Block], gap_ratio: float = 2.0) -> list[Block]:
    """Split a non-table block's lines wherever their spans stop being one run.

    Sharing a y-band does not make two runs of text one line. The labels of two
    side-by-side boxes in a diagram, a heading and the date opposite it, a
    sidebar beside body text — all land in one visual row, and joining them with
    a space reads them as one phrase: "Medical Imaging CNN / ViT Encoder" for two
    separate boxes.

    Runs *after* table reconstruction, and skips the two block types whose rows
    carry meaning across the gap:

    - ``table`` — the visual row is exactly what the reconstructor reads.
      Splitting rows before it runs collapses the grid (measured: cell-run
      detection stops firing and the table becomes one prose block).
    - ``kv`` — the gap is what separates a label from its value. Splitting it
      leaves ``Item Name:`` and ``Flange Coupling FC-42`` as unrelated lines and
      the pair can no longer be formed.

    Everywhere else the row has no such meaning, and two runs far apart are two
    pieces of content.

    Spans are never merged or dropped, only regrouped, so every character and
    every box survives.
    """
    out: list[Block] = []
    for block in blocks:
        if block.type in (BlockType.table, BlockType.kv) or not block.lines:
            out.append(block)
            continue
        split = [ln for line in block.lines for ln in _split_line_at_gaps(line, gap_ratio)]
        out.append(
            block
            if len(split) == len(block.lines)
            else block.model_copy(update={"lines": tuple(split)})
        )
    return out


def _split_line_at_gaps(line: Line, gap_ratio: float) -> list[Line]:
    """One line in, one or more out — split where the inter-span gap is too wide
    to be a word space. A gap several times the type size is a column boundary."""
    spans = sorted(line.spans, key=lambda sp: sp.bbox[0])
    if len(spans) < 2:
        return [line]
    height = max(1.0, line.bbox[3] - line.bbox[1])
    runs: list[list[Span]] = [[spans[0]]]
    for prev, span in pairwise(spans):
        if span.bbox[0] - prev.bbox[2] > gap_ratio * height:
            runs.append([span])
        else:
            runs[-1].append(span)
    if len(runs) == 1:
        return [line]
    return [
        line.model_copy(
            update={
                "line_id": f"{line.line_id}c{i}",
                "text": " ".join(sp.text for sp in run),
                "bbox": (
                    min(sp.bbox[0] for sp in run),
                    min(sp.bbox[1] for sp in run),
                    max(sp.bbox[2] for sp in run),
                    max(sp.bbox[3] for sp in run),
                ),
                "spans": tuple(run),
            }
        )
        for i, run in enumerate(runs)
    ]


_COLUMN_SPLIT_TYPES = frozenset({BlockType.paragraph, BlockType.header})
"""Block types whose lines are independent content and may be split into
columns. ``table``/``kv`` pair their cells *across* the gutter, and a ``figure``
is one region with one placeholder — splitting any of them would break the very
structure they encode."""


def split_column_blocks(blocks: Sequence[Block], gutter_ratio: float = 2.0) -> list[Block]:
    """Split a block whose lines sit in separate columns, one block per column.

    A block is the unit a consumer positions: the projection places it at its
    bbox and lets its lines stack. That is right only when the lines *do* stack.
    A block spanning several columns — a results grid the table reconstructor
    declined, a footer of date/department/page, a two-up layout — has lines
    scattered across the page, and stacking them at the block's top-left throws
    away every x position it had. Measured on a real deck: one block held 26
    lines across three columns and rendered as a single flat list, with the
    column structure of the page gone.

    The split is a vertical projection over the line boxes — the classic
    document-analysis gutter test, exact here because the line geometry is
    measured rather than guessed. A gap in x-coverage that **no line crosses**,
    wider than ``gutter_ratio`` line heights, is a column boundary. Ragged prose
    has no such gap: its lines all start at the same margin and overlap each
    other's x-range continuously.

    Reading order is reassigned densely over the result, top-to-bottom then
    left-to-right, because splitting one block into three would otherwise leave
    three blocks claiming the same order (which the IR rejects outright).
    """
    out: list[Block] = []
    for block in blocks:
        lines = list(block.lines or ())
        if block.type not in _COLUMN_SPLIT_TYPES or len(lines) < 2:
            out.append(block)
            continue
        columns = _partition_columns(lines, gutter_ratio)
        if len(columns) < 2:
            out.append(block)
            continue
        for i, column in enumerate(columns):
            ordered = sorted(column, key=lambda ln: (ln.bbox[1], ln.bbox[0]))
            out.append(
                block.model_copy(
                    update={
                        "block_id": f"{block.block_id}k{i}",
                        "bbox": (
                            min(ln.bbox[0] for ln in ordered),
                            min(ln.bbox[1] for ln in ordered),
                            max(ln.bbox[2] for ln in ordered),
                            max(ln.bbox[3] for ln in ordered),
                        ),
                        "lines": tuple(ordered),
                        "confidence": sum(ln.confidence for ln in ordered) / len(ordered),
                    }
                )
            )
    out.sort(key=lambda b: (round(b.bbox[1]), round(b.bbox[0])))
    return [b.model_copy(update={"reading_order": i}) for i, b in enumerate(out)]


def _partition_columns(lines: Sequence[Line], gutter_ratio: float) -> list[list[Line]]:
    """Group lines into columns separated by gutters no line crosses."""
    median_h = _median([ln.bbox[3] - ln.bbox[1] for ln in lines])
    ordered = sorted(lines, key=lambda ln: (ln.bbox[0], ln.bbox[1]))
    columns: list[list[Line]] = [[ordered[0]]]
    reach = ordered[0].bbox[2]
    for line in ordered[1:]:
        if line.bbox[0] - reach > gutter_ratio * median_h:
            columns.append([line])
            reach = line.bbox[2]
        else:
            columns[-1].append(line)
            reach = max(reach, line.bbox[2])
    return columns


def units_from_spans(lines: Sequence[Line]) -> list[TextUnit]:
    """Digital path: one unit per positioned span (ADR 0001 §2 — items are the
    natural cell-content unit on the digital route; a whole visual row is one
    Line there, which is exactly what cell assignment must *not* consume)."""
    return [
        TextUnit(bbox=sp.bbox, text=sp.text, confidence=sp.confidence, origin=ln.origin)
        for ln in lines
        for sp in ln.spans
    ]


# -- shared geometry helpers -----------------------------------------------------


def _median(values: Sequence[float], default: float = 1.0) -> float:
    if not values:
        return default
    ordered = sorted(values)
    return max(ordered[len(ordered) // 2], default)


def _unit_rows(units: Sequence[TextUnit], median_h: float, ratio: float = 0.6) -> list[list[int]]:
    """Group unit indices into visual rows: y-centres within ``ratio`` x the
    median unit height (the same rule used across phases 09/10)."""
    order = sorted(
        range(len(units)),
        key=lambda i: ((units[i].bbox[1] + units[i].bbox[3]) / 2.0, units[i].bbox[0]),
    )
    rows: list[list[int]] = []
    for idx in order:
        centre = (units[idx].bbox[1] + units[idx].bbox[3]) / 2.0
        if rows:
            last = rows[-1]
            last_centre = sum((units[i].bbox[1] + units[i].bbox[3]) / 2.0 for i in last) / len(last)
            if abs(centre - last_centre) <= ratio * median_h:
                last.append(idx)
                continue
        rows.append([idx])
    for row in rows:
        row.sort(key=lambda i: units[i].bbox[0])
    return rows


def _intersection_area(a: BBox, b: BBox) -> float:
    w = min(a[2], b[2]) - max(a[0], b[0])
    h = min(a[3], b[3]) - max(a[1], b[1])
    return max(0.0, w) * max(0.0, h)


def _clamp_bbox(bbox: BBox, width: float, height: float) -> BBox:
    x0 = min(max(bbox[0], 0.0), width)
    y0 = min(max(bbox[1], 0.0), height)
    return (x0, y0, min(max(bbox[2], x0), width), min(max(bbox[3], y0), height))


# -- ruled strategy: morphology → lattice ----------------------------------------


@dataclass(frozen=True)
class RulingAnalysis:
    """Ruling-line evidence for one block crop (coordinates crop-local)."""

    h_rules: tuple[float, ...]
    v_rules: tuple[float, ...]
    h_mask: npt.NDArray[np.uint8]
    v_mask: npt.NDArray[np.uint8]
    score: float
    """Median fractional length of the detected rules — the strategy-pick score."""


def analyze_ruling(
    gray: npt.NDArray[np.uint8],
    *,
    kernel_frac: float = 0.08,
    rule_min_len_frac: float = 0.45,
) -> RulingAnalysis:
    """Detect horizontal/vertical ruling lines in a grayscale block crop.

    Adaptive threshold (inverted) → morphological opening with long H/V
    kernels → per-axis coverage profiles; a profile band covering at least
    ``rule_min_len_frac`` of the crossing dimension is one rule.
    """
    h, w = gray.shape
    if h < 8 or w < 8:
        empty = np.zeros_like(gray)
        return RulingAnalysis((), (), empty, empty, 0.0)
    binv = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 15, 10
    )
    hk = max(16, int(w * kernel_frac))
    vk = max(16, int(h * kernel_frac))
    h_mask = cv2.morphologyEx(binv, cv2.MORPH_OPEN, np.ones((1, hk), dtype=np.uint8)).astype(
        np.uint8, copy=False
    )
    v_mask = cv2.morphologyEx(binv, cv2.MORPH_OPEN, np.ones((vk, 1), dtype=np.uint8)).astype(
        np.uint8, copy=False
    )
    h_rules, h_fracs = _profile_rules(h_mask, axis=1, min_len_frac=rule_min_len_frac)
    v_rules, v_fracs = _profile_rules(v_mask, axis=0, min_len_frac=rule_min_len_frac)
    fracs = h_fracs + v_fracs
    score = _median(fracs, 0.0) if fracs else 0.0
    return RulingAnalysis(tuple(h_rules), tuple(v_rules), h_mask, v_mask, min(score, 1.0))


def _profile_rules(
    mask: npt.NDArray[np.uint8], *, axis: int, min_len_frac: float
) -> tuple[list[float], list[float]]:
    """Rule centre positions + fractional lengths from a directional mask.

    ``axis=1`` sums along x (horizontal rules → y positions); ``axis=0`` sums
    along y (vertical rules → x positions).
    """
    crossing = mask.shape[axis]
    profile = (mask > 0).sum(axis=axis).astype(np.float64)
    hits = profile >= min_len_frac * crossing
    rules: list[float] = []
    fracs: list[float] = []
    start: int | None = None
    for pos in range(len(hits) + 1):
        on = pos < len(hits) and bool(hits[pos])
        if on and start is None:
            start = pos
        elif not on and start is not None:
            band = slice(start, pos)
            rules.append((start + pos - 1) / 2.0)
            fracs.append(float(profile[band].max()) / crossing)
            start = None
    return rules, fracs


def lattice_cells(
    h_rules: Sequence[float],
    v_rules: Sequence[float],
    h_mask: npt.NDArray[np.uint8],
    v_mask: npt.NDArray[np.uint8],
    *,
    edge_min_frac: float = 0.5,
) -> list[GridCell]:
    """Grid cells from the ruling lattice; a missing interior rule segment
    (checked against the masks) merges cells into spans."""
    ys = sorted(h_rules)
    xs = sorted(v_rules)
    n_rows, n_cols = len(ys) - 1, len(xs) - 1
    if n_rows < 1 or n_cols < 1:
        return []

    def v_edge_present(row: int, boundary: int) -> bool:
        """Vertical rule between (row, boundary-1) and (row, boundary)?"""
        x = round(xs[boundary])
        y0, y1 = int(ys[row]), int(ys[row + 1])
        margin = max(1, (y1 - y0) // 6)
        seg = v_mask[y0 + margin : y1 - margin, max(0, x - 2) : x + 3]
        return seg.size > 0 and float((seg > 0).any(axis=1).mean()) >= edge_min_frac

    def h_edge_present(boundary: int, col: int) -> bool:
        """Horizontal rule between (boundary-1, col) and (boundary, col)?"""
        y = round(ys[boundary])
        x0, x1 = int(xs[col]), int(xs[col + 1])
        margin = max(1, (x1 - x0) // 6)
        seg = h_mask[max(0, y - 2) : y + 3, x0 + margin : x1 - margin]
        return seg.size > 0 and float((seg > 0).any(axis=0).mean()) >= edge_min_frac

    visited = [[False] * n_cols for _ in range(n_rows)]
    cells: list[GridCell] = []
    for i in range(n_rows):
        for j in range(n_cols):
            if visited[i][j]:
                continue
            col_span = 1
            while (
                j + col_span < n_cols
                and not visited[i][j + col_span]
                and not v_edge_present(i, j + col_span)
            ):
                col_span += 1
            row_span = 1
            while i + row_span < n_rows:
                next_row = i + row_span
                blocked = any(visited[next_row][j + k] for k in range(col_span))
                edge_below = any(h_edge_present(next_row, j + k) for k in range(col_span))
                interior_split = any(v_edge_present(next_row, j + k) for k in range(1, col_span))
                if blocked or edge_below or interior_split:
                    break
                row_span += 1
            for r in range(i, i + row_span):
                for c in range(j, j + col_span):
                    visited[r][c] = True
            cells.append(
                GridCell(
                    row=i,
                    col=j,
                    row_span=row_span,
                    col_span=col_span,
                    bbox=(xs[j], ys[i], xs[j + col_span], ys[i + row_span]),
                )
            )
    return cells


# -- borderless strategy: 1-D clustering -----------------------------------------


def _cluster_anchors(values: Sequence[float], tol: float, support: int) -> list[float]:
    """Single-link clusters of ``values`` within ``tol``, keeping those with at
    least ``support`` members; the cluster mean is the anchor position."""
    ordered = sorted(values)
    clusters: list[list[float]] = [[ordered[0]]]
    for x in ordered[1:]:
        if x - clusters[-1][-1] <= tol:
            clusters[-1].append(x)
        else:
            clusters.append([x])
    return [sum(c) / len(c) for c in clusters if len(c) >= support]


def _anchor_hits(values: Sequence[float], anchors: Sequence[float], tol: float) -> int:
    """How many ``values`` sit within ``tol`` of some anchor — the evidence that
    an alignment hypothesis (left-edge vs centre) actually explains the units."""
    return sum(1 for v in values if any(abs(v - a) <= tol for a in anchors))


def borderless_cells(
    units: Sequence[TextUnit],
    block_bbox: BBox,
    *,
    col_tol_frac: float = 0.015,
    col_min_support: int = 2,
    straddle_frac: float = 0.3,
) -> list[GridCell]:
    """Grid cells from unit alignment alone (no raster evidence).

    Columns come from clustering an *anchor* x per unit with at least
    ``col_min_support`` members: its **left edge** when the column text is
    left-aligned, or its **centre** when the column is centred. Both are
    tried and the one that explains more units wins (ties → left, the
    historical behaviour); centred columns are the common real-world case
    that left-edge clustering cannot see at all — the anchors scatter across
    the column width and the grid shatters (first real-sample finding,
    2026-08-14). Rows are the visual-row y-clusters. A unit whose right edge
    reaches more than ``straddle_frac`` of the way into a following column
    spans it (``col_span``); the covered slots emit no empty cell. Returns
    ``[]`` when no plausible grid exists (fewer than two supported columns or
    rows) — the caller's quality gate decides what that means.
    """
    if not units:
        return []
    block_w = max(block_bbox[2] - block_bbox[0], 1.0)
    median_h = _median([u.bbox[3] - u.bbox[1] for u in units])
    rows = _unit_rows(units, median_h)
    n_rows = len(rows)
    tol = max(4.0, col_tol_frac * block_w)
    support = max(2, col_min_support)

    left_of = [u.bbox[0] for u in units]
    centre_of = [(u.bbox[0] + u.bbox[2]) / 2.0 for u in units]
    left_anchors = _cluster_anchors(left_of, tol, support)
    centre_anchors = _cluster_anchors(centre_of, tol, support)
    centred = _anchor_hits(centre_of, centre_anchors, tol) > _anchor_hits(
        left_of, left_anchors, tol
    )
    anchors = centre_anchors if centred else left_anchors
    unit_anchor = centre_of if centred else left_of
    n_cols = len(anchors)
    if n_cols < 2 or n_rows < 2:
        return []

    # Column boundaries: block edge, then between adjacent anchors — midway for
    # centred columns, just left of the start for left-aligned ones.
    col_bounds = [block_bbox[0]]
    if centred:
        col_bounds += [(a + b) / 2.0 for a, b in pairwise(anchors)]
    else:
        col_bounds += [a - tol / 2.0 for a in anchors[1:]]
    col_bounds.append(block_bbox[2])

    # Row boundaries: block edge, then midpoints between adjacent row bands.
    row_tops = [min(units[i].bbox[1] for i in row) for row in rows]
    row_bottoms = [max(units[i].bbox[3] for i in row) for row in rows]
    row_bounds = [block_bbox[1]]
    row_bounds += [(row_bottoms[i] + row_tops[i + 1]) / 2.0 for i in range(n_rows - 1)]
    row_bounds.append(block_bbox[3])

    def col_of(x0: float) -> int:
        return min(max(bisect_right(col_bounds, x0) - 1, 0), n_cols - 1)

    def span_of(col: int, x1: float) -> int:
        span = 1
        while col + span < n_cols:
            nxt_lo = col_bounds[col + span]
            nxt_hi = col_bounds[col + span + 1]
            reach = x1 - nxt_lo
            if reach <= straddle_frac * (nxt_hi - nxt_lo):
                break
            span += 1
        return span

    # Span slots claimed by straddling units; conflicts collapse to span 1.
    spans: dict[tuple[int, int], int] = {}
    occupied: set[tuple[int, int]] = set()
    for row_idx, row in enumerate(rows):
        for i in row:
            col = col_of(unit_anchor[i])
            occupied.add((row_idx, col))
    for row_idx, row in enumerate(rows):
        for i in row:
            col = col_of(unit_anchor[i])
            span = span_of(col, units[i].bbox[2])
            covered = {(row_idx, col + k) for k in range(1, span)}
            if covered & occupied:
                span = 1  # another unit owns a covered slot — not a merge
            key = (row_idx, col)
            spans[key] = max(spans.get(key, 1), span)

    cells: list[GridCell] = []
    covered_slots = {(r, c + k) for (r, c), span in spans.items() for k in range(1, span)}
    for r in range(n_rows):
        for c in range(n_cols):
            if (r, c) in covered_slots:
                continue
            span = spans.get((r, c), 1)
            cells.append(
                GridCell(
                    row=r,
                    col=c,
                    row_span=1,
                    col_span=span,
                    bbox=(
                        col_bounds[c],
                        row_bounds[r],
                        col_bounds[c + span],
                        row_bounds[r + 1],
                    ),
                )
            )
    return cells


# -- shared assembly: units → IR Table -------------------------------------------


def assemble_table(
    grid: Sequence[GridCell],
    units: Sequence[TextUnit],
    *,
    origin_default: Origin,
    page_width: float,
    page_height: float,
    min_ioa: float = 0.25,
) -> tuple[Table, float]:
    """The one cell-assignment code path (both strategies, both routes).

    Every unit goes to the grid cell with the highest intersection-over-unit-
    area (≥ ``min_ioa``); multi-line cell text joins visual rows with ``\\n``;
    cell confidence is the min of its members (1.0 when empty — an empty cell
    is a *certain* statement of emptiness, not a low-confidence one); empty
    cells are emitted, never dropped. Returns ``(table, grid_coverage)`` where
    coverage is the assigned fraction of ``units``.
    """
    n_rows = max((g.row + g.row_span for g in grid), default=0)
    n_cols = max((g.col + g.col_span for g in grid), default=0)
    assigned: dict[int, list[int]] = {}
    n_assigned = 0
    for u_idx, unit in enumerate(units):
        area = max((unit.bbox[2] - unit.bbox[0]) * (unit.bbox[3] - unit.bbox[1]), 1e-6)
        best_idx, best_ioa = -1, 0.0
        for g_idx, gcell in enumerate(grid):
            ioa = _intersection_area(unit.bbox, gcell.bbox) / area
            if ioa > best_ioa:
                best_idx, best_ioa = g_idx, ioa
        if best_idx >= 0 and best_ioa >= min_ioa:
            assigned.setdefault(best_idx, []).append(u_idx)
            n_assigned += 1

    cells: list[Cell] = []
    for g_idx, gcell in enumerate(grid):
        members = assigned.get(g_idx, [])
        if members:
            member_units = [units[i] for i in members]
            median_h = _median([u.bbox[3] - u.bbox[1] for u in member_units])
            visual = _unit_rows(member_units, median_h)
            text = "\n".join(
                " ".join(member_units[i].text for i in row if member_units[i].text)
                for row in visual
            ).strip("\n")
            confidence = min(u.confidence for u in member_units)
            origin = member_units[0].origin
        else:
            text, confidence, origin = "", 1.0, origin_default
        cells.append(
            Cell(
                row=gcell.row,
                col=gcell.col,
                row_span=gcell.row_span,
                col_span=gcell.col_span,
                bbox=_clamp_bbox(gcell.bbox, page_width, page_height),
                text=text,
                confidence=min(1.0, max(0.0, confidence)),
                origin=origin,
            )
        )
    header_rows = detect_header_rows(cells, n_rows)
    table = Table(
        n_rows=max(n_rows, 1),
        n_cols=max(n_cols, 1),
        header_rows=header_rows,
        cells=tuple(cells),
    )
    coverage = n_assigned / len(units) if units else 1.0
    return table, coverage


def detect_header_rows(cells: Sequence[Cell], n_rows: int) -> tuple[int, ...]:
    """Row 0 by default (plan §4.3); extend to row 1 when a second all-
    non-numeric row precedes numeric columns."""
    if n_rows < 2:
        return ()
    by_row: dict[int, list[Cell]] = {}
    for cell in cells:
        by_row.setdefault(cell.row, []).append(cell)

    def row_has_digits(row: int) -> bool:
        return any(_DIGIT_RE.search(c.text) for c in by_row.get(row, ()))

    header: tuple[int, ...] = (0,)
    if n_rows > 2 and not row_has_digits(1):
        body_numeric = any(row_has_digits(r) for r in range(2, n_rows))
        if body_numeric:
            header = (0, 1)
    return header


def single_cell_table(
    block_bbox: BBox, origin: Origin, *, page_width: float, page_height: float
) -> Table:
    """The honest degenerate: a region with no recognised units is one empty
    cell — nothing is claimed, nothing is faked."""
    return Table(
        n_rows=1,
        n_cols=1,
        header_rows=(),
        cells=(
            Cell(
                row=0,
                col=0,
                bbox=_clamp_bbox(block_bbox, page_width, page_height),
                text="",
                confidence=1.0,
                origin=origin,
            ),
        ),
    )


def _strong_columns(table: Table, min_fill_frac: float) -> int:
    """Columns whose non-empty cells cover at least ``min_fill_frac`` of the
    rows. Sparse columns (e.g. a mostly-empty Flag column) are legitimate table
    columns but poor *evidence* — only densely filled ones count."""
    fill: dict[int, int] = {}
    for cell in table.cells:
        if cell.text:
            fill[cell.col] = fill.get(cell.col, 0) + cell.row_span
    return sum(1 for count in fill.values() if count >= min_fill_frac * table.n_rows)


def _max_col_mean_chars(table: Table) -> float:
    """The largest per-column mean of non-empty cell text lengths — a wrapped
    text flow masquerading as a column stands far above any real cell column."""
    lens: dict[int, list[int]] = {}
    for cell in table.cells:
        if cell.text:
            lens.setdefault(cell.col, []).append(len(cell.text))
    if not lens:
        return 0.0
    return max(sum(v) / len(v) for v in lens.values())


_LEADER_CHARS = frozenset(". \n\u00b7\u2024\u2026\u22ef")
"""What a dot leader is made of: full stop, middle dot, one-dot leader,
horizontal and midline ellipsis — and the whitespace between them."""


def leader_cell_fraction(table: Table) -> float:
    """The share of non-empty cells that are nothing but leader dots.

    A contents page, an index or a price list draws a run of dots between a
    label and its page number. On the digital route every dot is a positioned
    span; on the OCR route the run is a recognised ``.....`` — and either way
    the reconstruction reads the dots as columns, dozens of them, and the page
    grows a grid it does not have (measured on a real 24-line contents page,
    2026-09-03: 569 cells, 309 of them a lone ``.``). A real table has no such
    cell: a leader-dominated grid is not a table (phase 22).
    """
    filled = [cell.text for cell in table.cells if cell.text.strip()]
    if not filled:
        return 0.0
    leaders = sum(1 for text in filled if set(text) <= _LEADER_CHARS)
    return leaders / len(filled)


_NUMERIC_CELL_RE = re.compile(
    "^[\\s\\d.,%$\u20ac\u00a3()+\\-\u2013\u2014/:*\u2020\u2021]*\\d"
    "[\\s\\d.,%$\u20ac\u00a3()+\\-\u2013\u2014/:*\u2020\u2021]*$"
)


_PLACEHOLDER_RE = re.compile(
    "^\\s*[(\\[]?(?:NA|N/A|n\\.?a\\.?|X|S|D|Z|nil|\\u2014|\\u2013|-|\\.{1,3}|:|\\*+|\\u2020|\\u2021)[)\\]]?\\s*$",
    re.IGNORECASE,
)


def _is_placeholder_cell(text: str) -> bool:
    """A value that is *not available*, as statistical tables write it: ``NA``,
    ``(X)``, an em rule, Eurostat's ``:``, a run of dots. A row of these is a
    body row as much as a row of numbers is (measured on the ICDAR 2013
    stratum: a row of ``NA`` taken for header merged a body row into the
    labels)."""
    return bool(_PLACEHOLDER_RE.match(text))


def _is_numeric_cell(text: str) -> bool:
    """A cell that reads as a value: digits with number punctuation and nothing
    else. ``2003-04`` (any dash), ``$33,200``, ``(4.1)`` and ``12.0-15.0`` qualify."""
    return bool(text.strip()) and _NUMERIC_CELL_RE.match(text.strip()) is not None


_YEAR_RE = re.compile(r"^\s*(?:1[89]|20)\d\d(?:\s*[-\u2013/]\s*(?:\d\d|\d\d\d\d))?\s*$")


def _is_year_label(text: str) -> bool:
    """``2007``, ``2010-11``, ``1995\u20131997``: a year set over columns is a
    header row even though it reads as a number — the first body row is the
    first row with a value that is not a year."""
    return bool(_YEAR_RE.match(text))


_HEADER_BAND_MAX_ROWS = 8
"""A wrapped column label rarely runs past eight lines; a longer run of rows
without a single value is a text table, not a header."""


def _row_fill(table: Table) -> dict[int, int]:
    fill: dict[int, int] = {}
    for cell in table.cells:
        if cell.text:
            fill[cell.row] = fill.get(cell.row, 0) + 1
    return fill


def _header_band(table: Table) -> int:
    """How many leading rows are header: the rows before the first *body* row —
    one that carries a cell reading as a value (a number, or a placeholder
    such as ``NA``) **and** fills at least half the columns. A unit or flag
    column does not make a row a header (``Wall Thickness | 10.9 | mm |
    12.0-15.0 | L`` is body); a row of years
    (``| 2007 | | | 2009 |``, ``2010 | 2020 | 2030``) is a header row.
    A table with no body row has a one-row header by convention."""
    numeric_rows = {
        cell.row
        for cell in table.cells
        if cell.text
        and (
            (_is_numeric_cell(cell.text) and not _is_year_label(cell.text))
            or _is_placeholder_cell(cell.text)
        )
    }
    fill = _row_fill(table)
    half = (table.n_cols + 1) // 2
    band = 0
    while band < table.n_rows and not (band in numeric_rows and fill.get(band, 0) >= half):
        band += 1
    if band >= table.n_rows or band > _HEADER_BAND_MAX_ROWS:
        return min(1, table.n_rows)
    return band


def _rebuild(
    cells: Sequence[Cell],
    *,
    row_of: Callable[[int], int],
    col_of: Callable[[int], int],
    n_rows: int,
    n_cols: int,
    header_rows: tuple[int, ...],
) -> Table:
    """Renumber cells through two index maps and merge whatever lands on the
    same slot (text joined in x order, bbox union, confidence min)."""
    merged: dict[tuple[int, int], list[Cell]] = {}
    for cell in cells:
        r0, c0 = row_of(cell.row), col_of(cell.col)
        r1 = max(r0, row_of(cell.row + cell.row_span - 1))
        c1 = max(c0, col_of(cell.col + cell.col_span - 1))
        merged.setdefault((r0, c0), []).append(
            cell.model_copy(
                update={"row": r0, "col": c0, "row_span": r1 - r0 + 1, "col_span": c1 - c0 + 1}
            )
        )
    out: list[Cell] = []
    for _slot, members in sorted(merged.items()):
        members.sort(key=lambda c: (c.bbox[1], c.bbox[0]))
        texts = [m.text for m in members if m.text]
        out.append(
            members[0].model_copy(
                update={
                    "text": " ".join(texts),
                    "bbox": (
                        min(m.bbox[0] for m in members),
                        min(m.bbox[1] for m in members),
                        max(m.bbox[2] for m in members),
                        max(m.bbox[3] for m in members),
                    ),
                    "confidence": min(m.confidence for m in members),
                    "row_span": max(m.row_span for m in members),
                    "col_span": max(m.col_span for m in members),
                }
            )
        )
    # a span may not run past the grid after renumbering
    out = [
        c.model_copy(
            update={
                "row_span": max(1, min(c.row_span, n_rows - c.row)),
                "col_span": max(1, min(c.col_span, n_cols - c.col)),
            }
        )
        for c in out
    ]
    # slots covered by a span must not also hold a cell of their own
    covered: set[tuple[int, int]] = set()
    for c in sorted(out, key=lambda c: (c.row, c.col)):
        for dr in range(c.row_span):
            for dc in range(c.col_span):
                if (dr, dc) != (0, 0):
                    covered.add((c.row + dr, c.col + dc))
    out = [c for c in out if (c.row, c.col) not in covered]
    return Table(
        n_rows=max(1, n_rows),
        n_cols=max(1, n_cols),
        header_rows=tuple(h for h in header_rows if h < n_rows),
        cells=tuple(out),
    )


def _column_extent(table: Table, col: int, rows: Sequence[int] | None = None) -> BBox | None:
    boxes = [
        c.bbox
        for c in table.cells
        if c.col == col and c.text and c.col_span == 1 and (rows is None or c.row in rows)
    ]
    if not boxes:
        return None
    return (min(b[0] for b in boxes), 0.0, max(b[2] for b in boxes), 0.0)


def _x_overlap(a: BBox, b: BBox) -> float:
    return max(0.0, min(a[2], b[2]) - max(a[0], b[0]))


def _collapse_columns(table: Table, removed: Mapping[int, int]) -> Table:
    """Fold each column in ``removed`` into the target column it maps to."""
    if not removed:
        return table
    survivors = [c for c in range(table.n_cols) if c not in removed]
    new_index = {c: i for i, c in enumerate(survivors)}

    def col_of(col: int) -> int:
        seen: set[int] = set()
        while col in removed and col not in seen:
            seen.add(col)
            col = removed[col]
        return new_index.get(col, new_index[min(survivors, key=lambda s: abs(s - col))])

    return _rebuild(
        table.cells,
        row_of=lambda r: r,
        col_of=col_of,
        n_rows=table.n_rows,
        n_cols=len(survivors),
        header_rows=table.header_rows,
    )


RuleSegment = tuple[float, float, float]
"""A drawn horizontal rule: ``(x0, x1, y)`` in page pixels."""

RULE_KERNEL_PX = 24
"""Shortest horizontal run that counts as drawn: a rule over two narrow columns
is a fifth of the block wide, far under the block-crossing kernel
``analyze_ruling`` uses to pick a strategy."""

RULE_MIN_LEN_PX = 30
"""Dashes, em-rules in empty cells and underlines are shorter than this."""

RULE_MAX_THICKNESS_PX = 4


def rule_segments(
    gray: npt.NDArray[np.uint8],
    *,
    x_off: float = 0.0,
    y_off: float = 0.0,
    kernel_px: int = RULE_KERNEL_PX,
    min_len_px: int = RULE_MIN_LEN_PX,
    max_thickness_px: int = RULE_MAX_THICKNESS_PX,
) -> list[RuleSegment]:
    """Every drawn horizontal rule in a grayscale crop, as ``(x0, x1, y)`` in
    page pixels — the spanner rules of a header hierarchy included. Inverted
    adaptive threshold, a short horizontal opening, then one segment per
    connected component that is long and thin."""
    h, w = gray.shape[:2]
    if h < 4 or w < kernel_px:
        return []
    binv = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 15, 10
    )
    mask = cv2.morphologyEx(binv, cv2.MORPH_OPEN, np.ones((1, kernel_px), dtype=np.uint8))
    n, _labels, stats, _centroids = cv2.connectedComponentsWithStats(mask, connectivity=8)
    out: list[RuleSegment] = []
    for i in range(1, int(n)):
        x = int(stats[i, cv2.CC_STAT_LEFT])
        y = int(stats[i, cv2.CC_STAT_TOP])
        cw = int(stats[i, cv2.CC_STAT_WIDTH])
        ch = int(stats[i, cv2.CC_STAT_HEIGHT])
        if cw >= min_len_px and ch <= max_thickness_px:
            out.append((x_off + x, x_off + x + cw, y_off + y + ch / 2.0))
    return out


GROUP_GAP_FRAC = 0.35
"""A header cell whose text continues beneath it at more than this fraction of
the band's text height is not wrapping: a rule and its padding sit in that gap.
The lines of one wrapped label follow each other at leading, a few pixels
apart (measured at 150 DPI: about one pixel between lines, twelve across a
rule)."""

GROUP_CENTRE_TOL = 0.3
"""How far, in mean column widths, a group label's centre may sit from the
centre of the columns it is taken to span. An even span puts the label over a
column boundary, a full half-column from either neighbour's centre, so the
tolerance stays under a half: a range one column wider on one side is never
taken for the label's."""


def _union(boxes: Sequence[BBox]) -> BBox:
    return (
        min(b[0] for b in boxes),
        min(b[1] for b in boxes),
        max(b[2] for b in boxes),
        max(b[3] for b in boxes),
    )


def _centre(box: BBox) -> tuple[float, float]:
    return ((box[0] + box[2]) / 2.0, (box[1] + box[3]) / 2.0)


def _inside(point: tuple[float, float], box: BBox) -> bool:
    return box[0] <= point[0] < box[2] and box[1] <= point[1] < box[3]


def _text_extents(cells: Sequence[Cell], units: Sequence[TextUnit]) -> dict[tuple[int, int], BBox]:
    """The text extent of each cell: the union of the units whose centre falls
    inside its slot, or the slot itself when nothing does (a caller without
    geometry)."""
    out: dict[tuple[int, int], BBox] = {}
    for cell in cells:
        inside = [u.bbox for u in units if _inside(_centre(u.bbox), cell.bbox)]
        out[(cell.row, cell.col)] = _union(inside) if inside else cell.bbox
    return out


def _slot_columns(table: Table) -> list[tuple[float, float]]:
    """The x-range of every column slot, from the cells that occupy exactly it."""
    out: list[tuple[float, float]] = []
    for c in range(table.n_cols):
        own = [cell.bbox for cell in table.cells if cell.col == c and cell.col_span == 1]
        if not own:
            own = [cell.bbox for cell in table.cells if cell.col <= c < cell.col + cell.col_span]
        out.append((min(b[0] for b in own), max(b[2] for b in own)) if own else (0.0, 0.0))
    return out


def _slot_rows(table: Table) -> list[tuple[float, float]]:
    """The y-range of every row slot."""
    out: list[tuple[float, float]] = []
    for r in range(table.n_rows):
        own = [cell.bbox for cell in table.cells if cell.row == r and cell.row_span == 1]
        if not own:
            own = [cell.bbox for cell in table.cells if cell.row <= r < cell.row + cell.row_span]
        out.append((min(b[1] for b in own), max(b[3] for b in own)) if own else (0.0, 0.0))
    return out


def _fold_empty_columns(table: Table) -> Table:
    """An anchor whose cells collect nothing at assembly is not a column."""
    filled_cols = {c.col for c in table.cells if c.text and c.col_span == 1}
    spanned_starts = {c.col for c in table.cells if c.text and c.col_span > 1}
    empty = [c for c in range(table.n_cols) if c not in filled_cols and c not in spanned_starts]
    if empty and len(empty) < table.n_cols:
        target = {c: (c + 1 if c + 1 < table.n_cols else c - 1) for c in empty}
        table = _collapse_columns(table, target)
    return table


def _fold_header_only_columns(table: Table) -> Table:
    """A column with header text and no body cell at all is a label's wrap:
    fold it into the neighbour its text overlaps most."""
    band = _header_band(table)
    body_rows = range(band, table.n_rows)
    body_fill: dict[int, int] = {}
    for c in table.cells:
        if c.text and c.row >= band:
            body_fill[c.col] = body_fill.get(c.col, 0) + 1
    sparse = [
        c
        for c in range(table.n_cols)
        if body_fill.get(c, 0) == 0
        and any(cell.text for cell in table.cells if cell.col == c and cell.row < band)
    ]
    if not sparse or len(sparse) >= table.n_cols:
        return table
    target: dict[int, int] = {}
    for c in sparse:
        head = _column_extent(table, c, rows=range(band))
        best, best_overlap = None, -1.0
        for neighbour in (c - 1, c + 1):
            if 0 <= neighbour < table.n_cols and neighbour not in sparse:
                ext = _column_extent(table, neighbour, rows=body_rows) or _column_extent(
                    table, neighbour
                )
                overlap = _x_overlap(head, ext) if head and ext else 0.0
                if overlap > best_overlap or (overlap == best_overlap and neighbour > c):
                    best, best_overlap = neighbour, overlap
        if best is not None:
            target[c] = best
    return _collapse_columns(table, target) if target else table


def _restructure_header(
    table: Table, units: Sequence[TextUnit], h_rules: Sequence[RuleSegment] = ()
) -> Table:
    """Resolve the header band into the rows the truth has (phase 24 §7).

    The band is the rows before the first body row, ending at its fullest row:
    column labels are set bottom-aligned, so the last line of every label
    shares that row and anything after it (``Actual`` alone in the stub
    column) is a section row of the body. Walking the band top-down, a row is
    a **group row** while it holds something structural — a label spanning
    two or more columns, or a one-column label with a rule's gap between it
    and the text beneath; the rows below the last group row are the wrapped
    lines of the column labels and merge into one. A group label spans the
    columns the rule drawn under it crosses (``h_rules``); with no rule, the
    narrowest run of columns whose text is centred under it. A column label
    lands under the deepest group that covers it — row 0 when none does — and
    spans down to the label row, so ``Year`` beside a two-row hierarchy is one
    cell two rows tall wherever its text was set.

    Without geometry (no ``units`` and no ``h_rules``) nothing can be told
    apart, and the whole band is taken as wrapped labels.
    """
    first_body = _header_band(table)
    if first_body < 2:
        return table
    fill = _row_fill(table)
    fullest = max(fill.get(r, 0) for r in range(first_body))
    end = max(r for r in range(first_body) if fill.get(r, 0) == fullest) + 1
    if end < 2:
        return table
    band = [c for c in table.cells if c.row < end and c.text]
    if not band:
        return table
    ext = _text_extents(band, units)
    text_h = _median([ext[k][3] - ext[k][1] for k in ext], 10.0)
    gap_tol = GROUP_GAP_FRAC * text_h
    col_x = _slot_columns(table)
    row_y = _slot_rows(table)
    n_cols = table.n_cols

    # What sits under a group label: the text below the band, per column.
    body_ext: dict[int, BBox] = {}
    body_top = row_y[end][0]
    body_units = [u for u in units if _centre(u.bbox)[1] >= body_top]
    if body_units:
        for u in body_units:
            cx = _centre(u.bbox)[0]
            for c, (x0, x1) in enumerate(col_x):
                if x0 <= cx < x1:
                    body_ext[c] = _union([body_ext[c], u.bbox]) if c in body_ext else u.bbox
                    break
    else:
        for cell in table.cells:
            if cell.row >= end and cell.text and cell.col_span == 1:
                c = cell.col
                body_ext[c] = _union([body_ext[c], cell.bbox]) if c in body_ext else cell.bbox

    def covers(cell: Cell, c: int) -> bool:
        return cell.col <= c < cell.col + cell.col_span

    def text_below(row: int, c: int) -> list[BBox]:
        return [ext[(o.row, o.col)] for o in band if o.row > row and covers(o, c)]

    def column_extent(c: int, row: int) -> BBox:
        boxes = [
            ext[(o.row, o.col)] for o in band if o.row > row and o.col == c and o.col_span == 1
        ]
        if c in body_ext:
            boxes.append(body_ext[c])
        return _union(boxes) if boxes else (col_x[c][0], 0.0, col_x[c][1], 0.0)

    def rules_under(extent: BBox, next_top: float) -> list[RuleSegment]:
        """Rules drawn between a cell's text and the text beneath it, crossing
        the cell's x-range."""
        return [
            s
            for s in h_rules
            if extent[3] <= s[2] <= next_top and s[0] <= extent[2] and s[1] >= extent[0]
        ]

    heads: dict[int, int] = {}
    """column -> group row where its wrapped label starts"""
    labels: dict[int, int] = {}
    """column -> group row of a label with nothing beneath it in the band"""
    spanners: dict[tuple[int, int], tuple[int, int]] = {}
    """(row, col) -> the columns a group label spans"""
    singles: set[tuple[int, int]] = set()
    """one-column group labels, kept where they are"""

    def spanner_range(
        key: tuple[int, int],
        home: tuple[int, int],
        extent: BBox,
        row: int,
        homes: Mapping[tuple[int, int], tuple[int, int]],
        rules: Sequence[RuleSegment],
    ) -> tuple[int, int] | None:
        lo, hi = home

        def eligible(c: int) -> bool:
            if c in heads or c in labels:
                return False
            if any(h_lo <= c <= h_hi for k, (h_lo, h_hi) in homes.items() if k != key):
                return False
            return bool(text_below(row, c))

        left, right = 0, n_cols - 1
        for a, d in spanners.values():
            if a <= lo and hi <= d:
                left, right = max(left, a), min(right, d)
        a_min = lo
        while a_min - 1 >= left and eligible(a_min - 1):
            a_min -= 1
        d_max = hi
        while d_max + 1 <= right and eligible(d_max + 1):
            d_max += 1
        cx = (extent[0] + extent[2]) / 2.0
        # The rule drawn under the label is the page's own statement of the
        # span: the columns whose text it crosses. A rule across every column
        # is a division of the table, not a group, and says nothing here.
        under = [s for s in rules if s[0] <= cx <= s[1]]
        if under:
            nearest = min(under, key=lambda s: s[2])
            a, d = lo, hi
            while (
                a - 1 >= a_min and nearest[0] <= _centre(column_extent(a - 1, row))[0] <= nearest[1]
            ):
                a -= 1
            while (
                d + 1 <= d_max and nearest[0] <= _centre(column_extent(d + 1, row))[0] <= nearest[1]
            ):
                d += 1
            if not (a == 0 and d == n_cols - 1):
                return (a, d) if d - a >= 1 else None
        best: tuple[int, float, int, int] | None = None
        for a in range(a_min, lo + 1):
            for d in range(hi, d_max + 1):
                width = d - a + 1
                if width < 2:
                    continue
                xs = [column_extent(c, row) for c in range(a, d + 1)]
                x0, x1 = min(b[0] for b in xs), max(b[2] for b in xs)
                tol = GROUP_CENTRE_TOL * (x1 - x0) / width
                off = abs(cx - (x0 + x1) / 2.0)
                if off > tol or extent[0] < x0 - tol or extent[2] > x1 + tol:
                    continue
                candidate = (-width, -off, a, d)
                if best is None or candidate > best:
                    best = candidate
        if best is not None:
            return (best[2], best[3])
        # The reconstruction's own straddle: text that physically reaches into
        # the next column is a span the page shows, kept when nothing decides
        # otherwise.
        return (lo, hi) if hi > lo else None

    g = 0
    if units or h_rules:
        while g < end - 1:
            row_cells = sorted((c for c in band if c.row == g), key=lambda c: c.col)
            homes = {(c.row, c.col): (c.col, c.col + c.col_span - 1) for c in row_cells}
            pending: dict[tuple[int, int], tuple[str, tuple[int, int] | None]] = {}
            structural = False
            for cell in row_cells:
                key = (cell.row, cell.col)
                if cell.col in heads:
                    continue  # a further line of a label that started above
                lo, hi = homes[key]
                extent = ext[key]
                below = [b for c in range(lo, hi + 1) for b in text_below(g, c)]
                rules: list[RuleSegment] = []
                if below:
                    next_top = min(b[1] for b in below)
                    rules = rules_under(extent, next_top)
                    if next_top - extent[3] <= gap_tol and not rules:
                        pending[key] = ("head", None)
                        continue
                span = spanner_range(key, (lo, hi), extent, g, homes, rules)
                if span is not None:
                    pending[key] = ("span", span)
                    structural = True
                elif not below:
                    pending[key] = ("label", None)
                else:
                    pending[key] = ("single", None)
                    structural = True
            if not structural:
                break
            for key, (kind, span) in pending.items():
                if kind == "head":
                    heads[key[1]] = g
                elif kind == "label":
                    labels[key[1]] = g
                elif kind == "span" and span is not None:
                    spanners[key] = span
                else:
                    singles.add(key)
            g += 1

    n_header = g + 1
    shift = end - n_header
    new_row_y = [row_y[r] for r in range(g)] + [(row_y[g][0], row_y[end - 1][1])]
    by_key = {(c.row, c.col): c for c in table.cells}
    origin_default = table.cells[0].origin
    out: list[Cell] = []
    taken: set[tuple[int, int]] = set()

    def emit(row: int, col: int, row_span: int, col_span: int, members: Sequence[Cell]) -> None:
        texts = [m.text for m in members if m.text]
        out.append(
            Cell(
                row=row,
                col=col,
                row_span=row_span,
                col_span=col_span,
                bbox=(
                    col_x[col][0],
                    new_row_y[row][0],
                    col_x[col + col_span - 1][1],
                    new_row_y[row + row_span - 1][1],
                ),
                text=" ".join(texts),
                confidence=min((m.confidence for m in members), default=1.0),
                origin=members[0].origin if members else origin_default,
            )
        )
        for dr in range(row_span):
            for dc in range(col_span):
                taken.add((row + dr, col + dc))

    for (r, c), (a, d) in spanners.items():
        emit(r, a, 1, d - a + 1, [by_key[(r, c)]])
    for r, c in sorted(singles):
        emit(r, c, 1, 1, [by_key[(r, c)]])

    row_text_y: dict[int, tuple[float, float]] = {}
    for cell in band:
        top, bottom = ext[(cell.row, cell.col)][1], ext[(cell.row, cell.col)][3]
        seen = row_text_y.get(cell.row)
        row_text_y[cell.row] = (min(seen[0], top), max(seen[1], bottom)) if seen else (top, bottom)
    col_mid = [(x0 + x1) / 2.0 for x0, x1 in _column_text_x(table, units)]

    def label_row(c: int, at: int) -> int:
        """Where a column's label lands: under the deepest group label or
        one-column group above it — row 0 when nothing is over it, however
        far down its own text sits (the truth's convention) — but never above
        a rule drawn across its column: a line between two rows of a ruled
        header is two cells, the upper one empty."""
        above = [r for (r, _c0), (a, d) in spanners.items() if a <= c <= d and r < at]
        above += [r for (r, c0) in singles if c0 == c and r < at]
        row = max(above, default=-1) + 1
        for r in range(row, at):
            if r not in row_text_y or r + 1 not in row_text_y:
                continue
            lo, hi = row_text_y[r][1], row_text_y[r + 1][0]
            if any(lo <= s[2] <= hi and s[0] <= col_mid[c] <= s[1] for s in h_rules):
                row = r + 1
        return row

    for c, r in labels.items():
        row = label_row(c, r)
        emit(row, c, n_header - row, 1, [by_key[(r, c)]])
    for c in range(n_cols):
        if c in labels:
            continue
        members = [cell for cell in band if cell.col == c and cell.row >= g]
        if c in heads:
            members += [cell for cell in band if cell.col == c and heads[c] <= cell.row < g]
        if not members:
            continue
        row = label_row(c, heads.get(c, g))
        emit(row, c, n_header - row, 1, sorted(members, key=lambda m: (m.row, m.col)))
    for r in range(n_header):
        for c in range(n_cols):
            if (r, c) not in taken:
                emit(r, c, 1, 1, [])
    for cell in table.cells:
        if cell.row >= end:
            out.append(cell.model_copy(update={"row": cell.row - shift}))
    return Table(
        n_rows=table.n_rows - shift,
        n_cols=n_cols,
        header_rows=tuple(range(n_header)),
        cells=tuple(out),
    )


@dataclass(frozen=True)
class Refinement:
    """A refined borderless table, and the rows that were never the table's:
    caption lines the block carried above the header, as page boxes for the
    caller to re-home."""

    table: Table
    captions: tuple[BBox, ...]


def _column_text_x(table: Table, units: Sequence[TextUnit]) -> list[tuple[float, float]]:
    """The x-range of the text in every column slot (the slot itself when no
    unit falls in it)."""
    slots = _slot_columns(table)
    out: list[tuple[float, float]] = []
    for x0, x1 in slots:
        xs = [u.bbox for u in units if x0 <= _centre(u.bbox)[0] < x1]
        out.append((min(b[0] for b in xs), max(b[2] for b in xs)) if xs else (x0, x1))
    return out


def _peel_captions(
    table: Table, units: Sequence[TextUnit], h_rules: Sequence[RuleSegment]
) -> tuple[Table, tuple[BBox, ...]]:
    """A title line inside the block is the table's caption, not its first row:
    the truth never counts it (measured on the ICDAR 2013 stratum: ``(Numbers
    in thousands)``, ``Vital Statistics``, the last line of a wrapped title).
    A top row with one cell is a caption when it is set like a title (centred
    on the table, flush with its left edge, or across most of its width) and
    the table's own top rule — one drawn across every column — lies between
    it and the text beneath, or when the cell sits in the stub column set off
    from the stub's label by a rule or a rule's gap. Peeled a row at a time
    while that is what the top row is. Needs geometry: without it a stub label
    on a line of its own cannot be told from a caption."""
    if not units and not h_rules:
        return table, ()
    first_body = _header_band(table)
    if first_body < 2:
        return table, ()
    band = [c for c in table.cells if c.row < first_body and c.text]
    if not band:
        return table, ()
    ext = _text_extents(band, units)
    gap_tol = GROUP_GAP_FRAC * _median([ext[k][3] - ext[k][1] for k in ext], 10.0)
    stub = min(c.col for c in table.cells if c.text)
    text_x = _column_text_x(table, units)
    first_mid = (text_x[0][0] + text_x[0][1]) / 2.0
    last_mid = (text_x[-1][0] + text_x[-1][1]) / 2.0
    table_x0, table_x1 = min(x for x, _ in text_x), max(x for _, x in text_x)
    table_w = max(table_x1 - table_x0, 1.0)
    row_y = _slot_rows(table)

    def row_extent(k: int, fallback: BBox) -> BBox:
        boxes = [u.bbox for u in units if row_y[k][0] <= _centre(u.bbox)[1] < row_y[k][1]]
        return _union(boxes) if boxes else fallback

    def title_like(k: int, fallback: BBox) -> bool:
        """Set like a title: centred on the table, flush with its left edge, or
        across most of its width. A group label over some of the columns is
        none of these, even under a rule drawn across the whole grid."""
        x0, _y0, x1, _y1 = row_extent(k, fallback)
        centred = abs((x0 + x1) / 2.0 - (table_x0 + table_x1) / 2.0) <= 0.1 * table_w
        flush = x0 - table_x0 <= 0.05 * table_w
        return centred or flush or (x1 - x0) >= 0.5 * table_w

    k = 0
    while k < first_body - 1:
        row_cells = [c for c in band if c.row == k]
        if len(row_cells) != 1:
            break
        cell = row_cells[0]
        extent = ext[(k, cell.col)]
        below = [
            ext[(o.row, o.col)]
            for o in band
            if o.row > k and o.col < cell.col + cell.col_span and cell.col < o.col + o.col_span
        ]
        if not below:
            break
        next_top = min(b[1] for b in below)
        between = [s for s in h_rules if extent[3] <= s[2] <= next_top]
        table_rule = any(s[0] <= first_mid <= s[1] and s[0] <= last_mid <= s[1] for s in between)
        crossing = any(s[0] <= extent[2] and s[1] >= extent[0] for s in between)
        set_off = next_top - extent[3] > gap_tol or crossing
        if not (table_rule and title_like(k, extent)) and not (cell.col == stub and set_off):
            break
        k += 1
    if k == 0:
        return table, ()
    col_x = _slot_columns(table)
    boxes = tuple((col_x[0][0], row_y[r][0], col_x[-1][1], row_y[r][1]) for r in range(k))
    cells = tuple(c.model_copy(update={"row": c.row - k}) for c in table.cells if c.row >= k)
    return (
        Table(n_rows=table.n_rows - k, n_cols=table.n_cols, header_rows=(0,), cells=cells),
        boxes,
    )


def refine_borderless(
    table: Table, units: Sequence[TextUnit] = (), h_rules: Sequence[RuleSegment] = ()
) -> Refinement:
    """:func:`refine_borderless_table` with the caption rows it peeled off
    (phase 24 §7), for a caller that can give them a block of their own."""
    if table.n_rows < 2 or table.n_cols < 2:
        return Refinement(table, ())
    table = _fold_empty_columns(table)
    table = _fold_header_only_columns(table)
    table, captions = _peel_captions(table, units, h_rules)
    return Refinement(_restructure_header(table, units, h_rules), captions)


def refine_borderless_table(
    table: Table, units: Sequence[TextUnit] = (), h_rules: Sequence[RuleSegment] = ()
) -> Table:
    """What alignment alone gets wrong on real tables, fixed from the grid's
    own shape and the text geometry behind it (phase 24, measured on the
    ICDAR 2013 stratum).

    1. **An empty column is not a column.** A ragged left edge — an indented
       stub, a differently-aligned header — seeds an anchor whose cells then
       collect nothing at assembly; the empty column shifts every real one by
       one and every cell of the table scores as misplaced (58 rows by 11 on a
       state-by-year table). Such columns fold into their neighbour.
    2. **A column only the header fills is that header's wrap.** Labels sit
       left- or centre-aligned over right-aligned numbers, so their ragged edges
       seed columns the body never uses; a column with *no* body cell at all
       folds into the neighbour its text overlaps most. A column the body fills
       even once — a flag column, a footnote marker — is a column.
    3. **The header band is a hierarchy, not a stack of rows.** Column labels
       wrap onto several lines and are set bottom-aligned, so the band's rows
       are the lines of the labels, not rows of the table — the truth has one
       row of labels. Above them may sit *group* rows (``Race/ethnicity``
       centred over six columns, ``2007`` over four, a rule beneath) which the
       truth keeps as rows of their own, each label spanning its columns. The
       two are told apart by ``units``: the lines of one label follow at
       leading, a group label is set off from the text beneath it by the rule
       and its padding (``GROUP_GAP_FRAC``), or by a drawn rule (``h_rules``).
       A group label spans the columns its rule crosses — with no rule, the
       narrowest run of columns whose text is centred under it
       (``GROUP_CENTRE_TOL``); a label with no group over it spans the header
       rows; wrapped lines join top-down.
       Without geometry the band is taken as wrapped labels and merged.
    4. **A title line is not a row.** One cell in the stub column, set off from
       the stub's label by a rule or a rule's gap, is the caption the block
       swallowed; it is peeled off (:func:`refine_borderless` says where it was).

    Applied to borderless reconstructions only: a ruled grid's columns are
    drawn, and an empty ruled column is a claim the page makes.
    """
    return refine_borderless(table, units, h_rules).table


def retype_digital_tables(
    blocks: Sequence[Block],
    *,
    page_width: float,
    page_height: float,
    min_rows: int = 3,
    min_cols: int = 3,
    min_grid_coverage: float = 0.8,
    strong_col_frac: float = 0.6,
    max_col_mean_chars: float = 40.0,
    max_leader_frac: float = 0.25,
    wide_min_cols: int = 4,
    page: PageImage | None = None,
) -> tuple[list[Block], int]:
    """Digital-path reuse (ADR 0001 §2, phase 11 §4.6): run the borderless
    reconstruction over each paragraph block's positioned-item boxes and
    re-type the block ``table`` when a real grid emerges.

    The span units, the reconstruction and the cell assembly are exactly the
    OCR path's code — only the unit source differs. Conservative by
    construction (no layout model vouches for these regions, and a plausible
    false table is the worst failure in this domain): at least ``min_rows``
    rows, full-coverage assignment, at least ``min_cols`` **strong**
    columns — columns non-empty in ≥ ``strong_col_frac`` of the rows — and no
    column whose non-empty cells average more than ``max_col_mean_chars``
    characters. A kv block is two columns and must stay kv; the phase-06
    cross-column line-merge artifact (two independent text flows sharing
    y-bands) aligns into well-supported columns, but one of them is a wrapped
    *text flow* — its cells are sentence fragments several times longer than
    any real table cell (measured on the 2-col fixture: 57 vs ≤ 14 mean chars)
    — and the length gate rejects it. A contents page aligns just as well —
    number, title, a run of leader dots, page number — and every dot becomes a
    column of its own; the leader gate (``max_leader_frac``) rejects a grid
    whose filled cells are mostly dots. The length gate is for *narrow* grids
    only (fewer than ``wide_min_cols`` strong columns): a wide table's stub
    column — "Student and institutional characteristics" — averages well over
    40 characters and is a column, not a text flow (measured on the ICDAR 2013
    stratum: two 30-row tables at full coverage were thrown away for it).
    A block the layout model vouched for (a ``table`` with its cells pending,
    ADR 0017) is judged only on having a grid at all: two rows, two columns,
    coverage, no leader dots. Measured on the ICDAR 2013 stratum (phase 24),
    the prose gates rejected 20 of 64 vouched tables — sparse numeric columns
    below the strong-column floor, genuine two-column tables, descriptive text
    columns — every one of them a real table. ``page`` — the page's own raster —
    lets the refinement read the rules drawn under group labels (phase 24 §7).
    Returns ``(blocks, n_retyped)``.
    """
    out: list[Block] = []
    n_retyped = 0
    for block in blocks:
        # Two kinds of block reach the reconstruction. A *paragraph* is a region
        # nothing vouched for, and the gates below are what keep a plausible false
        # table out of the IR. A *table with no cells* is the opposite case: a
        # layout model already said "this region is a table" and left the cell
        # structure pending (phase 19 — before layout ran on this route, such a
        # region arrived here as a paragraph and was reconstructed). Skipping it
        # would deliver a table block that knows it is a table and cannot say what
        # is in it, which is a regression against the pre-layout digital path.
        vouched = block.type is BlockType.table and (block.table is None or not block.table.cells)
        if not block.lines or (block.type is not BlockType.paragraph and not vouched):
            out.append(block)
            continue
        units = units_from_spans(block.lines)
        grid = borderless_cells(units, block.bbox)
        if not grid:
            out.append(block)
            continue
        table, coverage = assemble_table(
            grid,
            units,
            origin_default=block.origin,
            page_width=page_width,
            page_height=page_height,
        )
        if vouched:
            # Layout vouched for the region: the gates that keep a plausible
            # false grid out of prose have nothing to guard here, and they
            # threw away a fifth of the ICDAR 2013 tables — sparse columns,
            # two-column tables, descriptive text columns. What still must
            # hold: a grid at all, and its units actually assigned.
            rejected = (
                table.n_rows < 2
                or table.n_cols < 2
                or coverage < min_grid_coverage
                or leader_cell_fraction(table) > max_leader_frac
            )
        else:
            rejected = (
                table.n_rows < min_rows
                or table.n_cols < min_cols
                or coverage < min_grid_coverage
                or _strong_columns(table, strong_col_frac) < min_cols
                or (
                    _strong_columns(table, strong_col_frac) < wide_min_cols
                    and _max_col_mean_chars(table) > max_col_mean_chars
                )
                or leader_cell_fraction(table) > max_leader_frac
            )
        if rejected:
            if vouched and block.lines:
                # Layout said "table" and the grid could not be rebuilt: the
                # honest state is the failed flag with the lines kept (ADR
                # 0005) — not a placeholder grid that scores as a table with
                # nothing in it.
                out.append(block.model_copy(update={"table_failed": True}))
            else:
                out.append(block)
            continue
        rules: list[RuleSegment] = []
        if page is not None:
            rules = rule_segments(
                _crop_gray(page, block.bbox),
                x_off=max(0.0, float(np.floor(block.bbox[0]))),
                y_off=max(0.0, float(np.floor(block.bbox[1]))),
            )
        refined = refine_borderless(table, units, h_rules=rules)
        if refined.captions:
            # The block swallowed the table's title: it goes back out as the
            # paragraph it is, above the table, and the table keeps the rest.
            caption = [
                ln
                for ln in block.lines
                if any(_centre_inside(ln.bbox, box) for box in refined.captions)
            ]
            rest = [ln for ln in block.lines if not any(ln is c for c in caption)]
            if caption and rest:
                out.append(
                    block.model_copy(
                        update={
                            "block_id": f"{block.block_id}c",
                            "type": BlockType.paragraph,
                            "table": None,
                            "table_failed": False,
                            "lines": tuple(caption),
                            "bbox": _lines_bbox(caption),
                            "confidence": sum(ln.confidence for ln in caption) / len(caption),
                        }
                    )
                )
                block = block.model_copy(update={"lines": tuple(rest), "bbox": _lines_bbox(rest)})
        out.append(block.model_copy(update={"type": BlockType.table, "table": refined.table}))
        n_retyped += 1
    return out, n_retyped


RULE_TOUCH_TOL = 6.0
"""How far apart two ruling segments may sit and still count as meeting. Drawn
grids rarely close exactly — a corner is often a pixel or two short — and a
lattice that falls apart at its corners is not a lattice."""

LATTICE_MIN_RULES = 2
"""Rules per axis a component needs before it is a grid: two horizontals and two
verticals bound one cell. Below that it is a box, an underline or a bracket."""


def lattice_regions(
    rules: Sequence[BBox],
    *,
    touch_tol: float = RULE_TOUCH_TOL,
    min_rules: int = LATTICE_MIN_RULES,
) -> list[BBox]:
    """Group drawn rules into the table regions their intersections describe.

    A ruled table announces itself: its horizontal and vertical strokes cross.
    Grouping the page's rules by "do these two touch" and keeping the components
    that hold rules on both axes finds every ruled grid on the page, in page
    coordinates, before a single character is looked at — which is what the
    digital route was missing.

    It was missing it because its only table strategy was the borderless one,
    run per text block: column positions clustered from where the text happens
    to sit. On a fully ruled rate table that is guessing from shadows while the
    grid itself is drawn on the page. Measured on a 19-page insurance brochure:
    the borderless pass recovered 3 of 6 rows of the premium table and typed the
    other 3 as prose, and missed the eligibility table entirely; the drawn
    lattice gives both exactly, spans included.

    Regions come out sorted top-to-bottom and never nested — a component's box
    is the union of its rules, so an outer border and its interior rules are one
    region, not two.
    """
    horizontals = [b for b in rules if (b[2] - b[0]) >= (b[3] - b[1])]
    verticals = [b for b in rules if (b[2] - b[0]) < (b[3] - b[1])]
    if len(horizontals) < min_rules or len(verticals) < min_rules:
        return []
    boxes = horizontals + verticals
    axis = [0] * len(horizontals) + [1] * len(verticals)
    parent = list(range(len(boxes)))

    def find(i: int) -> int:
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i in range(len(horizontals)):
        for j in range(len(horizontals), len(boxes)):
            if _boxes_touch(boxes[i], boxes[j], touch_tol):
                parent[find(i)] = find(j)

    groups: dict[int, list[int]] = {}
    for idx in range(len(boxes)):
        groups.setdefault(find(idx), []).append(idx)

    regions: list[BBox] = []
    for members in groups.values():
        n_h = sum(1 for i in members if axis[i] == 0)
        n_v = len(members) - n_h
        if n_h < min_rules or n_v < min_rules:
            continue
        regions.append(
            (
                min(boxes[i][0] for i in members),
                min(boxes[i][1] for i in members),
                max(boxes[i][2] for i in members),
                max(boxes[i][3] for i in members),
            )
        )
    regions.sort(key=lambda r: (r[1], r[0]))
    return regions


def _boxes_touch(a: BBox, b: BBox, tol: float) -> bool:
    return a[0] - tol <= b[2] and b[0] - tol <= a[2] and a[1] - tol <= b[3] and b[1] - tol <= a[3]


def lattice_tables(
    page: PageImage,
    blocks: Sequence[Block],
    regions: Sequence[BBox],
    *,
    page_width: float,
    page_height: float,
    page_no: int,
    min_grid_coverage: float = 0.8,
    kernel_frac: float = 0.08,
    rule_min_len_frac: float = 0.45,
    edge_min_frac: float = 0.5,
) -> tuple[list[Block], list[BBox]]:
    """Rebuild each ruled ``region`` as a table block, from the drawn grid.

    The region crop goes through exactly the OCR route's ruled strategy —
    :func:`analyze_ruling` → :func:`lattice_cells` → :func:`assemble_table` —
    with the digital route's own units (positioned spans, ADR 0001 §2). One code
    path, two unit sources, as everywhere else in this module.

    Lines inside a region leave the blocks that held them and become the table
    block's lines; a block emptied that way disappears, and a block that keeps
    some lines is re-boxed around what is left, because a block's bbox is a
    claim about where its content sits and must not outlive the content. A
    region whose reconstruction does not cover ``min_grid_coverage`` of its own
    units is abandoned untouched: no grid at all beats a grid that drops text
    (hard rule 12).

    Returns the new block list and the regions that actually became tables — the
    caller needs those to drop the rules it found there, since a table's grid is
    modelled by the table and emitting it a second time as page rules counts the
    same ink twice (ADR 0011).
    """
    if not regions:
        return list(blocks), []
    remaining = list(blocks)
    tables: list[Block] = []
    used: list[BBox] = []
    for idx, region in enumerate(regions):
        inside = [
            line
            for block in remaining
            if block.type is not BlockType.table
            for line in (block.lines or ())
            if _centre_inside(line.bbox, region)
        ]
        if not inside:
            continue
        table = _lattice_table_for(
            page,
            region,
            inside,
            page_width=page_width,
            page_height=page_height,
            min_grid_coverage=min_grid_coverage,
            kernel_frac=kernel_frac,
            rule_min_len_frac=rule_min_len_frac,
            edge_min_frac=edge_min_frac,
        )
        if table is None:
            continue
        ordered = sorted(inside, key=lambda ln: (ln.bbox[1], ln.bbox[0]))
        tables.append(
            Block(
                block_id=f"p{page_no}_t{idx}",
                type=BlockType.table,
                bbox=_clamp_bbox(region, page_width, page_height),
                reading_order=0,  # reassigned over the merged set below
                origin=ordered[0].origin,
                confidence=min(ln.confidence for ln in ordered),
                lines=tuple(ordered),
                table=table,
            )
        )
        used.append(region)
        consumed = {id(line) for line in inside}
        remaining = [b for b in (_without_lines(b, consumed) for b in remaining) if b is not None]
    if not tables:
        return list(blocks), []
    merged = sorted([*remaining, *tables], key=lambda b: (round(b.bbox[1]), round(b.bbox[0])))
    return [b.model_copy(update={"reading_order": i}) for i, b in enumerate(merged)], used


def _lattice_table_for(
    page: PageImage,
    region: BBox,
    lines: Sequence[Line],
    *,
    page_width: float,
    page_height: float,
    min_grid_coverage: float,
    kernel_frac: float,
    rule_min_len_frac: float,
    edge_min_frac: float,
) -> Table | None:
    x0 = max(0.0, float(np.floor(region[0])))
    y0 = max(0.0, float(np.floor(region[1])))
    crop = _crop_gray(page, region)
    if crop.shape[0] < 8 or crop.shape[1] < 8:
        return None
    ruling = analyze_ruling(crop, kernel_frac=kernel_frac, rule_min_len_frac=rule_min_len_frac)
    grid = lattice_cells(
        ruling.h_rules, ruling.v_rules, ruling.h_mask, ruling.v_mask, edge_min_frac=edge_min_frac
    )
    if not grid:
        return None
    grid = [
        GridCell(
            row=g.row,
            col=g.col,
            row_span=g.row_span,
            col_span=g.col_span,
            bbox=(g.bbox[0] + x0, g.bbox[1] + y0, g.bbox[2] + x0, g.bbox[3] + y0),
        )
        for g in grid
    ]
    units = units_from_spans(lines)
    table, coverage = assemble_table(
        grid,
        units,
        origin_default=lines[0].origin,
        page_width=page_width,
        page_height=page_height,
    )
    if coverage < min_grid_coverage or table.n_rows < 2 or table.n_cols < 2:
        return None
    return table


def _centre_inside(bbox: BBox, region: BBox) -> bool:
    cx = (bbox[0] + bbox[2]) / 2.0
    cy = (bbox[1] + bbox[3]) / 2.0
    return region[0] <= cx <= region[2] and region[1] <= cy <= region[3]


def _lines_bbox(lines: Sequence[Line]) -> BBox:
    return (
        min(ln.bbox[0] for ln in lines),
        min(ln.bbox[1] for ln in lines),
        max(ln.bbox[2] for ln in lines),
        max(ln.bbox[3] for ln in lines),
    )


def _without_lines(block: Block, consumed: set[int]) -> Block | None:
    """``block`` minus the lines a table took, re-boxed — or ``None`` if empty."""
    if not block.lines:
        return block
    kept = [line for line in block.lines if id(line) not in consumed]
    if len(kept) == len(block.lines):
        return block
    if not kept:
        return None
    return block.model_copy(
        update={
            "lines": tuple(kept),
            "bbox": (
                min(ln.bbox[0] for ln in kept),
                min(ln.bbox[1] for ln in kept),
                max(ln.bbox[2] for ln in kept),
                max(ln.bbox[3] for ln in kept),
            ),
        }
    )


def _crop_gray(page: PageImage, bbox: BBox) -> npt.NDArray[np.uint8]:
    x0 = int(max(0, np.floor(bbox[0])))
    y0 = int(max(0, np.floor(bbox[1])))
    x1 = int(min(page.width, np.ceil(bbox[2])))
    y1 = int(min(page.height, np.ceil(bbox[3])))
    crop = page.pixels[y0:y1, x0:x1]
    if crop.ndim == 3:
        crop = cv2.cvtColor(crop, cv2.COLOR_RGB2GRAY)
    return crop.astype(np.uint8, copy=False)


# -- the primary engine ----------------------------------------------------------


@register("table", "geometric")
class GeometricTableEngine:
    """Ruled/borderless geometric reconstruction (plan §7 row "3 table")."""

    version = GEOMETRIC_VERSION

    def __init__(
        self,
        min_grid_coverage: float = 0.8,
        kernel_frac: float = 0.08,
        rule_min_len_frac: float = 0.45,
        edge_min_frac: float = 0.5,
        min_rules: int = 3,
        col_tol_frac: float = 0.015,
        col_min_support: int = 2,
        straddle_frac: float = 0.3,
        min_ioa: float = 0.25,
        max_leader_frac: float = 0.25,
    ) -> None:
        self.min_grid_coverage = min_grid_coverage
        self.kernel_frac = kernel_frac
        self.rule_min_len_frac = rule_min_len_frac
        self.edge_min_frac = edge_min_frac
        self.min_rules = min_rules
        self.col_tol_frac = col_tol_frac
        self.col_min_support = col_min_support
        self.straddle_frac = straddle_frac
        self.min_ioa = min_ioa
        self.max_leader_frac = max_leader_frac

    def recognize(self, page: PageImage, block: Block, ctx: StageContext) -> Table:
        ctx.deadline.check()
        units = units_from_lines(block.lines or ())
        if not units:
            return single_cell_table(
                block.bbox, block.origin, page_width=page.width, page_height=page.height
            )

        gray = _crop_gray(page, block.bbox)
        ruling = analyze_ruling(
            gray, kernel_frac=self.kernel_frac, rule_min_len_frac=self.rule_min_len_frac
        )
        x_off = max(0.0, float(np.floor(block.bbox[0])))
        y_off = max(0.0, float(np.floor(block.bbox[1])))
        strategy = (
            "ruled"
            if len(ruling.h_rules) >= self.min_rules and len(ruling.v_rules) >= self.min_rules
            else "borderless"
        )
        if strategy == "ruled":
            grid = [
                GridCell(
                    row=g.row,
                    col=g.col,
                    row_span=g.row_span,
                    col_span=g.col_span,
                    bbox=(
                        g.bbox[0] + x_off,
                        g.bbox[1] + y_off,
                        g.bbox[2] + x_off,
                        g.bbox[3] + y_off,
                    ),
                )
                for g in lattice_cells(
                    ruling.h_rules,
                    ruling.v_rules,
                    ruling.h_mask,
                    ruling.v_mask,
                    edge_min_frac=self.edge_min_frac,
                )
            ]
        else:
            grid = borderless_cells(
                units,
                block.bbox,
                col_tol_frac=self.col_tol_frac,
                col_min_support=self.col_min_support,
                straddle_frac=self.straddle_frac,
            )
        if not grid:
            raise EngineDegraded(
                f"geometric: no plausible grid (strategy={strategy}, "
                f"score={ruling.score:.2f}) for a block with {len(units)} unit(s)"
            )
        table, coverage = assemble_table(
            grid,
            units,
            origin_default=block.origin,
            page_width=page.width,
            page_height=page.height,
            min_ioa=self.min_ioa,
        )
        degenerate = (table.n_rows <= 1 or table.n_cols <= 1) and len(units) >= 2
        # Strategy choice + score + coverage: the engine-record evidence (§4.1).
        ctx.logger.info(
            "table geometric: strategy=%s score=%.2f grid=%dx%d coverage=%.2f",
            strategy,
            ruling.score,
            table.n_rows,
            table.n_cols,
            coverage,
        )
        if degenerate:
            raise EngineDegraded(
                f"geometric: degenerate {table.n_rows}x{table.n_cols} grid for "
                f"{len(units)} units (strategy={strategy})",
                quality=coverage,
            )
        if coverage < self.min_grid_coverage:
            raise EngineDegraded(
                f"geometric: grid_coverage {coverage:.2f} < {self.min_grid_coverage:.2f} "
                f"(strategy={strategy})",
                quality=coverage,
            )
        leaders = leader_cell_fraction(table)
        if leaders > self.max_leader_frac:
            raise EngineDegraded(
                f"geometric: {leaders:.2f} of filled cells are leader dots "
                f"(> {self.max_leader_frac:.2f}) — a contents page, not a table "
                f"(strategy={strategy})",
                quality=coverage,
            )
        if strategy == "borderless":
            table = refine_borderless_table(
                table, units, h_rules=rule_segments(gray, x_off=x_off, y_off=y_off)
            )
        return table


# -- the ML fallback: rapid-table (SLANet-plus) ----------------------------------


def _pinned_session_options() -> Any:
    import onnxruntime as ort  # pyright: ignore[reportMissingModuleSource]

    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 1
    opts.inter_op_num_threads = 1
    opts.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    opts.log_severity_level = 4
    return opts


def _resolve_model_path(model_path: str) -> Path:
    path = Path(model_path)
    if not path.is_file():
        raise FileNotFoundError(
            f"model file not found: {path} — models are fetched by `make models` "
            "and never downloaded at runtime (plan §12)"
        )
    return path


@register("table", "rapid-table")
class RapidTableEngine:
    """SLANet-plus structure model → the same IR ``Table`` shape.

    Configured as the ``geometric`` engine's fallback; the same quality gate
    applies, so a low-trust ML grid degrades to ``table_failed`` rather than
    shipping a plausible-but-wrong structure (hard rule 12).
    """

    def __init__(
        self,
        model_path: str = "models/slanet-plus.onnx",
        min_grid_coverage: float = 0.8,
        min_ioa: float = 0.25,
        max_leader_frac: float = 0.25,
    ) -> None:
        self.model_path = _resolve_model_path(model_path)
        self.min_grid_coverage = min_grid_coverage
        self.min_ioa = min_ioa
        self.max_leader_frac = max_leader_frac
        self.version = f"rapid-table-{RAPID_TABLE_VERSION}+{self.model_path.stem}"
        self._session: Any = None
        self._session_options: Any = None
        self._structurer: Any = None
        self._matcher: Any = None

    def _get_structurer(self) -> Any:
        if self._structurer is None:
            import onnxruntime as ort  # pyright: ignore[reportMissingModuleSource]
            from rapid_table.table_matcher import TableMatch
            from rapid_table.table_structure.pp_structure import PPTableStructurer
            from rapid_table.utils import EngineType, ModelType

            self._session_options = _pinned_session_options()
            self._session = ort.InferenceSession(
                str(self.model_path),
                sess_options=self._session_options,
                providers=["CPUExecutionProvider"],
            )
            # The cfg["session"] passthrough (rapid-table 3.0.2, PR #451): the
            # library's OrtInferSession adopts our pinned session instead of
            # building its own — its download path is never reachable.
            self._structurer = PPTableStructurer(
                {
                    "session": self._session,
                    "engine_type": EngineType.ONNXRUNTIME,
                    "model_type": ModelType.SLANETPLUS,
                    "model_dir_or_path": str(self.model_path),
                    "engine_cfg": {},
                }
            )
            self._matcher = TableMatch()
        return self._structurer

    def warm_up(self) -> None:
        """Create the session + handler now (worker init, after the pins)."""
        self._get_structurer()

    def session_info(self) -> dict[str, Any] | None:
        """Pinning evidence (None until first inference creates the session)."""
        if self._session is None or self._session_options is None:
            return None
        return {
            "model": self.model_path.name,
            "intra_op_num_threads": self._session_options.intra_op_num_threads,
            "inter_op_num_threads": self._session_options.inter_op_num_threads,
            "execution_mode": self._session_options.execution_mode.name,
            "providers": list(self._session.get_providers()),
        }

    def recognize(self, page: PageImage, block: Block, ctx: StageContext) -> Table:
        ctx.deadline.check()
        units = units_from_lines(block.lines or ())
        if not units:
            return single_cell_table(
                block.bbox, block.origin, page_width=page.width, page_height=page.height
            )
        x0 = int(max(0, np.floor(block.bbox[0])))
        y0 = int(max(0, np.floor(block.bbox[1])))
        x1 = int(min(page.width, np.ceil(block.bbox[2])))
        y1 = int(min(page.height, np.ceil(block.bbox[3])))
        crop = page.pixels[y0:y1, x0:x1]
        if crop.ndim == 2:
            crop_bgr = cv2.cvtColor(crop, cv2.COLOR_GRAY2BGR)
        else:
            crop_bgr = cv2.cvtColor(crop, cv2.COLOR_RGB2BGR)

        try:
            structurer = self._get_structurer()
            structs, cell_bboxes = structurer([crop_bgr])
            logic_points = self._matcher.decode_logic_points(structs)
        except Exception as exc:
            raise EngineDegraded(
                f"rapid-table inference failed: {type(exc).__name__}: {exc}"
            ) from exc

        grid = _grid_from_slanet(
            logic_points[0] if logic_points else np.empty((0, 4)),
            cell_bboxes[0] if cell_bboxes else np.empty((0, 8)),
            offset=(float(x0), float(y0)),
            block_bbox=block.bbox,
        )
        if not grid:
            raise EngineDegraded("rapid-table: model produced no usable cell grid")
        table, coverage = assemble_table(
            grid,
            units,
            origin_default=block.origin,
            page_width=page.width,
            page_height=page.height,
            min_ioa=self.min_ioa,
        )
        ctx.logger.info(
            "table rapid-table: grid=%dx%d coverage=%.2f", table.n_rows, table.n_cols, coverage
        )
        degenerate = (table.n_rows <= 1 or table.n_cols <= 1) and len(units) >= 2
        if degenerate or coverage < self.min_grid_coverage:
            raise EngineDegraded(
                f"rapid-table: grid {table.n_rows}x{table.n_cols} coverage {coverage:.2f} "
                f"below {self.min_grid_coverage:.2f}",
                quality=coverage,
            )
        leaders = leader_cell_fraction(table)
        if leaders > self.max_leader_frac:
            raise EngineDegraded(
                f"rapid-table: {leaders:.2f} of filled cells are leader dots "
                f"(> {self.max_leader_frac:.2f}) — a contents page, not a table",
                quality=coverage,
            )
        return table


def _grid_from_slanet(
    logic_points: npt.NDArray[np.float64],
    cell_bboxes: npt.NDArray[np.float64],
    *,
    offset: tuple[float, float],
    block_bbox: BBox,
) -> list[GridCell]:
    """SLANet logic points ``(row_start, row_end, col_start, col_end)`` +
    predicted cell boxes (crop-local, 4 corner points) → :class:`GridCell` list.

    The model can emit fewer boxes than logic points (blank-box filtering) or
    duplicate origins in degraded output; extra/duplicate slots are dropped —
    the caller's quality gate judges whatever grid survives.
    """
    cells: list[GridCell] = []
    seen: set[tuple[int, int]] = set()
    covered: set[tuple[int, int]] = set()
    n_boxes = int(cell_bboxes.shape[0]) if cell_bboxes.size else 0
    for idx in range(int(logic_points.shape[0]) if logic_points.size else 0):
        r0, r1, c0, c1 = (int(v) for v in logic_points[idx][:4])
        if r1 < r0 or c1 < c0 or r0 < 0 or c0 < 0:
            continue
        if (r0, c0) in seen or (r0, c0) in covered:
            continue
        if idx < n_boxes:
            pts = cell_bboxes[idx]
            xs = pts[0::2]
            ys = pts[1::2]
            bbox = (
                float(xs.min()) + offset[0],
                float(ys.min()) + offset[1],
                float(xs.max()) + offset[0],
                float(ys.max()) + offset[1],
            )
        else:
            bbox = block_bbox  # box filtered by the model — coarse but honest
        span_cells = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
        if (span_cells - {(r0, c0)}) & (seen | covered):
            continue
        seen.add((r0, c0))
        covered |= span_cells - {(r0, c0)}
        cells.append(
            GridCell(
                row=r0,
                col=c0,
                row_span=r1 - r0 + 1,
                col_span=c1 - c0 + 1,
                bbox=bbox,
            )
        )
    return cells


__all__ = [
    "GEOMETRIC_VERSION",
    "RAPID_TABLE_VERSION",
    "GeometricTableEngine",
    "GridCell",
    "RapidTableEngine",
    "Refinement",
    "TextUnit",
    "analyze_ruling",
    "assemble_table",
    "borderless_cells",
    "detect_header_rows",
    "lattice_cells",
    "lattice_regions",
    "lattice_tables",
    "leader_cell_fraction",
    "refine_borderless",
    "refine_borderless_table",
    "retype_digital_tables",
    "rule_segments",
    "single_cell_table",
    "split_column_blocks",
    "split_wide_gap_lines",
    "units_from_lines",
    "units_from_spans",
]
