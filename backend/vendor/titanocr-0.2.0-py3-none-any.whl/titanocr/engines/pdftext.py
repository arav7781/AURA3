"""pdf-inspector engine — stage-1 classification + positioned text items (ADR 0001/0002).

Consumed via the Python binding (ADR 0002 §3); the tool's Markdown output is never
touched (ADR 0001 §1) — only ``classify_pdf`` and ``extract_text_with_positions``
are wrapped, so there is nothing to "enforce": the lossy API simply isn't called.

Coordinate mapping (verified empirically against pdfium charboxes on fixture 1,
phase-06 log): items arrive in PDF points, origin **bottom-left**, ``y`` = glyph-box
bottom, ``height`` = font size. IR bboxes are page-space pixels of the rendered page,
origin top-left — the flip/scale happens in :func:`to_px_bbox` against the exact
page height in points, then clamps to the rendered pixel dimensions so every bbox
lands on the served PNG.

Both pdftext engines (this one and the pdfium fallback in
:mod:`titanocr.engines.raster`) implement the same informal interface —
``classify`` + ``extract_lines`` — so the orchestrator's fallback chain can swap
them without caring which produced a page.
"""

import unicodedata
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from importlib.metadata import version as _dist_version
from pathlib import Path
from statistics import median

import pdf_inspector

from titanocr.ir import BBox, Line, Origin, PdfClass, Span
from titanocr.stages import EngineDegraded, register

_PDF_TYPE_MAP: dict[str, PdfClass] = {
    "text_based": PdfClass.TextBased,
    "scanned": PdfClass.Scanned,
    "image_based": PdfClass.ImageBased,
    "mixed": PdfClass.Mixed,
}


@dataclass(frozen=True)
class PdfTextClassification:
    """Stage-1 classification, normalised: ``pages_needing_ocr`` is **1-indexed** here
    (pdf-inspector emits 0-indexed; the IR and job table are 1-indexed throughout)."""

    pdf_type: PdfClass
    confidence: float
    page_count: int
    pages_needing_ocr: frozenset[int]


@dataclass(frozen=True)
class PageGeometry:
    """How a PDF page maps to its rendered raster: points size, pixel size, px/pt scale."""

    width_pts: float
    height_pts: float
    width_px: int
    height_px: int
    scale: float


@dataclass(frozen=True)
class PositionedText:
    """One positioned text fragment in PDF points, origin bottom-left (pre-flip)."""

    text: str
    x: float
    y: float
    width: float
    height: float


def to_px_bbox(fragment: PositionedText, geom: PageGeometry) -> BBox:
    """PDF-points bottom-left box → page-space pixel box, clamped to the render."""
    x0 = fragment.x * geom.scale
    x1 = (fragment.x + fragment.width) * geom.scale
    y0 = (geom.height_pts - (fragment.y + fragment.height)) * geom.scale
    y1 = (geom.height_pts - fragment.y) * geom.scale
    x0 = min(max(x0, 0.0), geom.width_px)
    x1 = min(max(x1, x0), geom.width_px)
    y0 = min(max(y0, 0.0), geom.height_px)
    y1 = min(max(y1, y0), geom.height_px)
    return (x0, y0, x1, y1)


WORD_GAP_RATIO = 0.15
"""A horizontal gap between two fragments narrower than this fraction of the
taller one's height is not a word space. Fragments arrive per text run, and a
letter-spaced heading arrives one glyph per run: joined with a space each,
``Tax Invoice`` came out ``Ta x I n v o i c e`` on a real receipt (2026-09-03,
phase 23). A real word space is ~0.25 em; 0.15 sits under it with margin."""

LINE_MIN_OVERLAP_RATIO = 0.55
"""How much of the shorter fragment must fall inside the row's own vertical band
before it belongs to that row. See :func:`cluster_into_lines`."""

_LINE_MAX_X_OVERLAP_RATIO = 0.5
"""Two fragments overlapping horizontally by more than this fraction of the
narrower one are stacked, not side by side — whatever their y says."""


def overlap_ratio(a0: float, a1: float, b0: float, b1: float) -> float:
    """Overlap of two intervals as a fraction of the *shorter* one."""
    return max(0.0, min(a1, b1) - max(a0, b0)) / max(1e-6, min(a1 - a0, b1 - b0))


def join_fragments(cluster: Sequence[PositionedText], gap_ratio: float = WORD_GAP_RATIO) -> str:
    """The text of one visual row from its left-to-right fragments.

    A space goes between two fragments only when the gap between them is a
    real one — at least ``gap_ratio`` of the taller fragment's height — and
    neither already carries the space itself. Glyph-per-run text (a
    letter-spaced heading, a kerned wordmark) joins without inserted spaces;
    two words set apart join with one.
    """
    parts: list[str] = []
    prev: PositionedText | None = None
    for frag in cluster:
        if prev is not None:
            gap = frag.x - (prev.x + prev.width)
            unit = max(prev.height, frag.height, 1e-6)
            already = prev.text.endswith(" ") or frag.text.startswith(" ")
            if gap >= gap_ratio * unit and not already:
                parts.append(" ")
        parts.append(frag.text)
        prev = frag
    return "".join(parts)


def cluster_into_lines(
    fragments: Sequence[PositionedText],
    geom: PageGeometry,
    page_no: int,
    *,
    min_overlap_ratio: float = LINE_MIN_OVERLAP_RATIO,
) -> list[Line]:
    """Y-cluster positioned fragments into IR :class:`Line`s (one span per fragment).

    A fragment joins the row it overlaps vertically: at least
    ``min_overlap_ratio`` of the shorter of the two boxes must fall inside the
    row's band. Lines come out top-to-bottom, spans left-to-right; text is exact
    by construction, so line and span confidence are 1.0 with ``origin="digital"``.

    A visual row stays one Line here even when its fragments are far apart: the
    row is what the table reconstructor reads. Splitting far-apart runs into
    separate lines happens later, on the blocks that did *not* turn out to be
    tables — see ``split_wide_gap_lines``.

    Two properties are load-bearing, and the previous rule (centre distance from
    the *last accepted* fragment) had neither:

    1. **The band is the row's, not its neighbour's.** Comparing each fragment to
       the previous one lets a cluster walk down the page in small steps, and a
       column of stacked cell text is exactly a run of small steps. Measured on a
       real rate table: ``Rider``/``Option`` (a two-line cell) and the
       ``Prime Pro Ultra …`` header row centred between them chained into one
       "line" whose text came out as ``Option Rider Prime Pro …`` — three visual
       rows merged, in the wrong order, with a bbox twice the height of any of
       them. Anchoring to the seed fragment's band makes the test independent of
       arrival order and stops the walk.
    2. **Overlap, not centre distance.** A header row set between the two lines
       of a wrapped cell sits half a line-height away from both — closer than a
       0.6-of-height centre tolerance allows, but overlapping each by under half
       its box. Overlap says what centre distance cannot: these boxes are stacked.
       It also keeps a superscript or a size-mixed run on its own line, where a
       tolerance scaled to the smaller box would split them.

    The horizontal guard is the same judgement from the other axis: text that
    overlaps in x is stacked by construction, so it can never be one line however
    close the bands are.
    """
    if not fragments:
        return []

    def centre(f: PositionedText) -> float:
        return f.y + f.height / 2.0

    ordered = sorted(fragments, key=lambda f: (-centre(f), f.x))
    clusters: list[list[PositionedText]] = [[ordered[0]]]
    bands: list[tuple[float, float]] = [(ordered[0].y, ordered[0].y + ordered[0].height)]
    for frag in ordered[1:]:
        band = bands[-1]
        fits = overlap_ratio(frag.y, frag.y + frag.height, *band) >= min_overlap_ratio
        stacked = any(
            overlap_ratio(frag.x, frag.x + frag.width, other.x, other.x + other.width)
            > _LINE_MAX_X_OVERLAP_RATIO
            for other in clusters[-1]
        )
        if fits and not stacked:
            clusters[-1].append(frag)
        else:
            clusters.append([frag])
            bands.append((frag.y, frag.y + frag.height))

    lines: list[Line] = []
    for idx, cluster in enumerate(clusters):
        cluster.sort(key=lambda f: f.x)
        spans = tuple(Span(text=f.text, bbox=to_px_bbox(f, geom), confidence=1.0) for f in cluster)
        bbox = _union(s.bbox for s in spans)
        lines.append(
            Line(
                line_id=f"p{page_no}_l{idx}",
                bbox=bbox,
                text=join_fragments(cluster),
                confidence=1.0,
                origin=Origin.digital,
                is_handwritten=False,
                spans=spans,
            )
        )
    return lines


def _union(bboxes: Iterable[BBox]) -> BBox:
    boxes = list(bboxes)
    return (
        min(b[0] for b in boxes),
        min(b[1] for b in boxes),
        max(b[2] for b in boxes),
        max(b[3] for b in boxes),
    )


def median_or(values: Sequence[float], default: float) -> float:
    return float(median(values)) if values else default


_SUSPICIOUS_UNICODE_CATEGORIES = frozenset({"Co", "Cn", "Cs", "So"})
"""Private-use, unassigned, surrogate, and "other symbol" — where glyph runs land
when a subset font's ``ToUnicode`` CMap doesn't actually match its glyph indices.
The glyphs still *render* correctly (pdfium draws by glyph id, not by the broken
Unicode mapping) but the extracted characters are garbage; a resume rendered as
"EDUCATION" that extracts as "☠◆♥▲" is exactly this failure, and no amount of
character coverage against the (equally-broken) pdfium reference count catches it
— coverage only measures quantity, never validity."""


def garbled_char_ratio(texts: str | Iterable[str]) -> float:
    """Fraction of non-whitespace characters across ``texts`` whose Unicode category
    is symptomatic of a broken font encoding (see :data:`_SUSPICIOUS_UNICODE_CATEGORIES`).
    Normal prose — any script — lands near 0.0; a corrupted CID/cmap dump lands high.

    Accepts either one string or an iterable of them (e.g. a page's line texts)
    so callers don't need to materialise a joined copy first. Single pass, no
    intermediate list: every ASCII code point (0x00-0x7F) is skipped without a
    category lookup — none of them are ever ``Co``/``Cn``/``Cs``/``So``, so this is
    exact, not approximate, and it's the fast path that matters: ordinary
    English-heavy prose never reaches ``unicodedata.category`` at all.
    """
    total = 0
    suspicious = 0
    for text in (texts,) if isinstance(texts, str) else texts:
        for ch in text:
            if ch.isspace():
                continue
            total += 1
            if ord(ch) < 128:
                continue
            if unicodedata.category(ch) in _SUSPICIOUS_UNICODE_CATEGORIES:
                suspicious += 1
    return suspicious / total if total else 0.0


@register("pdftext", "pdfinspector")
class PdfInspectorEngine:
    """Primary stage-1 engine. Raises :class:`EngineDegraded` on parse failure or
    low classification confidence — the orchestrator then runs the configured
    fallback (``pdfium-text``), per the phase-03 fallback convention."""

    version: str = _dist_version("pdf-inspector")

    def __init__(
        self,
        digital_render_dpi: float = 150.0,
        min_text_coverage: float = 0.95,
        min_classify_confidence: float = 0.5,
        line_min_overlap_ratio: float = LINE_MIN_OVERLAP_RATIO,
        block_gap_ratio: float = 1.8,
        max_garbled_char_ratio: float = 0.10,
        max_unclaimed_ink_frac: float = 0.35,
        detect_connectors: bool = False,
        detect_rules: bool = False,
        ocr_unclaimed_regions: bool = True,
        region_min_side_px: int = 20,
        max_regions_per_page: int = 16,
    ) -> None:
        self.digital_render_dpi = digital_render_dpi
        self.min_text_coverage = min_text_coverage
        self.min_classify_confidence = min_classify_confidence
        self.line_min_overlap_ratio = line_min_overlap_ratio
        self.block_gap_ratio = block_gap_ratio
        self.max_garbled_char_ratio = max_garbled_char_ratio
        self.detect_connectors = detect_connectors
        """Read by the orchestrator, not this engine: whether a digital page's
        drawn arrows are detected (IR 1.6, ADR 0012). Off by default — see
        ``RapidLayoutEngine._with_connectors`` for the measured reason."""
        self.detect_rules = detect_rules
        """Also read by the orchestrator: whether a page's plain straight ink is
        emitted as ``rule`` blocks (ADR 0014). Off by default — the detection
        still runs, because the ruled-table lattice is built out of it; what is
        off is calling a line a finding. See ``RapidLayoutEngine._page_rules``."""
        self.max_unclaimed_ink_frac = max_unclaimed_ink_frac
        self.ocr_unclaimed_regions = ocr_unclaimed_regions
        """Read by the orchestrator (phase 23, ADR 0020): find the page's raster
        regions — image objects and unclaimed ink — and OCR each in a worker,
        merging additively. Off restores the pre-phase-23 fast path, where a
        born-digital page's pictures are invisible below the whole-page valve."""
        self.region_min_side_px = region_min_side_px
        self.max_regions_per_page = max_regions_per_page
        """Read by the orchestrator, not this engine: the pipeline-config carrier
        for :func:`titanocr.engines.layout.unclaimed_ink_fraction`'s threshold —
        the same pattern ``max_garbled_char_ratio`` already uses."""

    def classify(self, pdf_path: Path) -> PdfTextClassification:
        try:
            raw = pdf_inspector.classify_pdf(str(pdf_path))
        except ValueError as exc:
            raise EngineDegraded(f"pdf-inspector classify failed: {exc}") from exc
        if raw.confidence < self.min_classify_confidence:
            raise EngineDegraded(
                f"classification confidence {raw.confidence:.2f} below "
                f"min_classify_confidence {self.min_classify_confidence:.2f}",
                quality=raw.confidence,
            )
        return PdfTextClassification(
            pdf_type=_PDF_TYPE_MAP.get(raw.pdf_type, PdfClass.Mixed),
            confidence=raw.confidence,
            page_count=raw.page_count,
            pages_needing_ocr=frozenset(p + 1 for p in raw.pages_needing_ocr),
        )

    def extract_lines(
        self, pdf_path: Path, geometries: Mapping[int, PageGeometry]
    ) -> dict[int, list[Line]]:
        """Positioned items → IR lines per page, for the pages in ``geometries``."""
        try:
            items = pdf_inspector.extract_text_with_positions(str(pdf_path))
        except ValueError as exc:
            raise EngineDegraded(f"pdf-inspector item extraction failed: {exc}") from exc

        by_page: dict[int, list[PositionedText]] = {}
        for item in items:  # TextItem.page is 1-indexed (verified, phase-06 log)
            if item.item_type != "text" or not item.text.strip():
                continue
            by_page.setdefault(item.page, []).append(
                PositionedText(
                    text=item.text, x=item.x, y=item.y, width=item.width, height=item.height
                )
            )
        return {
            page_no: cluster_into_lines(
                by_page.get(page_no, []),
                geom,
                page_no,
                min_overlap_ratio=self.line_min_overlap_ratio,
            )
            for page_no, geom in geometries.items()
        }


__all__ = [
    "LINE_MIN_OVERLAP_RATIO",
    "PageGeometry",
    "PdfInspectorEngine",
    "PdfTextClassification",
    "PositionedText",
    "cluster_into_lines",
    "garbled_char_ratio",
    "median_or",
    "overlap_ratio",
    "to_px_bbox",
]
