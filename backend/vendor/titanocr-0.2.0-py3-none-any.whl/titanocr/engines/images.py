"""Image header probing for ingest (stage 0) — Pillow/pillow-heif quarantine.

Ingest needs page (frame) counts and pixel dimensions for raster uploads without
decoding pixels: :func:`probe_image` reads headers only. Pillow's default
decompression-bomb guard stays active (plan §14) — a bomb surfaces as a loud
:class:`ImageProbeError`, which ingest turns into a 422.
"""

# pillow-heif ships no type stubs; the noise stays confined to this quarantine module.
# pyright: reportMissingTypeStubs=false, reportUnknownMemberType=false

from pathlib import Path

import pillow_heif
from PIL import Image


class ImageProbeError(Exception):
    """The image could not be parsed — rejected at ingest (422)."""


def probe_image(path: Path) -> list[tuple[int, int]]:
    """Per-frame ``(width, height)`` — one entry per page (TIFF frames; others 1)."""
    pillow_heif.register_heif_opener()  # idempotent
    try:
        with Image.open(path) as img:
            n_frames = int(getattr(img, "n_frames", 1))
            dims: list[tuple[int, int]] = []
            for frame in range(n_frames):
                if n_frames > 1:
                    img.seek(frame)
                width, height = img.size
                if width <= 0 or height <= 0:
                    raise ImageProbeError(f"frame {frame + 1} has empty dimensions")
                dims.append((width, height))
            return dims
    except ImageProbeError:
        raise
    except Exception as exc:
        raise ImageProbeError(f"unreadable image: {exc}") from exc


__all__ = ["ImageProbeError", "probe_image"]
