"""TitanOCR: general-purpose OCR + document-structure engine (any PDF/image).

::

    from titanocr import ocr

    result = ocr("report.pdf")
    print(result.markdown)      # or .text, .layout_text, .lines, .ir

See :mod:`titanocr.library` for the engine lifecycle and :mod:`titanocr.results`
for what a call returns. The command line is ``titanocr`` (:mod:`titanocr.cli`).

Every public name is imported lazily. The pool's worker processes import this
package before they pin their BLAS and ONNX thread counts (hard rule 8), so
``import titanocr`` must never load OpenCV, NumPy or ONNX Runtime by itself.
"""

from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from typing import TYPE_CHECKING, Any

try:
    __version__ = version("titanocr")
except PackageNotFoundError:  # pragma: no cover - running from an uninstalled tree
    __version__ = "0.0.0+unknown"

_EXPORTS = {
    "ocr": "titanocr.library",
    "ocr_markdown": "titanocr.library",
    "ocr_text": "titanocr.library",
    "shutdown": "titanocr.library",
    "Engine": "titanocr.library",
    "EngineError": "titanocr.library",
    "DocumentError": "titanocr.library",
    "OCRResult": "titanocr.results",
    "OCRLine": "titanocr.results",
    "fetch_models": "titanocr.modelstore",
    "ModelsUnavailable": "titanocr.modelstore",
}

__all__ = [
    "DocumentError",
    "Engine",
    "EngineError",
    "ModelsUnavailable",
    "OCRLine",
    "OCRResult",
    "__version__",
    "fetch_models",
    "ocr",
    "ocr_markdown",
    "ocr_text",
    "shutdown",
]

if TYPE_CHECKING:
    from titanocr.library import DocumentError as DocumentError
    from titanocr.library import Engine as Engine
    from titanocr.library import EngineError as EngineError
    from titanocr.library import ocr as ocr
    from titanocr.library import ocr_markdown as ocr_markdown
    from titanocr.library import ocr_text as ocr_text
    from titanocr.library import shutdown as shutdown
    from titanocr.modelstore import ModelsUnavailable as ModelsUnavailable
    from titanocr.modelstore import fetch_models as fetch_models
    from titanocr.results import OCRLine as OCRLine
    from titanocr.results import OCRResult as OCRResult


def __getattr__(name: str) -> Any:
    module = _EXPORTS.get(name)
    if module is None:
        raise AttributeError(f"module 'titanocr' has no attribute {name!r}")
    value = getattr(import_module(module), name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(_EXPORTS))
