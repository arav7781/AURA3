"""Pipeline config loader, resolver and per-page runner (docs/08 §registry).

Pipelines are configuration, not code: a YAML file names an engine (and optional
fallback) per stage. Validation happens at load/resolve time — an unknown engine
name or a param the engine's ``__init__`` doesn't accept raises
:class:`PipelineConfigError` naming the file, stage and known alternatives, so a
typo fails the readiness probe, never a production document.

Fallback semantics (settled here, phases 06/11 rely on it): a primary engine that
raises — :class:`~titanocr.stages.protocols.EngineDegraded` for "my output is
too poor", or any other exception — hands the same call to the configured fallback
engine. Both engines are recorded in provenance. :class:`DeadlineExceeded` never
triggers a fallback. If the fallback also raises (or none is configured), the
runner wraps the cause in :class:`StageFailure` — policy (fail the page vs degrade
the document) belongs to the caller; the runner just reports faithfully.
"""

import inspect
from collections.abc import Callable, Collection, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from time import perf_counter
from typing import Any, TypeVar, cast

import yaml
from pydantic import BaseModel, ConfigDict, Field

from titanocr.ir import Block, BlockType, Line, Page, PageOrigin, ProvenanceEntry
from titanocr.stages.blocks import BLOCKS_VERSION, cluster_paragraph_blocks
from titanocr.stages.context import DeadlineExceeded, StageContext
from titanocr.stages.events import StageEvent
from titanocr.stages.protocols import (
    Escalator,
    LayoutAnalyzer,
    PageImage,
    PrepRecord,
    Preprocessor,
    TableRecognizer,
    TextDetector,
    TextRecognizer,
    TriagePolicy,
)
from titanocr.stages.registry import DEFAULT_REGISTRY, EngineRegistry, UnknownEngineError
from titanocr.stages.signals import SIGNALS_VERSION, compute_signals

T = TypeVar("T")

STAGE_TO_KIND: dict[str, str] = {
    "pdftext": "pdftext",
    "rasterize": "rasterizer",
    "prep": "prep",
    "detect": "detector",
    "recognize": "recognizer",
    "layout": "layout",
    "table": "table",
    "triage": "triage",
    "escalate": "escalator",
}
"""Pipeline-YAML stage key → registry kind (stage keys follow docs/08's example YAML)."""

_KIND_PROTOCOLS: dict[str, type | None] = {
    "prep": Preprocessor,
    "detector": TextDetector,
    "recognizer": TextRecognizer,
    "layout": LayoutAnalyzer,
    "table": TableRecognizer,
    "triage": TriagePolicy,
    "escalator": Escalator,
    "pdftext": None,  # phase-06 built-ins; no docs/08 Protocol exists for these kinds
    "rasterizer": None,
}


class PipelineConfigError(Exception):
    """Bad pipeline config — raised at load/resolve time, i.e. at startup."""


class StageFailure(Exception):
    """A stage (including its fallback, if any) failed on a page."""

    def __init__(self, stage: str, engine: str, cause: BaseException) -> None:
        super().__init__(f"stage {stage!r} failed in engine {engine!r}: {cause}")
        self.stage = stage
        self.engine = engine
        self.cause = cause


class StageSpec(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    engine: str
    fallback: str | None = None
    params: dict[str, Any] = Field(default_factory=dict)
    fallback_params: dict[str, Any] = Field(default_factory=dict)
    """Constructor params for the fallback engine — how a fallback that loads a
    model names it in config rather than relying on a default relative path."""


class PipelineConfig(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    version: int = Field(ge=1)
    name: str
    stages: dict[str, StageSpec]
    doc_types: dict[str, dict[str, Any]] = Field(default_factory=dict)
    source: str | None = None
    """Populated by :func:`load_pipeline` with the file path, for error context."""


def load_pipeline(path: str | Path, _chain: tuple[Path, ...] = ()) -> PipelineConfig:
    """YAML → validated :class:`PipelineConfig` (shape only; engines checked in resolve).

    A file may name a base with ``extends: <path relative to this file>`` and
    override or add stages on top of it — how an operator turns an optional
    stage on without copying the whole config (ADR 0023: ``pipelines/with-vlm.yaml``
    is `default.yaml` plus an ``escalate`` stage). Merging is per stage key:
    a stage the child names replaces the base's entirely, everything else is
    inherited; ``doc_types`` merges the same way, and ``version`` is the child's
    when it names one. ``name`` is always this file's stem, so provenance cites
    the config that actually ran.
    """
    p = Path(path)
    resolved = p.resolve()
    if resolved in _chain:
        cycle = " → ".join(str(q) for q in (*_chain, resolved))
        raise PipelineConfigError(f"{p}: 'extends' cycle: {cycle}")
    try:
        raw: object = yaml.safe_load(p.read_text(encoding="utf-8"))
    except OSError as exc:
        raise PipelineConfigError(f"{p}: cannot read pipeline config: {exc}") from exc
    except yaml.YAMLError as exc:
        raise PipelineConfigError(f"{p}: invalid YAML: {exc}") from exc
    if not isinstance(raw, dict):
        raise PipelineConfigError(
            f"{p}: pipeline config must be a mapping, got {type(raw).__name__}"
        )

    data = dict(cast(dict[Any, Any], raw))
    extends_raw = data.pop("extends", None)
    version = data.pop("version", None)
    stages_raw = data.pop("stages", {})
    doc_types_raw = data.pop("doc_types", {})
    if data:
        keys = ", ".join(sorted(str(k) for k in data))
        raise PipelineConfigError(
            f"{p}: unknown top-level key(s): {keys} — expected extends, version, stages, doc_types"
        )

    base: PipelineConfig | None = None
    if extends_raw is not None:
        if not isinstance(extends_raw, str) or not extends_raw:
            raise PipelineConfigError(
                f"{p}: 'extends' must be a path to another pipeline file, got {extends_raw!r}"
            )
        base = load_pipeline(p.parent / extends_raw, (*_chain, resolved))
    if version is None and base is not None:
        version = base.version
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        raise PipelineConfigError(f"{p}: 'version' must be a positive integer, got {version!r}")
    if not isinstance(stages_raw, dict):
        raise PipelineConfigError(f"{p}: 'stages' must be a mapping of stage → spec")
    if not isinstance(doc_types_raw, dict):
        raise PipelineConfigError(f"{p}: 'doc_types' must be a mapping")
    if base is None and not stages_raw:
        raise PipelineConfigError(f"{p}: 'stages' must be a mapping of stage → spec")

    stages: dict[str, StageSpec] = {}
    for key, spec_raw in cast(dict[Any, Any], stages_raw).items():
        if not isinstance(key, str) or key not in STAGE_TO_KIND:
            known = ", ".join(STAGE_TO_KIND)
            raise PipelineConfigError(f"{p}: unknown stage {key!r} — known stages: {known}")
        if not isinstance(spec_raw, dict):
            raise PipelineConfigError(f"{p}: stage {key!r} must be a mapping with an 'engine' key")
        spec_data = dict(cast(dict[Any, Any], spec_raw))
        engine = spec_data.pop("engine", None)
        if not isinstance(engine, str) or not engine:
            raise PipelineConfigError(f"{p}: stage {key!r} needs an 'engine' name (string)")
        fallback = spec_data.pop("fallback", None)
        if fallback is not None and not isinstance(fallback, str):
            raise PipelineConfigError(f"{p}: stage {key!r}: 'fallback' must be an engine name")
        fallback_params_raw = spec_data.pop("fallback_params", None)
        if fallback_params_raw is not None and (
            fallback is None or not isinstance(fallback_params_raw, dict)
        ):
            raise PipelineConfigError(
                f"{p}: stage {key!r}: 'fallback_params' must be a mapping, alongside 'fallback'"
            )
        fallback_params = {
            str(k): v for k, v in cast(dict[Any, Any], fallback_params_raw or {}).items()
        }
        params = {str(k): v for k, v in spec_data.items()}
        stages[key] = StageSpec(
            engine=engine, fallback=fallback, params=params, fallback_params=fallback_params
        )

    doc_types = {
        str(k): cast(dict[str, Any], v) for k, v in cast(dict[Any, Any], doc_types_raw).items()
    }
    if base is not None:
        stages = {**base.stages, **stages}
        doc_types = {**base.doc_types, **doc_types}
    return PipelineConfig(
        version=version, name=p.stem, stages=stages, doc_types=doc_types, source=str(p)
    )


@dataclass(frozen=True)
class ResolvedStage:
    stage: str
    kind: str
    engine_name: str
    engine: object
    fallback_name: str | None = None
    fallback: object | None = None


@dataclass(frozen=True)
class ResolvedPipeline:
    pipeline_version: str
    """``<name>@<version>`` — goes into provenance so every result cites its config."""

    stages: Mapping[str, ResolvedStage]

    doc_types: Mapping[str, Mapping[str, Any]] = field(default_factory=dict[str, Mapping[str, Any]])
    """The config's ``doc_types:`` section — per-``doc_type_hint`` structural-check
    knobs the triage policy reads via ``ctx.config`` (phase 12)."""


def _check_params(cls: type[Any], params: Mapping[str, Any], *, loc: str, engine: str) -> None:
    sig = inspect.signature(cls.__init__)
    accepted: set[str] = set()
    for name, param in sig.parameters.items():
        if name == "self":
            continue
        if param.kind is inspect.Parameter.VAR_KEYWORD:
            return  # engine takes **kwargs — nothing to check statically
        if param.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY):
            accepted.add(name)
    unknown = sorted(set(params) - accepted)
    if unknown:
        known = ", ".join(sorted(accepted)) or "(none)"
        raise PipelineConfigError(
            f"{loc}: engine {engine!r} does not accept param(s) "
            f"{', '.join(repr(u) for u in unknown)} — accepted params: {known}"
        )


def resolve(
    config: PipelineConfig,
    registry: EngineRegistry | None = None,
    *,
    only: Collection[str] | None = None,
) -> ResolvedPipeline:
    """Instantiate every declared engine (and fallback) from the registry.

    ``only`` restricts resolution to a subset of stage keys — phase 06 resolves
    just ``pdftext``/``rasterize`` while the OCR engines don't exist yet; the
    remaining stages stay informational in ``/readyz`` until their phases land.

    Raises :class:`PipelineConfigError` with file/stage context for an unknown
    engine, a rejected param, a failing constructor, or an instance that does not
    implement its stage Protocol.
    """
    reg = DEFAULT_REGISTRY if registry is None else registry
    source = config.source or f"<pipeline {config.name}>"
    resolved: dict[str, ResolvedStage] = {}
    for stage_key, spec in config.stages.items():
        if only is not None and stage_key not in only:
            continue
        kind = STAGE_TO_KIND[stage_key]
        loc = f"{source}: stage {stage_key!r}"
        engine = _build_engine(reg, kind, spec.engine, spec.params, loc=loc)
        fallback = None
        if spec.fallback is not None:
            fallback = _build_engine(
                reg, kind, spec.fallback, spec.fallback_params, loc=f"{loc} (fallback)"
            )
        resolved[stage_key] = ResolvedStage(
            stage=stage_key,
            kind=kind,
            engine_name=spec.engine,
            engine=engine,
            fallback_name=spec.fallback,
            fallback=fallback,
        )
    return ResolvedPipeline(
        pipeline_version=f"{config.name}@{config.version}",
        stages=resolved,
        doc_types=config.doc_types,
    )


def _build_engine(
    reg: EngineRegistry, kind: str, name: str, params: Mapping[str, Any], *, loc: str
) -> object:
    try:
        cls = reg.get_engine(kind, name)
    except UnknownEngineError as exc:
        raise PipelineConfigError(f"{loc}: {exc}") from exc
    _check_params(cls, params, loc=loc, engine=name)
    try:
        instance: object = cls(**params)
    except Exception as exc:
        raise PipelineConfigError(f"{loc}: constructing engine {name!r} failed: {exc}") from exc
    proto = _KIND_PROTOCOLS[kind]
    if proto is not None and not isinstance(instance, proto):
        raise PipelineConfigError(f"{loc}: engine {name!r} does not implement {proto.__name__}")
    return instance


def _engine_version(engine: object) -> str:
    version = getattr(engine, "version", None)
    return version if isinstance(version, str) else "unversioned"


_RUNNER_STAGES = ("prep", "detect", "recognize")
"""Stages the runner requires. ``layout`` is optional — without it (or when it
fails) the paragraph clustering builds the blocks (plan §7: never zero blocks).
``table`` is optional too (it arrives in phase 11): a layout-emitted table
candidate keeps its ``PENDING_TABLE`` placeholder and its assigned lines
(IR 1.1, ADR 0004) until a table stage is configured to complete it — the
Markdown projection renders the lines behind the tables-pending marker, so
nothing is lost in the meantime."""


class PageRunner:
    """Sequential per-page execution: prep → detect → recognize → layout → table → signals.

    Runs inside a pool worker (phase 08); triage and escalation happen outside, on
    the assembled :class:`~titanocr.ir.Page`. Appends a provenance entry per
    engine invocation to ``ctx.costs``, checks ``ctx.deadline`` before every
    invocation, and optionally reports :class:`StageEvent` via ``on_event``.
    """

    def __init__(
        self,
        pipeline: ResolvedPipeline,
        on_event: Callable[[StageEvent], None] | None = None,
    ) -> None:
        missing = [s for s in _RUNNER_STAGES if s not in pipeline.stages]
        if missing:
            raise PipelineConfigError(
                f"pipeline {pipeline.pipeline_version!r} is missing runner stage(s): "
                f"{', '.join(missing)}"
            )
        self._pipeline = pipeline
        self._on_event = on_event

    def run(
        self,
        page_image: PageImage,
        page_no: int,
        ctx: StageContext,
        *,
        preprocessed: tuple[PageImage, PrepRecord] | None = None,
    ) -> Page:
        """Run the page. ``preprocessed`` lets the caller supply an already-prepped
        image + record (the pool worker preps separately so it can apply the
        pass-through-on-failure policy and write the post-prep artifact); when
        given, the prep stage is skipped here and not re-recorded.
        """
        if preprocessed is None:
            prepped, prep_record = self._invoke(
                "prep",
                page_no,
                ctx,
                lambda engine: cast(Preprocessor, engine).process(page_image, ctx),
            )
        else:
            prepped, prep_record = preprocessed
        regions = self._invoke(
            "detect",
            page_no,
            ctx,
            lambda engine: cast(TextDetector, engine).detect(prepped, ctx),
        )
        lines = self._invoke(
            "recognize",
            page_no,
            ctx,
            lambda engine: cast(TextRecognizer, engine).recognize(prepped, regions, ctx),
        )
        blocks = self.build_blocks(prepped, lines, page_no, ctx)
        blocks = [self._recognize_table(prepped, block, page_no, ctx) for block in blocks]

        ctx.deadline.check()
        started = perf_counter()
        floor = getattr(self._pipeline.stages["recognize"].engine, "rec_conf_floor", None)
        confidence = compute_signals(
            lines,
            prepped.width,
            prepped.height,
            **({"rec_conf_floor": float(floor)} if isinstance(floor, int | float) else {}),
        )
        ms = (perf_counter() - started) * 1000.0
        ctx.costs.add(
            ProvenanceEntry(
                stage="signals", engine="builtin", version=SIGNALS_VERSION, ms=ms, cost_inr=0.0
            )
        )
        self._emit(StageEvent(page_no=page_no, stage="signals", status="ok", ms=ms))

        return Page(
            page_no=page_no,
            width=prepped.width,
            height=prepped.height,
            dpi_estimate=prepped.dpi,
            origin=PageOrigin.ocr,
            prep=prep_record.prep,
            quality=prep_record.quality,
            confidence=confidence,
            blocks=tuple(blocks),
        )

    def build_blocks(
        self, prepped: PageImage, lines: list[Line], page_no: int, ctx: StageContext
    ) -> list[Block]:
        """Layout when configured; interim/degrade paragraph clustering otherwise.

        A layout failure degrades to clustering instead of failing the page
        (plan §7: never zero blocks) — the failed attempt stays in provenance,
        then the cluster entry records what actually built the blocks.

        Public because the **digital route** calls it too (phase 19, ADR 0017).
        A born-digital page has exact lines and needs no OCR, but it still needs
        its regions typed — otherwise a diagram's labels arrive as body text and
        the page has no ``figure`` for ADR 0016's arrows to anchor to. Both routes
        therefore type regions through this one method, in a pool worker, so the
        model session stays where every other model session in this service lives
        (hard rule 7: never inference on the event loop).
        """
        if "layout" in self._pipeline.stages:
            try:
                return self._invoke(
                    "layout",
                    page_no,
                    ctx,
                    lambda engine: cast(LayoutAnalyzer, engine).analyze(prepped, lines, ctx),
                )
            except DeadlineExceeded:
                raise
            except StageFailure as exc:
                ctx.logger.warning("layout failed (%s) — degrading to paragraph clustering", exc)
        ctx.deadline.check()
        started = perf_counter()
        blocks = cluster_paragraph_blocks(page_no, lines)
        ms = (perf_counter() - started) * 1000.0
        ctx.costs.add(
            ProvenanceEntry(
                stage="layout", engine="line-cluster", version=BLOCKS_VERSION, ms=ms, cost_inr=0.0
            )
        )
        self._emit(StageEvent(page_no=page_no, stage="layout", status="ok", ms=ms))
        return blocks

    def recognize_region(self, image: PageImage, page_no: int, ctx: StageContext) -> list[Line]:
        """Detect + recognize one raster region of a born-digital page (phase 23,
        ADR 0020) through the OCR route's own two stages — the same ``_invoke``,
        so provenance and failure handling are identical to a full page. Public
        for the reason :meth:`build_blocks` is: the digital route calls it from
        a pool worker. No text detected → ``[]``; the caller keeps the region as
        a figure.
        """
        regions = self._invoke(
            "detect", page_no, ctx, lambda engine: cast(TextDetector, engine).detect(image, ctx)
        )
        if not regions:
            return []
        return self._invoke(
            "recognize",
            page_no,
            ctx,
            lambda engine: cast(TextRecognizer, engine).recognize(image, regions, ctx),
        )

    def _recognize_table(
        self, page: PageImage, block: Block, page_no: int, ctx: StageContext
    ) -> Block:
        if block.type is not BlockType.table:
            return block
        if "table" not in self._pipeline.stages:
            # Phase-10 interim: no table stage yet — the candidate stays honestly
            # pending (placeholder table + assigned lines, ADR 0004).
            return block
        try:
            table = self._invoke(
                "table",
                page_no,
                ctx,
                lambda engine: cast(TableRecognizer, engine).recognize(page, block, ctx),
            )
        except DeadlineExceeded:
            raise
        except StageFailure as exc:
            # Both engines lost (phase 11 §4.5, ADR 0005): the block keeps its
            # lines and is flagged — data is never lost, and the failure never
            # fails the page. A candidate without lines has nothing to keep, so
            # the flag (which asserts "lines are the delivered content") stays off.
            ctx.logger.warning("table recognition failed on %s (%s)", block.block_id, exc)
            return block.model_copy(update={"table_failed": bool(block.lines)})
        return block.model_copy(update={"table": table})

    def _invoke(
        self,
        stage_key: str,
        page_no: int,
        ctx: StageContext,
        call: Callable[[object], T],
    ) -> T:
        ctx.deadline.check()
        rs = self._pipeline.stages[stage_key]
        started = perf_counter()
        try:
            result = call(rs.engine)
        except DeadlineExceeded:
            raise
        except Exception as exc:
            ms = (perf_counter() - started) * 1000.0
            self._record(stage_key, rs.engine_name, rs.engine, ms, ctx)
            if rs.fallback is None or rs.fallback_name is None:
                self._emit(StageEvent(page_no=page_no, stage=stage_key, status="failed", ms=ms))
                raise StageFailure(stage_key, rs.engine_name, exc) from exc
            ctx.logger.warning(
                "stage %s: primary engine %s lost (%s: %s) — running fallback %s",
                stage_key,
                rs.engine_name,
                type(exc).__name__,
                exc,
                rs.fallback_name,
            )
            return self._invoke_fallback(stage_key, rs, page_no, ctx, call)
        ms = (perf_counter() - started) * 1000.0
        self._record(stage_key, rs.engine_name, rs.engine, ms, ctx)
        self._emit(StageEvent(page_no=page_no, stage=stage_key, status="ok", ms=ms))
        return result

    def _invoke_fallback(
        self,
        stage_key: str,
        rs: ResolvedStage,
        page_no: int,
        ctx: StageContext,
        call: Callable[[object], T],
    ) -> T:
        assert rs.fallback is not None and rs.fallback_name is not None
        ctx.deadline.check()
        started = perf_counter()
        try:
            result = call(rs.fallback)
        except DeadlineExceeded:
            raise
        except Exception as exc:
            ms = (perf_counter() - started) * 1000.0
            self._record(stage_key, rs.fallback_name, rs.fallback, ms, ctx)
            self._emit(StageEvent(page_no=page_no, stage=stage_key, status="failed", ms=ms))
            raise StageFailure(stage_key, rs.fallback_name, exc) from exc
        ms = (perf_counter() - started) * 1000.0
        self._record(stage_key, rs.fallback_name, rs.fallback, ms, ctx)
        self._emit(StageEvent(page_no=page_no, stage=stage_key, status="fallback", ms=ms))
        return result

    def _record(
        self, stage: str, engine_name: str, engine: object, ms: float, ctx: StageContext
    ) -> None:
        ctx.costs.add(
            ProvenanceEntry(
                stage=stage,
                engine=engine_name,
                version=_engine_version(engine),
                ms=ms,
                cost_inr=0.0,
            )
        )

    def _emit(self, event: StageEvent) -> None:
        if self._on_event is not None:
            self._on_event(event)


__all__ = [
    "STAGE_TO_KIND",
    "PageRunner",
    "PipelineConfig",
    "PipelineConfigError",
    "ResolvedPipeline",
    "ResolvedStage",
    "StageFailure",
    "StageSpec",
    "load_pipeline",
    "resolve",
]
