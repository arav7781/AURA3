"""Interim paragraph clustering — and the permanent layout-degrade path.

Phase 09 uses this as the only block builder until the real layout stage lands
(phase 10); afterwards it stays as the degrade path the runner falls back to
when layout fails, honouring plan §7 row "layout / on failure: paragraph blocks
from line clustering (never zero blocks)".

Rule (phase 09 §4.4): sort lines by y; group while the vertical gap to the
previous line is < ``PARAGRAPH_GAP_RATIO`` x the median line height **and** the
x-ranges overlap; reading order is top-to-bottom.
"""

from collections.abc import Sequence

from titanocr.ir import Block, BlockType, Line

BLOCKS_VERSION = "line-cluster-1"

PARAGRAPH_GAP_RATIO = 1.6
"""Vertical gap threshold, in units of median line height."""

SECTION_MAX_CHARS = 40
SECTION_WIDTH_FRAC = 0.6


def is_section_heading(line: Line, page_text_width: float) -> bool:
    """A short, narrow ALL-CAPS line is a section title (``KEY FEATURES``,
    ``EDUCATION``, ``EXPERIENCE``) even at body-text height — the common styling
    in real-world documents where only weight/colour, which neither the text
    layer nor OCR carries, distinguishes the heading.

    Lives here rather than beside either caller because *both* block builders
    need it: the digital fast path's ``group_blocks`` and the raster path's
    layout engine. ``stages`` is the layer they share (``stages ← engines ← app``).
    """
    text = line.text.strip()
    if not 4 <= len(text) <= SECTION_MAX_CHARS:
        return False
    if sum(c.isalpha() for c in text) < 4 or text != text.upper():
        return False
    return line.bbox[2] - line.bbox[0] <= SECTION_WIDTH_FRAC * page_text_width


def _x_overlap(a: tuple[float, float], b: tuple[float, float]) -> bool:
    return a[0] <= b[1] and b[0] <= a[1]


def cluster_paragraph_blocks(page_no: int, lines: Sequence[Line]) -> list[Block]:
    """Cluster lines into ``paragraph`` blocks; deterministic; never zero blocks
    for a page with lines."""
    if not lines:
        return []
    heights = sorted(line.bbox[3] - line.bbox[1] for line in lines)
    median_h = max(heights[len(heights) // 2], 1.0)
    ordered = sorted(lines, key=lambda line: (line.bbox[1], line.bbox[0]))

    groups: list[list[Line]] = [[ordered[0]]]
    for line in ordered[1:]:
        group = groups[-1]
        prev_bottom = max(prev.bbox[3] for prev in group)
        group_x = (min(p.bbox[0] for p in group), max(p.bbox[2] for p in group))
        gap = line.bbox[1] - prev_bottom
        if gap < PARAGRAPH_GAP_RATIO * median_h and _x_overlap(
            group_x, (line.bbox[0], line.bbox[2])
        ):
            group.append(line)
        else:
            groups.append([line])

    blocks: list[Block] = []
    for idx, group in enumerate(groups):
        bbox = (
            min(line.bbox[0] for line in group),
            min(line.bbox[1] for line in group),
            max(line.bbox[2] for line in group),
            max(line.bbox[3] for line in group),
        )
        confidence = sum(line.confidence for line in group) / len(group)
        blocks.append(
            Block(
                block_id=f"p{page_no}_b{idx}",
                type=BlockType.paragraph,
                bbox=bbox,
                reading_order=idx,
                origin=group[0].origin,
                confidence=min(1.0, max(0.0, confidence)),
                lines=tuple(group),
            )
        )
    return blocks


__all__ = ["BLOCKS_VERSION", "PARAGRAPH_GAP_RATIO", "cluster_paragraph_blocks"]
