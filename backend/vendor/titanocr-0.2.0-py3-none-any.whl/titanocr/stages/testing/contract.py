"""Contract-test bases for the swap-prone stages (docs/08 §testing, ADR 0003 #8).

Every implementation of prep/detector/recognizer/layout/table must pass the same
suite before it may appear in a pipeline config — that is what makes an engine
swap "a config change, not a leap of faith". An engine package subclasses the
matching base in its own test module and provides ``make_engine()``:

    from titanocr.stages.testing import DetectorContractTests

    class TestMyDetectorContract(DetectorContractTests):
        def make_engine(self) -> TextDetector:
            return MyDetector()

Bases are named ``*ContractTests`` (not ``Test*``) so pytest only collects them
once subclassed. Common assertions: output geometry within page bounds,
deterministic across two runs on identical input, input image never mutated, and
an already-expired deadline raises before any heavy work.
"""

import logging

import numpy as np

from titanocr.ir import Block, BlockType, Line, Origin, Span
from titanocr.stages.context import (
    CostAccumulator,
    Deadline,
    DeadlineExceeded,
    ResourceRegistry,
    StageContext,
)
from titanocr.stages.protocols import (
    PENDING_TABLE,
    LayoutAnalyzer,
    PageImage,
    Preprocessor,
    Region,
    TableRecognizer,
    TextDetector,
    TextRecognizer,
)

PAGE_WIDTH = 640
PAGE_HEIGHT = 480


def blank_page(width: int = PAGE_WIDTH, height: int = PAGE_HEIGHT) -> PageImage:
    """A white grayscale page — the standard contract-test input."""
    return PageImage(
        width=width,
        height=height,
        dpi=300.0,
        pixels=np.full((height, width), 255, dtype=np.uint8),
    )


def make_stage_context(
    deadline: Deadline | None = None,
    config: dict[str, object] | None = None,
    resources: ResourceRegistry | None = None,
) -> StageContext:
    """A self-contained StageContext for tests — fresh accumulator, quiet logger."""
    return StageContext(
        doc_id="test-doc",
        trace_id="test-trace",
        config=config if config is not None else {},
        deadline=deadline if deadline is not None else Deadline.never(),
        costs=CostAccumulator(),
        resources=resources if resources is not None else ResourceRegistry(),
        logger=logging.getLogger("titanocr.stages.testing"),
    )


def _expired_ctx() -> StageContext:
    return make_stage_context(deadline=Deadline.after(-1.0))


def _in_bounds(bbox: tuple[float, float, float, float], page: PageImage) -> bool:
    x0, y0, x1, y1 = bbox
    return 0 <= x0 <= x1 <= page.width and 0 <= y0 <= y1 <= page.height


def _sample_lines(page: PageImage) -> list[Line]:
    bbox = (10.0, 10.0, page.width / 2, 30.0)
    return [
        Line(
            line_id="l0",
            bbox=bbox,
            text="sample",
            confidence=0.97,
            origin=Origin.ocr,
            is_handwritten=False,
            spans=(Span(text="sample", bbox=bbox, confidence=0.97),),
        )
    ]


class _ContractBase:
    def make_page(self) -> PageImage:
        return blank_page()

    def make_ctx(self) -> StageContext:
        return make_stage_context()


class PrepContractTests(_ContractBase):
    def make_engine(self) -> Preprocessor:
        raise NotImplementedError("subclass provides make_engine()")

    def test_output_page_and_record_valid(self) -> None:
        out, record = self.make_engine().process(self.make_page(), self.make_ctx())
        assert isinstance(out, PageImage)  # PageImage.__post_init__ checked shape/dtype
        assert isinstance(record.prep.applied, tuple)

    def test_deterministic(self) -> None:
        engine = self.make_engine()
        out1, rec1 = engine.process(self.make_page(), self.make_ctx())
        out2, rec2 = engine.process(self.make_page(), self.make_ctx())
        assert np.array_equal(out1.pixels, out2.pixels)
        assert (out1.width, out1.height, out1.dpi) == (out2.width, out2.height, out2.dpi)
        assert rec1 == rec2

    def test_input_not_mutated(self) -> None:
        page = self.make_page()
        before = page.pixels.copy()
        self.make_engine().process(page, self.make_ctx())
        assert np.array_equal(page.pixels, before)

    def test_expired_deadline_raises(self) -> None:
        try:
            self.make_engine().process(self.make_page(), _expired_ctx())
        except DeadlineExceeded:
            return
        raise AssertionError("engine ignored an expired deadline")


class DetectorContractTests(_ContractBase):
    def make_engine(self) -> TextDetector:
        raise NotImplementedError("subclass provides make_engine()")

    def test_regions_within_page_bounds(self) -> None:
        page = self.make_page()
        regions = self.make_engine().detect(page, self.make_ctx())
        assert all(_in_bounds(region.bbox, page) for region in regions)

    def test_deterministic(self) -> None:
        engine = self.make_engine()
        first = engine.detect(self.make_page(), self.make_ctx())
        second = engine.detect(self.make_page(), self.make_ctx())
        assert first == second

    def test_input_not_mutated(self) -> None:
        page = self.make_page()
        before = page.pixels.copy()
        self.make_engine().detect(page, self.make_ctx())
        assert np.array_equal(page.pixels, before)

    def test_expired_deadline_raises(self) -> None:
        try:
            self.make_engine().detect(self.make_page(), _expired_ctx())
        except DeadlineExceeded:
            return
        raise AssertionError("engine ignored an expired deadline")


class RecognizerContractTests(_ContractBase):
    def make_engine(self) -> TextRecognizer:
        raise NotImplementedError("subclass provides make_engine()")

    def make_regions(self, page: PageImage) -> list[Region]:
        return [Region(bbox=(10.0, 10.0, page.width / 2, 30.0), confidence=0.99)]

    def test_lines_within_page_bounds_and_ocr_origin(self) -> None:
        page = self.make_page()
        lines = self.make_engine().recognize(page, self.make_regions(page), self.make_ctx())
        assert all(_in_bounds(line.bbox, page) for line in lines)
        assert all(line.origin is Origin.ocr for line in lines)

    def test_deterministic(self) -> None:
        engine = self.make_engine()
        page = self.make_page()
        first = engine.recognize(page, self.make_regions(page), self.make_ctx())
        second = engine.recognize(self.make_page(), self.make_regions(page), self.make_ctx())
        assert first == second

    def test_input_not_mutated(self) -> None:
        page = self.make_page()
        before = page.pixels.copy()
        self.make_engine().recognize(page, self.make_regions(page), self.make_ctx())
        assert np.array_equal(page.pixels, before)

    def test_expired_deadline_raises(self) -> None:
        page = self.make_page()
        try:
            self.make_engine().recognize(page, self.make_regions(page), _expired_ctx())
        except DeadlineExceeded:
            return
        raise AssertionError("engine ignored an expired deadline")


class LayoutContractTests(_ContractBase):
    def make_engine(self) -> LayoutAnalyzer:
        raise NotImplementedError("subclass provides make_engine()")

    def make_lines(self, page: PageImage) -> list[Line]:
        return _sample_lines(page)

    def test_nonempty_lines_yield_blocks_with_unique_reading_order(self) -> None:
        page = self.make_page()
        blocks = self.make_engine().analyze(page, self.make_lines(page), self.make_ctx())
        assert blocks, "layout must never emit zero blocks for a page with lines"
        orders = [block.reading_order for block in blocks]
        assert len(orders) == len(set(orders))
        assert all(_in_bounds(block.bbox, page) for block in blocks)

    def test_deterministic(self) -> None:
        engine = self.make_engine()
        page = self.make_page()
        first = engine.analyze(page, self.make_lines(page), self.make_ctx())
        second = engine.analyze(self.make_page(), self.make_lines(page), self.make_ctx())
        assert first == second

    def test_input_not_mutated(self) -> None:
        page = self.make_page()
        before = page.pixels.copy()
        self.make_engine().analyze(page, self.make_lines(page), self.make_ctx())
        assert np.array_equal(page.pixels, before)

    def test_expired_deadline_raises(self) -> None:
        page = self.make_page()
        try:
            self.make_engine().analyze(page, self.make_lines(page), _expired_ctx())
        except DeadlineExceeded:
            return
        raise AssertionError("engine ignored an expired deadline")


class TableContractTests(_ContractBase):
    def make_engine(self) -> TableRecognizer:
        raise NotImplementedError("subclass provides make_engine()")

    def make_block(self, page: PageImage) -> Block:
        return Block(
            block_id="t0",
            type=BlockType.table,
            bbox=(0.0, page.height / 2, float(page.width), float(page.height)),
            reading_order=0,
            origin=Origin.ocr,
            confidence=0.9,
            table=PENDING_TABLE,
        )

    def test_cells_within_page_bounds(self) -> None:
        page = self.make_page()
        table = self.make_engine().recognize(page, self.make_block(page), self.make_ctx())
        assert all(_in_bounds(cell.bbox, page) for cell in table.cells)

    def test_deterministic(self) -> None:
        engine = self.make_engine()
        page = self.make_page()
        first = engine.recognize(page, self.make_block(page), self.make_ctx())
        second = engine.recognize(self.make_page(), self.make_block(page), self.make_ctx())
        assert first == second

    def test_input_not_mutated(self) -> None:
        page = self.make_page()
        before = page.pixels.copy()
        self.make_engine().recognize(page, self.make_block(page), self.make_ctx())
        assert np.array_equal(page.pixels, before)

    def test_expired_deadline_raises(self) -> None:
        page = self.make_page()
        try:
            self.make_engine().recognize(page, self.make_block(page), _expired_ctx())
        except DeadlineExceeded:
            return
        raise AssertionError("engine ignored an expired deadline")
