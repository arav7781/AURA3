"""Fake engines: fixed, deterministic outputs for runner and contract tests.

Fakes follow the same conventions real engines must (deadline check first, no
input mutation, ``version`` attribute) and count their invocations, which is what
lets tests assert "expired deadline → no engine call made".

They are *not* auto-registered — call :func:`register_fakes` on a fresh
:class:`~titanocr.stages.registry.EngineRegistry` (never the process-wide
default) so tests stay isolated.
"""

from collections.abc import Sequence

from titanocr.ir import (
    Block,
    BlockType,
    Cell,
    Line,
    Origin,
    Prep,
    Quality,
    Span,
    Table,
)
from titanocr.stages.context import StageContext
from titanocr.stages.protocols import PENDING_TABLE, PageImage, PrepRecord, Region
from titanocr.stages.registry import EngineRegistry


class FakePrep:
    """Identity preprocessor: returns the page untouched with a neutral record."""

    version = "fake-1"

    def __init__(self, applied: Sequence[str] = ()) -> None:
        self.applied = tuple(applied)
        self.calls = 0

    def process(self, page: PageImage, ctx: StageContext) -> tuple[PageImage, PrepRecord]:
        self.calls += 1
        ctx.deadline.check()
        record = PrepRecord(
            prep=Prep(applied=self.applied),
            quality=Quality(blur_score=0.0, resolution_ok=True, is_grayscale=page.pixels.ndim == 2),
        )
        return page, record


class FakeDetector:
    """Returns fixed regions (default: one box near the top-left)."""

    version = "fake-1"

    def __init__(self, regions: Sequence[Region] | None = None) -> None:
        self.regions = (
            tuple(regions)
            if regions is not None
            else (Region(bbox=(10.0, 10.0, 100.0, 30.0), confidence=0.99),)
        )
        self.calls = 0

    def detect(self, page: PageImage, ctx: StageContext) -> list[Region]:
        self.calls += 1
        ctx.deadline.check()
        return list(self.regions)


class FakeRecognizer:
    """Echoes configured lines, or synthesises one line per detected region."""

    version = "fake-1"

    def __init__(self, lines: Sequence[Line] | None = None, text: str = "fake") -> None:
        self.lines = tuple(lines) if lines is not None else None
        self.text = text
        self.calls = 0

    def recognize(
        self, page: PageImage, regions: Sequence[Region], ctx: StageContext
    ) -> list[Line]:
        self.calls += 1
        ctx.deadline.check()
        if self.lines is not None:
            return list(self.lines)
        return [
            Line(
                line_id=f"l{idx}",
                bbox=region.bbox,
                text=self.text,
                confidence=0.99,
                origin=Origin.ocr,
                is_handwritten=False,
                spans=(Span(text=self.text, bbox=region.bbox, confidence=0.99),),
            )
            for idx, region in enumerate(regions)
        ]


class FakeLayout:
    """One paragraph block holding all input lines; optionally one table candidate."""

    version = "fake-1"

    def __init__(self, with_table: bool = False) -> None:
        self.with_table = with_table
        self.calls = 0

    def analyze(self, page: PageImage, lines: Sequence[Line], ctx: StageContext) -> list[Block]:
        self.calls += 1
        ctx.deadline.check()
        blocks: list[Block] = []
        if lines:
            x0 = min(line.bbox[0] for line in lines)
            y0 = min(line.bbox[1] for line in lines)
            x1 = max(line.bbox[2] for line in lines)
            y1 = max(line.bbox[3] for line in lines)
            blocks.append(
                Block(
                    block_id="b0",
                    type=BlockType.paragraph,
                    bbox=(x0, y0, x1, y1),
                    reading_order=0,
                    origin=Origin.ocr,
                    confidence=min(line.confidence for line in lines),
                    lines=tuple(lines),
                )
            )
        if self.with_table:
            blocks.append(
                Block(
                    block_id=f"b{len(blocks)}",
                    type=BlockType.table,
                    bbox=(0.0, float(page.height) / 2, float(page.width), float(page.height)),
                    reading_order=len(blocks),
                    origin=Origin.ocr,
                    confidence=0.9,
                    table=PENDING_TABLE,
                )
            )
        return blocks


class FakeTable:
    """Fixed 2x2 grid: cells quarter the candidate block's bbox."""

    version = "fake-1"

    def __init__(self) -> None:
        self.calls = 0

    def recognize(self, page: PageImage, block: Block, ctx: StageContext) -> Table:
        self.calls += 1
        ctx.deadline.check()
        x0, y0, x1, y1 = block.bbox
        xm, ym = (x0 + x1) / 2, (y0 + y1) / 2
        cells = tuple(
            Cell(
                row=r,
                col=c,
                bbox=(
                    x0 if c == 0 else xm,
                    y0 if r == 0 else ym,
                    xm if c == 0 else x1,
                    ym if r == 0 else y1,
                ),
                text=f"r{r}c{c}",
                confidence=0.95,
                origin=Origin.ocr,
            )
            for r in (0, 1)
            for c in (0, 1)
        )
        return Table(n_rows=2, n_cols=2, header_rows=(0,), cells=cells)


FAKE_ENGINES: tuple[tuple[str, str, type], ...] = (
    ("prep", "fake-prep", FakePrep),
    ("detector", "fake-detector", FakeDetector),
    ("recognizer", "fake-recognizer", FakeRecognizer),
    ("layout", "fake-layout", FakeLayout),
    ("table", "fake-table", FakeTable),
)


def register_fakes(registry: EngineRegistry) -> EngineRegistry:
    """Register all fakes under ``fake-*`` names; returns the registry for chaining."""
    for kind, name, cls in FAKE_ENGINES:
        registry.add(kind, name, cls)
    return registry
