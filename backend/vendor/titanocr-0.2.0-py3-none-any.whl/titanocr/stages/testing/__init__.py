"""Fakes and contract-test bases, importable by engine test suites (phase 03).

``from titanocr.stages.testing import DetectorContractTests`` is the intended
entry point for any engine package proving itself swap-safe (docs/08 §testing).
"""

from titanocr.stages.testing.contract import (
    DetectorContractTests,
    LayoutContractTests,
    PrepContractTests,
    RecognizerContractTests,
    TableContractTests,
    blank_page,
    make_stage_context,
)
from titanocr.stages.testing.fakes import (
    FAKE_ENGINES,
    FakeDetector,
    FakeLayout,
    FakePrep,
    FakeRecognizer,
    FakeTable,
    register_fakes,
)

__all__ = [
    "FAKE_ENGINES",
    "DetectorContractTests",
    "FakeDetector",
    "FakeLayout",
    "FakePrep",
    "FakeRecognizer",
    "FakeTable",
    "LayoutContractTests",
    "PrepContractTests",
    "RecognizerContractTests",
    "TableContractTests",
    "blank_page",
    "make_stage_context",
    "register_fakes",
]
