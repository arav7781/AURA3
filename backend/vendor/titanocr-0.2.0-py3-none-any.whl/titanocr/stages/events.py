"""Worker→parent progress events.

Pool workers (phase 08) push these over the ``mp.Queue``; the parent folds them
into the job table, which status **polling** reads (ADR 0003 #2 — there is no
streaming transport to feed). Frozen dataclasses of plain scalars so they pickle
cheaply across the process boundary.
"""

from dataclasses import dataclass
from typing import Literal

StageStatus = Literal["ok", "fallback", "failed"]
"""``fallback`` = primary lost, the configured fallback engine produced the result."""


@dataclass(frozen=True)
class StageEvent:
    page_no: int
    stage: str
    status: StageStatus
    ms: float


@dataclass(frozen=True)
class PageEvent:
    page_no: int
    route: str
    confidence: float
    triage: str
