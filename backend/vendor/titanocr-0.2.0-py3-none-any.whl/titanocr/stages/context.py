"""Stage execution context (docs/08 §why-stagecontext).

Everything a stage may consult at run time arrives through :class:`StageContext`:
deadline, cost accounting, injected resources and trace correlation. No stage
reaches into globals — that rule (docs/08 rule 5) is what makes two pipeline
versions runnable side by side and a fake registry the entire test setup.
"""

import threading
import time
from collections.abc import Mapping
from dataclasses import dataclass, field
from logging import Logger
from typing import Any, TypeVar

from titanocr.ir import ProvenanceEntry

T = TypeVar("T")


class DeadlineExceeded(Exception):
    """Raised by :meth:`Deadline.check` once the budget is spent.

    Never triggers a fallback engine — an expired deadline propagates so the
    caller can abandon the page instead of burning CPU on a result nobody is
    waiting for.
    """


@dataclass(frozen=True)
class Deadline:
    """Monotonic-clock deadline. Stages call :meth:`check` before expensive work."""

    expires_at: float | None
    """``time.monotonic()`` timestamp, or ``None`` for no deadline."""

    @classmethod
    def after(cls, seconds: float) -> "Deadline":
        return cls(expires_at=time.monotonic() + seconds)

    @classmethod
    def never(cls) -> "Deadline":
        return cls(expires_at=None)

    def remaining(self) -> float:
        """Seconds left; ``inf`` when no deadline, negative once expired."""
        if self.expires_at is None:
            return float("inf")
        return self.expires_at - time.monotonic()

    def expired(self) -> bool:
        return self.remaining() <= 0

    def check(self) -> None:
        remaining = self.remaining()
        if remaining <= 0:
            raise DeadlineExceeded(f"deadline exceeded by {-remaining:.3f}s")


class CostAccumulator:
    """Append-only, thread-safe provenance sink.

    Stages append; nothing reads it for control flow (docs/08). The runner and
    orchestrator take :meth:`snapshot` when assembling the document.
    """

    def __init__(self) -> None:
        self._entries: list[ProvenanceEntry] = []
        self._lock = threading.Lock()

    def add(self, entry: ProvenanceEntry) -> None:
        with self._lock:
            self._entries.append(entry)

    def snapshot(self) -> tuple[ProvenanceEntry, ...]:
        with self._lock:
            return tuple(self._entries)

    def __len__(self) -> int:
        with self._lock:
            return len(self._entries)


class ResourceNotRegistered(LookupError):
    """A stage asked for a resource key nobody registered."""


class ResourceRegistry:
    """Injected clients/indexes/model sessions — handed in, never imported (docs/08 rule 5)."""

    def __init__(self) -> None:
        self._resources: dict[str, object] = {}

    def register(self, key: str, obj: object) -> None:
        if key in self._resources:
            raise ValueError(f"resource {key!r} already registered")
        self._resources[key] = obj

    def get(self, key: str, expected_type: type[T]) -> T:
        if key not in self._resources:
            known = ", ".join(sorted(self._resources)) or "(none)"
            raise ResourceNotRegistered(
                f"resource {key!r} not registered — registered keys: {known}"
            )
        obj = self._resources[key]
        if not isinstance(obj, expected_type):
            raise TypeError(
                f"resource {key!r} is {type(obj).__name__}, expected {expected_type.__name__}"
            )
        return obj

    def keys(self) -> tuple[str, ...]:
        return tuple(sorted(self._resources))


@dataclass(frozen=True)
class StageContext:
    """Per-document execution context threaded through every stage call (docs/08)."""

    doc_id: str
    trace_id: str
    config: Mapping[str, Any]
    deadline: Deadline
    costs: CostAccumulator
    resources: ResourceRegistry
    logger: Logger = field(repr=False)
