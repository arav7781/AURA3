"""Built-in per-page confidence signals (docs/03 §signals) — the triage input.

This is deliberately not a pluggable engine: signals must always be computable and
uniform across pipelines (docs/08 §what-is-deliberately-not-pluggable, cost/deadline
paragraph applies in spirit). Formulas per plan §7 row 3½ / phase 09 §4.5:

- ``mean_rec``            unweighted mean of line confidences
- ``p10_rec``             10th percentile of line confidences
- ``text_coverage``       area of lines with conf ≥ floor ÷ area of all detected lines
- ``low_conf_area_ratio`` area of lines with conf < floor ÷ page area
- ``handwriting_ratio``   **heuristic_v1** (plan P10): area where detection succeeded
  but recognition confidence stayed below the floor ÷ all detected area — the classic
  handwriting signature (docs/03). A heuristic, never a gate; a learned estimator can
  replace it later under the same field name.

The floor is the ``rec_conf_floor`` pipeline param (recognizer stage), default 0.5.
"""

from collections.abc import Sequence

from titanocr.ir import ConfidenceBlock, Line

SIGNALS_VERSION = "builtin-1"

LOW_CONF_FLOOR = 0.5
"""Default per-line confidence floor (``rec_conf_floor`` pipeline param overrides)."""


def _area(bbox: tuple[float, float, float, float]) -> float:
    x0, y0, x1, y1 = bbox
    return max(0.0, x1 - x0) * max(0.0, y1 - y0)


def _clamp01(v: float) -> float:
    return min(1.0, max(0.0, v))


def compute_signals(
    lines: Sequence[Line],
    width: int,
    height: int,
    *,
    rec_conf_floor: float = LOW_CONF_FLOOR,
) -> ConfidenceBlock:
    """Fold recognized lines into ``page.confidence``.

    A page with no lines reads as "confidently empty": recognition signals stay at
    1.0 (no evidence of degradation) while ``text_coverage`` at 1.0 reflects that
    every detected region (none) was recognized. Triage owns the interpretation.
    """
    page_area = float(width * height)
    if not lines:
        return ConfidenceBlock(
            mean_rec=1.0,
            p10_rec=1.0,
            text_coverage=1.0,
            low_conf_area_ratio=0.0,
            handwriting_ratio=0.0,
        )

    confidences = sorted(line.confidence for line in lines)
    mean_rec = sum(confidences) / len(confidences)
    p10_rec = confidences[max(0, (len(confidences) - 1) // 10)]

    text_area = sum(_area(line.bbox) for line in lines)
    covered_area = sum(_area(line.bbox) for line in lines if line.confidence >= rec_conf_floor)
    low_conf_area = sum(_area(line.bbox) for line in lines if line.confidence < rec_conf_floor)

    return ConfidenceBlock(
        mean_rec=_clamp01(mean_rec),
        p10_rec=_clamp01(p10_rec),
        text_coverage=_clamp01(covered_area / text_area) if text_area > 0 else 1.0,
        low_conf_area_ratio=_clamp01(low_conf_area / page_area) if page_area > 0 else 0.0,
        # heuristic_v1: detected-but-unrecognized area fraction (see module docstring).
        handwriting_ratio=_clamp01(low_conf_area / text_area) if text_area > 0 else 0.0,
    )
