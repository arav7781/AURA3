"""Engine registry: named implementations per stage kind (docs/08 §registry).

Implementations self-register with ``@register(kind, name)``; pipeline YAML selects
them by name. The registry holds *classes*, not instances — construction happens in
:func:`titanocr.stages.pipeline.resolve` with the config's params, so no engine
carries module-level state.

The lookup-failure message is what an operator sees when a config typo fails
readiness: it always names the known alternatives.
"""

from collections.abc import Callable
from typing import Any, TypeVar

KINDS: frozenset[str] = frozenset(
    {
        "prep",
        "detector",
        "recognizer",
        "layout",
        "table",
        "triage",
        "escalator",
        "pdftext",
        "rasterizer",
    }
)

C = TypeVar("C", bound=type[Any])


class UnknownEngineError(LookupError):
    """Unknown kind or engine name — the message lists what *is* registered."""


class DuplicateEngineError(ValueError):
    """Two engines registered under the same (kind, name)."""


class EngineRegistry:
    def __init__(self) -> None:
        self._engines: dict[str, dict[str, type[Any]]] = {kind: {} for kind in sorted(KINDS)}

    def add(self, kind: str, name: str, cls: type[Any]) -> None:
        engines = self._engines_for(kind)
        if name in engines:
            raise DuplicateEngineError(
                f"{kind} engine {name!r} already registered as "
                f"{engines[name].__module__}.{engines[name].__qualname__}"
            )
        engines[name] = cls

    def get_engine(self, kind: str, name: str) -> type[Any]:
        engines = self._engines_for(kind)
        if name not in engines:
            known = ", ".join(sorted(engines)) or "(none registered)"
            raise UnknownEngineError(
                f"unknown {kind} engine {name!r} — known {kind} engines: {known}"
            )
        return engines[name]

    def names(self, kind: str) -> tuple[str, ...]:
        return tuple(sorted(self._engines_for(kind)))

    def _engines_for(self, kind: str) -> dict[str, type[Any]]:
        if kind not in self._engines:
            known = ", ".join(sorted(KINDS))
            raise UnknownEngineError(f"unknown engine kind {kind!r} — kinds: {known}")
        return self._engines[kind]


DEFAULT_REGISTRY = EngineRegistry()
"""Process-wide registry that ``@register`` decorators populate at import time."""


def register(kind: str, name: str, registry: EngineRegistry | None = None) -> Callable[[C], C]:
    """Class decorator: ``@register("detector", "ppocr-v5-det")``."""

    target = DEFAULT_REGISTRY if registry is None else registry

    def decorate(cls: C) -> C:
        target.add(kind, name, cls)
        return cls

    return decorate


def get_engine(kind: str, name: str, registry: EngineRegistry | None = None) -> type[Any]:
    target = DEFAULT_REGISTRY if registry is None else registry
    return target.get_engine(kind, name)
