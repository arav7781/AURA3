"""Stage interfaces & pipeline runner (docs/08) — the seam engines plug into.

Protocols + context + registry + validated pipeline config + per-page runner +
progress events. Imports only :mod:`titanocr.ir` and infrastructure libs
(numpy, pyyaml); no vendor code lives here (import-linter enforces it).
"""

from titanocr.stages.blocks import (
    BLOCKS_VERSION,
    PARAGRAPH_GAP_RATIO,
    cluster_paragraph_blocks,
    is_section_heading,
)
from titanocr.stages.context import (
    CostAccumulator,
    Deadline,
    DeadlineExceeded,
    ResourceNotRegistered,
    ResourceRegistry,
    StageContext,
)
from titanocr.stages.events import PageEvent, StageEvent, StageStatus
from titanocr.stages.pipeline import (
    STAGE_TO_KIND,
    PageRunner,
    PipelineConfig,
    PipelineConfigError,
    ResolvedPipeline,
    ResolvedStage,
    StageFailure,
    StageSpec,
    load_pipeline,
    resolve,
)
from titanocr.stages.protocols import (
    PENDING_TABLE,
    EngineDegraded,
    Escalator,
    LayoutAnalyzer,
    PageImage,
    PrepRecord,
    Preprocessor,
    Region,
    TableRecognizer,
    TextDetector,
    TextRecognizer,
    TriageAction,
    TriageDecision,
    TriagePolicy,
)
from titanocr.stages.registry import (
    DEFAULT_REGISTRY,
    KINDS,
    DuplicateEngineError,
    EngineRegistry,
    UnknownEngineError,
    get_engine,
    register,
)
from titanocr.stages.signals import LOW_CONF_FLOOR, SIGNALS_VERSION, compute_signals

__all__ = [
    "BLOCKS_VERSION",
    "DEFAULT_REGISTRY",
    "KINDS",
    "LOW_CONF_FLOOR",
    "PARAGRAPH_GAP_RATIO",
    "PENDING_TABLE",
    "SIGNALS_VERSION",
    "STAGE_TO_KIND",
    "CostAccumulator",
    "Deadline",
    "DeadlineExceeded",
    "DuplicateEngineError",
    "EngineDegraded",
    "EngineRegistry",
    "Escalator",
    "LayoutAnalyzer",
    "PageEvent",
    "PageImage",
    "PageRunner",
    "PipelineConfig",
    "PipelineConfigError",
    "PrepRecord",
    "Preprocessor",
    "Region",
    "ResolvedPipeline",
    "ResolvedStage",
    "ResourceNotRegistered",
    "ResourceRegistry",
    "StageContext",
    "StageEvent",
    "StageFailure",
    "StageSpec",
    "StageStatus",
    "TableRecognizer",
    "TextDetector",
    "TextRecognizer",
    "TriageAction",
    "TriageDecision",
    "TriagePolicy",
    "UnknownEngineError",
    "cluster_paragraph_blocks",
    "compute_signals",
    "get_engine",
    "is_section_heading",
    "load_pipeline",
    "register",
    "resolve",
]
