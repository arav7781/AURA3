"""The OCR-side seven stage Protocols (docs/08 §the-interfaces, signatures verbatim).

``Extractor``/``Linker``/``Verifier`` arrive with phase 17 (ADR 0003 #4 — no dead
interfaces now). ``Escalator`` is the only ``async`` interface: it is the only one
that does IO and it runs in the parent orchestrator; everything else is synchronous
CPU work executed inside a pool worker (docs/07).

Conventions engines are expected to honour (enforced by the contract suites in
:mod:`titanocr.stages.testing`):

- call ``ctx.deadline.check()`` before expensive work;
- never mutate the input :class:`PageImage`;
- be deterministic — identical input, identical output;
- expose a ``version: str`` class attribute (recorded in provenance);
- raise :class:`EngineDegraded` to hand over to a configured fallback engine
  without counting as a failure (phase-03 decision, see plan §6 log).
"""

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Protocol, runtime_checkable

import numpy as np
import numpy.typing as npt

from titanocr.ir import Block, Line, Page, Prep, Quality, Table
from titanocr.stages.context import StageContext


class EngineDegraded(Exception):
    """An engine judged its own output too poor to emit.

    Raised instead of returning: the runner treats it as "primary loses → run the
    configured fallback". With no fallback configured it escalates to a stage
    failure — an engine should only raise this when a result genuinely cannot be
    trusted, not as flow control.
    """

    def __init__(self, reason: str, quality: float | None = None) -> None:
        super().__init__(reason)
        self.reason = reason
        self.quality = quality


@dataclass(frozen=True, eq=False)
class PageImage:
    """A raster page in memory: dimensions + dpi + pixel buffer.

    ``pixels`` is ``(height, width)`` grayscale or ``(height, width, channels)``,
    dtype uint8. Equality is identity (numpy arrays make field equality ambiguous);
    compare pixels explicitly where needed.
    """

    width: int
    height: int
    dpi: float | None
    pixels: npt.NDArray[np.uint8]

    def __post_init__(self) -> None:
        if self.pixels.ndim not in (2, 3):
            raise ValueError(f"pixels must be 2-D or 3-D, got ndim={self.pixels.ndim}")
        if self.pixels.shape[0] != self.height or self.pixels.shape[1] != self.width:
            raise ValueError(
                f"pixels shape {self.pixels.shape[:2]} does not match "
                f"(height={self.height}, width={self.width})"
            )
        if self.pixels.dtype != np.uint8:
            raise ValueError(f"pixels dtype must be uint8, got {self.pixels.dtype}")


@dataclass(frozen=True)
class Region:
    """A detected text region (pre-IR): axis-aligned bbox in page-space pixels."""

    bbox: tuple[float, float, float, float]
    confidence: float = 1.0
    block_ids: tuple[str, ...] = ()
    """Blocks this region was grown from, when it came from triage (phase 13).

    Empty for detector output (no blocks exist yet at detection time). The
    escalator replaces exactly these blocks — precise beats a geometric
    coverage guess, and "narrowest failing unit" (docs/03) deserves an exact
    answer where triage already knows it."""
    quad: tuple[tuple[float, float], ...] | None = None
    """The detector's quadrilateral in page-space pixels, when it produced one.

    A recogniser may rectify a slanted line from it — a phone photo's
    perspective leaves lines tilted after the page-level deskew. Never enters
    the IR: every IR bbox stays axis-aligned (docs/02)."""


@dataclass(frozen=True)
class PrepRecord:
    """What preprocessing did to the page — goes into ``page.prep`` / ``page.quality``."""

    prep: Prep
    quality: Quality


class TriageAction(StrEnum):
    accept = "accept"
    escalate_regions = "escalate_regions"
    """The only escalating action (ADR 0023): a page escalates the *regions* it
    could not read, never itself. There is no page unit — text the engine read
    confidently never leaves the machine."""
    reject = "reject"
    review = "review"
    """Accepted content, flagged ``review_required`` — the honest v1 rendering of
    docs/03's "accept, then re-check after stage 6" arm (no stage 6 exists yet)
    and of a structural hit on an otherwise confident page."""


@dataclass(frozen=True)
class TriageDecision:
    """Outcome of the triage policy for one page (docs/03 §policy)."""

    action: TriageAction
    regions: tuple[Region, ...] = ()
    trigger: str = ""
    signals: Mapping[str, float] = field(default_factory=dict[str, float])
    findings: tuple[str, ...] = ()
    """Structural-sanity findings (docs/03 §signals) — recorded whatever the
    action, so a confident page with a structural anomaly stays explainable."""


PENDING_TABLE = Table(n_rows=1, n_cols=1, header_rows=(), cells=())
"""Placeholder carried by a layout-emitted table *candidate* block.

The IR requires a table-typed block to hold a table; the runner replaces it
wholesale with the table stage's output, so the placeholder never survives.
"""


@runtime_checkable
class Preprocessor(Protocol):
    def process(self, page: PageImage, ctx: StageContext) -> tuple[PageImage, PrepRecord]: ...


@runtime_checkable
class TextDetector(Protocol):
    def detect(self, page: PageImage, ctx: StageContext) -> list[Region]: ...


@runtime_checkable
class TextRecognizer(Protocol):
    def recognize(
        self, page: PageImage, regions: Sequence[Region], ctx: StageContext
    ) -> list[Line]: ...


@runtime_checkable
class LayoutAnalyzer(Protocol):
    def analyze(self, page: PageImage, lines: Sequence[Line], ctx: StageContext) -> list[Block]: ...


@runtime_checkable
class TableRecognizer(Protocol):
    def recognize(self, page: PageImage, block: Block, ctx: StageContext) -> Table: ...


@runtime_checkable
class TriagePolicy(Protocol):
    def decide(self, page: Page, ctx: StageContext) -> TriageDecision: ...


@runtime_checkable
class Escalator(Protocol):
    async def escalate(
        self, page: Page, decision: TriageDecision, ctx: StageContext
    ) -> list[Block]: ...
