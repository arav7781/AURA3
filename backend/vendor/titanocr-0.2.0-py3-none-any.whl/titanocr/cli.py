"""The ``titanocr`` command.

::

    titanocr report.pdf                       # Markdown on stdout
    titanocr scan.jpg --format layout         # text, each visual row on one line
    titanocr a.pdf b.png --format json        # one JSON object per document (JSON Lines)
    titanocr report.pdf -o report.md
    titanocr models                           # fetch + verify the default pipeline's models
    titanocr serve --port 8000                # the HTTP service and demo UI, no container
    titanocr stdio                            # the JSON-lines bridge (titanocr.stdio)

Exit status: 0 when every document was processed, 1 when any was refused,
rejected or failed (each reported on stderr), 2 when the engine could not start.
"""

import argparse
import asyncio
import json
import sys
from pathlib import Path
from typing import IO, TYPE_CHECKING

from titanocr.results import OCRResult

if TYPE_CHECKING:
    from titanocr.runtime import RuntimeConfig

_FORMATS = {
    "markdown": ".md",
    "spatial": ".md",
    "text": ".txt",
    "layout": ".txt",
    "json": ".json",
    "ir": ".json",
}
_COMMANDS = {"ocr", "models", "serve", "stdio"}


def _version() -> str:
    from titanocr import __version__

    return __version__


def _engine_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--pipeline",
        default="default",
        help="shipped pipeline name or path to a pipeline YAML (default: %(default)s)",
    )
    parser.add_argument(
        "--models-dir",
        type=Path,
        default=None,
        help="where the ONNX models live "
        "(default: $TITANOCR_MODELS_DIR, else ~/.cache/titanocr/models)",
    )
    parser.add_argument(
        "--offline", action="store_true", help="never download models; fail if one is missing"
    )
    parser.add_argument(
        "--workers",
        default="auto",
        help="worker processes: pages run on them in parallel; 'auto' (default) sizes the "
        "pool from this machine's CPUs and memory",
    )
    parser.add_argument(
        "--timeout", type=float, default=600.0, help="per-document deadline, seconds"
    )
    parser.add_argument("--log-level", default="WARNING", help="engine log level (to stderr)")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="titanocr",
        description="Deterministic CPU OCR + document structure: PDF or image in, "
        "Markdown / text / Document IR out.",
    )
    parser.add_argument("--version", action="version", version=f"titanocr {_version()}")
    sub = parser.add_subparsers(dest="command")

    ocr = sub.add_parser("ocr", help="OCR documents (the default command)")
    ocr.add_argument("files", nargs="+", type=Path, help="PDF or image files")
    ocr.add_argument(
        "-f",
        "--format",
        choices=sorted(_FORMATS),
        default="markdown",
        help="markdown (default) · spatial (Markdown with location comments) · text "
        "(reading order) · layout (rows and columns kept) · json (everything) · ir",
    )
    ocr.add_argument(
        "-o",
        "--out",
        type=Path,
        default=None,
        help="output file (one input) or directory (several); default stdout",
    )
    ocr.add_argument("--doc-type", default="auto", choices=["auto", "report", "note"])
    _engine_args(ocr)

    models = sub.add_parser("models", help="fetch and verify the pinned ONNX models")
    models.add_argument("--models-dir", type=Path, default=None)
    models.add_argument(
        "--all", action="store_true", help="every model in the manifest, not just the default's"
    )
    models.add_argument("--pipeline", default="default", help="fetch the models this pipeline uses")
    models.add_argument("--verify", action="store_true", help="verify only; never download")

    serve = sub.add_parser("serve", help="run the HTTP service (API + demo UI)")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    _engine_args(serve)

    stdio = sub.add_parser("stdio", help="JSON-lines engine on stdin/stdout (for bindings)")
    _engine_args(stdio)
    return parser


def _runtime_config(args: argparse.Namespace) -> "RuntimeConfig":
    from titanocr.runtime import RuntimeConfig, parse_workers

    return RuntimeConfig(
        pipeline=args.pipeline,
        models_dir=args.models_dir,
        download=not args.offline,
        workers=parse_workers(args.workers),
        timeout_s=args.timeout,
        log_level=args.log_level,
    )


def _render(result: OCRResult, fmt: str) -> str:
    if fmt == "markdown":
        return result.markdown
    if fmt == "spatial":
        return result.spatial_markdown
    if fmt == "text":
        return result.text
    if fmt == "layout":
        return result.layout_text
    if fmt == "ir":
        return json.dumps(result.ir.model_dump(mode="json"), ensure_ascii=False) + "\n"
    return json.dumps(result.to_dict(), ensure_ascii=False) + "\n"


def _progress(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


async def _ocr(args: argparse.Namespace, out: IO[str]) -> int:
    from titanocr.runtime import DocumentError, LocalService, RuntimeStartError

    files: list[Path] = args.files
    missing = [f for f in files if not f.is_file()]
    if missing:
        print(f"titanocr: no such file: {', '.join(map(str, missing))}", file=sys.stderr)
        return 1
    if args.out is not None and len(files) > 1:
        args.out.mkdir(parents=True, exist_ok=True)
    code = 0
    try:
        async with LocalService(_runtime_config(args), progress=_progress) as svc:
            for path in files:
                try:
                    status, ir = await svc.process(
                        path.read_bytes(), filename=path.name, doc_type_hint=args.doc_type
                    )
                except DocumentError as exc:
                    print(f"titanocr: {exc}", file=sys.stderr)
                    code = 1
                    continue
                result = OCRResult.from_service(status, ir)
                rendered = _render(result, args.format)
                if result.review_required:
                    print(
                        f"titanocr: {path.name}: some content is below the confidence "
                        "threshold and flagged for review",
                        file=sys.stderr,
                    )
                if args.out is None:
                    out.write(rendered)
                    out.flush()
                else:
                    target = (
                        args.out / (path.stem + _FORMATS[args.format])
                        if len(files) > 1
                        else args.out
                    )
                    target.write_text(rendered, encoding="utf-8")
    except RuntimeStartError as exc:
        print(f"titanocr: engine failed to start: {exc}", file=sys.stderr)
        return 2
    return code


def _models(args: argparse.Namespace) -> int:
    from titanocr.modelstore import ModelsUnavailable, fetch_models
    from titanocr.runtime import RuntimeStartError, materialize_pipeline, resolve_pipeline_file

    filenames: set[str] | None = None
    if not args.all:
        import tempfile

        try:
            source = resolve_pipeline_file(args.pipeline)
        except RuntimeStartError as exc:
            print(f"titanocr: {exc}", file=sys.stderr)
            return 2
        with tempfile.TemporaryDirectory() as tmp:
            # The chain walk collects every model the pipeline and its bases name.
            _, filenames = materialize_pipeline(source, Path(tmp), Path(tmp))
    try:
        target = fetch_models(
            args.models_dir, filenames=filenames, verify_only=args.verify, progress=_progress
        )
    except ModelsUnavailable as exc:
        print(f"titanocr: {exc}", file=sys.stderr)
        return 1
    print(f"models ready in {target}", file=sys.stderr)
    return 0


def _serve(args: argparse.Namespace) -> int:
    import shutil

    import uvicorn

    from titanocr.main import create_app
    from titanocr.runtime import RuntimeStartError, prepare

    try:
        prepared = prepare(_runtime_config(args), progress=_progress)
    except RuntimeStartError as exc:
        print(f"titanocr: engine failed to start: {exc}", file=sys.stderr)
        return 2
    try:
        uvicorn.run(
            create_app(prepared.settings),
            host=args.host,
            port=args.port,
            log_level=args.log_level.lower(),
        )
    finally:
        shutil.rmtree(prepared.work_dir, ignore_errors=True)
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    # `titanocr FILE` is shorthand for `titanocr ocr FILE`.
    if argv and argv[0] not in _COMMANDS and not argv[0].startswith("-"):
        argv.insert(0, "ocr")
    args = build_parser().parse_args(argv)
    if args.command is None:
        build_parser().print_help(sys.stderr)
        return 2
    if args.command == "models":
        return _models(args)
    if args.command == "serve":
        return _serve(args)

    from titanocr.stdio import claim_stdout, serve

    # Everything below owns this process: point fd 1 at stderr so the service's
    # JSON logs (and anything a worker prints) can never mix into the output.
    out = claim_stdout()
    if args.command == "stdio":
        return asyncio.run(serve(_runtime_config(args), out))
    return asyncio.run(_ocr(args, out))


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
