"""A private, in-process TitanOCR service — what the CLI and the stdio bridge run.

Nothing here is a second pipeline. :class:`LocalService` starts the real
application (``main.create_app``) with its real lifespan — config validation,
model checksums, the spawn worker pool with its thread pins and warm-up — and
talks to it over an in-memory ASGI transport, exactly as ``eval.harness.run``
does. A document processed through the library, the CLI, the JavaScript bridge,
the container or ``make eval`` meets the same code and yields the same IR.

What this module adds is the part a service deployment gets from its image and
its environment: a pipeline directory whose model paths point at wherever the
models actually live (a source checkout's ``models/`` or the user cache), those
models fetched and checksummed on first use, and a private scratch directory for
artifacts that is removed on close.

It must only run in a process whose ``__main__`` is safe to re-import — the pool
spawns its workers with the ``spawn`` start method. The CLI entry points and
``python -m titanocr`` are; an arbitrary user script may not be, which is why the
library's :class:`titanocr.Engine` runs this in a helper process of its own.
"""

import asyncio
import logging
import mimetypes
import os
import shutil
import tempfile
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import yaml

from titanocr.modelstore import (
    ModelsUnavailable,
    default_models_dir,
    ensure_models,
    model_files_in_pipeline,
)
from titanocr.resources import pipelines_dir

logger = logging.getLogger("titanocr.runtime")

TERMINAL = frozenset({"done", "partial", "failed", "rejected"})
_POLL_S = 0.05
_READY_POLL_S = 0.1


def _silent(_message: str) -> None:
    """The default progress sink: say nothing."""


class RuntimeStartError(RuntimeError):
    """The engine could not become ready; the message names every failed check."""


class DocumentError(RuntimeError):
    """A document was refused or could not be processed."""

    def __init__(self, message: str, *, status: str, reason: str | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.reason = reason


@dataclass(frozen=True)
class RuntimeConfig:
    pipeline: str = "default"
    """A shipped pipeline's name (``default``, ``with-vlm``) or a path to a YAML file."""
    models_dir: Path | None = None
    """``None`` = :func:`titanocr.modelstore.default_models_dir`."""
    download: bool = True
    """Fetch missing models (checksummed) before starting; off = fail instead."""
    workers: int = 1
    """Resolved pool size — see :func:`auto_workers` for the ``auto`` default."""
    timeout_s: float = 600.0
    """Per-document deadline, and the budget for the engine to become ready."""
    log_level: str = "WARNING"
    page_cap: int = 200
    upload_max_mb: int = 200


WORKER_MEMORY_BYTES = 1_500_000_000
"""Resident memory one pool worker needs while it processes a 300-DPI scanned
page with the shipped models: measured 1.0-1.5 GB per worker on FUNSD pages
(ADR 0026, docs/notes/throughput-2026-09-27.md)."""

AUTO_MEMORY_FRACTION = 0.5
"""``auto`` never plans to use more than this fraction of physical memory."""


def _physical_memory() -> int | None:
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
    except (ValueError, OSError, AttributeError):
        return None


def auto_workers() -> int:
    """The pool size ``workers="auto"`` means on this machine.

    One worker per CPU this process may run on, less one for the orchestrator
    and the caller (hard rule 8: ``workers x intra_op(=1) <= CPU limit``), and
    no more than half of physical memory at :data:`WORKER_MEMORY_BYTES` each.
    Pages of a document run on the workers in parallel, so this is what makes
    a 40-page document take a fraction of 40 pages' time.
    """
    cpus = os.process_cpu_count() or os.cpu_count() or 2
    by_cpu = max(1, cpus - 1)
    memory = _physical_memory()
    if memory is None:
        return by_cpu
    by_memory = max(1, int(memory * AUTO_MEMORY_FRACTION // WORKER_MEMORY_BYTES))
    return min(by_cpu, by_memory)


def parse_workers(value: str | int) -> int:
    """``"auto"`` or a positive integer (CLI, stdio and library all accept both)."""
    if value == "auto":
        return auto_workers()
    count = int(value)
    if count < 1:
        raise ValueError("workers must be at least 1 (or 'auto')")
    return count


def resolve_pipeline_file(pipeline: str) -> Path:
    candidate = Path(pipeline).expanduser()
    if candidate.suffix in {".yaml", ".yml"}:
        if not candidate.is_file():
            raise RuntimeStartError(f"pipeline config not found: {candidate}")
        return candidate.resolve()
    shipped = pipelines_dir() / f"{pipeline}.yaml"
    if not shipped.is_file():
        names = sorted(p.stem for p in pipelines_dir().glob("*.yaml"))
        raise RuntimeStartError(f"unknown pipeline {pipeline!r} — shipped pipelines: {names}")
    return shipped


def _rewrite_models(config: dict[str, Any], models_dir: Path) -> None:
    """Point every ``*model_path`` (at any depth of a stage spec) into ``models_dir``."""

    def walk(params: dict[str, Any]) -> None:
        for key, value in list(params.items()):
            if isinstance(value, dict):
                walk(cast("dict[str, Any]", value))
            elif key.endswith("model_path") and isinstance(value, str):
                path = Path(value)
                params[key] = str(path if path.is_absolute() else models_dir / path.name)

    for spec in cast("dict[str, Any]", config.get("stages") or {}).values():
        if isinstance(spec, dict):
            walk(cast("dict[str, Any]", spec))


def materialize_pipeline(source: Path, dest_dir: Path, models_dir: Path) -> tuple[str, set[str]]:
    """Write ``source`` (and its ``extends`` chain) into ``dest_dir`` with every model
    path pointing into ``models_dir``. Returns the pipeline's name and the model
    files the whole chain references.

    Only the selected pipeline lands in ``dest_dir`` itself — the service serves
    every YAML file there, and an unselected one that cannot start (``with-vlm``
    without an endpoint) would fail readiness for all of them. Bases go into
    ``dest_dir/base/``, which the service does not scan.
    """
    base_dir = dest_dir / "base"
    models: set[str] = set()

    def write(path: Path, target: Path, chain: tuple[Path, ...]) -> None:
        if path in chain:
            raise RuntimeStartError(f"'extends' cycle through {path}")
        raw = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise RuntimeStartError(f"{path}: pipeline config must be a mapping")
        config = cast("dict[str, Any]", raw)
        models.update(model_files_in_pipeline(config))
        _rewrite_models(config, models_dir)
        extends = config.get("extends")
        if isinstance(extends, str) and extends:
            base_path = (path.parent / extends).resolve()
            base_dir.mkdir(parents=True, exist_ok=True)
            base_target = base_dir / base_path.name
            write(base_path, base_target, (*chain, path))
            config["extends"] = (
                base_target.name if target.parent == base_dir else f"base/{base_target.name}"
            )
        target.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")

    dest_dir.mkdir(parents=True, exist_ok=True)
    write(source.resolve(), dest_dir / source.name, ())
    return source.stem, models


@dataclass(frozen=True)
class Prepared:
    """Everything the service needs that an image or an env would otherwise provide."""

    settings: Any  # titanocr.settings.Settings — imported lazily with the app
    work_dir: Path
    """Private scratch (pipelines, artifacts, signals); the caller removes it."""
    pipeline_name: str
    models_dir: Path


def prepare(config: RuntimeConfig, *, progress: Callable[[str], None] | None = None) -> Prepared:
    """Materialise the pipeline, make its models present and verified, build Settings.

    Raises :class:`RuntimeStartError` when a model is missing and may not be
    fetched, or fails its checksum.
    """
    source = resolve_pipeline_file(config.pipeline)
    models_dir = (
        config.models_dir.expanduser() if config.models_dir is not None else default_models_dir()
    )
    work = Path(tempfile.mkdtemp(prefix="titanocr-"))
    try:
        pipeline_dir = work / "pipelines"
        name, needed = materialize_pipeline(source, pipeline_dir, models_dir)
        report = progress if progress is not None else _silent

        def news(message: str) -> None:
            # Only fetches and failures are news; a verified model is the normal case.
            if not message.lstrip().startswith("ok "):
                report(message)

        try:
            ensure_models(needed, models_dir, download=config.download, progress=news)
        except ModelsUnavailable as exc:
            raise RuntimeStartError(str(exc)) from exc

        from titanocr.settings import Settings

        settings = Settings(
            workers=config.workers,
            queue_max=max(32, config.workers * 4),
            upload_max_mb=config.upload_max_mb,
            page_cap=config.page_cap,
            doc_deadline_s=config.timeout_s,
            pipeline_dir=pipeline_dir,
            models_dir=models_dir,
            artifacts_dir=work / "artifacts",
            signals_dir=work / "signals",
            fixtures_dir=work / "no-fixtures",
            log_level=config.log_level,
        )
    except BaseException:
        shutil.rmtree(work, ignore_errors=True)
        raise
    return Prepared(settings=settings, work_dir=work, pipeline_name=name, models_dir=models_dir)


class LocalService:
    """The real service, in this process, over an in-memory transport.

    ``async with LocalService(cfg) as svc: await svc.process(path)``. Startup
    fetches or verifies the pipeline's models, starts the application's own
    lifespan and waits for ``/readyz``; any failed check raises
    :class:`RuntimeStartError` naming it (hard rule 9 — a broken engine never
    processes a document).
    """

    def __init__(
        self, config: RuntimeConfig | None = None, *, progress: Callable[[str], None] | None = None
    ) -> None:
        self.config = config if config is not None else RuntimeConfig()
        self._progress: Callable[[str], None] = progress if progress is not None else _silent
        self._work: Path | None = None
        self._lifespan: Any = None
        self._client: Any = None
        self.pipeline_name = ""
        self.models_dir = Path()

    async def __aenter__(self) -> "LocalService":
        try:
            await self._start()
        except BaseException:
            await self.aclose()
            raise
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    async def _start(self) -> None:
        prepared = prepare(self.config, progress=self._progress)
        self._work = prepared.work_dir
        self.pipeline_name = prepared.pipeline_name
        self.models_dir = prepared.models_dir

        from httpx import ASGITransport, AsyncClient

        from titanocr.main import create_app

        app = create_app(prepared.settings)
        self._lifespan = app.router.lifespan_context(app)
        await self._lifespan.__aenter__()
        self._client = AsyncClient(
            transport=ASGITransport(app=app), base_url="http://titanocr.local", timeout=None
        )
        await self._wait_ready()

    async def _wait_ready(self) -> None:
        deadline = time.monotonic() + self.config.timeout_s
        while True:
            resp = await self._client.get("/readyz")
            body = resp.json()
            if resp.status_code == 200:
                return
            checks = body.get("checks", [])
            # Config and model failures are final; only a warming pool is worth waiting on.
            final = [
                detail
                for check in checks
                if check.get("check") in {"pipeline_config", "models", "artifacts_dir"}
                for detail in check.get("details", [])
            ]
            workers = cast("dict[str, Any]", body.get("workers") or {})
            failures = cast("dict[str, str]", workers.get("warmup_failures") or {})
            final.extend(f"worker warm-up failed: {reason}" for reason in failures.values())
            if final or time.monotonic() > deadline:
                raise RuntimeStartError("; ".join(final or body.get("errors") or ["not ready"]))
            await asyncio.sleep(_READY_POLL_S)

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None
        if self._lifespan is not None:
            lifespan, self._lifespan = self._lifespan, None
            await lifespan.__aexit__(None, None, None)
        if self._work is not None:
            shutil.rmtree(self._work, ignore_errors=True)
            self._work = None

    async def process(
        self,
        data: bytes,
        *,
        filename: str,
        doc_type_hint: str = "auto",
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Submit one document and wait for it. Returns ``(status_document, ir)``.

        Raises :class:`DocumentError` when the upload is refused, the document is
        rejected (unreadable input) or fails outright; a ``partial`` document is
        returned — its failed pages are named in the status document.
        """
        if self._client is None:
            raise RuntimeError("LocalService is not started")
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        resp = await self._client.post(
            "/v1/documents",
            files={"file": (filename, data, mime)},
            data={"pipeline": self.pipeline_name, "doc_type_hint": doc_type_hint},
        )
        # 202 = queued; 200 = an identical earlier upload's result, adopted (dedupe).
        if resp.status_code not in (200, 202):
            detail = resp.json().get("detail", resp.text)
            raise DocumentError(f"{filename}: {detail}", status="refused", reason=str(detail))
        doc_id = resp.json()["doc_id"]
        deadline = time.monotonic() + self.config.timeout_s + 30.0
        while True:
            status = (await self._client.get(f"/v1/documents/{doc_id}")).json()
            if status["status"] in TERMINAL:
                break
            if time.monotonic() > deadline:
                raise DocumentError(f"{filename}: timed out", status="timeout")
            await asyncio.sleep(_POLL_S)
        state = status["status"]
        if state in {"failed", "rejected"}:
            reason = status.get("reject_reason") or next(
                (p.get("reason") for p in status.get("pages", []) if p.get("reason")), None
            )
            raise DocumentError(
                f"{filename}: document {state}: {reason}", status=state, reason=reason
            )
        ir = (await self._client.get(f"/v1/documents/{doc_id}/ir")).json()
        return status, ir


__all__ = [
    "DocumentError",
    "LocalService",
    "Prepared",
    "RuntimeConfig",
    "RuntimeStartError",
    "auto_workers",
    "materialize_pipeline",
    "parse_workers",
    "prepare",
    "resolve_pipeline_file",
]
