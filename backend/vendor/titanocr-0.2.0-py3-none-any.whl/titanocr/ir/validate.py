"""Validator CLI: ``python -m titanocr.ir.validate <file.json>`` — exit 0 valid, 1 not.

The tool both sides of the seam (and later the eval harness) use to check an IR document
against the contract. Errors are printed one per line as ``<json path>: <message>``.
"""

import json
import sys
from pathlib import Path

from pydantic import ValidationError

from titanocr.ir.models import DocumentIR


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 1:
        print("usage: python -m titanocr.ir.validate <file.json>", file=sys.stderr)
        return 1
    path = Path(args[0])
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"cannot read {path}: {exc}", file=sys.stderr)
        return 1
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        print(f"{path} is not valid JSON: {exc}", file=sys.stderr)
        return 1
    try:
        ir = DocumentIR.model_validate(payload)
    except ValidationError as exc:
        print(f"{path}: {exc.error_count()} contract violation(s)", file=sys.stderr)
        for err in exc.errors():
            loc = ".".join(str(part) for part in err["loc"]) or "<document>"
            print(f"  {loc}: {err['msg']}", file=sys.stderr)
        return 1
    print(f"{path}: valid Document IR {ir.ir_version} ({ir.page_count} page(s))")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
