"""Document IR — the central contract (docs/02, ir_version 1.5).

ADRs 0004/0005/0006/0010/0011 record how the contract got here.

Stages 0-5 write toward it, everything downstream reads it. Imports nothing beyond
pydantic and the stdlib so it stays extraction-ready (ADR 0003 #1).

The CLI-bearing submodules (:mod:`titanocr.ir.schema`, :mod:`titanocr.ir.validate`)
are deliberately not re-exported here — pre-importing a module that is also run with
``python -m`` triggers a runpy double-import warning.
"""

from titanocr.ir.enums import BlockType, Origin, PageOrigin, PdfClass, SourceKind
from titanocr.ir.hashing import file_sha256
from titanocr.ir.models import (
    BBox,
    Block,
    Cell,
    Confidence,
    ConfidenceBlock,
    Connector,
    DocumentIR,
    Escalation,
    EscalationCost,
    Line,
    Page,
    Prep,
    ProvenanceEntry,
    Quality,
    Source,
    Span,
    Table,
    Totals,
    canonical_json,
)

__all__ = [
    "BBox",
    "Block",
    "BlockType",
    "Cell",
    "Confidence",
    "ConfidenceBlock",
    "Connector",
    "DocumentIR",
    "Escalation",
    "EscalationCost",
    "Line",
    "Origin",
    "Page",
    "PageOrigin",
    "PdfClass",
    "Prep",
    "ProvenanceEntry",
    "Quality",
    "Source",
    "SourceKind",
    "Span",
    "Table",
    "Totals",
    "canonical_json",
    "file_sha256",
]
