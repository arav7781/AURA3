"""Closed vocabularies of the Document IR (docs/02) and stage-1 classification (ADR 0001)."""

from enum import StrEnum


class Origin(StrEnum):
    """Where a piece of text came from. Downstream trusts digital > ocr > vlm (docs/02 inv. 2)."""

    digital = "digital"
    ocr = "ocr"
    vlm = "vlm"


class PageOrigin(StrEnum):
    """Page-level origin; `mixed` means blocks on the page disagree (e.g. after escalation)."""

    digital = "digital"
    ocr = "ocr"
    mixed = "mixed"


class BlockType(StrEnum):
    paragraph = "paragraph"
    header = "header"
    footer = "footer"
    table = "table"
    figure = "figure"
    kv = "kv"
    signature = "signature"
    rule = "rule"
    """IR 1.5 (ADR 0011): a horizontal division drawn on the page."""
    connector = "connector"
    """IR 1.6 (ADR 0012): a drawn stroke joining two places on the page — a
    diagram's arrow, with the path it takes and the ends that carry a head."""
    formula = "formula"
    """IR 1.8 (ADR 0018): a region of display mathematics. Carries its exact
    glyphs and their geometry and says only that they are mathematics — it makes
    no claim about what the mathematics *means*, and its ``lines`` are the same
    measured text any other block carries. Transcription to LaTeX is phase 21."""


class SourceKind(StrEnum):
    upload = "upload"
    url = "url"
    blob = "blob"


class PdfClass(StrEnum):
    """Stage-1 PDF classification vocabulary, as emitted by pdf-inspector (ADR 0001)."""

    TextBased = "TextBased"
    Scanned = "Scanned"
    ImageBased = "ImageBased"
    Mixed = "Mixed"
