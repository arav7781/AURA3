"""Document IR models — the central contract (docs/02, ir_version 1.8).

ADRs 0004/0005/0006/0010/0011/0012 record how the contract got here.

Every model is frozen and rejects unknown fields; every invariant of docs/02 is enforced
here by validators, not by convention. Field names match the schema in docs/02 exactly.

Serialisation convention (fixed in phase 02 — reuse, don't reinvent):
:func:`canonical_json` — sorted keys, compact separators, UTF-8 (no ASCII escaping),
floats left raw (Python's shortest-round-trip repr; no rounding). Byte-identical for
equal models, which is what determinism and dedupe key off.
"""

import json
from typing import Annotated, Literal, Self
from uuid import UUID

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, model_validator

from titanocr.ir.enums import BlockType, Origin, PageOrigin, SourceKind


def _validate_bbox(v: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
    x0, y0, x1, y1 = v
    if min(x0, y0, x1, y1) < 0:
        raise ValueError(f"bbox coordinates must all be >= 0, got {v}")
    if x0 > x1 or y0 > y1:
        raise ValueError(f"bbox must satisfy x0 <= x1 and y0 <= y1, got {v}")
    return v


BBox = Annotated[tuple[float, float, float, float], AfterValidator(_validate_bbox)]
"""Page-space pixels ``(x0, y0, x1, y1)``, origin top-left (docs/02 invariant 3)."""

Confidence = Annotated[float, Field(ge=0.0, le=1.0)]


class _IRBase(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")


class Span(_IRBase):
    """Word-level unit. Engines without word boxes emit one span covering the line."""

    text: str
    bbox: BBox
    confidence: Confidence


class Line(_IRBase):
    line_id: str
    bbox: BBox
    text: str
    confidence: Confidence
    origin: Origin
    is_handwritten: bool
    spans: tuple[Span, ...] = Field(min_length=1)


class Cell(_IRBase):
    row: int = Field(ge=0)
    col: int = Field(ge=0)
    row_span: int = Field(default=1, ge=1)
    col_span: int = Field(default=1, ge=1)
    bbox: BBox
    text: str
    confidence: Confidence
    origin: Origin


class Table(_IRBase):
    n_rows: int = Field(ge=1)
    n_cols: int = Field(ge=1)
    header_rows: tuple[int, ...]
    cells: tuple[Cell, ...]

    @model_validator(mode="after")
    def _check_table(self) -> Self:
        for h in self.header_rows:
            if not 0 <= h < self.n_rows:
                raise ValueError(f"header_rows index {h} outside 0..{self.n_rows - 1}")
        seen: set[tuple[int, int]] = set()
        for c in self.cells:
            if c.row + c.row_span > self.n_rows or c.col + c.col_span > self.n_cols:
                raise ValueError(
                    f"cell at ({c.row},{c.col}) span ({c.row_span},{c.col_span}) exceeds "
                    f"table grid {self.n_rows}x{self.n_cols}"
                )
            if (c.row, c.col) in seen:
                raise ValueError(f"duplicate cell origin ({c.row},{c.col})")
            seen.add((c.row, c.col))
        return self


_VISUAL_BLOCK_TYPES = frozenset(
    {BlockType.figure, BlockType.signature, BlockType.rule, BlockType.connector}
)
"""Block types that are non-text regions by construction and may therefore carry
no lines: the layout model's figure/image/chart/seal finds (IR 1.4, ADR 0010),
detected rules (IR 1.5, ADR 0011) and drawn connectors (IR 1.6, ADR 0012).

The last two are valid IR but opt-in: no default pipeline emits a ``rule``
(ADR 0014) or a ``connector`` (ADR 0012), so a consumer meets them only from a
pipeline that asked for them."""


class Connector(_IRBase):
    """IR 1.6 (ADR 0012): a drawn stroke that joins two places on the page.

    ``path`` is the stroke's medial line in page-space pixels, start to end —
    a polyline, because a real connector bends around what is in its way and a
    box could only say where it went if it went straight. ``head_start`` /
    ``head_end`` mark the ends drawn with an arrowhead; both false is an
    undirected join, which is a finding, not a failure.

    ``from_block_id`` / ``to_block_id`` name the blocks the ends land on when
    an end lands on one — that is what turns a stroke into an edge between two
    named things. Either may be ``None``: an arrow into empty space, or into a
    picture with no recognised text, is still an arrow, and guessing an endpoint
    would invent a relationship the document does not state (hard rule 12).

    IR **1.7** (ADR 0016): ``from_line_id`` / ``to_line_id`` name the *labels*
    the ends land on, and ``label_line_id`` the label written on the stroke
    itself. On a diagram the block anchors say almost nothing — a layout model
    returns the whole diagram as one ``figure``, so every arrow in it starts and
    ends in the same block — while the labels are exactly the named things the
    arrow joins: ``NE`` --*commission*--> ``LP``. Ids, not text, so the text
    stays in one place and every anchor is traceable to a line with its own bbox
    and confidence (hard rule 3).
    """

    path: tuple[tuple[float, float], ...] = Field(min_length=2)
    head_start: bool = False
    head_end: bool = False
    from_block_id: str | None = None
    to_block_id: str | None = None
    from_line_id: str | None = None
    to_line_id: str | None = None
    label_line_id: str | None = None

    @model_validator(mode="after")
    def _check_path(self) -> Self:
        for x, y in self.path:
            if x < 0 or y < 0:
                raise ValueError(f"connector path point must be >= 0, got {(x, y)}")
        return self


class Block(_IRBase):
    block_id: str
    type: BlockType
    bbox: BBox
    reading_order: int = Field(ge=0)
    origin: Origin
    confidence: Confidence
    lines: tuple[Line, ...] | None = None
    table: Table | None = None
    table_failed: bool = False
    """IR 1.2 (ADR 0005): both table engines failed on this block — ``table`` is
    the untrusted placeholder, ``lines`` remain the delivered content."""
    connector: Connector | None = None
    """IR 1.6 (ADR 0012): the drawn stroke a ``connector`` block *is*. Required
    on that type and forbidden on every other, the same way ``table`` is."""

    @model_validator(mode="after")
    def _check_content(self) -> Self:
        if (self.connector is not None) != (self.type is BlockType.connector):
            raise ValueError(
                "a connector is carried by exactly the blocks of type 'connector', "
                f"not by '{self.type}'"
            )
        if self.type is BlockType.table:
            if self.table is None:
                raise ValueError("block of type 'table' must carry a table")
            # IR 1.1 (ADR 0004): a table block may also carry the recognised
            # lines assigned to its region — never an empty tuple, though.
            if self.lines is not None and len(self.lines) == 0:
                raise ValueError("block of type 'table' must not carry an empty lines tuple")
            if self.table_failed and not self.lines:
                raise ValueError(
                    "a table_failed block must carry its lines — data is never lost (plan §7)"
                )
        else:
            # IR 1.4 (ADR 0010): a visual block (a logo, chart, photo, stamp)
            # holds no text by construction — its content is its bbox plus the
            # page raster underneath. Still never an *empty* tuple: absent is
            # `None`, so "no text" and "text we lost" stay distinguishable.
            if self.type in _VISUAL_BLOCK_TYPES:
                if self.lines is not None and len(self.lines) == 0:
                    raise ValueError(
                        f"block of type '{self.type}' must not carry an empty lines tuple "
                        "— use null for a region with no text"
                    )
            elif self.lines is None or len(self.lines) == 0:
                raise ValueError(f"block of type '{self.type}' must carry non-empty lines")
            if self.table is not None:
                raise ValueError(f"block of type '{self.type}' must not carry a table")
            if self.table_failed:
                raise ValueError(f"table_failed is only valid on 'table' blocks, not '{self.type}'")
        return self


class EscalationCost(_IRBase):
    input_tokens: int = Field(ge=0)
    output_tokens: int = Field(ge=0)
    inr: float = Field(ge=0)


class Escalation(_IRBase):
    """A VLM escalation record. Replaced blocks are retained (docs/02 invariant 4)."""

    region_bbox: BBox
    trigger: str
    signals: dict[str, float]
    provider: str
    model: str
    replaced_block_ids: tuple[str, ...]
    cost: EscalationCost


class Prep(_IRBase):
    """How page-space relates to the original upload (docs/02 invariant 3)."""

    applied: tuple[str, ...]
    skew_deg: float = 0.0
    crop_bbox_in_original: BBox | None = None
    scale: float = Field(default=1.0, gt=0)


class Quality(_IRBase):
    blur_score: float = Field(ge=0)
    resolution_ok: bool
    is_grayscale: bool
    ink_ratio: Annotated[float, Field(ge=0.0, le=1.0)] | None = None
    """IR 1.3 (ADR 0006): fraction of page pixels the prep ink mask marks as ink.
    ``None`` when nothing measured it (digital renders, legacy records) — triage's
    ink-vs-chars checks only fire on a measured value, never on a guess."""


class ConfidenceBlock(_IRBase):
    """Per-page confidence signals — the triage input (docs/03)."""

    mean_rec: Confidence
    p10_rec: Confidence
    text_coverage: Confidence
    low_conf_area_ratio: Confidence
    handwriting_ratio: Confidence


class Page(_IRBase):
    page_no: int = Field(ge=1)
    width: int = Field(gt=0)
    height: int = Field(gt=0)
    dpi_estimate: Annotated[float, Field(gt=0)] | None = None
    origin: PageOrigin
    prep: Prep
    quality: Quality
    confidence: ConfidenceBlock
    blocks: tuple[Block, ...]
    escalations: tuple[Escalation, ...] = ()

    @model_validator(mode="after")
    def _check_reading_order(self) -> Self:
        orders = [b.reading_order for b in self.blocks]
        if len(orders) != len(set(orders)):
            dupes = sorted({o for o in orders if orders.count(o) > 1})
            raise ValueError(f"reading_order values must be unique per page, duplicated: {dupes}")
        return self


class ProvenanceEntry(_IRBase):
    stage: str
    engine: str
    version: str
    ms: float = Field(ge=0)
    cost_inr: float = Field(ge=0)


class Totals(_IRBase):
    ms: float = Field(ge=0)
    cost_inr: float = Field(ge=0)
    escalated_pages: int = Field(ge=0)
    escalated_regions: int = Field(ge=0)


class Source(_IRBase):
    kind: SourceKind
    filename: str
    mime: str
    bytes: int = Field(ge=0)


class DocumentIR(_IRBase):
    ir_version: Literal["1.0", "1.1", "1.2", "1.3", "1.4", "1.5", "1.6", "1.7", "1.8"]
    doc_id: UUID
    content_hash: str = Field(pattern=r"^sha256:[0-9a-f]{64}$")
    source: Source
    page_count: int = Field(ge=1)
    pages: tuple[Page, ...]
    provenance: tuple[ProvenanceEntry, ...]
    totals: Totals

    @model_validator(mode="after")
    def _check_page_count(self) -> Self:
        if len(self.pages) != self.page_count:
            raise ValueError(f"page_count is {self.page_count} but {len(self.pages)} pages present")
        return self


def canonical_json(model: BaseModel) -> str:
    """Byte-stable JSON dump of an IR model (sorted keys, compact, raw floats)."""
    return json.dumps(
        model.model_dump(mode="json"),
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    )
