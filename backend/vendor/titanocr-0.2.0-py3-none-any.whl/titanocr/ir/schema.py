"""JSON Schema export for the Document IR — on demand, never committed (ADR 0003 #5).

Run ``make schema`` (or ``python -m titanocr.ir.schema [out.json]``) to emit the schema.
There is no committed artifact and no CI freshness gate until a non-Python consumer exists;
the pydantic models in :mod:`titanocr.ir.models` are the source of truth.
"""

import json
import sys
from pathlib import Path
from typing import Any

from titanocr.ir.models import DocumentIR


def export_json_schema() -> dict[str, Any]:
    """The Document IR contract as a JSON Schema document."""
    return DocumentIR.model_json_schema()


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    text = json.dumps(export_json_schema(), indent=2, sort_keys=True, ensure_ascii=False)
    if args:
        Path(args[0]).write_text(text + "\n", encoding="utf-8")
        print(f"wrote JSON Schema to {args[0]}", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
