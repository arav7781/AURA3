"""Content hashing for the v1 `content_hash` field and dedupe key.

v1 hashes the whole uploaded file (ADR 0003 #6): same bytes -> same hash -> same result,
served from cache. The page-order-independent scheme described in docs/02 ("hash each
page's normalised content, sort, hash the concatenation") is deliberately NOT built here —
it serves dedupe economics at production scale. When that matters, implement
docs/02's scheme; the IR field name does not change. Do not reinvent it half-way.
"""

import hashlib
from pathlib import Path

_CHUNK = 1 << 20


def file_sha256(data: bytes | Path) -> str:
    """Return ``"sha256:<hex>"`` of raw bytes or of a file's contents (read in chunks)."""
    h = hashlib.sha256()
    if isinstance(data, bytes):
        h.update(data)
    else:
        with data.open("rb") as f:
            while chunk := f.read(_CHUNK):
                h.update(chunk)
    return f"sha256:{h.hexdigest()}"
