"""``titanocr stdio`` — one warm engine behind a JSON-lines protocol on stdin/stdout.

This is how :class:`titanocr.Engine` (Python) and the ``titanocr`` npm package
(JavaScript) drive the engine: a helper process they start once and keep, so the
worker pool warms up once and every later document is fast. The helper's
``__main__`` is ``titanocr.__main__`` — safe for the pool's ``spawn`` workers to
re-import — and the caller's process never loads OpenCV or ONNX Runtime at all.

Protocol version 1. Every message is one JSON object on one line (UTF-8).

The helper writes, once, before anything else::

    {"type": "ready", "protocol": 1, "version": "0.2.0", "pipeline": "default", ...}
    {"type": "fatal", "error": {"type": "RuntimeStartError", "message": "..."}}

(``fatal`` is followed by exit code 2.) Requests, any number, concurrently::

    {"id": 1, "op": "ocr", "path": "/abs/report.pdf"}
    {"id": 2, "op": "ocr", "data_b64": "...", "filename": "scan.png",
     "doc_type_hint": "auto", "outputs": ["markdown", "text"]}
    {"id": 3, "op": "ping"}
    {"id": 4, "op": "shutdown"}

and one response per request, in completion order, matched by ``id``::

    {"id": 1, "ok": true, "result": {...}}          # OCRResult.to_dict(outputs)
    {"id": 2, "ok": false, "error": {"type": "DocumentError", "message": "...",
                                     "status": "rejected", "reason": "..."}}

Closing stdin is a shutdown too. Logs, warnings and model-download progress go
to stderr; stdout carries protocol lines and nothing else — file descriptor 1 is
pointed at stderr before the service starts, so neither the service's own JSON
logs nor anything a pool worker prints can corrupt the stream.
"""

import asyncio
import base64
import json
import os
import sys
import threading
from pathlib import Path
from typing import IO, Any

from titanocr.results import OUTPUTS, OCRResult
from titanocr.runtime import DocumentError, LocalService, RuntimeConfig, RuntimeStartError

PROTOCOL_VERSION = 1


def claim_stdout() -> IO[str]:
    """Return a private handle on the real stdout and point fd 1 (and ``sys.stdout``)
    at stderr, so nothing but the caller's own writes can reach the real stdout."""
    sys.stdout.flush()
    private = os.fdopen(os.dup(1), "w", encoding="utf-8", buffering=1)
    os.dup2(2, 1)
    sys.stdout = sys.stderr
    return private


def _version() -> str:
    from titanocr import __version__

    return __version__


def _to_stderr(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


class _Writer:
    def __init__(self, stream: IO[str]) -> None:
        self._stream = stream
        self._lock = threading.Lock()

    def send(self, message: dict[str, Any]) -> None:
        line = json.dumps(message, ensure_ascii=False, separators=(",", ":"))
        with self._lock:
            self._stream.write(line + "\n")
            self._stream.flush()


def _error(exc: BaseException) -> dict[str, Any]:
    error: dict[str, Any] = {"type": type(exc).__name__, "message": str(exc)}
    if isinstance(exc, DocumentError):
        error["status"] = exc.status
        error["reason"] = exc.reason
    return error


async def _handle(svc: LocalService, request: dict[str, Any]) -> dict[str, Any]:
    op = request.get("op", "ocr")
    if op == "ping":
        return {"pong": True}
    if op != "ocr":
        raise ValueError(f"unknown op {op!r}")
    outputs = request.get("outputs", list(OUTPUTS))
    if not isinstance(outputs, list) or not all(isinstance(o, str) for o in outputs):  # pyright: ignore[reportUnknownVariableType]
        raise ValueError("outputs must be a list of strings")
    if "data_b64" in request:
        data = base64.b64decode(request["data_b64"], validate=True)
        filename = str(request.get("filename") or "document")
    elif "path" in request:
        path = Path(str(request["path"])).expanduser()
        data = await asyncio.to_thread(path.read_bytes)  # file IO, not inference (rule 7)
        filename = str(request.get("filename") or path.name)
    else:
        raise ValueError("an ocr request needs 'path' or 'data_b64'")
    status, ir = await svc.process(
        data, filename=filename, doc_type_hint=str(request.get("doc_type_hint", "auto"))
    )
    return OCRResult.from_service(status, ir).to_dict(outputs)  # pyright: ignore[reportUnknownArgumentType]


async def serve(config: RuntimeConfig, out: IO[str]) -> int:
    """Run the protocol until shutdown or stdin EOF. Returns the exit code."""
    writer = _Writer(out)
    try:
        svc = LocalService(config, progress=_to_stderr)
        await svc.__aenter__()
    except RuntimeStartError as exc:
        writer.send({"type": "fatal", "error": _error(exc)})
        return 2
    loop = asyncio.get_running_loop()
    requests: asyncio.Queue[str | None] = asyncio.Queue()

    def read_stdin() -> None:
        for raw in sys.stdin:
            loop.call_soon_threadsafe(requests.put_nowait, raw)
        loop.call_soon_threadsafe(requests.put_nowait, None)

    threading.Thread(target=read_stdin, name="titanocr-stdin", daemon=True).start()
    writer.send(
        {
            "type": "ready",
            "protocol": PROTOCOL_VERSION,
            "version": _version(),
            "pipeline": svc.pipeline_name,
            "models_dir": str(svc.models_dir),
            "workers": config.workers,
        }
    )

    async def respond(request_id: Any, request: dict[str, Any]) -> None:
        try:
            result = await _handle(svc, request)
        except Exception as exc:
            writer.send({"id": request_id, "ok": False, "error": _error(exc)})
        else:
            writer.send({"id": request_id, "ok": True, "result": result})

    tasks: set[asyncio.Task[None]] = set()
    try:
        while (raw := await requests.get()) is not None:
            if not raw.strip():
                continue
            try:
                request = json.loads(raw)
                if not isinstance(request, dict):
                    raise ValueError("a request must be a JSON object")
            except ValueError as exc:
                writer.send({"id": None, "ok": False, "error": _error(exc)})
                continue
            request_id = request.get("id")  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
            if request.get("op") == "shutdown":  # pyright: ignore[reportUnknownMemberType]
                writer.send({"id": request_id, "ok": True, "result": {"shutdown": True}})
                break
            task = asyncio.create_task(respond(request_id, request))  # pyright: ignore[reportUnknownArgumentType]
            tasks.add(task)
            task.add_done_callback(tasks.discard)
        if tasks:
            await asyncio.gather(*tasks)
    finally:
        await svc.aclose()
    return 0


__all__ = ["PROTOCOL_VERSION", "claim_stdout", "serve"]
