"""The pinned ONNX models: where they live, which ones a pipeline needs, fetch + verify.

The service never downloads a model: a missing or tampered file fails readiness
(hard rule 9, ``api/models_check.py``). This module is how a model gets onto the
disk in the first place — ``make models`` (``scripts/fetch_models.py``), the
``titanocr models`` command, and the library's first run all come through here, so
there is exactly one download path and it always checksums before it moves a file
into place (tmp file + atomic rename). A download whose bytes do not match the
manifest's sha256 is deleted and reported; it can never masquerade as a model.

The manifest is the pin: the sha256, not the URL, says which weights run
(``models/MANIFEST.json``, shipped inside the wheel as a resource).
"""

import hashlib
import json
import os
import ssl
import urllib.request
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from titanocr.resources import model_manifest_path, source_checkout_root

_CHUNK = 1 << 20

Progress = Callable[[str], None]


class ModelsUnavailable(RuntimeError):
    """A model the pipeline needs is missing or fails its checksum, and was not fetched."""


@dataclass(frozen=True)
class ModelEntry:
    name: str
    filename: str
    url: str
    sha256: str
    licence: str


def load_manifest(path: Path | None = None) -> list[ModelEntry]:
    manifest_path = path if path is not None else model_manifest_path()
    raw = cast("dict[str, Any]", json.loads(manifest_path.read_text(encoding="utf-8")))
    entries: list[ModelEntry] = []
    for item in cast("list[dict[str, Any]]", raw["models"]):
        files = item["files"]
        if not isinstance(files, list) or len(cast("list[Any]", files)) != 1:
            raise ValueError(f"{item['name']}: one file per model in v1")
        entries.append(
            ModelEntry(
                name=str(item["name"]),
                filename=str(cast("list[Any]", files)[0]),
                url=str(item["url"]),
                sha256=str(item["sha256"]),
                licence=str(item.get("licence", "")),
            )
        )
    return entries


def default_models_dir() -> Path:
    """``$TITANOCR_MODELS_DIR``; else a source checkout's ``models/``; else the user cache.

    The cache is ``$XDG_CACHE_HOME/titanocr/models`` (``~/.cache/titanocr/models``
    when unset) — one copy per user, shared by every environment that installs
    the package.
    """
    env = os.environ.get("TITANOCR_MODELS_DIR")
    if env:
        return Path(env).expanduser()
    root = source_checkout_root()
    if root is not None:
        return root / "models"
    cache = os.environ.get("XDG_CACHE_HOME")
    base = Path(cache).expanduser() if cache else Path.home() / ".cache"
    return base / "titanocr" / "models"


def _tls_context() -> ssl.SSLContext:
    """Verify downloads against the operating system's trust store (as pip does).

    A Python from python-build-standalone (what uv provides) carries its own CA
    bundle, so behind a TLS-inspecting corporate proxy every model download
    failed certificate verification although the OS trusted the proxy's root.
    Trust decides only who we talk to: every file is still checked against its
    pinned sha256 before it is used, so no proxy can substitute bytes.
    """
    try:
        import truststore
    except ImportError:  # pragma: no cover - a declared dependency
        return ssl.create_default_context()
    return truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)


def sha256_of(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while chunk := fh.read(_CHUNK):
            digest.update(chunk)
    return digest.hexdigest()


def model_files_in_pipeline(config: dict[str, Any]) -> set[str]:
    """Basenames of every model a raw pipeline mapping references.

    Any stage parameter whose name ends in ``model_path`` names a model file
    (``model_path``, prep's ``cls_model_path``, the recogniser's
    ``second_model_path``, a fallback's ``fallback_params.model_path``); only the
    basename is kept, because the manifest pins files by name.
    """
    names: set[str] = set()

    def walk(params: dict[str, Any]) -> None:
        for key, value in params.items():
            if isinstance(value, dict):
                walk(cast("dict[str, Any]", value))
            elif key.endswith("model_path") and isinstance(value, str):
                names.add(Path(value).name)

    stages = cast("dict[str, Any]", config.get("stages") or {})
    for spec in stages.values():
        if isinstance(spec, dict):
            walk(cast("dict[str, Any]", spec))
    return names


def fetch_one(
    entry: ModelEntry,
    models_dir: Path,
    *,
    verify_only: bool = False,
    progress: Progress = print,
) -> bool:
    """Ensure one manifest entry is present and verified. Returns True on success.

    ``verify_only`` never touches the network: it is the checksum gate the Docker
    build runs over the baked models and CI runs over a restored cache.
    """
    dest = models_dir / entry.filename
    if dest.is_file():
        actual = sha256_of(dest)
        if actual == entry.sha256:
            progress(f"  ok       {dest.name}")
            return True
        if verify_only:
            progress(
                f"  FAILED   {dest.name}: sha256 mismatch "
                f"(expected {entry.sha256[:12]}…, got {actual[:12]}…)"
            )
            return False
        progress(f"  refetch  {dest.name} (sha256 mismatch: {actual[:12]}…)")
    elif verify_only:
        progress(f"  FAILED   {dest.name}: missing — run `titanocr models` or `make models`")
        return False

    models_dir.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + f".{os.getpid()}.tmp")
    progress(f"  fetch    {dest.name}  ←  {entry.url}")
    try:
        with (
            urllib.request.urlopen(entry.url, timeout=120, context=_tls_context()) as resp,
            tmp.open("wb") as out,
        ):
            while chunk := resp.read(_CHUNK):
                out.write(chunk)
    except OSError as exc:
        tmp.unlink(missing_ok=True)
        progress(f"  FAILED   {dest.name}: download error: {exc}")
        return False

    actual = sha256_of(tmp)
    if actual != entry.sha256:
        tmp.unlink(missing_ok=True)
        progress(
            f"  FAILED   {dest.name}: sha256 mismatch after download "
            f"(expected {entry.sha256[:12]}…, got {actual[:12]}…)"
        )
        return False
    tmp.replace(dest)
    progress(f"  verified {dest.name} ({dest.stat().st_size:,} bytes)")
    return True


def ensure_models(
    filenames: Iterable[str],
    models_dir: Path,
    *,
    download: bool,
    manifest: Path | None = None,
    progress: Progress = print,
) -> None:
    """Make every named model present and checksum-verified, or raise.

    With ``download`` off nothing touches the network and a missing file is an
    error naming the command that fetches it. A file the manifest does not pin
    is always an error: every model that runs must be pinned (hard rule 9).
    """
    manifest_path = manifest if manifest is not None else model_manifest_path()
    entries = {entry.filename: entry for entry in load_manifest(manifest_path)}
    problems: list[str] = []
    for filename in sorted(set(filenames)):
        entry = entries.get(filename)
        if entry is None:
            problems.append(f"{filename} is not pinned in the model manifest")
            continue
        if not fetch_one(entry, models_dir, verify_only=not download, progress=progress):
            problems.append(f"{filename} is missing or fails its checksum in {models_dir}")
    if not problems:
        _place_manifest(manifest_path, models_dir)
    if problems:
        hint = (
            ""
            if download
            else " — fetch them with `titanocr models` (or allow downloads: unset TITANOCR_OFFLINE)"
        )
        raise ModelsUnavailable("; ".join(problems) + hint)


def _place_manifest(manifest: Path, models_dir: Path) -> None:
    """Put the manifest the files were just verified against beside them.

    The service's own startup gate (``api/models_check.py``) checksums every
    model against ``<models_dir>/MANIFEST.json`` — in a source checkout that is
    the tracked file itself; in a cache it has to be placed there. Atomic, and
    skipped when the bytes are already identical.
    """
    target = models_dir / "MANIFEST.json"
    data = manifest.read_bytes()
    if target.is_file() and target.read_bytes() == data:
        return
    tmp = target.with_name(f"MANIFEST.json.{os.getpid()}.tmp")
    tmp.write_bytes(data)
    tmp.replace(target)


def fetch_models(
    models_dir: Path | None = None,
    *,
    filenames: Iterable[str] | None = None,
    verify_only: bool = False,
    progress: Progress = print,
) -> Path:
    """Fetch (or only verify) models into ``models_dir``; returns the directory.

    ``filenames`` limits the set; the default is every model in the manifest.
    Raises :class:`ModelsUnavailable` when any model could not be made present.
    """
    target = models_dir if models_dir is not None else default_models_dir()
    entries = load_manifest()
    wanted = set(filenames) if filenames is not None else {e.filename for e in entries}
    verb = "verifying" if verify_only else "fetching"
    progress(f"{verb} {len(wanted)} model(s) into {target}")
    ensure_models(wanted, target, download=not verify_only, progress=progress)
    return target


__all__ = [
    "ModelEntry",
    "ModelsUnavailable",
    "default_models_dir",
    "ensure_models",
    "fetch_models",
    "fetch_one",
    "load_manifest",
    "model_files_in_pipeline",
    "sha256_of",
]
