"""The Python library surface: ``from titanocr import ocr``.

::

    from titanocr import ocr

    result = ocr("report.pdf")
    result.markdown        # Markdown: headings, lists, tables
    result.text            # the words in reading order
    result.layout_text     # every line on its row and column (tables stay row-aligned)
    result.lines           # each line with its confidence, bbox and origin
    result.review_required # True when something on a page is below threshold
    result.ir              # the Document IR — the truth everything else projects

The engine runs in a helper process (``python -m titanocr stdio``) that this
module starts on first use and keeps warm, talking to it over the stdio
protocol :mod:`titanocr.stdio` defines. That is a deliberate boundary, not an
optimisation: the pool pins its threads before ONNX Runtime and OpenCV load and
spawns its workers with the ``spawn`` start method (hard rule 8), neither of
which a library can guarantee inside an arbitrary host process — a script
without an ``if __name__ == "__main__":`` guard would be re-executed by every
worker. In the helper, determinism does not depend on the caller.

:func:`ocr` shares one engine per configuration across calls and shuts it down
at interpreter exit. :class:`Engine` is the explicit form, for a caller that
wants to own the lifecycle.
"""

import atexit
import base64
import json
import os
import subprocess
import sys
import threading
import weakref
from concurrent.futures import Future
from os import PathLike
from pathlib import Path
from typing import IO, Any, Literal, Self

from titanocr.results import OCRResult

_START_TIMEOUT_S = 900.0
"""First start may download ~46 MB of models before the pool warms up."""


class EngineError(RuntimeError):
    """The engine could not start, or its helper process died."""


class DocumentError(RuntimeError):
    """The engine refused or could not process a document.

    ``status`` is ``refused`` (not a supported format, too large), ``rejected``
    (the input is unreadable — too blurred, too small, no text), ``failed`` or
    ``timeout``; ``reason`` is the engine's own explanation.
    """

    def __init__(self, message: str, *, status: str, reason: str | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.reason = reason


def _offline_from_env() -> bool:
    return os.environ.get("TITANOCR_OFFLINE", "").strip().lower() in {"1", "true", "yes", "on"}


class Engine:
    """A warm TitanOCR engine in a helper process.

    ::

        with Engine() as engine:
            for path in paths:
                print(engine.ocr(path).markdown)

    ``pipeline`` is a shipped pipeline name (``default``) or a path to a
    pipeline YAML. ``models_dir`` defaults to ``$TITANOCR_MODELS_DIR``, then the
    user cache (``~/.cache/titanocr/models``). ``download`` fetches missing
    models (checksum-verified) on first start; it defaults to on unless
    ``TITANOCR_OFFLINE`` is set. ``workers`` is the size of the engine's process
    pool: the pages of a document (and of concurrent documents) run on it in
    parallel. ``"auto"`` (the default) sizes it from this machine's CPUs and
    memory; the answer is the same at every size, only the wait changes. ``python``
    is the interpreter for the helper (default: this one).

    Thread-safe: concurrent :meth:`ocr` calls are processed concurrently.
    """

    def __init__(
        self,
        *,
        pipeline: str | PathLike[str] = "default",
        models_dir: str | PathLike[str] | None = None,
        download: bool | None = None,
        workers: int | Literal["auto"] = "auto",
        timeout: float = 600.0,
        python: str | None = None,
        log_level: str = "WARNING",
    ) -> None:
        if workers != "auto" and (type(workers) is not int or workers < 1):
            raise ValueError("workers must be a positive integer or 'auto'")
        self.pipeline = str(pipeline)
        self.models_dir = Path(models_dir).expanduser() if models_dir is not None else None
        self.download = (not _offline_from_env()) if download is None else download
        self.workers = workers
        self.timeout = timeout
        self.python = python or sys.executable
        self.log_level = log_level
        self.info: dict[str, Any] = {}
        self._proc: subprocess.Popen[str] | None = None
        self._pending: dict[int, Future[dict[str, Any]]] = {}
        self._exited = threading.Event()
        """Set by the current helper's reader when its stdout ends (the helper is gone)."""
        self._lock = threading.Lock()
        self._next_id = 0
        self._ready: Future[dict[str, Any]] = Future()
        self._reader: threading.Thread | None = None
        self._finalizer: weakref.finalize[..., Any] | None = None

    # -- lifecycle -------------------------------------------------------------------

    def _command(self) -> list[str]:
        cmd = [
            self.python,
            "-m",
            "titanocr",
            "stdio",
            "--pipeline",
            self.pipeline,
            "--workers",
            str(self.workers),
            "--timeout",
            str(self.timeout),
            "--log-level",
            self.log_level,
        ]
        if self.models_dir is not None:
            cmd += ["--models-dir", str(self.models_dir)]
        if not self.download:
            cmd.append("--offline")
        return cmd

    def start(self) -> Self:
        """Start the helper and wait until it is ready (idempotent; respawns a dead one)."""
        with self._lock:
            if self._proc is None or self._exited.is_set() or self._proc.poll() is not None:
                self._spawn()
            ready = self._ready
        try:
            self.info = ready.result(timeout=_START_TIMEOUT_S)
        except TimeoutError as exc:
            self.close()
            raise EngineError("the engine did not become ready in time") from exc
        except EngineError:
            self.close()
            raise
        return self

    def _spawn(self) -> None:
        """Start a helper with its own ready future and request table (lock held).

        Each helper's reader thread owns exactly the state it was started with,
        so a previous helper's late EOF can never fail a request of this one.
        """
        if self._finalizer is not None:
            self._finalizer.detach()
        self._ready = Future()
        self._pending = {}
        self._exited = threading.Event()
        self._proc = subprocess.Popen(
            self._command(),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=None,  # progress and warnings reach the caller's stderr
            text=True,
            encoding="utf-8",
            bufsize=1,
        )
        self._finalizer = weakref.finalize(self, _terminate, self._proc)
        self._reader = threading.Thread(
            target=self._read,
            args=(self._proc.stdout, self._ready, self._pending, self._exited),
            name="titanocr-engine",
            daemon=True,
        )
        self._reader.start()

    def close(self) -> None:
        """Stop the helper (idempotent). In-flight calls fail with :class:`EngineError`."""
        with self._lock:
            proc, self._proc = self._proc, None
        if proc is None:
            return
        try:
            if proc.stdin is not None:
                proc.stdin.close()  # EOF = graceful shutdown
            proc.wait(timeout=30)
        except (OSError, subprocess.TimeoutExpired):
            proc.kill()
            proc.wait()
        if self._finalizer is not None:
            self._finalizer.detach()
        if self._reader is not None:
            self._reader.join(timeout=5)

    def __enter__(self) -> Self:
        return self.start()

    def __exit__(self, *exc: object) -> None:
        self.close()

    @property
    def running(self) -> bool:
        proc = self._proc
        return proc is not None and proc.poll() is None

    # -- protocol --------------------------------------------------------------------

    def _read(
        self,
        stream: IO[str],
        ready: "Future[dict[str, Any]]",
        pending: "dict[int, Future[dict[str, Any]]]",
        exited: threading.Event,
    ) -> None:
        for raw in stream:
            try:
                message: dict[str, Any] = json.loads(raw)
            except ValueError:
                continue  # stdout carries protocol lines only; ignore anything else
            kind = message.get("type")
            if kind == "ready":
                ready.set_result(message)
            elif kind == "fatal":
                error = message.get("error", {})
                ready.set_exception(EngineError(str(error.get("message", error))))
            elif "id" in message:
                with self._lock:
                    future = pending.pop(message["id"], None)
                if future is not None:
                    future.set_result(message)
        # EOF: this helper exited — fail whatever is still waiting on it.
        if not ready.done():
            ready.set_exception(
                EngineError(
                    "the engine exited during startup — its error is on stderr above "
                    "(is titanocr installed for this Python?)"
                )
            )
        with self._lock:
            exited.set()  # under the lock: no request can register on this helper after this
            orphans = list(pending.values())
            pending.clear()
        for future in orphans:
            future.set_exception(EngineError("the engine process exited"))

    def _request(self, payload: dict[str, Any]) -> dict[str, Any]:
        self.start()
        future: Future[dict[str, Any]] = Future()
        with self._lock:
            proc = self._proc
            if proc is None or proc.stdin is None or self._exited.is_set():
                raise EngineError("the engine is closed")
            self._next_id += 1
            request_id = self._next_id
            self._pending[request_id] = future
            try:
                proc.stdin.write(json.dumps({"id": request_id, **payload}) + "\n")
                proc.stdin.flush()
            except OSError as exc:
                self._pending.pop(request_id, None)
                raise EngineError(f"the engine is not accepting requests: {exc}") from exc
        response = future.result()
        if not response.get("ok"):
            error: dict[str, Any] = response.get("error", {})
            if error.get("type") == "DocumentError":
                raise DocumentError(
                    str(error.get("message")),
                    status=str(error.get("status")),
                    reason=error.get("reason"),
                )
            raise EngineError(f"{error.get('type')}: {error.get('message')}")
        return response["result"]

    # -- public ----------------------------------------------------------------------

    def ocr(
        self,
        source: str | PathLike[str] | bytes,
        *,
        filename: str | None = None,
        doc_type_hint: str = "auto",
    ) -> OCRResult:
        """OCR one document — a path to a PDF or image, or its bytes.

        Returns an :class:`OCRResult` for a ``done`` or ``partial`` document;
        raises :class:`DocumentError` when the document is refused, rejected as
        unreadable, or fails. Supported inputs (by content): PDF, JPEG, PNG,
        TIFF, WebP, HEIC.
        """
        if isinstance(source, bytes | bytearray | memoryview):
            payload: dict[str, Any] = {
                "data_b64": base64.b64encode(bytes(source)).decode("ascii"),
                "filename": filename or "document",
            }
        else:
            path = Path(source).expanduser().resolve()
            if not path.is_file():
                raise FileNotFoundError(path)
            payload = {"path": str(path), "filename": filename or path.name}
        payload |= {"op": "ocr", "doc_type_hint": doc_type_hint, "outputs": ["ir"]}
        result = self._request(payload)
        return OCRResult.from_service(
            {
                "status": result["status"],
                "pages": result.get("pages", []),
                "degraded": result.get("degraded", False),
            },
            result["ir"],
        )


def _terminate(proc: subprocess.Popen[str]) -> None:
    if proc.poll() is None:
        try:
            if proc.stdin is not None:
                proc.stdin.close()
            proc.wait(timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            proc.kill()


# -- the convenience functions --------------------------------------------------------

_shared: dict[tuple[Any, ...], Engine] = {}
_shared_lock = threading.Lock()


def _engine(
    pipeline: str | PathLike[str], models_dir: str | PathLike[str] | None, download: bool | None
) -> Engine:
    key = (str(pipeline), str(models_dir) if models_dir is not None else None, download)
    with _shared_lock:
        engine = _shared.get(key)
        if engine is None or not engine.running:
            engine = Engine(pipeline=pipeline, models_dir=models_dir, download=download)
            _shared[key] = engine
    return engine.start()


def shutdown() -> None:
    """Stop the engines :func:`ocr` started (also runs at interpreter exit)."""
    with _shared_lock:
        engines = list(_shared.values())
        _shared.clear()
    for engine in engines:
        engine.close()


atexit.register(shutdown)


def ocr(
    source: str | PathLike[str] | bytes,
    *,
    filename: str | None = None,
    doc_type_hint: str = "auto",
    pipeline: str | PathLike[str] = "default",
    models_dir: str | PathLike[str] | None = None,
    download: bool | None = None,
) -> OCRResult:
    """OCR a PDF or image and return an :class:`OCRResult`.

    The first call starts a warm engine (and, on a fresh machine, fetches the
    ~46 MB of pinned models into ``~/.cache/titanocr/models``, verifying every
    checksum); later calls with the same configuration reuse it.
    """
    return _engine(pipeline, models_dir, download).ocr(
        source, filename=filename, doc_type_hint=doc_type_hint
    )


def ocr_markdown(source: str | PathLike[str] | bytes, **kwargs: Any) -> str:
    """OCR a document and return its Markdown (headings, lists, tables)."""
    return ocr(source, **kwargs).markdown


def ocr_text(source: str | PathLike[str] | bytes, *, layout: bool = False, **kwargs: Any) -> str:
    """OCR a document and return plain text.

    ``layout=False``: the words in reading order. ``layout=True``: every line on
    its visual row and column — keeps a table's rows (a lab test, its value, its
    unit, its range) on one line.
    """
    result = ocr(source, **kwargs)
    return result.layout_text if layout else result.text


__all__ = [
    "DocumentError",
    "Engine",
    "EngineError",
    "ocr",
    "ocr_markdown",
    "ocr_text",
    "shutdown",
]
