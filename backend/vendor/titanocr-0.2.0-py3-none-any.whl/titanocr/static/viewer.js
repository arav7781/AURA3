/* Page viewer: prep-space image + canvas overlay (phase 07 §4.6).
 *
 * IR bboxes are page-space pixels of the served `variant=prep` image, origin
 * top-left, so drawing needs no transform (plan §7 coordinate rule): the canvas
 * backing store is the image's natural size and both are CSS-scaled together
 * for zoom. Boxes paint incrementally — app.js pushes each page's IR the
 * moment a poll shows it done.
 */
"use strict";

const Viewer = (() => {
  // Overlay colours are drawn onto the page raster, which is paper-white — so
  // every one of them is chosen to read as ink on white, not as a glow on black.
  const TYPE_COLOURS = {
    paragraph: "#2563eb",
    header: "#7c3aed",
    footer: "#6b7280",
    table: "#0f8a52",
    figure: "#c2740a",
    kv: "#0e8f9e",
    signature: "#d33a2c",
    rule: "#57534e", // IR 1.5 (ADR 0011): a printed division of the page
    formula: "#b0398e", // IR 1.8 (ADR 0018): a region of display mathematics
  };
  const HEAT = { low: "#d33a2c", mid: "#c2740a", high: "#0f8a52" };
  const VLM_COLOUR = "#6d4bc4"; // escalated (origin="vlm") content, phase 13
  const FOCUS_COLOUR = "#1f1e1d"; // the selected unit, in either direction
  const ZOOM_MIN = 0.1, ZOOM_MAX = 3.0, ZOOM_STEP = 0.25;
  const IMAGE_RETRY_MS = 900;  // phase 15: re-probe the raster while a page is processing
  const REVEAL_MS = 1200;      // phase 15: staggered box reveal when a page's IR lands
  const PENDING = ["queued", "processing"]; // page slot states whose raster may still appear

  let els = null;
  let docId = null;
  let pageSlots = [];          // status-document page entries, 1-based order
  let irByPage = new Map();    // page_no -> page IR
  let current = 1;
  let zoom = 1.0;
  let fitMode = true;          // phase 15: fit the full page in view until the user zooms
  let naturalW = 0, naturalH = 0;
  let imageOk = false;
  let isPreview = false;       // phase 15: a local pre-upload preview is showing (no boxes)
  let loadedKey = null;        // page+status the shown image was fetched under
  let lastImageAttempt = 0;
  let reveal = new Map();      // page_no -> reveal start timestamp (phase 15)
  let revealPending = false;
  // The selected unit — {page, blockId, lineId, cell:{row,col}, text}. Set by a
  // click on the canvas or by app.js when the rendered Markdown is clicked; it
  // is the page-image half of the two-way IR <-> Markdown link.
  let focus = null;
  let onSelect = () => {};     // canvas click -> app.js (highlight the Markdown)
  let onPage = () => {};       // page changed -> app.js (scroll the text pane)

  function heatColour(conf) {
    if (conf < 0.7) return HEAT.low;
    if (conf < 0.9) return HEAT.mid;
    return HEAT.high;
  }

  function init(elements) {
    els = elements;
    if (elements.onSelect) onSelect = elements.onSelect;
    if (elements.onPage) onPage = elements.onPage;
    els.image.addEventListener("load", onImageLoad);
    els.image.addEventListener("error", onImageError);
    els.canvas.addEventListener("mousemove", onHover);
    els.canvas.addEventListener("mouseleave", hideTooltip);
    els.canvas.addEventListener("click", onClick);
    els.prev.addEventListener("click", () => goto(current - 1));
    els.next.addEventListener("click", () => goto(current + 1));
    els.zoomIn.addEventListener("click", () => setZoom(zoom + ZOOM_STEP));
    els.zoomOut.addEventListener("click", () => setZoom(zoom - ZOOM_STEP));
    els.zoomFit.addEventListener("click", () => { fitMode = true; if (imageOk) applyFit(); });
    window.addEventListener("resize", () => { if (fitMode && imageOk) applyFit(); });
    els.layerBlocks.addEventListener("change", redraw);
    els.layerLines.addEventListener("change", redraw);
    els.layerCells.addEventListener("change", redraw);
    els.colourMode.addEventListener("change", redraw);
    buildLegend();
  }

  function buildLegend() {
    if (!els.legend) return;
    els.legend.replaceChildren();
    for (const [type, colour] of Object.entries(TYPE_COLOURS)) {
      const item = document.createElement("span");
      item.className = "legend-item";
      const swatch = document.createElement("span");
      swatch.className = "legend-swatch";
      swatch.style.backgroundColor = colour;
      item.append(swatch, document.createTextNode(type));
      els.legend.appendChild(item);
    }
  }

  function updateLegend() {
    if (!els.legend) return;
    const show = imageOk && els.layerBlocks.checked && els.colourMode.value === "type"
      && irByPage.has(current);
    els.legend.classList.toggle("hidden", !show);
  }

  function reset(newDocId) {
    docId = newDocId;
    pageSlots = [];
    irByPage = new Map();
    current = 1;
    fitMode = true;
    naturalW = naturalH = 0;
    imageOk = false;
    isPreview = false;
    loadedKey = null;
    lastImageAttempt = 0;
    reveal = new Map();
    focus = null;
    if (els.pageStrip) {
      els.pageStrip.replaceChildren();
      els.pageStrip.classList.add("hidden");
    }
    els.stage.style.display = "none";
    els.scanline.classList.add("hidden");
    els.empty.textContent = "processing…";
    els.empty.classList.remove("hidden");
    els.originBadge.classList.add("hidden");
    if (els.legend) els.legend.classList.add("hidden");
    hideTooltip();
    updateNav();
  }

  // Phase 15: show the just-picked file instantly (object URL) while the
  // upload/pipeline runs. Preview only — bboxes are in post-prep coordinates,
  // so nothing is drawn until the served raster replaces this image.
  function previewLocal(url) {
    if (imageOk && !isPreview) return;
    isPreview = true;
    els.image.src = url;
  }

  function setStatusPages(pages) {
    pageSlots = pages || [];
    // Reload whenever the current page's status/stage moved: for raster pages
    // the served PNG changes underfoot as pool prep replaces the initial render
    // (phase 08) — the stage in the cache key forces the refetch. While the
    // page is still processing and nothing (or only a local preview) is shown,
    // keep re-probing: the post-prep raster exists long before the page is done
    // (phase 15 — the "watch it scan" requirement).
    if (pageSlots.length && slotKey(current) !== loadedKey) loadPage();
    else {
      const slot = pageSlots[current - 1];
      // A queued page counts as waiting too: jumping ahead to one must not
      // dead-end on "no image" — its raster appears as soon as the pool renders
      // it, and re-probing is what puts it on screen without another click.
      const waiting = (!imageOk || isPreview) && slot && PENDING.includes(slot.status);
      if (waiting && Date.now() - lastImageAttempt > IMAGE_RETRY_MS) loadPage();
    }
    updateScanline();
    updateNav();
  }

  function slotKey(pageNo) {
    const slot = pageSlots[pageNo - 1];
    return `${pageNo}:${slot ? slot.status : "none"}:${slot && slot.stage ? slot.stage : ""}`;
  }

  function setPageIR(pageNo, pageIR) {
    irByPage.set(pageNo, pageIR);
    if (!reveal.has(pageNo)) reveal.set(pageNo, performance.now()); // phase 15
    if (pageNo === current) {
      if (!imageOk || isPreview) loadPage(); // raster may have landed after the first attempt
      redraw();
      updateBadge();
    }
  }

  function hasIR(pageNo) {
    return irByPage.has(pageNo);
  }

  function getIR(pageNo) {
    return irByPage.get(pageNo) || null; // Signals tab reads confidence/quality from here
  }

  function goto(pageNo, silent) {
    if (!docId || pageNo < 1 || pageNo > pageSlots.length) return;
    const moved = pageNo !== current;
    current = pageNo;
    if (moved) {
      focus = null;
      // `imageOk` means "what is on screen is *this* page" — the instant we move
      // it is false, before the new raster has had a chance to load. Leaving it
      // true let the probe's error guard (`!imageOk`) fall through, so a page
      // whose image is not ready kept the *previous* page's raster on screen
      // while the label said otherwise: the page appeared not to change at all.
      imageOk = false;
    }
    loadPage();
    updateScanline();
    updateNav();
    updateBadge();
    // The boxes belong to the page that is showing: clear them the moment we
    // leave it, or the old overlay sits on the new raster until it loads.
    if (moved) clearOverlay();
    // `silent` when the move was caused by the text pane itself — it is already
    // showing what the user clicked; scrolling it again would yank it away.
    if (!silent) onPage(pageNo);
  }

  function loadPage() {
    if (!docId || pageSlots.length === 0) return;
    const key = slotKey(current);
    loadedKey = key;
    lastImageAttempt = Date.now();
    const slot = pageSlots[current - 1];
    const rev = slot ? `${slot.status}-${slot.stage || ""}` : "none";
    const url = `/v1/documents/${docId}/pages/${current}/image?variant=prep&s=${rev}`;
    // Probe first (phase 15): a not-ready 404 must not blank an image (or a
    // local preview) that is already on screen — on success the cached bytes
    // swap in instantly; on failure whatever is showing stays.
    const probe = new Image();
    probe.onload = () => {
      if (loadedKey !== key) return; // the page or its stage moved on
      isPreview = false;
      imageOk = false; // until the <img> load event confirms the swap
      els.image.src = url;
    };
    probe.onerror = () => {
      if (!imageOk && !isPreview) onImageError();
    };
    probe.src = url;
  }

  function onImageLoad() {
    imageOk = true;
    naturalW = els.image.naturalWidth;
    naturalH = els.image.naturalHeight;
    els.canvas.width = naturalW;
    els.canvas.height = naturalH;
    els.empty.classList.add("hidden");
    els.stage.style.display = "block";
    if (fitMode) applyFit(); else applyZoom();
    updateScanline();
    redraw();
    updateBadge();
  }

  function onImageError() {
    imageOk = false;
    els.stage.style.display = "none";
    els.scanline.classList.add("hidden");
    const slot = pageSlots[current - 1];
    const why = slot && slot.status === "pending_engine"
      ? `page ${current} is waiting for the OCR engine (${slot.reason || "pending_engine"}) — no raster yet`
      : slot && PENDING.includes(slot.status)
      // Jumping ahead of the pipeline is allowed; say so, and say it will fill
      // itself in — setStatusPages keeps re-probing the raster.
      ? `page ${current} is still ${slot.status} — it appears here the moment its image exists`
      : `no image available for page ${current} yet`;
    els.empty.textContent = why;
    els.empty.classList.remove("hidden");
  }

  function applyZoom() {
    els.image.style.width = `${naturalW * zoom}px`;
    els.canvas.style.width = `${naturalW * zoom}px`;
    els.canvas.style.height = `${naturalH * zoom}px`;
    els.zoomLabel.textContent = `${fitMode ? "fit · " : ""}${Math.round(zoom * 100)}%`;
  }

  // Phase 15: fit the whole page inside the scroll pane (the default view).
  function applyFit() {
    if (!naturalW || !naturalH) return;
    const pad = 24; // the stage's margin, both axes
    const w = els.scroll.clientWidth - pad;
    const h = els.scroll.clientHeight - pad;
    if (w <= 0 || h <= 0) return;
    zoom = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.min(w / naturalW, h / naturalH)));
    applyZoom();
  }

  function setZoom(z) {
    fitMode = false;
    zoom = Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, z));
    if (imageOk) applyZoom();
    else els.zoomLabel.textContent = `${Math.round(zoom * 100)}%`;
  }

  // Phase 15: scanner sweep over the page while it is genuinely processing.
  function updateScanline() {
    const slot = pageSlots[current - 1];
    const on = imageOk && slot && slot.status === "processing";
    els.scanline.classList.toggle("hidden", !on);
  }

  function updateNav() {
    els.pageLabel.textContent = pageSlots.length ? `page ${current}/${pageSlots.length}` : "–";
    els.prev.disabled = current <= 1;
    els.next.disabled = current >= pageSlots.length;
    updatePageStrip();
  }

  // A numbered box per page, right next to the image it switches. The buttons
  // are built once per page count and only their classes change afterwards:
  // a listener attached to a node that a later repaint replaces is a listener
  // the click never reaches.
  function updatePageStrip() {
    const strip = els.pageStrip;
    if (!strip) return;
    const n = pageSlots.length;
    strip.classList.toggle("hidden", n < 2);
    if (strip.childElementCount !== n) {
      strip.replaceChildren();
      for (let i = 1; i <= n; i++) {
        const chip = document.createElement("button");
        chip.className = "page-chip";
        chip.textContent = String(i);
        chip.dataset.page = String(i);
        chip.title = `show page ${i}`;
        chip.addEventListener("click", () => goto(i));
        strip.appendChild(chip);
      }
    }
    for (const chip of strip.children) {
      const pageNo = Number(chip.dataset.page);
      const slot = pageSlots[pageNo - 1];
      chip.classList.toggle("active", pageNo === current);
      chip.classList.toggle("waiting", !!slot && PENDING.includes(slot.status));
      chip.classList.toggle("bad", !!slot && ["failed", "rejected"].includes(slot.status));
    }
  }

  function updateBadge() {
    const ir = irByPage.get(current);
    const slot = pageSlots[current - 1];
    const origin = ir ? ir.origin : slot ? slot.route : null;
    if (!origin) { els.originBadge.classList.add("hidden"); return; }
    els.originBadge.textContent = origin;
    els.originBadge.className = `badge ${origin}`;
  }

  function blocksOf(pageIR) {
    return (pageIR && pageIR.blocks) || [];
  }

  function* linesOf(pageIR) {
    for (const block of blocksOf(pageIR)) {
      for (const line of block.lines || []) yield { block, line };
    }
  }

  function* cellsOf(pageIR) {
    // Cells of recognised tables (phase 11); a failed or pending table has
    // an empty/placeholder grid and yields nothing.
    for (const block of blocksOf(pageIR)) {
      if (block.type !== "table" || !block.table || block.table_failed) continue;
      for (const cell of block.table.cells || []) yield { block, cell };
    }
  }

  // Phase 15: reveal fraction for the current page — 1.0 once the staggered
  // draw-in (started when the page's IR first arrived) has finished.
  function revealFraction() {
    const start = reveal.get(current);
    if (start == null) return 1;
    const f = (performance.now() - start) / REVEAL_MS;
    return f >= 1 ? 1 : f;
  }

  function scheduleRevealFrame() {
    if (revealPending) return;
    revealPending = true;
    requestAnimationFrame(() => { revealPending = false; redraw(); });
  }

  function clearOverlay() {
    if (!els.canvas.width) return;
    els.canvas.getContext("2d").clearRect(0, 0, els.canvas.width, els.canvas.height);
  }

  function redraw() {
    updateLegend();
    if (!imageOk || isPreview) return;
    const ctx = els.canvas.getContext("2d");
    ctx.clearRect(0, 0, naturalW, naturalH);
    const pageIR = irByPage.get(current);
    if (!pageIR) return;
    const byConf = els.colourMode.value === "conf";
    // Ease the reveal so boxes land gently; entities draw in reading order.
    const f = revealFraction();
    const eased = 1 - (1 - f) * (1 - f);
    const cut = (n) => (f >= 1 ? n : Math.ceil(eased * n));

    if (els.layerBlocks.checked) {
      const blocks = blocksOf(pageIR)
        .slice()
        .sort((a, b) => a.reading_order - b.reading_order)
        .slice(0, cut(blocksOf(pageIR).length));
      for (const block of blocks) {
        const colour = byConf ? heatColour(block.confidence) : TYPE_COLOURS[block.type] || "#57534e";
        // A table_failed block is visually flagged: dashed red outline (ADR 0005).
        if (block.table_failed) drawBox(ctx, block.bbox, HEAT.low, 2, 0.04, [8, 5]);
        // Escalated text (phase 13): dashed violet outline + a `vlm` badge, so
        // model-corrected content never looks like plain OCR output.
        else if (block.origin === "vlm") {
          drawBox(ctx, block.bbox, VLM_COLOUR, 2, 0.06, [6, 4]);
          drawBadge(ctx, block.bbox, "vlm", VLM_COLOUR);
        } else drawBox(ctx, block.bbox, colour, 2, 0.04);
      }
      // The escalated region itself (page.escalations[]) — the unit that was
      // actually sent, which can be larger than the block that replaced it.
      if (f >= 1) {
        for (const esc of pageIR.escalations || []) {
          drawBox(ctx, esc.region_bbox, VLM_COLOUR, 1, 0.0, [3, 4]);
        }
      }
    }
    if (els.layerCells.checked) {
      const cells = [...cellsOf(pageIR)];
      for (const { cell } of cells.slice(0, cut(cells.length))) {
        const colour = byConf ? heatColour(cell.confidence) : "#0f8a52";
        drawBox(ctx, cell.bbox, colour, 1, cell.text ? 0.10 : 0.03);
      }
    }
    if (els.layerLines.checked) {
      const lines = [...linesOf(pageIR)];
      for (const { line } of lines.slice(0, cut(lines.length))) {
        const colour = byConf ? heatColour(line.confidence) : "#64748b";
        drawBox(ctx, line.bbox, colour, 1, 0.08);
      }
    }
    drawFocus(ctx, pageIR);
    if (f < 1) scheduleRevealFrame();
  }

  // The selected unit, drawn last so it reads over every layer: the block that
  // owns it outlined, the exact line/cell filled.
  function drawFocus(ctx, pageIR) {
    if (!focus || focus.page !== current) return;
    const block = blocksOf(pageIR).find((b) => b.block_id === focus.blockId);
    if (!block) return;
    drawBox(ctx, block.bbox, FOCUS_COLOUR, 3, 0.05);
    const unit = focusUnit(block);
    if (unit) drawBox(ctx, unit.bbox, FOCUS_COLOUR, 2, 0.22);
  }

  // The line or cell inside the focused block, when the selection named one.
  function focusUnit(block) {
    if (focus.cell && block.table) {
      return (block.table.cells || []).find(
        (c) => c.row === focus.cell.row && c.col === focus.cell.col) || null;
    }
    if (focus.lineId) {
      return (block.lines || []).find((l) => l.line_id === focus.lineId) || null;
    }
    return null;
  }

  // -- selection: page image <-> Markdown --------------------------------------

  function onClick(event) {
    const hit = hitAt(event);
    if (!hit) {
      focus = null;
      redraw();
      onSelect(null);
      return;
    }
    focus = {
      page: current,
      blockId: hit.block.block_id,
      lineId: hit.line ? hit.line.line_id : null,
      cell: hit.cell ? { row: hit.cell.row, col: hit.cell.col } : null,
      text: hit.line ? hit.line.text : hit.cell ? hit.cell.text : null,
    };
    redraw();
    onSelect(focus);
  }

  /* Select from the other side: app.js resolved a piece of rendered Markdown
   * back to the block (and cell) that produced it. Switching pages is part of
   * the job — the text pane is a whole document, the viewer shows one page. */
  function focusBlock(pageNo, blockId, cell) {
    if (pageNo !== current) goto(pageNo, true);
    focus = { page: pageNo, blockId, lineId: null, cell: cell || null, text: null };
    redraw();
    const pageIR = irByPage.get(pageNo);
    const block = pageIR ? blocksOf(pageIR).find((b) => b.block_id === blockId) : null;
    if (!block) return;
    const unit = focusUnit(block);
    scrollBoxIntoView((unit || block).bbox);
  }

  function clearFocus() {
    if (!focus) return;
    focus = null;
    redraw();
  }

  // Bring a page-space box into the scroll pane when it is not already visible.
  function scrollBoxIntoView(bbox) {
    if (!imageOk) return;
    const stage = els.stage;
    const [x0, y0, x1, y1] = bbox.map((v) => v * zoom);
    const top = stage.offsetTop + y0;
    const left = stage.offsetLeft + x0;
    const view = els.scroll;
    if (top < view.scrollTop || top + (y1 - y0) > view.scrollTop + view.clientHeight) {
      view.scrollTop = Math.max(0, top - view.clientHeight / 2 + (y1 - y0) / 2);
    }
    if (left < view.scrollLeft || left + (x1 - x0) > view.scrollLeft + view.clientWidth) {
      view.scrollLeft = Math.max(0, left - view.clientWidth / 2 + (x1 - x0) / 2);
    }
  }

  /* One hit test for hover and click. Cells win over lines, lines over blocks —
   * the narrowest unit under the cursor is the one the user means — and a layer
   * that is switched off is not hittable, because it is not on screen. */
  function hitAt(event) {
    const pageIR = irByPage.get(current);
    if (!pageIR || !imageOk || isPreview) return null;
    const rect = els.canvas.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * naturalW;
    const y = ((event.clientY - rect.top) / rect.height) * naturalH;
    const inside = ([x0, y0, x1, y1]) => x >= x0 && x <= x1 && y >= y0 && y <= y1;

    let hit = null;
    if (els.layerCells.checked) {
      for (const { block, cell } of cellsOf(pageIR)) {
        if (inside(cell.bbox)) hit = { block, cell, line: null };
      }
      if (hit) return hit;
    }
    if (els.layerLines.checked) {
      for (const { block, line } of linesOf(pageIR)) {
        if (inside(line.bbox)) hit = { block, line, cell: null };
      }
      if (hit) return hit;
    }
    if (els.layerBlocks.checked) {
      for (const block of blocksOf(pageIR)) {
        if (inside(block.bbox)) hit = { block, line: null, cell: null };
      }
    }
    return hit;
  }

  function drawBadge(ctx, bbox, text, colour) {
    const [x0, y0] = bbox;
    ctx.save();
    ctx.font = "600 13px ui-monospace, monospace";
    const w = ctx.measureText(text).width + 10;
    ctx.fillStyle = colour;
    ctx.fillRect(x0, Math.max(0, y0 - 18), w, 18);
    ctx.fillStyle = "#ffffff";
    ctx.fillText(text, x0 + 5, Math.max(0, y0 - 18) + 13);
    ctx.restore();
  }

  function drawBox(ctx, bbox, colour, width, fillAlpha, dash) {
    const [x0, y0, x1, y1] = bbox;
    ctx.save();
    ctx.strokeStyle = colour;
    ctx.lineWidth = width;
    if (dash) ctx.setLineDash(dash);
    ctx.globalAlpha = fillAlpha;
    ctx.fillStyle = colour;
    ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
    ctx.globalAlpha = 1;
    ctx.strokeRect(x0, y0, x1 - x0, y1 - y0);
    ctx.restore();
  }

  function onHover(event) {
    const hit = hitAt(event);
    if (!hit) { hideTooltip(); return; }
    const click = " · click to find this text →";
    // Cell badge first (phase 11): `r,c (span)` + the cell's text.
    if (hit.cell) {
      const span = (hit.cell.row_span > 1 || hit.cell.col_span > 1)
        ? ` (${hit.cell.row_span}×${hit.cell.col_span})` : "";
      const text = hit.cell.text ? ` · ${hit.cell.text}` : " · (empty)";
      showTooltip(event, `r${hit.cell.row},c${hit.cell.col}${span}${text}${click}`);
      return;
    }
    if (hit.line) {
      showTooltip(event,
        `${hit.line.text} · ${hit.line.confidence.toFixed(2)} · ${hit.line.origin}${click}`);
      return;
    }
    // No line under the cursor — fall back to the enclosing block (phase 10:
    // type + reading order at a glance).
    const block = hit.block;
    const failed = block.table_failed ? " · TABLE FAILED (lines preserved)" : "";
    // Escalated blocks say so, and say that their confidence is a prior.
    const vlm = block.origin === "vlm" ? " · vlm (confidence is a prior, not measured)" : "";
    showTooltip(event,
      `${block.type} · order ${block.reading_order} · ${block.confidence.toFixed(2)}` +
      `${failed}${vlm}${click}`);
  }

  function showTooltip(event, text) {
    els.tooltip.textContent = text;
    els.tooltip.style.left = `${event.clientX + 14}px`;
    els.tooltip.style.top = `${event.clientY + 14}px`;
    els.tooltip.classList.remove("hidden");
  }

  function hideTooltip() {
    els.tooltip.classList.add("hidden");
  }

  return {
    init, reset, setStatusPages, setPageIR, hasIR, getIR, goto, previewLocal,
    focusBlock, clearFocus, page: () => current, pageCount: () => pageSlots.length,
  };
})();
