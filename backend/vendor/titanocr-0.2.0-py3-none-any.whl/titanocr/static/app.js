/* Demo controller: upload → poll → tracker/tabs (phase 07 §4.5).
 *
 * Progress is poll-based (ADR 0003 #2 — no streaming): the status document is
 * fetched every 500 ms while the document is non-terminal, backing off to 2 s
 * after 60 s. Per-page IR artifacts are fetched the moment a poll shows a page
 * done, so boxes paint incrementally. Any poll failure (server restart, lost
 * job) surfaces a clean error state and never wedges the next upload.
 */
"use strict";

(() => {
  const POLL_MS = 500;
  const POLL_SLOW_MS = 2000;
  const POLL_SLOW_AFTER_MS = 60000;
  const TERMINAL = new Set(["done", "partial", "failed", "rejected"]);

  const $ = (id) => document.getElementById(id);
  const docs = new Map(); // doc_id -> {status, markdown, ir} — the state store
  let active = null;      // {docId, timer, startedAt, fetchingPages:Set}

  // -- boot -------------------------------------------------------------------

  document.addEventListener("DOMContentLoaded", () => {
    Viewer.init({
      image: $("page-image"),
      canvas: $("overlay"),
      stage: $("viewer-stage"),
      empty: $("viewer-empty"),
      tooltip: $("tooltip"),
      prev: $("page-prev"),
      next: $("page-next"),
      pageLabel: $("page-label"),
      zoomIn: $("zoom-in"),
      zoomOut: $("zoom-out"),
      zoomFit: $("zoom-fit"),
      zoomLabel: $("zoom-label"),
      scroll: $("viewer-scroll"),
      scanline: $("scanline"),
      layerBlocks: $("layer-blocks"),
      layerLines: $("layer-lines"),
      layerCells: $("layer-cells"),
      colourMode: $("colour-mode"),
      originBadge: $("page-origin-badge"),
      legend: $("type-legend"),
      pageStrip: $("page-strip"),
      onSelect: highlightMarkdown,
      onPage: scrollMarkdownToPage,
    });
    configureMarked();
    wireUpload();
    wireTabs();
    wireHints();
    wireCopy($("doc-id-label"));
    wirePaneActions();
    wireDrawer();
    wireSplitter();
    wireRail();
    wireMarkdownLinks();
    wireSpatialToggle();
    wireFields();
    loadPipelines();
    loadSamples();
  });

  // -- drawer (phase 15): samples + processing options live off-canvas ---------

  let closeDrawer = () => {};

  function wireDrawer() {
    const drawer = $("drawer");
    const backdrop = $("drawer-backdrop");
    const set = (open) => {
      drawer.classList.toggle("open", open);
      backdrop.classList.toggle("hidden", !open);
    };
    closeDrawer = () => set(false);
    $("config-btn").addEventListener("click", () => set(!drawer.classList.contains("open")));
    $("drawer-close").addEventListener("click", () => set(false));
    backdrop.addEventListener("click", () => set(false));
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") set(false); });
  }

  // -- pane splitter (phase 15): the two panes trade space ---------------------
  // A pointer-captured drag on the middle grid track; the fraction persists in
  // localStorage. The viewer listens for window resize to re-fit, so the drag
  // dispatches one.

  function wireSplitter() {
    const split = $("split");
    const bar = $("splitter");
    const apply = (f) => { split.style.gridTemplateColumns = `${f}fr 6px ${1 - f}fr`; };
    let frac = Number(localStorage.getItem("split-frac"));
    if (!(frac >= 0.15 && frac <= 0.85)) frac = 0.5;
    apply(frac);
    const save = () => {
      try { localStorage.setItem("split-frac", String(frac)); } catch { /* private mode */ }
    };
    let dragging = false;
    bar.addEventListener("pointerdown", (e) => {
      dragging = true;
      bar.setPointerCapture(e.pointerId);
    });
    bar.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const r = split.getBoundingClientRect();
      frac = Math.min(0.85, Math.max(0.15, (e.clientX - r.left) / r.width));
      apply(frac);
      window.dispatchEvent(new Event("resize"));
    });
    bar.addEventListener("pointerup", () => { dragging = false; save(); });
    bar.addEventListener("dblclick", () => {
      frac = 0.5;
      apply(frac);
      save();
      window.dispatchEvent(new Event("resize"));
    });
  }

  // Plain-words hover hints (phase 15): any element carrying data-tip shows its
  // explanation in the fixed #hint bubble. Delegated on the document, so the
  // tracker can rebuild freely; fixed positioning means nothing clips inside
  // the horizontally scrolling rail.
  function wireHints() {
    const hint = $("hint");
    const hide = () => hint.classList.add("hidden");
    document.addEventListener("mouseover", (e) => {
      const el = e.target instanceof Element ? e.target.closest("[data-tip]") : null;
      if (!el || !el.dataset.tip) { hide(); return; }
      hint.textContent = el.dataset.tip;
      hint.classList.remove("hidden");
      const r = el.getBoundingClientRect();
      const x = Math.min(Math.max(8, r.left + r.width / 2 - hint.offsetWidth / 2),
        window.innerWidth - hint.offsetWidth - 8);
      const above = r.top - hint.offsetHeight - 8;
      hint.style.left = `${x}px`;
      hint.style.top = above > 4 ? `${above}px` : `${r.bottom + 8}px`;
    });
    document.addEventListener("mouseout", (e) => { if (!e.relatedTarget) hide(); });
    document.addEventListener("scroll", hide, true);
  }

  function wireCopy(el) {
    el.addEventListener("click", () => {
      copyText(el.textContent, () => {
        el.classList.add("copied");
        setTimeout(() => el.classList.remove("copied"), 900);
      });
    });
  }

  // -- clipboard --------------------------------------------------------------
  // `navigator.clipboard` needs a secure context, and the demo is regularly
  // opened over a plain-http LAN address, so there is a selection-based
  // fallback rather than a button that silently does nothing.

  function copyText(text, onDone) {
    const value = String(text || "");
    if (!value) return;
    const done = (ok) => { if (onDone) onDone(ok); };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(value).then(() => done(true), () => done(legacyCopy(value)));
    } else {
      done(legacyCopy(value));
    }
  }

  function legacyCopy(value) {
    const ta = document.createElement("textarea");
    ta.value = value;
    ta.setAttribute("readonly", "");
    ta.style.cssText = "position:fixed;top:-1000px;left:0;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch { ok = false; }
    ta.remove();
    return ok;
  }

  // A button that reports what happened in its own label, then returns to rest.
  // The rest label is resolved when the button returns to it, not when it was
  // clicked: the tab can change in between, and the copy button's rest label is
  // whatever the tab now showing would copy.
  function copyInto(button, text, restLabel) {
    // The label is a *child* span wherever the button has one — writing to the
    // button itself would replace its glyph and label with a text node, and the
    // button would never come back. Every copy button marks its span
    // `.copy-label`; a bare button (a table's) is its own label.
    const label = button.querySelector(".copy-label") || button;
    copyText(text, (ok) => {
      label.textContent = ok ? "copied" : "copy failed";
      button.classList.toggle("copied", ok);
      setTimeout(() => {
        label.textContent = typeof restLabel === "function" ? restLabel() : restLabel;
        button.classList.remove("copied");
      }, 1200);
    });
  }

  // -- output-pane actions: copy the active tab, save the projection ----------

  function paneText() {
    const entry = active ? docs.get(active.docId) : null;
    if (!entry) return "";
    if (activeTab === "ir") return entry.ir ? JSON.stringify(entry.ir, null, 2) : "";
    if (activeTab === "fields") return lastFields ? JSON.stringify(lastFields, null, 2) : "";
    if (activeTab === "signals") return $("tab-signals").innerText.trim();
    return entry.markdown || ""; // Markdown and Raw MD are the same bytes
  }

  function wirePaneActions() {
    $("copy-btn").addEventListener("click", () => {
      copyInto($("copy-btn"), paneText(), copyRestLabel);
    });
    $("download-btn").addEventListener("click", () => {
      const entry = active ? docs.get(active.docId) : null;
      if (!entry || !entry.markdown) return;
      const url = URL.createObjectURL(new Blob([entry.markdown], { type: "text/markdown" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = `${active.docId}.md`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }

  const copyRestLabel = () =>
    (activeTab === "ir" || activeTab === "fields" ? "copy JSON" : "copy");

  // Both actions are dead until there is something to hand over, and the copy
  // button names what it would copy — Markdown from three of the four tabs, the
  // IR document from the fourth.
  function syncPaneActions() {
    const entry = active ? docs.get(active.docId) : null;
    const copyable = !!paneText();
    $("copy-btn").disabled = !copyable;
    $("copy-label").textContent = copyRestLabel();
    $("download-btn").disabled = !(entry && entry.markdown);
  }

  // -- upload -----------------------------------------------------------------

  function wireUpload() {
    const input = $("file-input");
    input.addEventListener("change", () => {
      if (input.files.length) upload(input.files[0]);
      input.value = "";
    });
    // The upload affordances live on the preview pane itself: the empty-state
    // CTA and, once a document is showing, the floating button bottom-right.
    // Three ways in, all the same picker: the empty-state CTA, the floating
    // button over a document, and the always-present topbar button — which is
    // the one that answers "how do I start another one without reloading".
    for (const id of ["upload-btn", "upload-fab", "new-doc-btn"]) {
      $(id).addEventListener("click", () => input.click());
    }
    // Whole-page drag & drop: dragging a file anywhere raises a full-screen
    // "drop to process" overlay (depth-counted — dragenter/leave fire for
    // every child crossed).
    const overlay = $("drop-overlay");
    let depth = 0;
    document.addEventListener("dragenter", (e) => {
      if (!e.dataTransfer || !Array.from(e.dataTransfer.types).includes("Files")) return;
      e.preventDefault();
      depth += 1;
      overlay.classList.remove("hidden");
    });
    document.addEventListener("dragover", (e) => e.preventDefault());
    document.addEventListener("dragleave", () => {
      depth = Math.max(0, depth - 1);
      if (!depth) overlay.classList.add("hidden");
    });
    document.addEventListener("drop", (e) => {
      e.preventDefault();
      depth = 0;
      overlay.classList.add("hidden");
      if (e.dataTransfer && e.dataTransfer.files.length) upload(e.dataTransfer.files[0]);
    });
  }

  let previewUrl = null; // phase 15: object URL of the instant local preview

  async function upload(file) {
    clearError();
    stopPolling();
    const form = new FormData();
    form.append("file", file, file.name);
    form.append("pipeline", $("pipeline-select").value);
    form.append("doc_type_hint", $("doctype-select").value);
    form.append("escalation", $("escalation-select").value);
    let resp;
    try {
      resp = await fetch("/v1/documents", { method: "POST", body: form });
    } catch (err) {
      showError(`upload failed — is the service running? (${err.message})`);
      return;
    }
    let body;
    try { body = await resp.json(); } catch { body = {}; }
    if (!resp.ok && resp.status !== 200) {
      showError(`upload rejected (${resp.status}): ${body.detail || resp.statusText}`);
      return;
    }
    startDocument(body.doc_id);
    // Phase 15: show the picked image immediately (the browser can render it;
    // the served post-prep raster replaces it as soon as it exists). PDFs wait
    // for the first server raster — no client-side PDF renderer is vendored.
    if (previewUrl) { URL.revokeObjectURL(previewUrl); previewUrl = null; }
    if (file.type && file.type.startsWith("image/")) {
      previewUrl = URL.createObjectURL(file);
      Viewer.previewLocal(previewUrl);
    }
  }

  function startDocument(docId) {
    docs.set(docId, { status: null, markdown: null, ir: null });
    active = { docId, timer: null, startedAt: Date.now(), fetchingPages: new Set() };
    Viewer.reset(docId);
    $("tracker").classList.remove("hidden");
    $("upload-fab").classList.remove("hidden");
    $("doc-id-label").textContent = docId;
    for (const id of ["doc-status", "doc-totals", "pipeline-rail"]) {
      const el = $(id);
      el.__html = null;
      el.textContent = "";
    }
    mdBlocks = new Map();
    $("link-hint").classList.add("hidden");
    $("tab-markdown").innerHTML = "";
    $("tab-raw").textContent = "";
    $("tab-ir").replaceChildren();
    $("tab-signals").innerHTML = '<p class="dim">processing…</p>';
    syncPaneActions();
    poll();
  }

  // -- polling ----------------------------------------------------------------

  function stopPolling() {
    if (active && active.timer) clearTimeout(active.timer);
    active = null;
  }

  async function poll() {
    if (!active) return;
    const { docId } = active;
    let resp, status;
    try {
      resp = await fetch(`/v1/documents/${docId}`);
      status = await resp.json();
    } catch (err) {
      showError(`lost contact with the service while polling (${err.message}) — ` +
        "it may have restarted; upload again when it is back.");
      stopPolling();
      return;
    }
    if (!resp.ok) {
      showError(`document ${docId} is gone (${resp.status}) — ` +
        "the service probably restarted (jobs are in-memory); upload again.");
      stopPolling();
      return;
    }
    docs.get(docId).status = status;
    renderTracker(status);
    Viewer.setStatusPages(status.pages);
    fetchCompletedPages(docId, status);
    renderSignals(docId, status);
    renderLiveTranscript(docId);

    if (TERMINAL.has(status.status)) {
      stopPollingKeepDoc();
      await fetchArtifacts(docId, status);
      return;
    }
    const elapsed = Date.now() - active.startedAt;
    const wait = elapsed > POLL_SLOW_AFTER_MS ? POLL_SLOW_MS : POLL_MS;
    active.timer = setTimeout(poll, wait);
  }

  function stopPollingKeepDoc() {
    if (active && active.timer) clearTimeout(active.timer);
    if (active) active.timer = null;
  }

  function fetchCompletedPages(docId, status) {
    for (const page of status.pages || []) {
      // "done" = fully processed; "pending_engine" = pool prep finished but the
      // OCR core hasn't been built yet (phase 08) — its per-page IR (prep record,
      // quality, post-prep dimensions) exists and is worth painting. "rejected"
      // (phase 12) pages have an IR too: quality measured, zero claimed text.
      if (!["done", "pending_engine", "rejected"].includes(page.status)) continue;
      // The escalation status is part of the key (phase 13): a page whose IR was
      // rewritten by a landing escalation must repaint with its VLM blocks.
      const key = `${page.page_no}:${page.escalation || ""}`;
      if (!active || active.fetchingPages.has(key)) continue;
      active.fetchingPages.add(key);
      fetch(`/v1/documents/${docId}/pages/${page.page_no}/ir`)
        .then((r) => (r.ok ? r.json() : null))
        .then((ir) => {
          if (!ir || !active || active.docId !== docId) return;
          Viewer.setPageIR(page.page_no, ir);
          const entry = docs.get(docId);
          if (entry && entry.status) {
            renderSignals(docId, entry.status);
            // The rail's page card shows the OCR confidence, which only exists
            // once this IR is here — repaint it (setHTML dedupes if unchanged).
            renderTracker(entry.status);
          }
          renderLiveTranscript(docId);
        })
        .catch(() => {});
    }
  }

  // -- live transcript (phase 15) ----------------------------------------------
  // While the document is non-terminal, the Markdown tab fills per page with
  // the IR line texts (reading order, staggered in with CSS) — the honest
  // progress view of a poll-based pipeline. The real rendered markdown replaces
  // it at completion, exactly as before.

  function renderLiveTranscript(docId) {
    if (!active || active.docId !== docId) return;
    const entry = docs.get(docId);
    if (!entry || entry.markdown || !entry.status) return; // final markdown wins
    const pages = entry.status.pages || [];
    const sig = pages.map((p) =>
      `${p.page_no}:${p.status}:${Viewer.hasIR(p.page_no) ? 1 : 0}`).join(",");
    if (active.liveSig === sig) return; // no change — don't restart CSS animations
    active.liveSig = sig;

    const parts = [];
    const rawParts = [];
    let delay = 0;
    for (const p of pages) {
      const ir = Viewer.hasIR(p.page_no) ? Viewer.getIR(p.page_no) : null;
      if (!ir) {
        // Same page separator the finished render uses: the boundaries are
        // visible from the first poll, not only at the end.
        const stage = p.stage ? ` · ${p.stage}` : "";
        parts.push(pageSeparator(p.page_no, `${p.status || "queued"}${stage}…`));
        continue;
      }
      const blocks = (ir.blocks || []).slice().sort((a, b) => a.reading_order - b.reading_order);
      const lines = [];
      const rawLines = [];
      for (const block of blocks) {
        for (const line of block.lines || []) {
          lines.push(`<div class="live-line" style="animation-delay:${Math.min(delay, 1400)}ms">` +
            `${esc(line.text)}</div>`);
          rawLines.push(line.text);
          delay += 35;
        }
      }
      parts.push(pageSeparator(p.page_no, ir.origin) +
        `<div class="live-page" data-live-page="${p.page_no}">${lines.join("")}</div>`);
      rawParts.push(rawLines.join("\n"));
    }
    $("tab-markdown").innerHTML = `<div class="live-transcript">${parts.join("")}</div>`;
    $("tab-raw").textContent = rawParts.join("\n\n");
  }

  // -- tracker: the pipeline rail ---------------------------------------------
  // Phase 15: one scrollable line — document stages as connected steps, then a
  // card per page — and every element explains itself in plain words through
  // data-tip. Each region rebuilds only when its HTML actually changed
  // (setHTML), so the CSS animations never restart on an idle poll.

  const STAGE_INFO = {
    ingest: { label: "Ingest", sub: "receive & checksum",
      tip: "the upload is accepted: bytes checksummed (an identical re-upload dedupes to the " +
        "same result), format sniffed, pages counted" },
    classify: { label: "Classify", sub: "digital or scan?",
      tip: "every page is probed for a usable born-digital text layer — pages that have one " +
        "skip OCR entirely and are exact by construction; the rest go down the image path" },
    raster: { label: "Raster", sub: "pages → images",
      tip: "PDF pages are rendered to images — the page pictures shown on the left" },
    extract: { label: "Extract", sub: "read the text layer",
      tip: "digital pages: text is read straight out of the PDF's embedded layer, with " +
        "positions — exact, no OCR, no confidence loss" },
    prep: { label: "Prep", sub: "clean up the image",
      tip: "raster pages: deskew, denoise, normalise — OCR runs on this cleaned image, and " +
        "the boxes on the left are drawn on it 1:1" },
    ocr: { label: "OCR", sub: "detect + recognise",
      tip: "text detection and recognition on the prepped image — CPU-only and deterministic; " +
        "every line carries a confidence score" },
    layout: { label: "Layout", sub: "group into blocks",
      tip: "recognised lines are grouped into typed blocks (paragraph, header, table, …) " +
        "with a reading order" },
    table: { label: "Tables", sub: "rows & columns",
      tip: "table regions are cut into cells with row/column coordinates so the structure " +
        "survives into the output" },
    triage: { label: "Triage", sub: "accept / escalate",
      tip: "confidence and structure checks decide per page: accept, flag for review, or " +
        "escalate the weak region — below-threshold text is never emitted as if certain" },
    escalate: { label: "Escalate", sub: "VLM assist",
      tip: "only what CPU OCR could not read confidently goes to the VLM — cropped to the " +
        "failing region, grounded with the OCR text, and budgeted" },
  };

  const DOC_STATUS_TIP = {
    queued: "accepted — waiting for a worker slot.",
    processing: "pages are being processed in parallel; results land below as they finish.",
    done: "every page fully processed.",
    partial: "served, but at least one page could not be fully processed — " +
      "the page cards say which and why.",
    failed: "processing failed — nothing could be served for this document.",
    rejected: "not processed: the file was refused up front (unsupported, corrupt, or over limits).",
  };

  const ROUTE_TIP = {
    digital: "route: this page had a usable embedded text layer, so its text is copied out " +
      "exactly — no OCR involved",
    ocr: "route: no usable text layer — this page went down the image path " +
      "(prep → detect → recognise), so every line carries a confidence score",
  };

  // innerHTML that skips when nothing changed — the guard that keeps infinite
  // CSS animations (pulse, spin, link-flow) from restarting every 500 ms poll.
  function setHTML(el, html) {
    if (el.__html === html) return false;
    el.__html = html;
    el.innerHTML = html;
    return true;
  }

  function renderTracker(status) {
    const live = !TERMINAL.has(status.status);

    const badge = $("doc-status");
    const badgeHTML = `<span class="dot${live ? " pulse" : ""}"></span>${esc(status.status)}` +
      (status.degraded ? '<span class="deg">degraded</span>' : "");
    if (setHTML(badge, badgeHTML)) {
      badge.className = `doc-status ${status.status}${status.degraded ? " degraded" : ""}`;
      badge.dataset.tip = (DOC_STATUS_TIP[status.status] || status.status) + (status.degraded
        ? " Degraded: an escalation was skipped or failed — those pages are flagged, not guessed."
        : "");
    }

    const totals = status.totals || {};
    const bits = [];
    if (live && active) {
      bits.push('<span data-tip="time since upload (client clock) — the measured total ' +
        `replaces this when the document finishes">${
          ((Date.now() - active.startedAt) / 1000).toFixed(1)}s elapsed</span>`);
    } else if (totals.ms != null) {
      bits.push('<span data-tip="measured end-to-end processing time (from stage provenance, ' +
        `not estimated)">${Math.round(totals.ms)} ms total</span>`);
    }
    if (!live) {
      bits.push('<span data-tip="actual provider spend for this document — the CPU path costs ' +
        `nothing per call; only VLM escalations are billed">₹${
          (totals.cost_inr || 0).toFixed(4)} spent</span>`);
    }
    if (totals.escalated_pages) {
      bits.push('<span data-tip="pages where a low-confidence region was re-read by the VLM">' +
        `${totals.escalated_pages} escalated</span>`);
    }
    if (status.pipeline) {
      bits.push('<span data-tip="pipeline configuration + version that processed this ' +
        `document">pipeline ${esc(status.pipeline)}</span>`);
    }
    setHTML($("doc-totals"), bits.join('<span class="meta-dot">·</span>'));

    const stages = status.stages || [];
    const parts = stages.flatMap((s, i) => {
      const node = stageNode(s);
      if (i === 0) return [node];
      const prev = stages[i - 1].status;
      const cls = prev === "done" ? "done" : prev === "failed" ? "failed" : "";
      return [`<span class="rail-link ${cls}"></span>`, node];
    });
    if (live) {
      parts.push('<span class="rail-link flow"></span>',
        '<span class="rail-node ghost" data-tip="later stages appear here as the pipeline ' +
        "reaches them — per-page work (prep, OCR, triage, escalation) shows on the page cards " +
        'to the right">…</span>');
    }
    const pages = status.pages || [];
    if (pages.length) {
      parts.push('<span class="rail-sep"></span>',
        '<span class="rail-caption" data-tip="one card per page: its route (digital text ' +
        "layer or OCR), what it is doing right now, and how it ended — click a card to show " +
        `that page on the left">${pages.length > 1 ? "pages" : "page"}</span>`);
      for (const p of pages) parts.push(pageCard(p));
    }
    setHTML($("pipeline-rail"), parts.join(""));
  }

  /* Page cards switch the page shown on the left. The listener lives on the
   * rail itself, not on the cards: the rail rebuilds as the pipeline advances,
   * so a card is a short-lived node — one that a press can easily outlive.
   * When the pressed card is replaced between pointerdown and pointerup the
   * browser fires the click on the surviving ancestor (the rail) instead, and
   * the page recorded at pointerdown is what the user actually aimed at. */
  function wireRail() {
    const rail = $("pipeline-rail");
    let pressed = null;
    const pageOf = (target) => {
      const card = target instanceof Element ? target.closest("[data-page]") : null;
      return card ? Number(card.dataset.page) : null;
    };
    rail.addEventListener("pointerdown", (e) => { pressed = pageOf(e.target); });
    rail.addEventListener("click", (e) => {
      const page = pageOf(e.target) ?? pressed;
      pressed = null;
      if (page) Viewer.goto(page);
    });
  }

  function stageIcon(status) {
    return status === "done" ? "✓"
      : status === "failed" ? "✗"
      : status === "processing" ? '<span class="spin">⟳</span>' : "·";
  }

  function stageNode(s) {
    const info = STAGE_INFO[s.stage] || { label: s.stage, sub: "", tip: s.stage };
    const cls = s.status === "processing" ? "running" : s.status;
    const ms = s.status === "done" && s.ms != null
      ? `<span class="n-ms">${Math.round(s.ms)} ms</span>` : "";
    return `<span class="rail-node ${cls}" data-tip="${esc(info.tip)}">` +
      `<span class="n-top"><span class="n-icon">${stageIcon(s.status)}</span>` +
      `${esc(info.label)}${ms}</span>` +
      `<span class="n-sub">${esc(info.sub)}</span></span>`;
  }

  function pageCard(p) {
    const cls = p.status === "processing" ? "running" : p.status;
    const icon = p.status === "processing" ? '<span class="spin">⟳</span>'
      : p.status === "done" ? "✓"
      : p.status === "failed" ? "✗"
      : p.status === "rejected" ? "⛔"
      : p.status === "pending_engine" ? "⏸" : "·";
    const route = p.route
      ? ` <span class="route ${esc(p.route)}" data-tip="${esc(ROUTE_TIP[p.route] || p.route)}">` +
        `${esc(p.route)}</span>`
      : "";
    const [sub, tip] = pageExplain(p);
    return `<span class="rail-node page ${cls}" data-page="${p.page_no}" data-tip="${esc(tip)}">` +
      `<span class="n-top"><span class="n-icon">${icon}</span>Page ${p.page_no}${route}` +
      `${pageFlags(p)}</span>` +
      `<span class="n-sub">${esc(sub)}</span></span>`;
  }

  // The one-line story of a page: [sublabel shown on the card, hover explanation].
  function pageExplain(p) {
    if (p.status === "queued") {
      return ["waiting for a worker…", "queued behind the pages currently being processed"];
    }
    if (p.status === "processing") {
      const info = STAGE_INFO[p.stage];
      if (info) {
        return [`${info.label.toLowerCase()} — ${info.sub}…`,
          `currently in the ${info.label} stage: ${info.tip}`];
      }
      return [`${p.stage || "working"}…`, "this page is being processed right now"];
    }
    if (p.status === "pending_engine") {
      return ["prepped — awaiting OCR core", p.reason ||
        "the image is prepped, but the OCR core is not available in this build — " +
        "no text is claimed for it (abstention over guessing)"];
    }
    if (p.status === "rejected") {
      return [p.reason || "rejected",
        "the quality gate refused to claim text for this page (abstention over guessing) — " +
        "the Signals tab shows the measured quality that triggered it"];
    }
    if (p.status === "failed") {
      return ["failed", "the worker failed on this page; the rest of the document is " +
        "still served (document status: partial)"];
    }
    if (p.route === "digital") {
      return ["exact text layer", "this text came straight from the PDF's embedded text " +
        "layer — exact by construction, no OCR involved"];
    }
    const ir = Viewer.getIR(p.page_no);
    const conf = ir && ir.confidence ? ir.confidence.mean_rec : null;
    const sub = conf != null ? `${(conf * 100).toFixed(1)}% confident` : "read by OCR";
    let tip = "read by CPU OCR on the prepped image; the score is the mean recognizer " +
      "confidence across lines — the Signals tab has the full breakdown";
    if (p.triage) tip += `. Triage: ${p.triage}${p.trigger ? ` (trigger: ${p.trigger})` : ""}`;
    return [sub, tip];
  }

  // Phase-12/13 flags on a page card: review_required and the escalation
  // outcome stay visible without opening the Signals tab.
  function pageFlags(p) {
    let out = "";
    if (p.review_required) {
      out += ' <span class="flag review" data-tip="triage flagged this page for human ' +
        'review — its confidence or structure checks fell below the accept threshold">⚑</span>';
    }
    if (!p.escalation) return out;
    if (p.escalation === "running") {
      out += ' <span class="flag vlm" data-tip="a low-confidence region is being re-read ' +
        'by the VLM right now"><span class="spin">⤴</span></span>';
    } else if (p.escalation === "done") {
      out += ' <span class="flag vlm" data-tip="a low-confidence region was re-read by the ' +
        'VLM — the Signals tab shows exactly what changed">⤴</span>';
    } else {
      out += ` <span class="flag degraded" data-tip="escalation ${esc(p.escalation)} — the ` +
        "VLM assist did not fully happen (no key, switched off, budget, or failure), so the " +
        'page keeps its OCR text and is flagged degraded">⤴</span>';
    }
    return out;
  }

  // -- artifacts + tabs -------------------------------------------------------

  async function fetchArtifacts(docId, status) {
    const entry = docs.get(docId);
    if (["done", "partial"].includes(status.status)) {
      try {
        const md = await (await fetch(`/v1/documents/${docId}/markdown`)).text();
        entry.markdown = md;
        // Renderer 1.5: the stored projection already carries a
        // `<!-- block: id · type · bbox: ... -->` comment per block, which is
        // what links rendered text back to the box it came from — so the Raw
        // tab and the rendered tab are the same bytes, and there is no second
        // request for an anchored variant.
        renderMarkdown(md);
        $("tab-raw").textContent = md;
      } catch { /* markdown missing is not fatal to the viewer */ }
      try {
        const ir = await (await fetch(`/v1/documents/${docId}/ir`)).json();
        entry.ir = ir;
        renderIRTree(ir);
        renderSignals(docId, status); // provenance table needs the document IR
      } catch { /* ditto */ }
    } else if (status.status === "rejected") {
      showError(`document rejected: ${status.reject_reason || "no reason given"}`);
    } else if (status.status === "failed") {
      showError("document processing failed — see service logs.");
    }
    syncPaneActions();
  }

  // -- rendered Markdown: page separation + the link back to the page image ----
  // Built from the anchored projection: `<!-- page N · origin: X -->` and
  // `<!-- block: id -->` survive marked.parse() as comment nodes, and become a
  // visible page rule and one wrapper per block. The wrapper carries the link —
  // click a box on the page and its text lights up here; click the text and the
  // box lights up there. Without anchors (older document, failed fetch) the
  // page rules still render; only the linking is absent.

  // Both comments carry optional trailing metadata (renderer 1.5: page size on
  // the page comment, `· type · bbox: ...` on the block one), so neither pattern
  // may anchor at the end — it would stop matching the moment more is added.
  const PAGE_COMMENT = /^\s*page\s+(\d+)\s*·\s*origin:\s*([^\s·]+)(?:\s*·\s*(\d+)x(\d+))?/;
  const BLOCK_COMMENT = /^\s*block:\s*([^\s·]+)/;
  // Renderer 1.5 also carries the type and the page-space bbox, which is what
  // lets the rendered view put side-by-side content side by side.
  // `grid:` is a recognised table's own lines; `layout:` is the grid a block of
  // scattered content was projected onto so that its two-dimensional
  // arrangement survives in *any* Markdown renderer (renderer 1.9). Both give
  // the same thing here — the boundaries to pin the rendered table to.
  const GRID_COMMENT =
    /^\s*(?:grid|layout):\s*(\S+)\s*·\s*cols:\s*([\d,]+)\s*·\s*rows:\s*([\d,]+)/;
  // Every emitted line's own box, on any block that projects to more than one
  // (renderer 1.8). The block box locates the region; this locates each line
  // inside it, so nothing here has to infer a position from a line count.
  // Renderer 1.10 adds the two numbers a box cannot carry on its own: how many
  // page lines are stacked inside it, and how tall their type was. A reflowed
  // paragraph is one emitted line over a box eight lines deep, and reading that
  // box as a single line squeezes the paragraph to 2 px to make it fit.
  const ROW_COMMENT =
    /^\s*row:\s*(\d+),(\d+),(\d+),(\d+)(?:\s*·\s*lines:\s*(\d+))?(?:\s*·\s*text-h:\s*(\d+))?/;
  const BLOCK_GEOMETRY =
    /^\s*block:\s*(\S+)\s*·\s*(\S+)\s*·\s*bbox:\s*(\d+),(\d+),(\d+),(\d+)\s*·\s*lines:\s*(\d+)(?:\s*·\s*text-h:\s*(\d+))?/;

  let mdBlocks = new Map(); // `${page}:${block_id}` -> wrapper element

  // Marked runs on stated options, never on whatever its defaults happen to be:
  // the projection emits GFM pipe tables, so `gfm` is what makes a table a
  // table; `breaks` stays off because a paragraph's line ends are the
  // projection's own `\` hard breaks, not every newline in the file; `pedantic`
  // would drop GFM entirely.
  function configureMarked() {
    if (window.marked && marked.setOptions) {
      marked.setOptions({ gfm: true, breaks: false, pedantic: false });
    }
  }

  // Marked passes raw HTML through, which the projection needs — a table with
  // spanning cells projects to `<table>`, a multi-line cell to `<br>`. But the
  // rest of the projection is *document text*, and a document can print
  // anything, `<script>` and `<img onerror=…>` included. So the parse happens
  // inside an inert `<template>` (nothing loads, nothing runs), the tree is
  // cleaned, and only then does it reach the page.
  const UNSAFE_TAGS = new Set([
    "SCRIPT", "STYLE", "IFRAME", "OBJECT", "EMBED", "LINK", "META", "BASE", "FORM",
  ]);

  function parseMarkdown(text) {
    const tpl = document.createElement("template");
    tpl.innerHTML = marked.parse(text);
    for (const el of [...tpl.content.querySelectorAll("*")]) {
      if (UNSAFE_TAGS.has(el.tagName)) { el.remove(); continue; }
      for (const attr of [...el.attributes]) {
        const name = attr.name.toLowerCase();
        const unsafeUrl = (name === "href" || name === "src")
          && /^\s*(javascript|data|vbscript):/i.test(attr.value);
        if (name.startsWith("on") || unsafeUrl) el.removeAttribute(attr.name);
      }
    }
    return tpl.content;
  }

  function renderMarkdown(text) {
    const host = $("tab-markdown");
    // Phase 15: the live transcript fades out under the final render.
    const doc = document.createElement("div");
    doc.className = "fade-in md-doc";
    doc.appendChild(parseMarkdown(text));
    host.replaceChildren(doc);
    mdBlocks = groupMarkdown(doc);
    $("link-hint").classList.toggle("hidden", mdBlocks.size === 0);
  }

  function pageSeparator(pageNo, label) {
    return `<div class="md-page-sep" data-page="${pageNo}" data-tip="page boundary in the ` +
      `source document — click to show this page on the left">` +
      '<span class="md-page-rule"></span>' +
      `<span class="md-page-label">page ${pageNo}${label ? ` · ${esc(label)}` : ""}</span>` +
      '<span class="md-page-rule"></span></div>';
  }

  const pageSize = new Map(); // page_no -> {w, h} from the page comment

  function groupMarkdown(root) {
    const index = new Map();
    pageSize.clear();
    if (!root) return index;
    const frag = document.createDocumentFragment();
    let page = 1;
    let group = null;
    // A rule is held back one node: the `---` the projection puts before every
    // page comment is replaced by the labelled separator, and any other rule is
    // ordinary content that belongs where it was found.
    let rule = null;
    let ruleParent = null;
    let block = null; // the block the rows being read belong to
    const flushRule = () => {
      if (rule) ruleParent.appendChild(rule);
      rule = null;
    };
    for (const node of [...root.childNodes]) {
      if (node.nodeType === Node.COMMENT_NODE) {
        const asPage = PAGE_COMMENT.exec(node.nodeValue);
        const asBlock = BLOCK_COMMENT.exec(node.nodeValue);
        if (asPage) {
          rule = null; // the labelled separator stands in for the bare rule
          page = Number(asPage[1]);
          group = null;
          if (asPage[3]) pageSize.set(page, { w: +asPage[3], h: +asPage[4] });
          const sep = html(pageSeparator(page, asPage[2]));
          sep.dataset.pageSep = String(page);
          frag.appendChild(sep);
        } else if (GRID_COMMENT.test(node.nodeValue)) {
          // Follows its block's geometry comment: the row/column boundaries the
          // grid is drawn on, which a pipe table cannot express.
          const g = GRID_COMMENT.exec(node.nodeValue);
          if (group && g && group.dataset.blockId === g[1]) {
            group.dataset.cols = g[2];
            group.dataset.rows = g[3];
          }
          continue;
        } else if (ROW_COMMENT.test(node.nodeValue)) {
          // One positioned unit per emitted line — the same treatment a block
          // gets, because when a block projects to several lines the line *is*
          // the unit whose position carries meaning.
          const r = ROW_COMMENT.exec(node.nodeValue);
          flushRule();
          group = document.createElement("div");
          group.className = "md-block";
          group.dataset.page = String(page);
          group.dataset.x0 = r[1];
          group.dataset.y0 = r[2];
          group.dataset.x1 = r[3];
          group.dataset.y1 = r[4];
          // Pre-1.10 artifacts carry neither: one line, type as tall as the box.
          group.dataset.lines = r[5] || "1";
          group.dataset.textH = r[6] || String(Math.max(1, +r[4] - +r[2]));
          if (block) {
            group.dataset.blockId = block.id;
            // A row filling its whole block is the block's own stand-in — a
            // figure's `[figure]` marker over the region it replaces — and
            // keeps the block's type so it still draws as that region. Every
            // other row is one line of text inside it.
            const whole = block.box && r.slice(1, 5).join(",") === block.box;
            group.dataset.type = whole ? block.type : `${block.type}-row`;
          }
          frag.appendChild(group);
          continue;
        } else if (asBlock) {
          flushRule();
          group = document.createElement("div");
          group.className = "md-block";
          group.dataset.page = String(page);
          group.dataset.blockId = asBlock[1];
          const geo = BLOCK_GEOMETRY.exec(node.nodeValue);
          if (geo) {
            group.dataset.type = geo[2];
            group.dataset.x0 = geo[3];
            group.dataset.y0 = geo[4];
            group.dataset.x1 = geo[5];
            group.dataset.y1 = geo[6];
            group.dataset.lines = geo[7];
            if (geo[8]) group.dataset.textH = geo[8];
          }
          block = {
            id: asBlock[1],
            type: geo ? geo[2] : "paragraph",
            box: geo ? geo.slice(3, 7).join(",") : null,
          };
          index.set(`${page}:${asBlock[1]}`, group);
          frag.appendChild(group);
        }
        continue;
      }
      if (node.nodeType === Node.TEXT_NODE && !node.nodeValue.trim()) continue;
      if (node.nodeName === "HR") {
        flushRule();
        rule = node;
        ruleParent = group || frag;
        continue;
      }
      flushRule();
      (group || frag).appendChild(node);
    }
    flushRule();
    root.replaceChildren(frag);
    layoutSpatial(root);
    if (!spatialMode) flowLayout(root, index);
    return index;
  }

  // -- flow reading: the same content without the page's geometry -------------
  // Two things have to be adjusted for a linear read to stay honest.

  function flowLayout(root, index) {
    collapseRuleRuns(root, index);
    decorateTables(root);
  }

  // A `rule` block is one stroke the page drew, and a drawn figure is made of
  // dozens of them — a diagram page projects to sixty in a row. Placed on the
  // canvas they are the figure's box sides; stacked in a flow they are sixty
  // full-width horizontal rules with nothing between them, which reads as a
  // broken render rather than as a document. A run collapses to one marker that
  // says what it stands for and where to see it drawn.
  function collapseRuleRuns(root, index) {
    let run = [];
    const collapse = () => {
      if (run.length >= 3) {
        const mark = document.createElement("div");
        mark.className = "md-figure-rule";
        mark.dataset.page = run[0].dataset.page;
        mark.textContent =
          `${run.length} ruled lines — a drawn figure; switch on layout to see it placed`;
        run[0].before(mark);
        for (const el of run) {
          index.delete(`${el.dataset.page}:${el.dataset.blockId}`);
          el.remove();
        }
      }
      run = [];
    };
    for (const node of [...root.children]) {
      if (node.classList.contains("md-block") && node.dataset.type === "rule") run.push(node);
      else collapse();
    }
    collapse();
  }

  // A projected table can be wider than the pane, so it gets its own scroll box
  // and the pane itself never scrolls sideways. It also gets a copy button: a
  // table is the thing most likely to be pasted somewhere else, and the pipe
  // table rebuilt from the DOM is what the projection emitted.
  function decorateTables(root) {
    for (const table of [...root.querySelectorAll("table")]) {
      if (table.parentElement.classList.contains("md-table-scroll")) continue;
      // Two boxes, not one: the scroll box clips, so the copy button has to sit
      // outside it or it is clipped away with everything else.
      const wrap = document.createElement("div");
      wrap.className = "md-table-wrap";
      const scroll = document.createElement("div");
      scroll.className = "md-table-scroll";
      table.replaceWith(wrap);
      scroll.appendChild(table);
      wrap.appendChild(scroll);
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "md-table-copy";
      btn.textContent = "copy";
      btn.dataset.tip = "copy this table as a Markdown pipe table";
      btn.addEventListener("click", (e) => {
        e.stopPropagation(); // the click on a block is the link back to its box
        copyInto(btn, tableAsMarkdown(table), "copy");
      });
      wrap.appendChild(btn);
    }
  }

  const cellText = (c) => c.textContent.replace(/\s+/g, " ").trim().replace(/\|/g, "\\|");

  function tableAsMarkdown(table) {
    const rows = [...table.rows].map((r) => [...r.cells].map(cellText));
    if (!rows.length) return "";
    const width = Math.max(...rows.map((r) => r.length));
    const line = (cells) => `| ${cells.concat(Array(width - cells.length).fill("")).join(" | ")} |`;
    const sep = `| ${Array(width).fill("---").join(" | ")} |`;
    return [line(rows[0]), sep, ...rows.slice(1).map(line)].join("\n");
  }

  // -- spatial layout: place blocks where they sat on the page -----------------
  // Markdown is linear, so a heading in the left margin and the date opposite it
  // become two stacked paragraphs and the page's shape is lost. The projection
  // carries every block's page-space bbox (renderer 1.5), so the rendered view
  // reads it back and positions each block on a page-sized canvas, scaled to the
  // pane. The Markdown itself is untouched — this is presentation only, and it
  // degrades to the plain flow whenever the geometry is absent.

  let spatialMode = true;

  const box = (el) => (el.dataset.x0 === undefined ? null : {
    x0: +el.dataset.x0, y0: +el.dataset.y0, x1: +el.dataset.x1, y1: +el.dataset.y1,
  });

  function layoutSpatial(root) {
    if (!root) return;
    root.classList.toggle("md-spatial", spatialMode);
    if (!spatialMode) return;
    // Walk the flow, moving each page's blocks onto their own canvas.
    let canvas = null;
    let size = null;
    for (const node of [...root.children]) {
      if (node.dataset.pageSep !== undefined) {
        const page = Number(node.dataset.pageSep);
        size = pageSize.get(page) || null;
        canvas = null;
        if (size) {
          canvas = document.createElement("div");
          canvas.className = "md-canvas";
          canvas.dataset.page = String(page);
          // True page pixel space inside; one transform scales the whole thing,
          // so every bbox is used verbatim and text scales with its box.
          canvas.style.width = `${size.w}px`;
          canvas.style.height = `${size.h}px`;
          const frame = document.createElement("div");
          frame.className = "md-canvas-frame";
          frame.appendChild(canvas);
          node.after(frame);
        }
        continue;
      }
      if (!canvas || !node.classList.contains("md-block")) continue;
      const b = box(node);
      if (!b) continue;
      node.style.left = `${b.x0}px`;
      node.style.top = `${b.y0}px`;
      node.style.width = `${Math.max(1, b.x1 - b.x0)}px`;
      // A visual block's box *is* its content, so it gets its measured height
      // too. A rule is then drawn by filling that box: an 8x300 box is a
      // vertical stroke, a 700x8 box a horizontal one. Markdown has only `***`
      // for both, and rendering a box side as a horizontal bar was wrong.
      if (node.dataset.type === "rule" || node.dataset.type === "figure") {
        node.style.height = `${Math.max(1, b.y1 - b.y0)}px`;
      }
      // Type size is the block's *measured* text height; the line box is the
      // block's height shared over its lines. The two are different numbers —
      // pitch includes the leading — and using pitch for both rendered generously
      // spaced text several times too large, which is what made blocks collide.
      //
      // The pitch is only meaningful when the block's lines actually stack. When
      // they sit side by side on one y-band — a footer's date/department/page, a
      // table row's cells — the block is one row tall while carrying three
      // lines, and Markdown has no choice but to stack them. Dividing then
      // inverts: a 55px-tall block with three 55px lines yields an 18px line box
      // for 45px glyphs, and the text lands on top of itself. So the pitch is a
      // preference, never a licence to draw a line box shorter than its own
      // text. Measured on the reported deck: 21 blocks were below that floor.
      const lines = Math.max(1, +node.dataset.lines || 1);
      const pitch = (b.y1 - b.y0) / lines;
      const textH = +node.dataset.textH || pitch;
      // A region's marker (`[figure]`, `[signature]`) is a label *about* the box,
      // not text that was printed at that size — scaling it to a full-page photo
      // draws the word "[figure]" across the whole page. A region that also
      // carries a layout grid is not that case: the grid is the page's own text,
      // and it takes the text's own height like anything else.
      const table = node.querySelector("table");
      const marker =
        !table && (node.dataset.type === "figure" || node.dataset.type === "signature");
      const fontPx = marker ? 13 : Math.max(4, textH * 0.82);
      node.style.fontSize = `${fontPx}px`;
      // A table's rows are pinned to the grid the page drew, so its own line
      // box must be the text's, not the row pitch — a two-line cell in a tall
      // row would otherwise be spaced as if each of its lines were a row.
      node.style.lineHeight = table
        ? `${fontPx * 1.15}px`
        : `${Math.max(1, pitch, fontPx * 1.15)}px`;
      applyGrid(node, b);
      canvas.appendChild(node);
      // A single source line (a label, a table-adjacent value, a heading) was
      // exactly one line on the page and must render as exactly one — never
      // wrapped. Without this, a font size picked from height alone can still
      // be too *wide* for the box: the browser wraps it, the block's height was
      // never reserved for a second line, and that line spills down over
      // whatever sits in the row beneath it. That is the overlap bug: two rows
      // of real, correctly-positioned text reading as garbled because one
      // block silently grew into the other's space.
      if (lines <= 1 && node.textContent.trim()) {
        node.style.whiteSpace = "nowrap";
        fitSingleLineWidth(node, Math.max(1, b.x1 - b.x0));
      } else if (!table && node.textContent.trim()) {
        // The mirror image for a box that holds several lines: it must wrap,
        // and it must wrap into its own height. Prose reflowed at a font the
        // page did not use takes one line more than the page did, and that
        // line lands on the block below.
        fitWrappedHeight(node, Math.max(1, b.y1 - b.y0));
      } else if (table) {
        fitTableHeight(node, table, Math.max(1, b.y1 - b.y0));
      }
    }
    fitCanvases(root);
  }

  // Shrink a nowrap block's font until it actually fits the width its bbox
  // measured on the page — a glyph-width estimate, not the page's own metrics,
  // so it is checked against the real rendered width rather than trusted.
  function fitSingleLineWidth(node, maxWidth) {
    let size = parseFloat(node.style.fontSize) || 12;
    const floor = 4;
    for (let i = 0; i < 6 && node.scrollWidth > maxWidth && size > floor; i += 1) {
      size = Math.max(floor, size * (maxWidth / node.scrollWidth) * 0.98);
      node.style.fontSize = `${size}px`;
    }
  }

  // A row's height is a *minimum* in CSS, never a maximum: a cell whose text
  // needs two lines where the page printed one makes its row taller, every row
  // under it shifts down, and the table grows out of the bottom of its own
  // measured box and over whatever the page printed beneath it. That is the
  // garbled render — two correctly positioned tables drawn on top of each other.
  //
  // `applyGrid` pins the rows to the grid the page drew; this makes the text
  // small enough to live inside them. Measured, like the other two fitters: the
  // table is re-read after each step rather than solved for, because changing
  // the font changes where every cell wraps.
  function fitTableHeight(node, table, maxHeight) {
    let size = parseFloat(node.style.fontSize) || 12;
    const floor = 4;
    for (let i = 0; i < 6 && table.offsetHeight > maxHeight && size > floor; i += 1) {
      const shrink = Math.max(0.75, Math.sqrt(maxHeight / table.offsetHeight));
      size = Math.max(floor, size * shrink);
      node.style.fontSize = `${size}px`;
      node.style.lineHeight = `${size * 1.15}px`;
    }
  }

  // The same for a wrapping block: shrink until the reflowed text fits the
  // height its lines occupied on the page. Each step changes where the text
  // wraps, so the result is measured again rather than solved for.
  function fitWrappedHeight(node, maxHeight) {
    let size = parseFloat(node.style.fontSize) || 12;
    const floor = 4;
    for (let i = 0; i < 6 && node.scrollHeight > maxHeight && size > floor; i += 1) {
      const shrink = Math.max(0.75, Math.sqrt(maxHeight / node.scrollHeight));
      size = Math.max(floor, size * shrink);
      node.style.fontSize = `${size}px`;
      node.style.lineHeight = `${size * 1.15}px`;
    }
  }

  // A rendered table auto-sizes both axes, so a table built from Markdown lands
  // nowhere near the grid it was read from — and, worse, grows past its own
  // measured box and covers whatever the page put underneath it. The projection
  // carries the real boundaries in both directions; this pins every column and
  // every row to the size it had on the page, so the table occupies exactly the
  // space it occupied in the document and the rules line up with it.
  function applyGrid(node, b) {
    const table = node.querySelector("table");
    if (!table || !node.dataset.cols) return;
    const cols = node.dataset.cols.split(",").map(Number);
    if (cols.length < 2) return;
    table.style.tableLayout = "fixed";
    table.style.width = `${Math.max(1, b.x1 - b.x0)}px`;
    const group = document.createElement("colgroup");
    for (let i = 0; i < cols.length - 1; i += 1) {
      const col = document.createElement("col");
      col.style.width = `${Math.max(1, cols[i + 1] - cols[i])}px`;
      group.appendChild(col);
    }
    table.prepend(group);
    const rows = (node.dataset.rows || "").split(",").map(Number).filter((v) => !isNaN(v));
    if (rows.length < 2) return;
    const trs = [...table.querySelectorAll("tr")];
    // GFM can express exactly one header row, so a table the IR says has no
    // header gets a synthetic empty one that no grid row corresponds to. It is
    // always the first, which is what makes the count difference an offset.
    const offset = trs.length - (rows.length - 1);
    trs.forEach((tr, i) => {
      const g = i - offset;
      if (g >= 0 && g < rows.length - 1) {
        tr.style.height = `${Math.max(1, rows[g + 1] - rows[g])}px`;
      }
    });
    table.style.height = `${Math.max(1, rows[rows.length - 1] - rows[0])}px`;
  }

  // Scale each canvas to the pane. Re-run on resize and on splitter drags, since
  // the pane width is what decides the scale.
  // "page" puts a whole page on screen at once — the document read the way it is
  // held, one page per view, with the scroll snapping between them. "width" fills
  // the pane's width instead, which is what you want to actually read the text
  // and is the only sensible choice on a narrow pane. Persisted, because it is a
  // habit rather than a per-document decision.
  let fitMode = "page";

  const PAGE_FIT_MIN_HEIGHT = 320;

  function fitCanvases(root) {
    const host = root || $("tab-markdown").querySelector(".md-doc");
    if (!host) return;
    const body = $("tab-markdown");
    const avail = host.clientWidth || body.clientWidth;
    // The pane's own height, less the page label above each canvas — the page
    // has to fit under it, not behind it.
    const frames = [...host.querySelectorAll(".md-canvas-frame")];
    const label = host.querySelector(".md-page-sep");
    const chrome = label ? label.offsetHeight + 24 : 24;
    const availH = Math.max(PAGE_FIT_MIN_HEIGHT, body.clientHeight - chrome);
    for (const frame of frames) {
      const canvas = frame.firstElementChild;
      const w = parseFloat(canvas.style.width);
      const h = parseFloat(canvas.style.height);
      if (!w || !h || !avail) continue;
      const scale = fitMode === "page" ? Math.min(avail / w, availH / h) : avail / w;
      canvas.style.transform = `scale(${scale})`;
      frame.style.height = `${h * scale}px`;
      // A page narrower than the pane is centred rather than left-aligned —
      // off to one side it reads as a rendering mistake.
      frame.style.paddingLeft = `${Math.max(0, (avail - w * scale) / 2)}px`;
    }
    body.classList.toggle("md-snap", fitMode === "page" && frames.length > 1);
  }

  function wireSpatialToggle() {
    const cb = $("spatial-mode");
    if (!cb) return;
    cb.addEventListener("change", () => {
      spatialMode = cb.checked;
      $("fit-mode").classList.toggle("hidden", !spatialMode || activeTab !== "markdown");
      const entry = active && docs.get(active.docId);
      if (entry && entry.markdown) renderMarkdown(entry.markdown);
    });
    try {
      const saved = localStorage.getItem("md-fit-mode");
      if (saved === "page" || saved === "width") fitMode = saved;
    } catch { /* private mode */ }
    const fit = $("fit-mode");
    for (const btn of fit.querySelectorAll("button")) {
      btn.classList.toggle("active", btn.dataset.fit === fitMode);
      btn.addEventListener("click", () => {
        fitMode = btn.dataset.fit;
        for (const other of fit.querySelectorAll("button")) {
          other.classList.toggle("active", other === btn);
        }
        try { localStorage.setItem("md-fit-mode", fitMode); } catch { /* private mode */ }
        fitCanvases(null);
      });
    }
    // Both axes of the pane set the scale, so a window resize and a splitter drag
    // (which dispatches one) have to re-fit.
    window.addEventListener("resize", () => fitCanvases(null));
  }

  // -- Fields tab (ADR 0013): named lookup over the finished IR ---------------
  // The engine's job ends at the IR; this asks it a question. Everything shown
  // here comes back with the OCR text, box, confidence and origin it was read
  // from, because a value without those is the bare string the IR exists to
  // prevent.

  let lastFields = null;

  const fieldNames = () =>
    $("fields-input").value
      .split(/[\n,]/)
      .map((s) => s.trim())
      .filter(Boolean);

  let fieldsView = "table";

  function wireFields() {
    const box = $("fields-input");
    $("fields-run").addEventListener("click", runFields);
    // The box is a *list*, so Enter has to add a line — binding it to submit is
    // what made it impossible to ask for a second field. The shortcut runs it.
    box.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); runFields(); }
    });
    box.addEventListener("input", syncFieldCount);
    $("fields-labels").addEventListener("click", showLabels);
    $("fields-copy").addEventListener("click", () => {
      copyInto($("fields-copy"), lastFields ? JSON.stringify(lastFields, null, 2) : "", "copy JSON");
    });
    const view = $("fields-view");
    for (const btn of view.querySelectorAll("button")) {
      btn.addEventListener("click", () => {
        fieldsView = btn.dataset.view;
        for (const other of view.querySelectorAll("button")) {
          other.classList.toggle("active", other === btn);
        }
        applyFieldsView();
      });
    }
    syncFieldCount();
  }

  // What the box currently parses to, echoed back — a comma-separated line and
  // a list of lines are both accepted, so saying how many names were understood
  // removes the guesswork about which one happened.
  function syncFieldCount() {
    const n = fieldNames().length;
    $("fields-count").textContent =
      n === 0 ? "no fields yet" : `${n} field${n === 1 ? "" : "s"}`;
  }

  function applyFieldsView() {
    $("fields-result").classList.toggle("hidden", fieldsView !== "table");
    $("fields-json").classList.toggle("hidden", fieldsView !== "json");
  }

  function fieldsBusy(message) {
    fieldsView = "table";
    for (const btn of $("fields-view").querySelectorAll("button")) {
      btn.classList.toggle("active", btn.dataset.view === "table");
    }
    applyFieldsView();
    $("fields-view").classList.add("hidden");
    $("fields-copy").disabled = true;
    lastFields = null;
    $("fields-json").textContent = "";
    $("fields-result").innerHTML = `<p class="dim">${esc(message)}</p>`;
    syncPaneActions();
  }

  async function runFields() {
    const names = fieldNames();
    if (!active) { fieldsBusy("process a document first."); return; }
    if (!names.length) { fieldsBusy("name at least one field."); return; }
    fieldsBusy("looking…");
    try {
      const resp = await fetch(`/v1/documents/${active.docId}/fields`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ fields: names, include_raw_ocr: $("fields-raw").checked }),
      });
      const body = await resp.json();
      if (!resp.ok) { fieldsBusy(body.detail || `request failed (${resp.status})`); return; }
      lastFields = body;
      renderFields(body);
      $("fields-json").textContent = JSON.stringify(body, null, 2);
      $("fields-view").classList.remove("hidden");
      $("fields-copy").disabled = false;
      applyFieldsView();
      syncPaneActions();
    } catch (err) {
      fieldsBusy(`request failed: ${err.message}`);
    }
  }

  async function showLabels() {
    if (!active) { fieldsBusy("process a document first."); return; }
    fieldsBusy("reading the document's labels…");
    try {
      const body = await (await fetch(`/v1/documents/${active.docId}/fields/labels`)).json();
      const labels = body.labels || [];
      $("fields-result").innerHTML =
        `<p class="dim">${labels.length} label(s) this document prints — click one to add it:</p>` +
        `<div class="field-chips">${labels
          .map((l) => `<button type="button" class="chip label-chip">${esc(l)}</button>`)
          .join("")}</div>`;
      for (const chip of $("fields-result").querySelectorAll(".label-chip")) {
        chip.addEventListener("click", () => {
          const box = $("fields-input");
          box.value = `${box.value.trim()}\n${chip.textContent}`.trim();
          syncFieldCount();
          box.focus();
        });
      }
    } catch (err) {
      fieldsBusy(`could not read labels: ${err.message}`);
    }
  }

  // A hit is shown with its provenance inline and its box clickable, so "where
  // did this come from" is one click, not a JSON hunt.
  function renderFields(body) {
    const rows = Object.entries(body.fields || {}).map(([name, hit]) => {
      if (hit.value === null) {
        return `<tr class="field-miss"><td>${esc(name)}</td>` +
          `<td colspan="3"><span class="field-null">null</span> ` +
          `<span class="dim">— ${esc(hit.reason || "not found")}</span></td></tr>`;
      }
      const conf = Math.round((hit.confidence || 0) * 100);
      return `<tr class="field-hit" data-page="${hit.page_no}" data-block="${esc(hit.block_id)}">` +
        `<td>${esc(name)}</td><td class="field-value">${esc(hit.value)}</td>` +
        `<td class="dim">${esc(hit.strategy)}</td>` +
        `<td class="dim field-prov">${conf}% · p${hit.page_no} · ` +
        `<code>${esc(hit.block_id)}</code></td></tr>`;
    });
    const missing = (body.available_labels || []).length
      ? `<p class="dim">Nothing matched. This document prints: ` +
        `${body.available_labels.slice(0, 40).map(esc).join(" · ")}</p>`
      : "";
    $("fields-result").innerHTML =
      `<p class="dim fields-count">${body.found}/${body.requested} found · ` +
      `extractor ${esc(body.extractor_version)} · IR ${esc(body.ir_version)}</p>` +
      `<table class="fields-table"><thead><tr><th>field</th><th>value</th>` +
      `<th>found by</th><th>provenance</th></tr></thead>` +
      `<tbody>${rows.join("")}</tbody></table>${missing}` +
      (body.raw_ocr ? `<details class="fields-raw"><summary>raw OCR ` +
        `(${body.raw_ocr.length} line(s))</summary><pre>${esc(
          body.raw_ocr.map((l) => `p${l.page_no} ${JSON.stringify(l.bbox)} ` +
            `${l.confidence} ${l.text}`).join("\n"))}</pre></details>` : "");
    // Clicking a hit lights up the box it was read from, the same link the
    // Markdown tab has.
    for (const tr of $("fields-result").querySelectorAll(".field-hit")) {
      tr.addEventListener("click", () => {
        Viewer.goto(Number(tr.dataset.page));
        Viewer.focusBlock(Number(tr.dataset.page), tr.dataset.block, null);
      });
    }
  }

  function html(markup) {
    const tpl = document.createElement("template");
    tpl.innerHTML = markup;
    return tpl.content.firstElementChild;
  }

  function wireMarkdownLinks() {
    $("tab-markdown").addEventListener("click", (e) => {
      const target = e.target instanceof Element ? e.target : null;
      if (!target) return;
      const sep = target.closest(".md-page-sep");
      if (sep) { Viewer.goto(Number(sep.dataset.page)); return; }
      const el = target.closest(".md-block");
      if (!el) return;
      const page = Number(el.dataset.page);
      const blockId = el.dataset.blockId;
      const cell = cellUnderClick(el, target, page, blockId);
      clearMarkdownFocus();
      for (const part of blockParts(page, blockId)) part.classList.add("focus");
      el.classList.add("focus");
      if (cell) markCell(el, blockOf(page, blockId), cell);
      Viewer.focusBlock(page, blockId, cell);
    });
  }

  // Every element one block projects to. A block that emits several positioned
  // lines (renderer 1.8) is several elements, and lighting up only the first
  // would highlight the wrong part of a long passage — or, since the block's own
  // wrapper is then empty, nothing at all.
  function blockParts(page, blockId) {
    if (!blockId) return [];
    return [
      ...$("tab-markdown").querySelectorAll(
        `.md-block[data-page="${page}"][data-block-id="${blockId}"]`,
      ),
    ];
  }

  // Viewer -> Markdown: a box was clicked on the page image (null = deselected).
  function highlightMarkdown(sel) {
    clearMarkdownFocus();
    if (!sel) return;
    const parts = blockParts(sel.page, sel.blockId);
    const el = mdBlocks.get(`${sel.page}:${sel.blockId}`);
    if (!parts.length && !el) return; // this block projects to nothing of its own
    showTab("markdown");
    for (const part of parts) part.classList.add("focus");
    if (el) el.classList.add("focus");
    const block = blockOf(sel.page, sel.blockId);
    let hit = null;
    for (const part of parts.length ? parts : [el]) {
      hit = (sel.cell ? markCell(part, block, sel.cell) : null) || highlightText(part, sel.text);
      if (hit) break;
    }
    (hit || parts[0] || el).scrollIntoView({ block: "center", behavior: "smooth" });
  }

  function clearMarkdownFocus() {
    const host = $("tab-markdown");
    for (const el of host.querySelectorAll(".md-block.focus")) el.classList.remove("focus");
    for (const cell of host.querySelectorAll(".md-hit-cell")) cell.classList.remove("md-hit-cell");
    for (const mark of [...host.querySelectorAll("mark.md-hit")]) {
      const parent = mark.parentNode;
      parent.replaceChild(document.createTextNode(mark.textContent), mark);
      parent.normalize();
    }
  }

  const blockOf = (page, blockId) => {
    const ir = Viewer.getIR(page);
    return ir ? (ir.blocks || []).find((b) => b.block_id === blockId) || null : null;
  };

  /* An IR cell and its rendered counterpart. Rule 4: a spanless table projects
   * to GFM, whose one header row is table row 0 when the IR says so and a
   * synthetic empty row when it does not — that offset is the whole mapping. A
   * table with spans projects to HTML, where the spans reshape the grid; there
   * the block highlight is the honest answer rather than a guessed cell. */
  function cellOffset(block) {
    if (!block || !block.table) return null;
    if ((block.table.cells || []).some((c) => c.row_span > 1 || c.col_span > 1)) return null;
    return (block.table.header_rows || []).includes(0) ? 0 : 1;
  }

  function markCell(root, block, cell) {
    const offset = cellOffset(block);
    const table = root.querySelector("table");
    if (offset === null || !table) return null;
    const row = table.rows[cell.row + offset];
    const el = row ? row.cells[cell.col] : null;
    if (el) el.classList.add("md-hit-cell");
    return el;
  }

  function cellUnderClick(root, target, page, blockId) {
    const td = target.closest("td, th");
    if (!td || !root.contains(td)) return null;
    const offset = cellOffset(blockOf(page, blockId));
    if (offset === null) return null;
    const tr = td.parentElement;
    const row = [...td.closest("table").rows].indexOf(tr) - offset;
    const col = [...tr.cells].indexOf(td);
    return row >= 0 && col >= 0 ? { row, col } : null;
  }

  const reEscape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  /* Wrap the first occurrence of `needle` in `root` in a <mark>. The needle is
   * an IR line's text; the projection may have joined it with its neighbours or
   * wrapped parts of it in emphasis, so the search runs over the block's text
   * nodes as one string and tolerates any run of whitespace between words. */
  function highlightText(root, needle) {
    const want = String(needle || "").replace(/\s+/g, " ").trim();
    if (!want) return null;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    let hay = "";
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      nodes.push([node, hay.length]);
      hay += node.nodeValue;
    }
    const match = new RegExp(want.split(" ").map(reEscape).join("\\s+")).exec(hay);
    if (!match) return null;
    const start = match.index;
    const end = start + match[0].length;
    let first = null;
    // Back to front: wrapping splits the text node it touches, which would
    // shift the offsets of anything after it.
    for (const [node, base] of nodes.slice().reverse()) {
      const from = Math.max(start - base, 0);
      const to = Math.min(end - base, node.nodeValue.length);
      if (from >= to) continue;
      const range = document.createRange();
      range.setStart(node, from);
      range.setEnd(node, to);
      const mark = document.createElement("mark");
      mark.className = "md-hit";
      range.surroundContents(mark);
      first = mark;
    }
    return first;
  }

  function scrollMarkdownToPage(pageNo) {
    // The page separator comes before that page's blocks, so it wins the query.
    const target = $("tab-markdown").querySelector(`[data-page="${pageNo}"]`);
    if (target) target.scrollIntoView({ block: "start", behavior: "smooth" });
  }

  function renderIRTree(ir) {
    const root = $("tab-ir");
    root.replaceChildren();
    for (const page of ir.pages || []) {
      const pageDetails = document.createElement("details");
      const summary = document.createElement("summary");
      const blocks = page.blocks || [];
      summary.textContent =
        `page ${page.page_no} · origin ${page.origin} · ${blocks.length} block(s)`;
      pageDetails.appendChild(summary);
      for (const block of blocks) {
        const blockDetails = document.createElement("details");
        const blockSummary = document.createElement("summary");
        const n = block.table ? `${block.table.cells.length} cell(s)`
          : `${(block.lines || []).length} line(s)`;
        blockSummary.textContent =
          `${block.block_id} · ${block.type} · order ${block.reading_order} · ${n}`;
        const pre = document.createElement("pre");
        pre.textContent = JSON.stringify(block, null, 2);
        blockDetails.appendChild(blockSummary);
        blockDetails.appendChild(pre);
        pageDetails.appendChild(blockDetails);
      }
      root.appendChild(pageDetails);
    }
  }

  // -- Signals tab (phase 12) ---------------------------------------------------
  // Rendered from three sources as they land: the status document (triage
  // decision/trigger/flags per page), per-page IR (confidence + quality) and the
  // document IR (provenance table). Re-rendered on every poll — it is cheap and
  // keeps the tab live while pages settle.

  const esc = (s) => String(s).replace(/[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const CONF_FIELDS = [
    "mean_rec", "p10_rec", "text_coverage", "low_conf_area_ratio", "handwriting_ratio",
  ];

  const CONF_TIPS = {
    mean_rec: "mean recognizer confidence across all lines — 1.000 means every line was " +
      "read with certainty",
    p10_rec: "10th-percentile line confidence — how weak the worst tail of the page is",
    text_coverage: "share of the detected text area that produced accepted text",
    low_conf_area_ratio: "share of the text area sitting below the low-confidence " +
      "threshold — triage's main escalation signal",
    handwriting_ratio: "estimated share of the text area that looks handwritten — " +
      "high values route to the VLM assist",
  };

  const TRIAGE_TIP = {
    accept: "confidence and structure checks passed — the OCR text is accepted as-is",
    review: "served, but flagged for a human to double-check — confidence landed in the grey zone",
    escalate_page: "the whole page fell below threshold — sent to the VLM assist",
    escalate_regions: "specific low-confidence regions were sent to the VLM assist",
    reject: "quality too poor to claim any text — the page is refused, not guessed",
  };

  function confBar(label, value) {
    const pct = Math.round(value * 100);
    const heat = value >= 0.9 ? "good" : value >= 0.7 ? "mid" : "bad";
    return `<div class="sig-bar-row">` +
      `<span class="sig-bar-label" data-tip="${esc(CONF_TIPS[label] || "")}">${esc(label)}</span>` +
      `<span class="sig-bar"><span class="sig-bar-fill ${heat}" style="width:${pct}%"></span></span>` +
      `<span class="sig-bar-value">${value.toFixed(3)}</span></div>`;
  }

  function renderSignals(docId, status) {
    const root = $("tab-signals");
    if (!root || !status) return;
    const entry = docs.get(docId) || {};
    const parts = [];

    const degraded = status.degraded
      ? ' <span class="flag degraded">degraded — escalation skipped</span>' : "";
    const hint = status.doc_type_hint ? ` · hint <code>${esc(status.doc_type_hint)}</code>` : "";
    parts.push(`<div class="sig-doc">document <code>${esc(status.status)}</code>${hint}${degraded}` +
      (status.reject_reason ? ` · <span class="flag rejected">${esc(status.reject_reason)}</span>` : "") +
      `</div>`);

    for (const p of status.pages || []) {
      const ir = Viewer.getIR(p.page_no);
      const chips = [];
      if (p.triage) {
        chips.push(`<span class="chip triage-${esc(p.triage)}" ` +
          `data-tip="triage decision: ${esc(TRIAGE_TIP[p.triage] || p.triage)}">${esc(p.triage)}</span>`);
      }
      if (p.trigger) {
        chips.push('<span class="chip trigger" data-tip="the measured signal that fired ' +
          `this triage decision">${esc(p.trigger)}</span>`);
      }
      if (p.review_required) {
        chips.push('<span class="chip review" data-tip="served, but a human should ' +
          'double-check this page">review required</span>');
      }
      if (p.escalation === "skipped") chips.push('<span class="chip degraded">escalation skipped</span>');
      else if (p.escalation === "running") chips.push('<span class="chip vlm">escalating…</span>');
      else if (p.escalation === "done") chips.push('<span class="chip vlm">escalated</span>');
      else if (p.escalation) chips.push(`<span class="chip degraded">escalation ${esc(p.escalation)}</span>`);
      for (const f of p.findings || []) {
        chips.push('<span class="chip finding" data-tip="structural sanity check from the ' +
          `doc-type profile that did not pass">${esc(f)}</span>`);
      }
      let bars = '<p class="dim">page IR not fetched yet</p>';
      let quality = "";
      if (ir && ir.confidence) {
        bars = CONF_FIELDS.map((f) => confBar(f, ir.confidence[f] ?? 0)).join("");
      }
      if (ir && ir.quality) {
        const q = ir.quality;
        const ink = q.ink_ratio == null ? "–" : q.ink_ratio.toFixed(4);
        quality = `<div class="sig-quality dim">quality: blur ${q.blur_score.toFixed(1)}` +
          ` · resolution_ok ${q.resolution_ok} · grayscale ${q.is_grayscale}` +
          ` · ink_ratio ${ink}</div>`;
      }
      const escalations = renderEscalations(docId, p.page_no, ir);
      parts.push(`<details class="sig-page" open><summary>page ${p.page_no}` +
        ` <span class="dim">${esc(p.status)}${p.route ? " · " + esc(p.route) : ""}</span>` +
        ` ${chips.join(" ")}</summary>${bars}${quality}${escalations}</details>`);
    }

    if (entry.ir && entry.ir.provenance) {
      const rows = entry.ir.provenance.map((e) =>
        `<tr><td>${esc(e.stage)}</td><td>${esc(e.engine)}</td><td>${esc(e.version)}</td>` +
        `<td class="num">${e.ms.toFixed(1)}</td><td class="num">${e.cost_inr.toFixed(4)}</td></tr>`);
      parts.push('<details class="sig-prov" open><summary>provenance</summary>' +
        '<table class="prov-table"><thead><tr><th>stage</th><th>engine</th><th>version</th>' +
        `<th>ms</th><th>cost ₹</th></tr></thead><tbody>${rows.join("")}</tbody></table></details>`);
    }

    root.innerHTML = parts.join("");
  }

  // -- escalation panel + OCR-vs-VLM diff (phase 13) ----------------------------
  // The IR keeps both sides of an escalation: the merged page (origin="vlm"
  // blocks + `escalations[]`) and the pre-escalation page artifact. The diff
  // below is the human-readable form of docs/03's disagreement-rate metric —
  // low disagreement means the threshold escalated a page that did not need it.

  const preIR = new Map(); // `${docId}:${pageNo}` -> pre-escalation page IR

  function fetchPreEscalation(docId, pageNo) {
    const key = `${docId}:${pageNo}`;
    if (preIR.has(key)) return;
    preIR.set(key, null); // in flight — never re-request
    fetch(`/v1/documents/${docId}/pages/${pageNo}/ir?variant=pre_escalation`)
      .then((r) => (r.ok ? r.json() : null))
      .then((ir) => {
        if (!ir) return;
        preIR.set(key, ir);
        const entry = docs.get(docId);
        if (entry && entry.status) renderSignals(docId, entry.status);
      })
      .catch(() => {});
  }

  function renderEscalations(docId, pageNo, ir) {
    const list = (ir && ir.escalations) || [];
    if (!list.length) return "";
    fetchPreEscalation(docId, pageNo);
    const before = preIR.get(`${docId}:${pageNo}`);
    const vlmBlocks = (ir.blocks || []).filter((b) => b.origin === "vlm");
    return list.map((e, i) => {
      const cost = e.cost || { input_tokens: 0, output_tokens: 0, inr: 0 };
      const meta = `<div class="dim">${esc(e.provider)} · <code>${esc(e.model)}</code>` +
        ` · tokens ${cost.input_tokens} in / ${cost.output_tokens} out` +
        ` · ₹${cost.inr.toFixed(4)}` +
        ` · region [${e.region_bbox.map((v) => Math.round(v)).join(", ")}]</div>`;
      const chips = [`<span class="chip trigger">${esc(e.trigger)}</span>`]
        .concat(Object.entries(e.signals || {})
          .map(([k, v]) => `<span class="chip">${esc(k)} ${Number(v).toFixed(3)}</span>`));
      const ocrLines = before ? linesOfBlocks(before, e.replaced_block_ids) : null;
      const vlmLines = linesOf(vlmBlocks[i]);
      const diff = ocrLines === null
        ? '<p class="dim">loading the pre-escalation page…</p>'
        : diffTable(ocrLines, vlmLines);
      return `<details class="sig-esc" open><summary>escalation ${i + 1} · replaced ` +
        `${e.replaced_block_ids.map((b) => `<code>${esc(b)}</code>`).join(", ") || "nothing"}` +
        `</summary>${meta}<div class="sig-esc-chips">${chips.join(" ")}</div>${diff}</details>`;
    }).join("");
  }

  const linesOf = (block) => (block && block.lines ? block.lines.map((l) => l.text) : []);

  function linesOfBlocks(pageIR, ids) {
    const wanted = new Set(ids || []);
    const out = [];
    for (const block of pageIR.blocks || []) {
      if (!wanted.has(block.block_id)) continue;
      for (const line of block.lines || []) out.push(line.text);
    }
    return out;
  }

  /* Line-level LCS: equal lines pair up, the rest show as removed/added. */
  function diffTable(before, after) {
    const n = before.length, m = after.length;
    const lcs = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
    for (let i = n - 1; i >= 0; i--) {
      for (let j = m - 1; j >= 0; j--) {
        lcs[i][j] = before[i] === after[j]
          ? lcs[i + 1][j + 1] + 1
          : Math.max(lcs[i + 1][j], lcs[i][j + 1]);
      }
    }
    const rows = [];
    let i = 0, j = 0;
    while (i < n && j < m) {
      if (before[i] === after[j]) { rows.push(["same", before[i], after[j]]); i++; j++; }
      else if (lcs[i + 1][j] >= lcs[i][j + 1]) { rows.push(["ocr", before[i++], ""]); }
      else { rows.push(["vlm", "", after[j++]]); }
    }
    while (i < n) rows.push(["ocr", before[i++], ""]);
    while (j < m) rows.push(["vlm", "", after[j++]]);
    const changed = rows.filter((r) => r[0] !== "same").length;
    const body = rows.map(([kind, a, b]) =>
      `<tr class="diff-${kind}"><td>${esc(a)}</td><td>${esc(b)}</td></tr>`).join("");
    return `<table class="diff-table"><thead><tr><th>OCR (replaced)</th><th>VLM</th></tr></thead>` +
      `<tbody>${body}</tbody></table>` +
      `<div class="dim">${changed}/${rows.length} line(s) differ</div>`;
  }

  const TAB_BODIES = ["markdown", "raw", "ir", "signals", "fields"];
  let activeTab = "markdown";

  function showTab(name) {
    activeTab = name;
    for (const tab of document.querySelectorAll(".tab")) {
      tab.classList.toggle("active", tab.dataset.tab === name);
    }
    for (const body of TAB_BODIES) $(`tab-${body}`).classList.toggle("hidden", body !== name);
    $("link-hint").classList.toggle("hidden", name !== "markdown" || mdBlocks.size === 0);
    // Both layout controls belong to the rendered projection only.
    for (const id of ["layout-toggle", "fit-mode"]) {
      $(id).classList.toggle("hidden", name !== "markdown");
    }
    syncPaneActions();
  }

  function wireTabs() {
    for (const tab of document.querySelectorAll(".tab")) {
      tab.addEventListener("click", () => showTab(tab.dataset.tab));
    }
  }

  // -- pipelines + samples ----------------------------------------------------

  async function loadPipelines() {
    try {
      const body = await (await fetch("/v1/pipelines")).json();
      const select = $("pipeline-select");
      select.replaceChildren();
      for (const p of body.pipelines || []) {
        const opt = document.createElement("option");
        opt.value = p.name;
        opt.textContent = p.id;
        select.appendChild(opt);
      }
    } catch { /* keep the static default option */ }
  }

  async function loadSamples() {
    try {
      const body = await (await fetch("/demo/samples")).json();
      const row = $("samples-list");
      row.replaceChildren();
      for (const sample of body.samples || []) {
        const btn = document.createElement("button");
        const name = document.createElement("span");
        name.textContent = sample.name;
        const size = document.createElement("span");
        size.className = "dim";
        size.textContent = `${Math.max(1, Math.round(sample.bytes / 1024))} KB`;
        btn.append(name, size);
        btn.addEventListener("click", async () => {
          clearError();
          closeDrawer();
          try {
            const blob = await (await fetch(sample.url)).blob();
            // Samples go through the normal upload path — no special server route.
            upload(new File([blob], sample.name, { type: blob.type }));
          } catch (err) {
            showError(`could not fetch sample ${sample.name}: ${err.message}`);
          }
        });
        row.appendChild(btn);
      }
    } catch { /* samples row is best-effort */ }
  }

  // -- errors -----------------------------------------------------------------

  function showError(message) {
    const banner = $("error-banner");
    banner.textContent = message;
    banner.classList.remove("hidden");
  }

  function clearError() {
    $("error-banner").classList.add("hidden");
  }
})();
