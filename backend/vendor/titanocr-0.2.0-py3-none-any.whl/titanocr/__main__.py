"""``python -m titanocr`` — the same command as ``titanocr`` (see :mod:`titanocr.cli`)."""

from titanocr.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
