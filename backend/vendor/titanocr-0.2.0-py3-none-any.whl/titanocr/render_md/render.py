"""IR -> Markdown projection v1 (implementation_plan.md §9, all rules).

Pure and stdlib-only: the output is a display/debugging artifact, never an
extraction source (ADR 0001 §1). Determinism is load-bearing — two renders of
the same IR must be byte-identical, so nothing here depends on dict order,
locale, wall-clock or randomness.

Rule 4 (phase 11): a table with cells renders as a GFM pipe table from its
``(row, col)`` grid — **HTML ``<table>`` iff any ``row_span``/``col_span`` >
1** (GFM cannot express spans); ``table.header_rows`` are honoured (GFM can
express exactly one header row, so a spanless multi-row header renders row 0
as the GFM header and the rest as leading body rows — the IR keeps the
truth); empty cells render empty, never dropped (column alignment is the
point). Two honest degradations remain plain rows: a still-pending candidate
(placeholder table, ADR 0004) behind :data:`TABLE_PENDING_MARKER`, and a
``table_failed`` block (both engines lost, ADR 0005) behind
:data:`TABLE_FAILED_MARKER` — never a faked grid.
"""

from collections.abc import Sequence
from dataclasses import dataclass
from html import escape
from itertools import pairwise
from statistics import median

from titanocr.ir import Block, BlockType, Cell, DocumentIR, Line, Page, Table
from titanocr.render_md.spatial import spatial_block, spatial_page

RENDERER_VERSION = "1.14"  # 1.14: source text + normalised boxes + spatial labels
# 1.13: a header block ranks by its tallest line
# 1.12: display mathematics projects verbatim, in a fence
# 1.11: a y-band is one row, and a staircase is not a grid
# 1.10: a row states how many page lines its box holds

TABLE_PENDING_MARKER = "<!-- table: cell structure pending -->"

TABLE_FAILED_MARKER = "<!-- table: recognition failed — lines preserved -->"

FIGURE_MARKER = "*[figure]*"

SIGNATURE_MARKER = "*[signature]*"

FORMULA_FENCE = "```formula"
"""Opening fence for a display-mathematics block (IR 1.8). Deliberately not
``$$``: the content is measured glyphs, not LaTeX, and a maths delimiter would
render it as wrong mathematics instead of as raw content."""

BLOCK_ANCHOR_RE = "<!-- block: {block_id} -->"
"""Format of the bare per-block anchor (:attr:`RenderOptions.block_anchors`)."""

BLOCK_GEOMETRY_RE = (
    "<!-- block: {block_id} · {type} · bbox: {x0},{y0},{x1},{y1}"
    " · lines: {lines} · text-h: {text_h} -->"
)
"""Format of the geometry annotation (:attr:`RenderOptions.block_geometry`).

A superset of the bare anchor: same ``block: {id}`` lead-in, so anything that
already parsed anchors keeps working, plus the block's type and its bbox in
page-space pixels, the count of page lines it held, and all of it separated the
way the page comment separates its fields. That is what carries *layout* through
a linear format — Markdown says what the text is, the annotation says where on
the page it sat, what kind of region it was, how much of the page it covered and
how tall its type was. ``text-h`` is the median height of the block's own lines:
the block box divided by the line count gives the line *pitch*, which is a
different number and renders at the wrong size wherever the leading is generous.
Deliberately no ``|``: a pipe inside a comment is inert to a Markdown parser, but
it reads as table syntax to a human skimming the raw file and to a model trained
on one."""


ROW_GEOMETRY_RE = "<!-- row: {x0},{y0},{x1},{y1} · lines: {lines} · text-h: {text_h} -->"
"""Format of a row's geometry annotation (:attr:`RenderOptions.block_geometry`).

One per emitted line, on every block that projects to more than one (renderer
1.8). The block annotation gives the region; this gives the position of each
line *inside* it, which is the only thing that survives the projection intact.

A block box plus a line count does not locate a block's lines: it locates them
if — and only if — they stack evenly down the box, and the blocks that matter
most are exactly the ones that do not. A figure's labels are scattered in two
dimensions. A leftover grid's rows sit in columns. And an ordinary long
paragraph block that a section band interrupts has real gaps in it, so dividing
its height by its line count puts every line a little lower than it belongs and
the drift grows with each one. Measured on a 19-page brochure: a 41-line block
spanning 1494 px reported a 36 px line pitch for 23 px text, and by the middle
of the page its lines were rendering across the printed rules that separate its
sections. Each line carrying its own box removes the arithmetic entirely.

``lines`` and ``text-h`` say the same thing for the row that the block
annotation says for the block, and for the same reason: a box is not a line.
Reflowable prose projects one Markdown line per *paragraph*, so its box holds
however many page lines the paragraph wrapped onto — reading that box as a
single line renders the paragraph as one long string squeezed to the column
width, which is a real regression the block annotation was never exposed to
(measured: a 27-line block's three paragraphs at 2 px). ``lines: 1`` is a row
that was genuinely one line on the page and must render as one; ``text-h`` is
the median height of the page lines behind it, never the box height, because
those differ exactly when the leading is generous."""


def row_geometry(
    bbox: tuple[float, float, float, float],
    *,
    lines: int = 1,
    text_h: float | None = None,
) -> str:
    """The geometry annotation emitted before one emitted row.

    ``text_h`` defaults to the box's own height, which is right for the common
    case the default also covers: a row that was one line on the page.
    """
    x0, y0, x1, y1 = bbox
    return ROW_GEOMETRY_RE.format(
        x0=round(x0),
        y0=round(y0),
        x1=round(x1),
        y1=round(y1),
        lines=max(1, lines),
        text_h=round(y1 - y0 if text_h is None or text_h <= 0 else text_h),
    )


def block_anchor(block_id: str) -> str:
    """The anchor comment emitted before ``block_id``'s projection."""
    return BLOCK_ANCHOR_RE.format(block_id=block_id)


def block_geometry(block: Block) -> str:
    """The geometry annotation emitted before ``block``'s projection.

    Coordinates are rounded to whole pixels: sub-pixel precision is noise from
    the reader's point of view (human or model) and would make the artifact
    churn between runs for no gain.
    """
    x0, y0, x1, y1 = block.bbox
    return BLOCK_GEOMETRY_RE.format(
        block_id=block.block_id,
        type=block.type.value,
        x0=round(x0),
        y0=round(y0),
        x1=round(x1),
        y1=round(y1),
        lines=_source_line_count(block),
        text_h=round(_block_line_height(block)),
    )


def _source_line_count(block: Block) -> int:
    """How many lines of the page this block held.

    Not derivable from the projected Markdown — a six-line address renders as one
    paragraph — so it is recorded here. It is what lets a renderer size the block
    back to the space it occupied, and it tells a reader how much of the page a
    passage covered.
    """
    if block.table is not None and block.table.cells:
        # A table's visual unit is its row. The lines assigned to the region are
        # the same ink counted a second way (58 of them for a 14-row grid), and
        # sizing anything by that number makes the table unreadable.
        return block.table.n_rows
    if block.lines:
        return len(block.lines)
    return 0


BLOCK_GRID_RE = "<!-- grid: {block_id} · cols: {cols} · rows: {rows} -->"
"""Format of the table grid annotation (:attr:`RenderOptions.block_geometry`).

The block annotation gives a table's outer box; this gives the lines *inside* it.
``cols`` and ``rows`` are the page-space pixel boundaries of the grid — every
column edge left to right, every row edge top to bottom — so the row and column
rules survive the projection instead of being flattened into pipe characters
whose positions mean nothing. A renderer can draw the grid where it sits on the
page; a reader can tell which column a value was under."""


def block_grid(block: Block) -> str | None:
    """The grid annotation for a table block, or ``None`` when there is no grid.

    Derived from the cells' own bboxes, which tile exactly (a row's bottom edge
    is the next row's top edge), so the boundaries are the shared edges.
    """
    table = block.table
    if table is None or not table.cells:
        return None
    cols = sorted(
        {round(c.bbox[0]) for c in table.cells} | {round(max(c.bbox[2] for c in table.cells))}
    )
    rows = sorted(
        {round(c.bbox[1]) for c in table.cells} | {round(max(c.bbox[3] for c in table.cells))}
    )
    return BLOCK_GRID_RE.format(
        block_id=block.block_id,
        cols=",".join(str(v) for v in cols),
        rows=",".join(str(v) for v in rows),
    )


BLOCK_PATH_RE = "<!-- path: {points} · heads: {heads} -->"
"""Format of a connector's path annotation (IR 1.6, ADR 0012).

``points`` are the stroke's page-space pixels, ``x,y`` each, space-separated,
start to end; ``heads`` is ``start``, ``end``, ``both`` or ``none``. A bbox
cannot describe a connector — a stroke that leaves one box, goes around a third
and arrives at another has a bounding box covering all three and saying nothing
about which two it joins — so the path travels with it."""


def block_path(block: Block) -> str | None:
    """The path annotation for a connector block, else ``None``."""
    conn = block.connector
    if conn is None:
        return None
    heads = {
        (True, True): "both",
        (True, False): "start",
        (False, True): "end",
        (False, False): "none",
    }[(conn.head_start, conn.head_end)]
    return BLOCK_PATH_RE.format(
        points=" ".join(f"{round(x)},{round(y)}" for x, y in conn.path), heads=heads
    )


CONNECTOR_MARKER = "*[connector]*"
"""Projection of a connector whose ends land on nothing named — the drawing says
two places are joined without saying which two, and so does this."""


def _render_connector(block: Block, labels: dict[str, str]) -> str:
    """Rule 9 (renderer 1.8): a connector projects as the edge it draws.

    ``A → B`` when both ends land on something with text, with the arrow
    pointing the way the heads do (``—`` for a plain join, ``↔`` for two heads);
    one end named gives ``A →``; neither gives the bare marker. The point is
    that a diagram's edges are its content — a page of boxes with the arrows
    dropped is a bag of nouns — and that a *linear* format can still carry them,
    as a list of relations, without pretending to be a picture.

    The **labels** an end lands on are preferred over the block (IR 1.7, ADR
    0016): a diagram is one ``figure`` block, so block anchors on it say
    "the diagram" at both ends and name nothing. The edge's own label, when the
    stroke carries one, renders on the arrow — ``NE —commission→ LP`` — which is
    the whole relation the drawing states, in one line of text.
    """
    conn = block.connector
    assert conn is not None
    arrow = "→"
    if conn.head_start and conn.head_end:
        arrow = "↔"
    elif conn.head_start and not conn.head_end:
        arrow = "←"
    elif not conn.head_start and not conn.head_end:
        arrow = "—"
    left = labels.get(conn.from_line_id or "") or labels.get(conn.from_block_id or "", "")
    right = labels.get(conn.to_line_id or "") or labels.get(conn.to_block_id or "", "")
    if not left and not right:
        return CONNECTOR_MARKER
    edge = labels.get(conn.label_line_id or "", "")
    if edge:
        arrow = f"—{edge}{arrow}" if arrow != "—" else f"—{edge}—"
    return f"{left} {arrow} {right}".strip()


def _connector_labels(page: Page) -> dict[str, str]:
    """One short label per thing a connector can point at — a block's first line's
    text, trimmed. Deliberately the *first* line only: an edge label wants the
    name of the thing, and a whole paragraph pasted into an arrow is unreadable
    in the projection and useless to a reader."""
    labels: dict[str, str] = {}
    for block in page.blocks:
        first = (block.lines or (None,))[0]
        # A *figure* is not a named thing: its first line is simply the first
        # label that happens to sit inside the picture, and using it as the
        # block's name makes every unresolved end on a diagram read as an edge
        # to that one word (measured: half a flow diagram's arrows rendered
        # "... → RS", which was the top-left label of the whole figure). An end
        # that found nothing says nothing.
        if first is not None and first.text.strip() and block.type not in _UNNAMED_BLOCKS:
            labels[block.block_id] = " ".join(first.text.split())[:_MAX_EDGE_LABEL]
        # ...and every line by its own id, which is what a connector on a
        # diagram anchors to: the block there is the whole picture.
        for line in block.lines or ():
            if line.text.strip():
                labels[line.line_id] = " ".join(line.text.split())[:_MAX_EDGE_LABEL]
    return labels


_UNNAMED_BLOCKS = frozenset({BlockType.figure, BlockType.signature})
"""Blocks whose first line is not a name for the block (see :func:`_connector_labels`)."""

_MAX_EDGE_LABEL = 60

_MAX_HEADING_DEPTH = 3
_HEIGHT_QUANTUM = 0.1
"""Header heights are quantised to this many px before ranking so float noise
between visually equal headings cannot split a rank."""


@dataclass(frozen=True)
class RenderOptions:
    """Renderer knobs. Defaults are the plan-§9 values; options exist so later
    phases can project variants (e.g. no page delimiters for single-page crops)
    without forking the renderer."""

    hard_break_gap_ratio: float = 1.6
    """Rule 3: a vertical gap between consecutive paragraph lines larger than
    this multiple of the block's median line height becomes a hard line break."""

    page_delimiters: bool = True
    """Rule 1: emit ``---`` + page-number comment before every page."""

    min_prose_aspect: float = 12.0
    """Rule 3d: how wide a block must be, in line heights, before it can be
    treated as flowing prose at all. Roughly 25 characters — narrower than that
    and the block is a label column or a sidebar, not a paragraph."""

    prose_fill_ratio: float = 0.5
    """Rule 3d: the fraction of a block's lines (excluding its last) that must
    reach the right margin before the block is treated as reflowable prose at
    all. Under it, every source line is preserved as its own line."""

    wrap_slack_ratio: float = 2.5
    """Rule 3d: how close to its column's right edge a line must reach, in line
    heights, to count as having *filled* it — and so to make the line beneath it
    a wrapped continuation rather than a new line the author chose. Roughly a
    word's width. Larger merges more aggressively; 0 keeps every source line."""

    block_anchors: bool = False
    """Emit the bare :func:`block_anchor` before every rendered block.

    Superseded by :attr:`block_geometry` for general use, and ignored when that
    is on. Kept because a consumer that only wants addressing (the demo's
    page-image ↔ Markdown highlight) should not have to parse coordinates."""

    layout_grids: bool = True
    """Project two-dimensional content as a pipe table (renderer 1.9).

    The geometry comments are exact and invisible: paste the file into any
    Markdown previewer and a diagram's five side-by-side service names come out
    as five stacked paragraphs, because a single column is what a linear format
    does to a page. A pipe table is the one two-dimensional construct plain
    Markdown has and it renders everywhere, so a block whose runs genuinely
    share lines on the page projects into one, on the columns and rows it
    already occupied.

    Off restores the pure list-of-positioned-rows projection, for a consumer
    that reads the annotations itself and would rather not see a grid."""

    block_geometry: bool = True
    """Emit :func:`block_geometry` — id, type and bbox — before every block.

    **This is how layout survives a linear format.** Markdown alone answers
    "what does the page say, in reading order"; it cannot say that a heading sat
    in the left margin and a date sat opposite it on the same line. The
    annotation carries that: page-space pixel coordinates for every block, in a
    comment, so the geometry travels with the text in one artifact.

    On by default, including in the stored ``output.md``, because the coordinates
    are useful to exactly the readers the projection has:

    - a renderer shows nothing — HTML comments are invisible, so the rendered
      Markdown is unchanged;
    - a language model reading the file gets the spatial relationships it would
      otherwise have to guess at from reading order alone;
    - a program can map any passage back to its block, and so to the pixels.

    Still a projection, never an extraction source (ADR 0001 §1, hard rule 4):
    the IR remains the truth, and this is a lossy view of it."""

    spatial_metadata: bool = True
    """With block_geometry, include self-describing JSON comments for LLMs.

    Preserves source lines/cells before Markdown reflow, normalised boxes,
    position labels and confidence. Off keeps the compact geometry projection;
    block_geometry=False disables both kinds of geometry.
    """


_DEFAULT_OPTIONS = RenderOptions()


def ir_to_markdown(ir: DocumentIR, opts: RenderOptions = _DEFAULT_OPTIONS) -> str:
    """Project a Document IR to Markdown. Never raises on a valid IR."""
    parts: list[str] = []
    for page in ir.pages:
        if opts.page_delimiters:
            # The page's own pixel dimensions travel with it: block bboxes are
            # only interpretable against the page they were measured on.
            size = f" · {page.width}x{page.height}" if opts.block_geometry else ""
            parts.append(f"---\n<!-- page {page.page_no} · origin: {page.origin.value}{size} -->")
        if opts.block_geometry and opts.spatial_metadata:
            parts.append(spatial_page(page))
        parts.extend(_render_page(page, opts))
    return "\n\n".join(parts) + "\n" if parts else ""


def _render_page(page: Page, opts: RenderOptions) -> list[str]:
    depths = _heading_depths(page)
    labels = _connector_labels(page)
    body: list[str] = []
    furniture: list[str] = []
    for block in sorted(page.blocks, key=lambda b: b.reading_order):
        if block.type is BlockType.footer:
            # Rule 6: page furniture renders as a single italic line at the
            # page bottom, out of the reading flow.
            _emit(furniture, block, f"*{_join_lines(block)}*", opts, page)
        elif block.type is BlockType.connector:
            _emit(body, block, _render_connector(block, labels), opts, page)
        else:
            rendered = _render_block(block, depths, opts)
            if rendered or (opts.block_geometry and opts.spatial_metadata):
                _emit(body, block, rendered, opts, page)
    return body + furniture


@dataclass(frozen=True)
class _Row:
    """One emitted line of the projection with the page box it came from.

    The unit of geometry is the emitted line, not the source line: reflowing
    three wrapped source lines into one paragraph line makes their union the box
    of that line, and there is nothing finer left to locate. Blocks that reflow
    nothing — a label stack, a figure's labels, a kv list — end up with one row
    per source line, which is exactly the resolution they need.
    """

    text: str
    bbox: tuple[float, float, float, float]
    lines: int = 1
    """How many page lines are *stacked* inside the box. Runs joined side by
    side are still one line; wrapped prose joined into a paragraph is not."""
    text_h: float = 0.0
    """Median height of the page lines behind the row; 0 means take the box's."""


def _stacked_row(text: str, lines: Sequence[Line]) -> _Row:
    """A row built from lines that sat above one another — a wrapped paragraph,
    a bullet item and its continuations. Its box holds all of them."""
    return _Row(text, _rows_bbox(lines), len(lines), _line_height(lines))


def _flat_row(text: str, lines: Sequence[Line]) -> _Row:
    """A row built from lines that sat beside one another on one y-band, or from
    a single line: one line's worth of height however many fragments it joins."""
    return _Row(text, _rows_bbox(lines), 1, _line_height(lines))


def _rows_bbox(lines: Sequence[Line]) -> tuple[float, float, float, float]:
    return (
        min(ln.bbox[0] for ln in lines),
        min(ln.bbox[1] for ln in lines),
        max(ln.bbox[2] for ln in lines),
        max(ln.bbox[3] for ln in lines),
    )


@dataclass(frozen=True)
class _Grid:
    """A layout-grid projection: the pipe table plus the boundaries it sits on."""

    text: str
    cols: tuple[float, ...]
    rows: tuple[float, ...]


_Rendered = str | list[_Row] | _Grid


def _emit(
    parts: list[str], block: Block, rendered: _Rendered, opts: RenderOptions, page: Page
) -> None:
    """Append a block's projection, preceded by its geometry/anchor comment."""
    if opts.block_geometry:
        parts.append(block_geometry(block))
        if opts.spatial_metadata:
            parts.append(spatial_block(block, page))
        grid = block_grid(block)
        if grid is not None:
            parts.append(grid)
        path = block_path(block)
        if path is not None:
            parts.append(path)
        if isinstance(rendered, _Grid):
            parts.append(
                BLOCK_LAYOUT_RE.format(
                    block_id=block.block_id,
                    cols=",".join(str(round(v)) for v in rendered.cols),
                    rows=",".join(str(round(v)) for v in rendered.rows),
                )
            )
    elif opts.block_anchors:
        parts.append(block_anchor(block.block_id))
    if isinstance(rendered, _Grid):
        parts.append(rendered.text)
        return
    if isinstance(rendered, str):
        parts.append(rendered)
        return
    for row in rendered:
        parts.append(row_geometry(row.bbox, lines=row.lines, text_h=row.text_h))
        parts.append(row.text)


def _render_block(block: Block, depths: dict[str, int], opts: RenderOptions) -> _Rendered:
    """The block's projection: one string, or the rows it projects to.

    Rows are returned only when the annotations are on and the block projects to
    more than one line — a single-line block is already located by the block
    comment, and adding a second identical box to it would be noise.
    """
    if block.type is BlockType.header:
        return f"{'#' * depths.get(block.block_id, 2)} {_join_lines(block)}"
    if block.type is BlockType.table:
        return _render_table(block, opts)
    if block.type is BlockType.kv:
        return _positioned(_kv_rows(block), "\\\n", opts)
    if block.type is BlockType.rule:
        # A printed division of the page (IR 1.5, ADR 0011). `***` is a thematic
        # break, so it renders as the line it is, and stays distinguishable in
        # the raw text from the `---` that separates pages.
        return "***"
    if block.type in (BlockType.figure, BlockType.signature):
        # The marker records what kind of region it is; recognised text inside
        # it (a chart's labels, a sidebar the layout model mis-typed) is
        # delivered content and is never dropped for it (line conservation,
        # plan §7) — kept one visual row per line rather than joined as prose,
        # since figure text is typically scattered labels, not a sentence.
        marker = FIGURE_MARKER if block.type is BlockType.figure else SIGNATURE_MARKER
        return _render_placeholder(block, marker, opts)
    if block.type is BlockType.formula:
        return _render_formula(block, opts)
    grid = _scattered_grid(block, opts)
    if grid is not None:
        return grid
    rows, joiner = _paragraph_rows(block, opts)
    return _positioned(rows, joiner, opts)


def _scattered_grid(block: Block, opts: RenderOptions) -> _Grid | None:
    """The block as a layout grid, when its content is genuinely two-dimensional.

    Two runs of text sharing a line on the page is the test, and it is the only
    one that matters: a stack of lines is already projected correctly by a
    linear format, and content laid out across the page is not projected at all.
    """
    if not opts.layout_grids:
        return None
    if block.type is BlockType.formula:
        # Mathematics is two-dimensional and is *never* a grid (IR 1.8, ADR 0018).
        # Phase 19's staircase gate catches the common shapes geometrically; this
        # is the guarantee, and it holds for a layout a gate has not seen.
        return None
    bands = _visual_bands(block)
    if not any(len(band) > 1 for band in bands):
        return None
    built = _layout_grid(bands)
    if built is None:
        return None
    matrix, cols, rows = built
    return _Grid(_render_layout_grid(matrix), tuple(cols), tuple(rows))


def _positioned(rows: list[_Row], joiner: str, opts: RenderOptions) -> str | list[_Row]:
    """Rows when they can carry their own boxes, the joined text when they can't."""
    if not rows:
        return ""
    if opts.block_geometry and len(rows) > 1:
        return rows
    return joiner.join(row.text for row in rows)


def _render_placeholder(block: Block, marker: str, opts: RenderOptions) -> _Rendered:
    """Rule 7: the marker stands in for the image; recognised text inside the
    region follows it — as a layout grid when the labels are scattered across
    the region, one visual row per line when they simply stack.

    A figure is where the grid earns its keep. A diagram's labels are laid out
    in two dimensions by definition; projecting them as a list is projecting the
    one thing about them that is not true. The rows are still never joined as
    prose — figure text is labels, and running them together would invent a
    sentence (the same honest degradation :func:`_render_table_lines` applies).

    The marker takes the region's own box, so a reader (and the demo) can tell
    the picture's extent from the labels scattered inside it.
    """
    grid = _scattered_grid(block, opts)
    if grid is not None:
        return _Grid(f"{marker}\n\n{grid.text}", grid.cols, grid.rows)
    rows = [row for row in _visual_row_items(block) if row.text]
    if not rows:
        return marker
    if not opts.block_geometry:
        return "\\\n".join([marker, *(row.text for row in rows)])
    return [_Row(marker, block.bbox), *rows]


def _render_formula(block: Block, opts: RenderOptions) -> _Rendered:
    """Rule 9 (renderer 1.12, IR 1.8): display mathematics, verbatim.

    A formula is text the page arranged in two dimensions, and every rule this
    renderer applies to prose is wrong for it. Reflowing it into a sentence
    destroys the arrangement; a hard break between its parts implies they are
    separate lines of content; a pipe table claims a row/column relationship it
    does not have. So the projection does the one honest thing: it emits the
    region's own rows, one visual row per line, inside a fence.

    The fence is annotated ``formula`` and **not** ``$$``. A ``$$`` wrapper would
    make a Markdown reader typeset this as mathematics, and the content is not
    LaTeX — it is the glyphs in the order and position the page put them, which
    would typeset as *wrong* mathematics rather than as visibly raw content. That
    is the abstention rule (hard rule 12) applied to a projection: say what is
    known, and do not dress it as more. Transcription is phase 21, and the
    ``$$`` question belongs there, with the content to justify it.

    Rows come from :func:`_y_bands`, so an equation and its right-flush number —
    separate lines, one visual row — project onto one line here, exactly as they
    do in prose (phase 19).
    """
    lines = list(block.lines or ())
    if not lines:
        return ""
    median_h = max(_block_line_height(block), 1.0)
    rows = [
        _stacked_row(" ".join(ln.text for ln in band if ln.text), band)
        for band in _y_bands(lines, median_h)
    ]
    rows = [row for row in rows if row.text]
    if not rows:
        return ""
    body = "\n".join(row.text for row in rows)
    fenced = f"{FORMULA_FENCE}\n{body}\n```"
    if not opts.block_geometry or len(rows) < 2:
        return fenced
    # Annotated, the fence markers are structure rather than content, so they
    # ride on the rows they wrap and every row still carries its own box.
    return [
        _Row(FORMULA_FENCE, block.bbox),
        *rows,
        _Row("```", block.bbox),
    ]


def _heading_depths(page: Page) -> dict[str, int]:
    """Rule 2: ``#``-depth by bbox-height rank within the page.

    Heights (the **tallest** line of each header block, quantised) are ranked
    descending; rank 1 → ``#``, 2 → ``##``, 3+ → ``###``. Blocks whose heights
    tie share a rank; when every header on the page ties (no rank signal at
    all) they land on ``##`` per the spec's tie rule. A lone header is the page
    title and keeps ``#``.

    Tallest, not median (renderer 1.13): a title region usually carries its
    subtitle — layout groups them, and the block is honest about it — and the
    median of a 33 px title and a 25 px subtitle sits *below* a 31 px section
    heading. That is how a real paper's title came out ``##`` under a ``#``
    Abstract (2026-09-03). A block's rank is its most prominent line.
    """
    headers = [b for b in page.blocks if b.type is BlockType.header]
    if not headers:
        return {}
    heights = {b.block_id: _block_heading_height(b) for b in headers}
    ranked = sorted(set(heights.values()), reverse=True)
    if len(ranked) == 1:
        depth = 1 if len(headers) == 1 else 2
        return dict.fromkeys(heights, depth)
    return {
        block_id: min(ranked.index(h) + 1, _MAX_HEADING_DEPTH) for block_id, h in heights.items()
    }


def _block_line_height(block: Block) -> float:
    return _line_height(block.lines or ())


def _block_heading_height(block: Block) -> float:
    """The tallest line of a header block, quantised like :func:`_line_height`."""
    heights = [line.bbox[3] - line.bbox[1] for line in block.lines or ()]
    if not heights:
        return 0.0
    return round(max(heights) / _HEIGHT_QUANTUM) * _HEIGHT_QUANTUM


def _line_height(lines: Sequence[Line]) -> float:
    heights = [line.bbox[3] - line.bbox[1] for line in lines]
    if not heights:
        return 0.0
    return round(median(heights) / _HEIGHT_QUANTUM) * _HEIGHT_QUANTUM


_BULLET_CHARS = (
    "\u2022\u25e6\u25aa\u2023\u25cf\u25cb\u25a0\u25a1"  # bullet/circle/square glyphs
    "\u00b7\u00bb\u27a2\u27a4\u2713"  # middot, guillemet, arrow heads, check
    "\u2013\u2014*<>-"  # en/em dash, asterisk, angle marks, hyphen
)
"""Line-leading marks that read as list bullets. Deliberately broad: custom
bullet fonts map to odd glyphs in the text layer (``<`` is a real-world
example) — but a run of two same-marked lines is required, so ordinary prose
never qualifies. The en/em dashes are escaped: a lookalike-to-hyphen character
is exactly what a linter flags as ambiguous, and here it is deliberate."""


def _line_bullet(text: str) -> str | None:
    stripped = text.lstrip()
    head, rest = stripped[:1], stripped[1:]
    if head and head in _BULLET_CHARS and (not rest or rest.startswith(" ")):
        return head
    return None


def _bullet_mark(lines: list[Line]) -> str | None:
    """The block's bullet mark when its lines form a bullet run: the first line
    carries a mark and at least one later line carries the same one."""
    first = _line_bullet(lines[0].text)
    if first is None:
        return None
    n = sum(1 for ln in lines if _line_bullet(ln.text) == first)
    return first if n >= 2 else None


_ROW_GRID_GAP_RATIO = 2.0
"""A span gap this many median line heights wide separates cells, not words."""

_ROW_GRID_MIN_FRAC = 0.5
"""Fraction of a block's lines that must be cell rows for it to read as a grid."""


def _is_row_grid(lines: list[Line]) -> bool:
    heights = sorted(ln.bbox[3] - ln.bbox[1] for ln in lines)
    median_h = max(heights[len(heights) // 2], 1.0)
    gap_min = _ROW_GRID_GAP_RATIO * median_h
    rows = sum(
        1
        for ln in lines
        if any(b.bbox[0] - a.bbox[2] >= gap_min for a, b in pairwise(ln.spans or ()))
    )
    return len(lines) >= 3 and rows >= _ROW_GRID_MIN_FRAC * len(lines)


def _paragraph_rows(block: Block, opts: RenderOptions) -> tuple[list[_Row], str]:
    """Rule 3: lines joined with a space; a vertical gap > ratio x the block's
    median line height is preserved as a Markdown hard break (``\\`` newline).

    Rule 3b (renderer 1.2): a bullet run — first line marked, ≥ 2 lines with
    the same mark — projects as a Markdown list; unmarked lines are wrapped
    continuations of the item above. Joining such lines into prose (the plain
    rule 3) destroys structure the IR's per-line geometry preserves.

    Rule 3c (renderer 1.2): a block whose lines are mostly *cell rows* (spans
    separated by wide horizontal gaps) is a grid the table reconstructor
    declined to claim — a nested or heavily wrapped one. Its rows are kept one
    per line instead of being run together as prose: the same honest
    degradation :func:`_render_table_lines` applies to a pending table, never
    a fabricated grid.

    Returns the emitted lines with the source lines each was built from, plus
    the string that joins them when the annotations are off — the three shapes
    join differently (a list is newline-separated, everything else takes a hard
    break), and that difference is the whole of the un-annotated projection.
    """
    lines = list(block.lines or ())
    if not lines:
        return [], ""
    if _is_row_grid(lines):
        return [_flat_row(line.text, [line]) for line in lines], "\\\n"
    mark = _bullet_mark(lines)
    if mark is not None:
        items: list[tuple[list[str], list[Line]]] = []
        for line in lines:
            if _line_bullet(line.text) == mark:
                items.append(([line.text.lstrip()[1:].strip()], [line]))
            else:
                items[-1][0].append(line.text.strip())
                items[-1][1].append(line)
        return [
            _stacked_row("- " + " ".join(part for part in parts if part), group)
            for parts, group in items
        ], "\n"
    median_h = _block_line_height(block)
    right_edge = max(line.bbox[2] for line in lines)
    flows = _is_flowing_prose(lines, right_edge, median_h, opts)
    bands = _y_bands(lines, max(median_h, 1.0))
    runs: list[list[Line]] = [list(bands[0])]
    for prev_band, band in pairwise(bands):
        gap = min(ln.bbox[1] for ln in band) - max(ln.bbox[3] for ln in prev_band)
        gapped = median_h > 0 and gap > opts.hard_break_gap_ratio * median_h
        # A band holding more than one run never counts as wrapped, however far
        # right its last run reaches. Reaching the margin is the wrap signature
        # only for text that ran there continuously; a run sitting alone at the
        # right of its band got there by being flushed, and the gap before it is
        # the proof that the line stopped early.
        wrapped = (
            flows and len(prev_band) == 1 and _is_wrapped(prev_band[-1], right_edge, median_h, opts)
        )
        if wrapped and not gapped:
            runs[-1].extend(band)
        else:
            runs.append(list(band))
    return [_stacked_row(" ".join(ln.text for ln in run), run) for run in runs], "\\\n"


def _is_flowing_prose(
    lines: Sequence[Line], right_edge: float, median_h: float, opts: RenderOptions
) -> bool:
    """Is this block reflowable prose, or a stack of lines the author chose?

    Asked of the block before any line is joined, because the per-line test
    cannot answer it alone: in a column of short labels the *widest* label does
    reach the column edge, so it looks wrapped and swallows the line beneath it.

    Prose gives itself away in bulk. Every line of a paragraph except its last is
    full by construction — that is what wrapping means — so most lines reach the
    margin. A list of labels, a column of dates, a stack of headings: almost none
    do. Below ``prose_fill_ratio`` the block is not prose and every source line
    is kept, which is the formatting the document actually had.
    """
    if median_h <= 0 or len(lines) < 2:
        return True
    # A column too narrow to hold a sentence cannot be a paragraph, however its
    # lines happen to line up. Width in line-heights is a scale-free proxy for
    # characters-per-line: below ~12 the column holds a couple of words, which is
    # a label stack, a column of dates or a sidebar — never flowing text. This is
    # the guard the fill test alone cannot supply, because in a narrow column
    # even short lines sit close to the right edge.
    left = min(ln.bbox[0] for ln in lines)
    if (right_edge - left) < opts.min_prose_aspect * median_h:
        return False
    body = lines[:-1]  # a paragraph's last line is short by construction
    filled = sum(1 for ln in body if _is_wrapped(ln, right_edge, median_h, opts))
    return filled / len(body) >= opts.prose_fill_ratio


def _is_wrapped(prev: Line, right_edge: float, median_h: float, opts: RenderOptions) -> bool:
    """Did ``prev`` run out of room, making the line after it a continuation?

    Rule 3d (renderer 1.6). Vertical gap alone cannot tell a wrapped line from a
    deliberate one: a list of short labels and the lines of a flowing paragraph
    are spaced identically, so joining on "small gap" ran whole sections together
    as prose — every résumé project entry, every label in a skills column.

    Text wrapping leaves a signature. A line only wraps because it *filled* its
    column; if it stopped well short of the right margin, the break was the
    author's. So a continuation requires the previous line to reach within
    ``wrap_slack_ratio`` line-heights of the column's right edge — about a word.
    Prose still reflows, because prose lines do reach the margin.
    """
    if median_h <= 0:
        return True
    return prev.bbox[2] >= right_edge - opts.wrap_slack_ratio * median_h


def _kv_rows(block: Block) -> list[_Row]:
    """Rule 5: ``**Key:** value`` per pair, one pair per (hard-broken) line.
    A line without a colon has no key/value split and passes through verbatim.
    A colon between two digits (``09:14``, ``1:500``) is a value, not a label
    separator — the OCR path can deliver a kv row's value as its own line, and
    bolding a time fragment as a pseudo-key corrupts the projection (phase 15)."""
    pairs: list[_Row] = []
    for line in block.lines or ():
        key, sep, value = line.text.partition(":")
        digit_colon = bool(key[-1:].isdigit() and value[:1].isdigit())
        text = f"**{key}:**{value}" if sep and key.strip() and not digit_colon else line.text
        pairs.append(_flat_row(text, [line]))
    return pairs


def _render_table(block: Block, opts: RenderOptions) -> str | list[_Row]:
    """Rule 4 dispatch: grid render for a table with cells; honest line
    fallback behind a marker for a failed or still-pending one."""
    table = block.table
    if block.table_failed:
        return _render_table_lines(block, TABLE_FAILED_MARKER, opts)
    if table is None or not table.cells:
        # A layout-emitted candidate (IR 1.1, ADR 0004): no cells yet, only the
        # recognised lines assigned to the region — visual rows, nothing lost.
        return _render_table_lines(block, TABLE_PENDING_MARKER, opts)
    if any(cell.row_span > 1 or cell.col_span > 1 for cell in table.cells):
        return _render_table_html(table)
    return _render_table_gfm(table)


def _render_table_lines(block: Block, marker: str, opts: RenderOptions) -> str | list[_Row]:
    rows = [row for row in _visual_row_items(block) if row.text]
    if not rows:
        return marker
    if not opts.block_geometry:
        return marker + "\n" + "\\\n".join(row.text for row in rows)
    return [_Row(marker, block.bbox), *rows]


def _cell_grid(table: Table) -> dict[tuple[int, int], Cell]:
    return {(cell.row, cell.col): cell for cell in table.cells}


def _gfm_cell_text(text: str) -> str:
    """Verbatim (rule 8) except the two characters that would break the grid:
    ``|`` is escaped, a multi-line cell keeps its break as ``<br>``."""
    return text.replace("|", "\\|").replace("\n", "<br>")


def _render_table_gfm(table: Table) -> str:
    """GFM pipe table. GFM requires exactly one header row: ``header_rows``
    ``(0,)`` uses row 0; an explicitly headerless table gets an empty header
    row so no body row is misrepresented as a header; extra header rows (no
    span to force HTML) flow into the body — the IR keeps the truth."""
    grid = _cell_grid(table)

    def row_cells(row: int) -> list[str]:
        return [
            _gfm_cell_text(grid[(row, col)].text) if (row, col) in grid else ""
            for col in range(table.n_cols)
        ]

    def pipe_row(texts: list[str]) -> str:
        return "| " + " | ".join(texts) + " |"

    lines: list[str] = []
    body_start = 0
    if 0 in table.header_rows:
        lines.append(pipe_row(row_cells(0)))
        body_start = 1
    else:
        lines.append(pipe_row([""] * table.n_cols))
    lines.append(pipe_row(["---"] * table.n_cols))
    lines.extend(pipe_row(row_cells(row)) for row in range(body_start, table.n_rows))
    return "\n".join(lines)


def _render_table_html(table: Table) -> str:
    """HTML ``<table>`` — the only projection that can express spans. Header
    rows land in ``<thead>`` as ``<th>``; positions covered by a span emit no
    element; empty cells still emit theirs."""
    grid = _cell_grid(table)
    covered: set[tuple[int, int]] = set()
    for cell in table.cells:
        for r in range(cell.row, cell.row + cell.row_span):
            for c in range(cell.col, cell.col + cell.col_span):
                if (r, c) != (cell.row, cell.col):
                    covered.add((r, c))

    def html_row(row: int, tag: str) -> str:
        parts: list[str] = ["<tr>"]
        for col in range(table.n_cols):
            if (row, col) in covered:
                continue
            cell = grid.get((row, col))
            attrs = ""
            text = ""
            if cell is not None:
                if cell.row_span > 1:
                    attrs += f' rowspan="{cell.row_span}"'
                if cell.col_span > 1:
                    attrs += f' colspan="{cell.col_span}"'
                text = escape(cell.text).replace("\n", "<br>")
            parts.append(f"<{tag}{attrs}>{text}</{tag}>")
        parts.append("</tr>")
        return "".join(parts)

    header = {row for row in table.header_rows}
    out: list[str] = ["<table>"]
    if header:
        out.append("<thead>")
        out.extend(html_row(row, "th") for row in range(table.n_rows) if row in header)
        out.append("</thead>")
    out.append("<tbody>")
    out.extend(html_row(row, "td") for row in range(table.n_rows) if row not in header)
    out.append("</tbody>")
    out.append("</table>")
    return "\n".join(out)


BLOCK_LAYOUT_RE = "<!-- layout: {block_id} · cols: {cols} · rows: {rows} -->"
"""Format of a layout-grid annotation (renderer 1.9).

Deliberately **not** ``grid:``. That one says "this table's cells sit on these
lines"; this one says "the pipe table below is a projection of scattered content
onto the columns and rows it occupied". A consumer must be able to tell a
recognised table from a layout device, and the two words are the whole
distinction."""


_GRID_MIN_MULTI_RUN_BANDS = 2
"""How many runs a band needs before it counts as a *row* rather than one item on its
own line. A grid must have such rows in at least half its bands."""


MAX_LAYOUT_COLUMNS = 10
"""Beyond this a layout grid is unreadable in any renderer, and the flat list of
positioned rows is the better projection."""


def _layout_grid(
    bands: Sequence[Sequence[_Row]],
) -> tuple[list[list[str]], list[float], list[float]] | None:
    """Project 2-D scattered content onto the grid it already occupies.

    **This is how layout survives into a foreign renderer.** The geometry
    comments say exactly where everything sat, and they are exactly right for
    anything that parses them — but they are HTML comments, so a reader who
    pastes the file into a Markdown previewer sees the one thing Markdown does
    to two-dimensional content: a single column, top to bottom, with every
    horizontal relationship gone. A diagram's five side-by-side service names
    become five paragraphs, and nothing in the visible output says they were
    side by side.

    A pipe table is the only two-dimensional construct plain Markdown has, and
    it renders everywhere — GitHub, a previewer, pandoc, a model reading the raw
    file. So a block whose content really is laid out across the page projects
    into one: columns clustered from the runs' own x-intervals, rows from the
    bands they already sit in, every cell in the column it occupied. Nothing is
    invented — the grid is measured, and the annotation calls it ``layout`` so
    no consumer mistakes it for a recognised table.

    Returns ``None`` when the content is not two-dimensional (one column), is
    too wide to read as a grid, or **cannot be placed one run per cell**; the
    caller then keeps the positioned flat list, which is the honest projection of
    a stack.

    That last condition is what keeps the promise in the paragraph above. The
    columns are clustered by horizontal overlap, and overlap chains: a wide label
    bridges two narrow ones, the merged column then reaches a third, and on a
    flow diagram — labels scattered at every x, some of them wide — the chain
    walks the width of the page. Measured on one (31 labels, 1900x1100): five
    columns, with ``AC``, ``EC``, ``DD``, ``targeted offers`` and ``T5`` all
    landing in the same cell, five distinct nodes projected as one cell's
    content. A cell holding two runs is not a measured grid, it is a claim that
    they belong together — exactly the invention this projection is not allowed
    to make (hard rule 12). So the grid is offered only when every run has a cell
    of its own, and a diagram, which is not a grid, keeps its labels and their
    geometry instead.

    **A grid also has to repeat.** Content can satisfy everything above and still not
    be a grid: stacked mathematics is genuinely two-dimensional, places one run per
    cell, and clusters into clean columns — yet it is a *staircase*, not a table. A
    summation puts its operator in one column, its body in another and its limits in a
    third, each on its own band, so every column is occupied exactly once. Projected as
    a pipe table it comes out mostly empty and claims a row/column relationship that
    the page never had (hard rule 12). Two measurements separate the two shapes, and a
    grid must pass both: at least half the bands hold more than one run, and at least
    two columns are occupied on more than one band. Equation (4) of the real paper that
    prompted this — bands of 1, 2 and 1 runs across three columns, 4 cells filled of 9 —
    fails both.

    Measured 2026-08-26 across every fixture and all 14 pages of that paper: the only
    blocks reaching this function were three stacked formulae. A cleanly aligned grid
    cannot reach it on the digital path in either direction — narrow column gaps and the
    text layer merges the band into one full-width line that clusters to a single
    column, wide gaps and ``split_column_blocks`` cuts the block into one per column
    first. The intended population is the OCR path and figure regions, where runs
    arrive separately; that case is covered by unit tests over constructed bands.
    """
    runs = [row for band in bands for row in band]
    if len(bands) < 2 or len(runs) < 3:
        return None
    if sum(1 for band in bands if len(band) >= _GRID_MIN_MULTI_RUN_BANDS) * 2 < len(bands):
        return None  # mostly one run per band: a stack, not a grid
    columns = _cluster_columns(runs)
    if len(columns) < 2 or len(columns) > MAX_LAYOUT_COLUMNS:
        return None
    matrix: list[list[str]] = []
    for band in bands:
        cells = [""] * len(columns)
        for row in band:
            idx = _column_of(row.bbox, columns)
            if cells[idx]:
                return None  # two runs, one cell: the column model does not fit
            cells[idx] = row.text
        matrix.append(cells)
    spanning = sum(1 for c in range(len(columns)) if sum(1 for row in matrix if row[c]) >= 2)
    if spanning < 2:
        return None  # no column repeats down the block: a staircase, not a grid
    col_bounds = [c[0] for c in columns] + [columns[-1][1]]
    row_bounds = [min(r.bbox[1] for r in band) for band in bands]
    row_bounds.append(max(r.bbox[3] for r in bands[-1]))
    return matrix, col_bounds, row_bounds


def _cluster_columns(runs: Sequence[_Row]) -> list[tuple[float, float]]:
    """Column x-ranges: runs that overlap horizontally share a column.

    A single pass over the runs sorted by left edge, merging into the open
    column while they still overlap it. Two labels in different bands that sit
    over each other are one column by construction, which is what a column is.
    """
    columns: list[list[float]] = []
    for row in sorted(runs, key=lambda r: r.bbox[0]):
        x0, x1 = row.bbox[0], row.bbox[2]
        if columns and x0 < columns[-1][1]:
            columns[-1][1] = max(columns[-1][1], x1)
        else:
            columns.append([x0, x1])
    return [(c[0], c[1]) for c in columns]


def _column_of(
    bbox: tuple[float, float, float, float], columns: Sequence[tuple[float, float]]
) -> int:
    """The column a run belongs to: the one it overlaps most."""
    best, best_overlap = 0, -1.0
    for idx, (x0, x1) in enumerate(columns):
        overlap = min(bbox[2], x1) - max(bbox[0], x0)
        if overlap > best_overlap:
            best, best_overlap = idx, overlap
    return best


def _render_layout_grid(matrix: Sequence[Sequence[str]]) -> str:
    """The matrix as a headerless GFM table — a layout device, so no header row
    is claimed; the leading empty row is what GFM requires and what says the
    first row of content is content."""
    n_cols = len(matrix[0])

    def pipe_row(cells: Sequence[str]) -> str:
        return "| " + " | ".join(_gfm_cell_text(c) for c in cells) + " |"

    out = [pipe_row([""] * n_cols), "| " + " | ".join(["---"] * n_cols) + " |"]
    out.extend(pipe_row(row) for row in matrix)
    return "\n".join(out)


_VISUAL_ROW_GAP_RATIO = 2.0
"""How far apart, in line heights, two lines in the same y-band may sit before
they stop being one visual row (mirrors ``tables.split_wide_gap_lines``)."""


_BAND_CENTRE_RATIO = 0.6
"""How close two line centres must be, in median line heights, to sit in one y-band."""


def _y_bands(lines: Sequence[Line], median_h: float) -> list[list[Line]]:
    """A block's lines grouped into visual rows: one list per y-band, top to
    bottom, lines within a band left to right.

    One band is one row *on the page*, which is the relation both projections
    need. ``tables.split_wide_gap_lines`` deliberately cuts a line wherever a
    wide horizontal gap separates two pieces of content — a heading and its
    right-flush date, an equation and its number, two boxes of a diagram — so
    the pieces arrive here as separate lines that were never separate rows.
    Recovering the band is what lets each projection decide for itself whether
    to keep them apart (the grid) or put them back on one row (the paragraph).
    """
    ordered = sorted(lines, key=lambda ln: ((ln.bbox[1] + ln.bbox[3]) / 2.0, ln.bbox[0]))
    bands: list[list[Line]] = []
    for line in ordered:
        centre = (line.bbox[1] + line.bbox[3]) / 2.0
        if bands:
            last = bands[-1]
            last_centre = sum((ln.bbox[1] + ln.bbox[3]) / 2.0 for ln in last) / len(last)
            if abs(centre - last_centre) <= _BAND_CENTRE_RATIO * median_h:
                last.append(line)
                continue
        bands.append([line])
    for band in bands:
        band.sort(key=lambda ln: ln.bbox[0])
    return bands


def _visual_row_items(block: Block) -> list[_Row]:
    """Every run of a block, band by band — :func:`_visual_bands` flattened."""
    return [row for band in _visual_bands(block) for row in band]


def _visual_bands(block: Block) -> list[list[_Row]]:
    """Group a block's lines into visual rows — one list per y-band, one
    :class:`_Row` per run within it, bands top to bottom and runs left to right.

    Two passes: first y-proximity (centres within 0.6 x the median line
    height), same as always. Then, *within* each y-band, an x-gap split —
    sharing a y-band does not make separate content one row. A layout model
    that cannot read a diagram types the whole thing one ``figure``, and this
    is what renders its text: four side-by-side boxes in an onboarding
    workflow sit in the same horizontal band, and without the x-split their
    labels ran together as "Register Fill startup Upload Documents Submit
    for" — four boxes read as one meaningless phrase. The gap threshold is
    the same one the digital fast path already uses to solve the identical
    problem for ordinary text blocks (``tables.split_wide_gap_lines``); a
    figure's OCR'd labels deserve the same treatment.
    """
    lines = list(block.lines or ())
    if not lines:
        return []
    median_h = max(_block_line_height(block), 1.0)
    out: list[list[_Row]] = []
    for band in _y_bands(lines, median_h):
        runs: list[_Row] = []
        for run in _split_run_at_gaps(band, median_h, _VISUAL_ROW_GAP_RATIO):
            text = " ".join(ln.text for ln in run if ln.text)
            if text:
                runs.append(_flat_row(text, run))
        if runs:
            out.append(runs)
    return out


def _split_run_at_gaps(band: Sequence[Line], median_h: float, gap_ratio: float) -> list[list[Line]]:
    """Break an x-sorted band wherever the horizontal gap is too wide to be a
    word space — a column boundary, a gutter, or the space between two boxes
    drawn side by side."""
    runs: list[list[Line]] = [[band[0]]]
    for prev, line in pairwise(band):
        if line.bbox[0] - prev.bbox[2] > gap_ratio * median_h:
            runs.append([line])
        else:
            runs[-1].append(line)
    return runs


def _join_lines(block: Block) -> str:
    return " ".join(line.text for line in block.lines or ())


__all__ = [
    "BLOCK_ANCHOR_RE",
    "BLOCK_GEOMETRY_RE",
    "BLOCK_GRID_RE",
    "BLOCK_LAYOUT_RE",
    "BLOCK_PATH_RE",
    "CONNECTOR_MARKER",
    "FIGURE_MARKER",
    "RENDERER_VERSION",
    "ROW_GEOMETRY_RE",
    "SIGNATURE_MARKER",
    "TABLE_FAILED_MARKER",
    "TABLE_PENDING_MARKER",
    "RenderOptions",
    "block_anchor",
    "block_geometry",
    "block_grid",
    "block_path",
    "ir_to_markdown",
    "row_geometry",
]
