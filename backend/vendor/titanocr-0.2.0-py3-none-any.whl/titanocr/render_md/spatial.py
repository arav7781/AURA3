"""Self-describing spatial metadata for consumers reading raw Markdown.

The IR remains authoritative. Coordinates refer to its rendered/prepared page,
not the original upload before deskew, crop or perspective correction.
"""

import json

from titanocr.ir import Block, Page

BBox = tuple[float, float, float, float]


def _location(bbox: BBox, page: Page) -> dict[str, object]:
    # Retain the measured pixel box; only the convenience normalisation clips
    # overhanging boxes to the page. Never infer precise geometry from the label.
    norm = [
        round(1000 * min(1.0, max(0.0, value / extent)), 2)
        for value, extent in zip(
            bbox, (page.width, page.height, page.width, page.height), strict=True
        )
    ]
    cx, cy = (norm[0] + norm[2]) / 2, (norm[1] + norm[3]) / 2
    horizontal = "left" if cx < 1000 / 3 else "right" if cx >= 2000 / 3 else "center"
    vertical = "top" if cy < 1000 / 3 else "bottom" if cy >= 2000 / 3 else "middle"
    return {
        "bbox_px": list(bbox),
        "bbox_norm": norm,
        "position": f"{vertical}-{horizontal}",
    }


def _comment(kind: str, data: dict[str, object]) -> str:
    # OCR text is untrusted comment content: preserve it losslessly in JSON
    # while preventing -->, nested <!--, and HTML from escaping the comment.
    encoded = json.dumps(data, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    for char, escaped in (
        ("&", "\\u0026"),
        ("<", "\\u003c"),
        (">", "\\u003e"),
        ("--", "\\u002d\\u002d"),
    ):
        encoded = encoded.replace(char, escaped)
    return f"<!-- {kind}: {encoded} -->"


def spatial_page(page: Page) -> str:
    """Coordinate legend, included even when display page delimiters are off."""
    return _comment(
        "spatial-page",
        {
            "schema": "titanocr.spatial.v1",
            "page": page.page_no,
            "size_px": [page.width, page.height],
            "coordinate_space": "prepared/rendered page",
            "bbox_format": "[x0,y0,x1,y1]",
            "axes": "origin top-left; x increases right; y increases down",
            "bbox_norm_scale": 1000,
            "bbox_norm_clipped": True,
            "position_rule": "clipped bbox center in equal page thirds; use bbox for extent",
            "table_indices": "zero-based; row_span/col_span count covered cells",
            "confidence_note": "engine score, not a calibrated probability of correctness",
            "confidence_signals": page.confidence.model_dump(mode="json"),
        },
    )


def spatial_block(block: Block, page: Page) -> str:
    """Link exact source text to boxes, including reflowed lines and table cells."""
    data: dict[str, object] = {
        "page": page.page_no,
        "block_id": block.block_id,
        "type": block.type.value,
        "reading_order": block.reading_order,
        **_location(block.bbox, page),
        "origin": block.origin.value,
        "confidence": block.confidence,
    }
    if block.lines:
        data["lines"] = [
            {
                "line_id": line.line_id,
                "text": line.text,
                **_location(line.bbox, page),
                "origin": line.origin.value,
                "confidence": line.confidence,
            }
            for line in block.lines
        ]
    if block.table is not None:
        data["table_failed"] = block.table_failed
        data["shape"] = [block.table.n_rows, block.table.n_cols]
        data["header_rows"] = list(block.table.header_rows)
        data["cells"] = [
            {
                "row": cell.row,
                "col": cell.col,
                "row_span": cell.row_span,
                "col_span": cell.col_span,
                "text": cell.text,
                **_location(cell.bbox, page),
                "origin": cell.origin.value,
                "confidence": cell.confidence,
            }
            for cell in sorted(block.table.cells, key=lambda cell: (cell.row, cell.col))
        ]
    return _comment("spatial", data)
