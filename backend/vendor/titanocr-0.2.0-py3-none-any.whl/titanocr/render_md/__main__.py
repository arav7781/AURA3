"""Render stored IR with current spatial metadata, without rerunning OCR."""

import argparse
import sys
from pathlib import Path

from titanocr.ir import DocumentIR
from titanocr.render_md import RenderOptions, ir_to_markdown


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ir", type=Path, help="Document IR JSON file")
    parser.add_argument("--out", "-o", type=Path, help="Markdown destination (default: stdout)")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--compact", action="store_true", help="Pixel comments without spatial JSON")
    mode.add_argument("--plain", action="store_true", help="Omit all geometry metadata")
    args = parser.parse_args()
    ir = DocumentIR.model_validate_json(args.ir.read_text(encoding="utf-8"))
    markdown = ir_to_markdown(
        ir, RenderOptions(block_geometry=not args.plain, spatial_metadata=not args.compact)
    )
    if args.out is None:
        sys.stdout.write(markdown)
    else:
        args.out.write_text(markdown, encoding="utf-8")


if __name__ == "__main__":
    main()
