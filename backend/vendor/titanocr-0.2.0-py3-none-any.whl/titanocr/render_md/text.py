"""Plain-text projections of the IR: reading order, and the page's own rows.

Two views, both lossy, both deterministic, neither a source of truth (the IR is;
hard rule 4 applies to plain text exactly as it does to Markdown):

- :func:`ir_to_text` — the page's words in reading order, block by block. A
  table comes out one row per line with its cells joined by `` | ``; anything
  else one visual row per line.
- :func:`ir_to_layout_text` — every line on the page placed on its visual row
  and column, like ``pdftotext -layout``. A lab report whose test names, values
  and units the layout stage kept in separate column blocks still reads
  ``HEMOGLOBIN   15   g/dl   13 - 17`` here, because the row is what the page
  put them on. A two-column article interleaves its columns in this view; read
  it with :func:`ir_to_text` instead.

Pages are separated by a form feed (``\\f``), the convention plain-text
extractors share.
"""

from collections.abc import Sequence
from statistics import median

from titanocr.ir import Block, BlockType, DocumentIR, Line, Page

PAGE_BREAK = "\f"

_BAND_CENTRE_RATIO = 0.6
"""Two lines share a visual row when their centres are within this many median
line heights — the same rule the Markdown renderer bands rows by."""

_NO_TEXT = frozenset({BlockType.connector, BlockType.rule})


def _height(line: Line) -> float:
    return max(line.bbox[3] - line.bbox[1], 1.0)


def _centre(line: Line) -> float:
    return (line.bbox[1] + line.bbox[3]) / 2.0


def _bands(lines: Sequence[Line]) -> list[list[Line]]:
    """Visual rows, top to bottom; lines within a row left to right."""
    readable = [line for line in lines if line.text.strip()]
    if not readable:
        return []
    median_h = median(_height(line) for line in readable)
    bands: list[list[Line]] = []
    for line in sorted(readable, key=lambda ln: (_centre(ln), ln.bbox[0])):
        if bands:
            last = bands[-1]
            last_centre = sum(_centre(ln) for ln in last) / len(last)
            if abs(_centre(line) - last_centre) <= _BAND_CENTRE_RATIO * median_h:
                last.append(line)
                continue
        bands.append([line])
    for band in bands:
        band.sort(key=lambda ln: ln.bbox[0])
    return bands


def _block_text(block: Block) -> str:
    table = block.table
    if table is not None and table.cells:
        rows: dict[int, list[tuple[int, str]]] = {}
        for cell in table.cells:
            text = cell.text.strip()
            if text:
                rows.setdefault(cell.row, []).append((cell.col, text))
        return "\n".join(" | ".join(text for _, text in sorted(rows[row])) for row in sorted(rows))
    return "\n".join(
        " ".join(line.text.strip() for line in band) for band in _bands(block.lines or ())
    )


def page_text(page: Page) -> str:
    """One page's words in reading order (see :func:`ir_to_text`)."""
    parts: list[str] = []
    for block in sorted(page.blocks, key=lambda b: b.reading_order):
        if block.type in _NO_TEXT:
            continue
        text = _block_text(block)
        if text:
            parts.append(text)
    return "\n\n".join(parts)


def page_layout_text(page: Page) -> str:
    """One page's lines on their visual rows and columns (see :func:`ir_to_layout_text`)."""
    lines = [
        line for block in page.blocks if block.type not in _NO_TEXT for line in block.lines or ()
    ]
    bands = _bands(lines)
    if not bands:
        return ""
    # One character column ≈ the median glyph advance of the page's own text.
    advances = [
        (line.bbox[2] - line.bbox[0]) / len(line.text.strip())
        for band in bands
        for line in band
        if len(line.text.strip()) >= 3
    ]
    heights = [_height(line) for band in bands for line in band]
    char_w = median(advances) if advances else 0.5 * median(heights)
    char_w = max(char_w, 1.0)
    row_h = median(heights)

    out: list[str] = []
    prev_bottom: float | None = None
    for band in bands:
        top = min(line.bbox[1] for line in band)
        if prev_bottom is not None and top - prev_bottom > row_h:
            out.append("")  # a vertical gap wider than a row is a paragraph break
        prev_bottom = max(line.bbox[3] for line in band)
        row = ""
        for line in band:
            column = round(line.bbox[0] / char_w)
            if row:
                column = max(column, len(row) + 1)
            row = row.ljust(column) + line.text.strip()
        out.append(row.rstrip())
    return "\n".join(out)


def ir_to_text(ir: DocumentIR) -> str:
    """The document's words in reading order; pages separated by ``\\f``."""
    return PAGE_BREAK.join(page_text(page) for page in ir.pages) + "\n"


def ir_to_layout_text(ir: DocumentIR) -> str:
    """Every page's lines on their visual rows and columns; pages separated by ``\\f``."""
    return PAGE_BREAK.join(page_layout_text(page) for page in ir.pages) + "\n"


__all__ = ["PAGE_BREAK", "ir_to_layout_text", "ir_to_text", "page_layout_text", "page_text"]
