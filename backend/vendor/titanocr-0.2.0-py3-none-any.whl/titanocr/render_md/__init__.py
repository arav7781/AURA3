"""Deterministic IR -> Markdown projection; depends only on titanocr.ir (phase 07).

Markdown is a display/debug artifact — never the extraction source (ADR 0001 §1,
CLAUDE.md hard rule 4). The renderer version is stamped into each document's
``meta.json`` by the orchestrator, not into the IR.
"""

from titanocr.render_md.render import (
    BLOCK_ANCHOR_RE,
    BLOCK_GEOMETRY_RE,
    BLOCK_GRID_RE,
    BLOCK_LAYOUT_RE,
    BLOCK_PATH_RE,
    CONNECTOR_MARKER,
    FIGURE_MARKER,
    FORMULA_FENCE,
    RENDERER_VERSION,
    ROW_GEOMETRY_RE,
    SIGNATURE_MARKER,
    TABLE_FAILED_MARKER,
    TABLE_PENDING_MARKER,
    RenderOptions,
    block_anchor,
    block_geometry,
    block_grid,
    block_path,
    ir_to_markdown,
    row_geometry,
)

__all__ = [
    "BLOCK_ANCHOR_RE",
    "BLOCK_GEOMETRY_RE",
    "BLOCK_GRID_RE",
    "BLOCK_LAYOUT_RE",
    "BLOCK_PATH_RE",
    "CONNECTOR_MARKER",
    "FIGURE_MARKER",
    "FORMULA_FENCE",
    "RENDERER_VERSION",
    "ROW_GEOMETRY_RE",
    "SIGNATURE_MARKER",
    "TABLE_FAILED_MARKER",
    "TABLE_PENDING_MARKER",
    "RenderOptions",
    "block_anchor",
    "block_geometry",
    "block_grid",
    "block_path",
    "ir_to_markdown",
    "row_geometry",
]
