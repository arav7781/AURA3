"""FastAPI application: lifespan wiring for settings, pipelines, jobs and the orchestrator.

Startup loads and validates every pipeline YAML in ``OCR_PIPELINE_DIR`` via
``stages.load_pipeline``, then resolves the stages the v1 orchestrator actually
runs (``pdftext``/``rasterize`` — phase 06) against the engine registry. A broken
config never reaches a production document: the app still starts (so probes can
answer) but the error is recorded, the pipeline is not served, and ``/readyz``
reports 503 with the pointed detail until it is fixed (docs/08, hard rule 9).
Shutdown is a graceful drain: new submissions get 503, the orchestrator finishes
in-flight and queued work, artifacts are flushed, then the process exits — the
groundwork phases 08/14 build on.
"""

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.responses import Response
from starlette.types import Scope

import titanocr.engines  # noqa: F401 — registers engines # pyright: ignore[reportUnusedImport]
from titanocr.api.artifacts import ArtifactStore
from titanocr.api.demo import router as demo_router
from titanocr.api.escalation import build_escalation_runtime
from titanocr.api.jobs import JobManager
from titanocr.api.models_check import verify_models
from titanocr.api.obs import configure_logging, install_request_logging
from titanocr.api.orchestrator import Orchestrator
from titanocr.api.pool import WorkerPool
from titanocr.api.routes import router
from titanocr.api.signals_log import SignalsLog
from titanocr.settings import Settings
from titanocr.stages import (
    DEFAULT_REGISTRY,
    STAGE_TO_KIND,
    PipelineConfig,
    PipelineConfigError,
    ResolvedPipeline,
    load_pipeline,
    resolve,
)

logger = logging.getLogger("titanocr.main")

ORCHESTRATOR_STAGES = ("pdftext", "rasterize", "prep")
"""The stages resolved (= config-validated) at startup: pdftext/rasterize run in
the orchestrator itself; prep runs inside pool workers (phase 08) but its config
must fail readiness here, never a production document (hard rule 9)."""

OCR_STAGES = ("detect", "recognize", "layout", "table", "triage", "escalate")
"""Phase-09/10/12/13 stages, validated at startup with a twist: an engine name
nothing has registered stays *informational* (``missing_engines`` in /readyz —
the phase-06 convention for future-phase engines), but a **registered** engine
that fails to construct (missing model file, bad param) is a hard readiness
failure. Model checksums are then verified separately. ``triage`` and
``escalate`` resolve here because the parent orchestrator runs them (phases
12/13) — a bad threshold or a malformed price table must fail readiness, never
a document."""

STATIC_DIR = Path(__file__).resolve().parent / "static"
"""The demo UI: vanilla JS + vendored marked.min.js, no build step, no CDN (plan §10)."""


class _RevalidatingStatic(StaticFiles):
    """Static files that must be revalidated, never served blind from cache.

    There is no build step and therefore no content-hashed filenames: ``app.js``
    is always ``app.js``. Starlette sends ``etag``/``last-modified`` but no
    ``Cache-Control``, which lets a browser apply *heuristic* freshness and keep
    serving a stale bundle after the file on disk has changed — the UI then
    silently runs old code, which looks exactly like a broken feature.

    ``no-cache`` does not mean "do not store": the browser still caches and still
    sends ``If-None-Match``, so an unchanged asset costs one 304. It only removes
    the browser's licence to skip that check.
    """

    async def get_response(self, path: str, scope: Scope) -> Response:
        response = await super().get_response(path, scope)
        response.headers["Cache-Control"] = "no-cache, must-revalidate"
        return response


def _load_pipelines(settings: Settings) -> tuple[dict[str, PipelineConfig], list[str]]:
    configs: dict[str, PipelineConfig] = {}
    errors: list[str] = []
    paths = sorted(
        p for pattern in ("*.yaml", "*.yml") for p in settings.pipeline_dir.glob(pattern)
    )
    for path in paths:
        try:
            config = load_pipeline(path)
        except PipelineConfigError as exc:
            errors.append(str(exc))
            continue
        configs[config.name] = config
    return configs, errors


def _resolve_pipelines(
    configs: dict[str, PipelineConfig], errors: list[str]
) -> dict[str, ResolvedPipeline]:
    """Resolve the orchestrator stages per pipeline; failures drop the pipeline
    from service and fail readiness (hard rule 9 — never a production document)."""
    resolved: dict[str, ResolvedPipeline] = {}
    for name, config in list(configs.items()):
        missing = [key for key in ORCHESTRATOR_STAGES if key not in config.stages]
        if missing:
            errors.append(
                f"{config.source}: missing required stage(s) for the v1 orchestrator: "
                f"{', '.join(missing)}"
            )
            del configs[name]
            continue
        try:
            pipeline = resolve(config, only=ORCHESTRATOR_STAGES)
        except PipelineConfigError as exc:
            errors.append(str(exc))
            del configs[name]
            continue
        stages = dict(pipeline.stages)
        ocr_keys = [
            key
            for key in OCR_STAGES
            if key in config.stages
            and config.stages[key].engine in DEFAULT_REGISTRY.names(STAGE_TO_KIND[key])
        ]
        if ocr_keys:
            try:
                ocr_pipeline = resolve(config, only=ocr_keys)
            except PipelineConfigError as exc:
                errors.append(str(exc))
                del configs[name]
                continue
            stages.update(ocr_pipeline.stages)
        resolved[f"{config.name}@{config.version}"] = ResolvedPipeline(
            pipeline_version=pipeline.pipeline_version, stages=stages, doc_types=config.doc_types
        )
    return resolved


@asynccontextmanager
async def _lifespan(app: FastAPI) -> AsyncGenerator[None]:
    settings: Settings = app.state.settings
    configure_logging(settings.log_level)
    logger.info("settings loaded", extra=settings.redacted())

    configs, errors = _load_pipelines(settings)
    resolved = _resolve_pipelines(configs, errors)
    # Phase 09: checksum every model a served pipeline references against the
    # manifest — a tampered or missing model fails readiness, loudly. Kept
    # separate from the config errors so /readyz can name *which* check failed
    # (phase 14 §4.3), and run once here, never per probe.
    model_errors = verify_models(resolved, settings.models_dir)
    for error in (*errors, *model_errors):
        logger.error("startup self-check failed — readiness will fail", extra={"error": error})
    logger.info(
        "pipelines loaded",
        extra={"pipelines": sorted(f"{c.name}@{c.version}" for c in configs.values())},
    )
    app.state.pipelines = configs
    app.state.pipeline_errors = errors
    app.state.model_errors = model_errors

    store = ArtifactStore(settings.artifacts_dir)
    try:
        store.ensure_root()
    except OSError as exc:
        # Recorded, not fatal: /readyz re-probes writability and reports 503.
        logger.error("artifacts dir unavailable", extra={"error": str(exc)})
    app.state.store = store

    jobs = JobManager(queue_max=settings.queue_max)
    app.state.jobs = jobs

    # Worker pool (phase 08): pre-forked spawn workers, pinned + warmed;
    # /readyz stays 503 until every worker has posted ready (docs/07).
    pool: WorkerPool | None = None
    if resolved:
        pool = WorkerPool(
            workers=settings.workers,
            pipeline_dir=settings.pipeline_dir,
            models_dir=settings.models_dir,
            artifacts_dir=settings.artifacts_dir,
            fixtures_dir=settings.fixtures_dir,
            jobs=jobs,
        )
        pool.start()
    app.state.pool = pool

    # Stage 5 runtime (phase 13): the provider client + the process-wide circuit
    # breaker, built from env. No key → escalation records its decisions and
    # skips every call; the service starts and serves regardless (plan P5).
    # ``vlm_transport`` is the test seam — a fake provider, never set in production.
    escalation = build_escalation_runtime(
        settings, transport=getattr(app.state, "vlm_transport", None)
    )
    app.state.escalation = escalation
    # A pipeline that *declares* escalation without an endpoint is a config
    # error, not a silent skip (hard rule 9, ADR 0023): escalation is opt-in, so
    # asking for it and not configuring it can only be a mistake. A provider
    # that is configured and *down* still degrades documents instead (docs/07).
    if not escalation.enabled:
        declared = sorted(
            f"{config.name}@{config.version}"
            for config in configs.values()
            if "escalate" in config.stages
        )
        if declared:
            errors.append(
                f"pipeline(s) {', '.join(declared)} declare an 'escalate' stage but no VLM "
                f"endpoint is configured ({escalation.disabled_reason}) — set OCR_VLM_BASE_URL, "
                "OCR_VLM_MODEL and OCR_VLM_API_KEY, or run a pipeline without the stage "
                "(pipelines/default.yaml)"
            )
            logger.error(
                "startup self-check failed — readiness will fail", extra={"error": errors[-1]}
            )
            app.state.pipeline_errors = errors

    orchestrator = Orchestrator(
        jobs,
        store,
        resolved=resolved,
        pool=pool,
        doc_deadline_s=settings.doc_deadline_s,
        signals_log=SignalsLog(settings.signals_dir),
        escalation=escalation,
    )
    app.state.orchestrator = orchestrator
    orchestrator.start()
    app.state.draining = False

    try:
        yield
    finally:
        app.state.draining = True
        logger.info("shutdown: draining in-flight jobs")
        await orchestrator.drain()
        if pool is not None:
            await pool.shutdown()
        await escalation.aclose()
        logger.info("shutdown complete")


def create_app(settings: Settings | None = None) -> FastAPI:
    app = FastAPI(title="TitanOCR", version="v1", lifespan=_lifespan)
    app.state.settings = settings if settings is not None else Settings()
    app.state.draining = True  # flips to False once the lifespan has started the orchestrator
    app.state.pipelines = {}
    app.state.pipeline_errors = []
    app.state.model_errors = []
    app.state.pool = None
    app.state.escalation = None
    install_request_logging(app)
    app.include_router(router)
    # Samples routes must register before the /demo mount so they win route matching.
    app.include_router(demo_router)
    app.mount("/demo", _RevalidatingStatic(directory=STATIC_DIR, html=True), name="demo")
    return app


app = create_app()

__all__ = ["app", "create_app"]
